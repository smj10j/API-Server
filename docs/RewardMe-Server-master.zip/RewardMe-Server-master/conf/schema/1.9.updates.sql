
-- 6/2 --

alter table customer_invoice drop paid;
alter table customer_invoice drop due_time;
alter table customer_invoice add paid_date timestamp not null;
alter table customer_invoice add due_date timestamp not null;
alter table user add column `pin_code` char(32) DEFAULT NULL;

-- 6/2 --

drop table if exists device_application;
CREATE TABLE `device_application` (
  `device_application_id` int(11) unsigned not null AUTO_INCREMENT,
  `device_id` char(64) NOT NULL,
  `type` enum('KIOSK','COUNTER_SERVICE_LOYALTY','AD_NETWORK','TABLE_SERVICE_WAITING_LIST') NOT NULL,
  `url` varchar(255) NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `checkin_option_id` int(11) unsigned DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`device_application_id`),
  UNIQUE KEY (`device_id`),
  KEY `customer_id_address_id` (`customer_id`,`address_id`)
) ENGINE=InnoDB CHARSET=utf8;

-- 6/7 --

drop table if exists device_link;
CREATE TABLE `device_link` (
  `device_link_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `device1_id` char(64) NOT NULL,
  `device2_id` char(64) NOT NULL,
  `server_id` int(11) unsigned NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`device_link_id`),
  UNIQUE KEY `device1_id_to_device2_id` (`device1_id`,`device2_id`),
  KEY `device2_id` (`device2_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 6/13 --
alter table reward add column `image_url` varchar(255) DEFAULT NULL;
alter table reward add column `image_url_small` varchar(255) DEFAULT NULL;

-- 6/16 -- 
ALTER TABLE address ADD facebook_id varchar(32) DEFAULT NULL AFTER yelp_data;

-- 6/17 --

drop table if exists event;
CREATE TABLE `event` (
  `event_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `customer_id` int(11) unsigned DEFAULT NULL,
  `address_id` int(11) unsigned DEFAULT NULL,
  `name` varchar(64) NOT NULL,
  `value` varchar(64) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `admin` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`event_id`),
  KEY `customer_id` (`customer_id`,`admin`,`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

drop table if exists event_trigger;
CREATE TABLE `event_trigger` (
  `event_trigger_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned DEFAULT NULL,
  `event_name` varchar(64) NOT NULL,
  `event_value` varchar(64) NOT NULL,
  `type` enum('USER_MESSAGE') NOT NULL,
  `type_id` int(11) unsigned NOT NULL,
  `triggered` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `event_hash` varchar(64) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`event_trigger_id`),
  KEY `triggered_event_hash` (`triggered`,`event_hash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 6/21 --
ALTER TABLE address ADD twitter_id varchar(32) DEFAULT NULL AFTER facebook_id;
ALTER TABLE address ADD foursquare_id varchar(32) DEFAULT NULL AFTER twitter_id;

-- 6/23 --
drop table if exists customer_preference;
CREATE TABLE `customer_preference` (
  `customer_preference_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `name` varchar(128) NOT NULL,
  `value` varchar(1024) DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `address_id` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`customer_preference_id`),
  UNIQUE KEY `customer_id_address_id_name` (`customer_id`, `address_id`, `name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 6/27 --
ALTER TABLE address DROP facebook_id;
ALTER TABLE address DROP twitter_id;
ALTER TABLE address DROP foursquare_id;

-- 6/27 --
alter table user_points_history change column type type enum('CHECKIN','REFERRAL','REDEEM','GIFT','SOCIAL','PROMOTIONAL','INCENTIVE','CHEATING') NOT NULL;

-- 7/5 --
drop table if exists survey;
CREATE TABLE `survey` (
  `survey_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `content` varchar(1024) NOT NULL,
  `available_on_mobile` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `able_to_show_results` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`survey_id`),
  KEY `customer_id_enabled` (`customer_id`, `enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists user_survey;
CREATE TABLE `user_survey` (
  `user_survey_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `survey_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned DEFAULT NULL,
  `response` varchar(255) DEFAULT NULL,
  `sent` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_survey_id`),
  KEY `user_id_created` (`user_id`, `created`),
  KEY `survey_id_response` (`survey_id`, `response`),
  UNIQUE KEY `user_id_survey_id` (`user_id`, `survey_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 7/14 --
drop table if exists session;
CREATE TABLE `session` (
  `session_id` int(11) unsigned NOT NULL auto_increment,
  `user_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned default NULL,
  `created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`session_id`),
  UNIQUE KEY `user_id_customer_id_address_id_created` (`user_id`,`customer_id`,`address_id`,`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists warehouse_session;
CREATE TABLE `warehouse_session` (
  `warehouse_session_id` int(11) unsigned NOT NULL auto_increment,
  `session_id` int(11) unsigned NOT NULL,
  `data` mediumblob COMMENT 'map of clazz to object that stores all things linked to session',
  `updated` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`warehouse_session_id`),
  UNIQUE KEY `session_id` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 7/15 --
drop table if exists user_social_checkin;
CREATE TABLE `user_social_checkin` (
  `user_social_checkin_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `type` enum('facebook','foursquare','twitter') NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_social_checkin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 7/27 --
--alter table reward change column `type` `type` enum('FREE','DISCOUNT','SPECIAL_OFFER','VIP') NOT NULL;

-- 8/3 --

drop table if exists admin_secret_key;
CREATE TABLE `admin_secret_key` (
  `admin_secret_key_id` int(11) unsigned NOT NULL auto_increment,
  `secret_key` char(64) NOT NULL,
  `created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`admin_secret_key_id`),
  UNIQUE KEY `secret_key` (`secret_key`)  
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into admin_secret_key(secret_key) VALUES ("V7Kb7pn9XFJmstu3Dv9naNMxQKMdjexAaxpCNG6n-tablet"),
("439A_(f0495h[_S8G[08h4-82pG{h324*0g0mda2-notifier"),
("paf09820n79adgnn23nag923m0agdsf]p]23aw3y-steve"),
("m-2cm[enm,c3yk]kac4[][2qca[893y75AZ;p8a3-patrick"),
("P(79to876dsp[4238[a(*p97289q[0q8243t7jnc-gerald"),
("54908()$98a4ymc4yq9p793wp6742pnvjp328qp3-webadmin"),
("AP(79gp984332qp9g9gfpn892&P$9832120gagh/-myrewardme"),
("62458(84594gkjhk;43&P56679g,i9646534(*3/-junit"),
("7562h3k(6805780bfnn9;;43&09jDSG5t343a*3/-demos"),
("I1pJr1SznkmmVrNaVBOQQhnw4BKiYmMpGDJxrIyx-appedit"),
("asd;(&432;hiag;kl2d93kdp83ikoszlfn37qaifl-push");

alter table event add column `admin_secret_key_id` int(11) unsigned DEFAULT NULL;
alter table event add key secret_key_name (`admin_secret_key_id`,`name`);

-- 8/5 --
truncate customer_feature;

drop table if exists warehouse_event_descriptor;
CREATE TABLE `warehouse_event_descriptor` (
  `warehouse_event_descriptor_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `dimensions` mediumblob,
  `facts` mediumblob,
  `filling` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`warehouse_event_descriptor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 8/7 --
drop table if exists peripheral;
CREATE TABLE `peripheral` (
  `peripheral_id` int(11) unsigned not null AUTO_INCREMENT,
  `external_peripheral_id` varchar(64) NOT NULL,
  `type` enum('SAVERMINT') NOT NULL,
  `device_application_id` int(11) unsigned NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`peripheral_id`),
  UNIQUE KEY (`external_peripheral_id`),
  KEY `type_created` (`type`,`created`)
) ENGINE=InnoDB CHARSET=utf8;

-- 8/8 --

drop table if exists application;
CREATE TABLE `application` (
  `application_id` int(11) unsigned not null AUTO_INCREMENT,
  `type` enum('KIOSK','COUNTER_SERVICE_LOYALTY','AD_NETWORK','TABLE_SERVICE_WAITING_LIST') NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `archived` tinyint(1) unsigned NOT NULL default 0,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`application_id`),
  KEY `customer_id_archived_type_name` (`customer_id`,`archived`,`type`,`name`)
) ENGINE=InnoDB CHARSET=utf8;

alter table device_application drop column type;
alter table device_application drop column customer_id;
alter table device_application drop column url;
alter table device_application add column application_id int(11) unsigned not null after device_id;

-- 8/9 --
alter table admin_secret_key drop column type;
alter table admin_secret_key add column type enum('EVERYTHING','API','PUSH') not null after secret_key;
update admin_secret_key set type='EVERYTHING';

insert into admin_secret_key(secret_key,type) VALUES ("5724ALJK-423yt089h(97832p9g98198-A_37gg13-poshero",'PUSH');

rename table admin_secret_key to secret_key;
alter table secret_key change column admin_secret_key_id secret_key_id int(11) unsigned NOT NULL auto_increment;
alter table secret_key drop key secret_key;
alter table secret_key add key (type,secret_key);

-- 8/10 --
alter table customer add column subdomain varchar(32) not null after name;	
update customer set subdomain=api_key;

alter table event change column admin_secret_key_id secret_key_id int(11) unsigned default null;

-- 8/11 --
 insert into secret_key(secret_key,type) VALUES ("AS:KL43kljads:LKAh23;aalskh408(&2029740as;Aga-printer",'EVERYTHING');
 
-- 8/17 --
drop table if exists application_observation;
CREATE TABLE `application_observation` (
  `application_observation_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `application_id` int(11) unsigned NOT NULL,
  `observations_instance_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned DEFAULT NULL,
  `module` varchar(64) DEFAULT NULL,
  `element` varchar(64) DEFAULT NULL,
  `action` varchar(64) DEFAULT NULL,
  `data` varchar(64) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`application_observation_id`),
  KEY `application_id` (`application_id`,`observations_instance_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 8/30 --
drop table if exists user_message_NEW;
CREATE TABLE `user_message_NEW` (
  `user_message_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `message` varchar(512) DEFAULT NULL,
  `sent` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `timestamp` timestamp DEFAULT '0000-00-00 00:00:00',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_message_id`),
  KEY `customer_id_user_id_created` (`customer_id`,`user_id`,`created`),
  KEY `user_id_created` (`user_id`,`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 9/1 --
alter table user_points_history change column `type` `type` enum('CHECKIN','REFERRAL','REDEEM','GIFT','SOCIAL','PROMOTIONAL','INCENTIVE','CHEATING','TRANSFER') NOT NULL;

-- 9/15 --
alter table employee add column `address_id` int(11) unsigned NOT NULL after `customer_id`;
alter table employee drop key external_employee_id;
alter table employee add unique key external_employee_id (customer_id, address_id, external_employee_id);

alter table pos_tx drop key external_pos_tx_id;
alter table pos_tx add unique key external_pos_tx_id (customer_id, address_id, external_pos_tx_id);

-- 9/16 --
alter table application change column type `type` enum('KIOSK','COUNTER_SERVICE_LOYALTY','COUNTER_SERVICE_LOYALTY_EMPLOYEE_FACING','AD_NETWORK','TABLE_SERVICE_WAITING_LIST') NOT NULL;

-- 9/20 --
alter table pos_tx change column user_id `user_id` int(11) unsigned DEFAULT NULL;

-- 10/12 --
alter table pos_inventory_item add column kitchen_item_name varchar(64) DEFAULT NULL after `external_pos_inventory_item_id`;
alter table pos_inventory_item add UNIQUE KEY `kitchen_item_name` (`customer_id`,`kitchen_item_name`);
alter table pos_inventory_item_mod add column kitchen_item_name varchar(64) DEFAULT NULL after `external_pos_inventory_item_mod_id`;
alter table pos_inventory_item_mod add UNIQUE KEY `kitchen_item_name` (`customer_id`,`kitchen_item_name`);
