
drop table if exists npa_nxx_to_zipcode;
CREATE TABLE `npa_nxx_to_zipcode` (
  `npa_nxx_to_zipcode_id` int(11) unsigned not null AUTO_INCREMENT,
  `npa_nxx` int(6) NOT NULL,
  `city` varchar(64) NOT NULL,
  `county` varchar(32) NOT NULL,
  `zipcode` int(11) NOT NULL,
  `state` char(2) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`npa_nxx_to_zipcode_id`),
  UNIQUE KEY (`npa_nxx`)
) ENGINE=InnoDB CHARSET=utf8;

drop table if exists zipcode_demographics;
CREATE TABLE `zipcode_demographics` (
  `zipcode` int(11) unsigned not null,
  `households` int(11) NOT NULL,
  `population` int(11) NOT NULL,
  `population_white` int(11) NOT NULL,
  `population_black` int(11) NOT NULL,
  `population_hispanic` int(11) NOT NULL,
  `population_asian` int(11) NOT NULL,
  `population_hawaiian` int(11) NOT NULL,
  `population_indian` int(11) NOT NULL,
  `population_other` int(11) NOT NULL,
  `population_male` int(11) NOT NULL,
  `population_female` int(11) NOT NULL,
  `persons_per_household` decimal(4,2) NOT NULL,
  `average_house_value` int(11) NOT NULL,
  `average_income_per_household` int(11) NOT NULL,
  `median_age` decimal(4,1) NOT NULL,
  `median_age_male` decimal(4,1) NOT NULL,
  `median_age_female` decimal(4,1) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`zipcode`)
) ENGINE=InnoDB CHARSET=utf8;

alter table user add column npa_nxx int(6) default null after phone_number;
alter table user add key(npa_nxx);
update user set npa_nxx=substring(phone_number,3,6) where phone_number is not null;

drop table if exists report;
CREATE TABLE `report` (
  `report_id` int(11) unsigned not null AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `group_name` varchar(128) NOT NULL,
  `description` varchar(512) NOT NULL,
  `definition` varchar(2048) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`report_id`)
) ENGINE=InnoDB CHARSET=utf8;

alter table user_points_summary add column `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00';
update user_points_summary set created=updated;

alter table event add column `device_id` char(64) DEFAULT NULL;
alter table user add column `mobile` tinyint(1) unsigned NOT NULL DEFAULT 1;


drop table if exists pos_receipt;
CREATE TABLE `pos_receipt` (
  `pos_receipt_id` int(11) unsigned not null AUTO_INCREMENT,
  `pos_tx_id` int(11) unsigned not null,
  `raw_data` blob NOT NULL,
  `ascii_data` blob NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`pos_receipt_id`),
  UNIQUE KEY (`pos_tx_id`)
) ENGINE=InnoDB CHARSET=utf8;

alter table pos_tx add column payment_method enum('CREDIT','CHECK','CASH','GIFT_CARD','HOUSE_TAB','MOBILE','BARTER','UNKNOWN') not null default 'UNKNOWN' after amount_less_tax_and_discount;

alter table pos_tx change column payment_method `payment_method` enum('CREDIT','CHECK','CASH','GIFT_CARD','HOUSE_TAB','MOBILE','BARTER','DEBIT','UNKNOWN') NOT NULL DEFAULT 'UNKNOWN';

drop table if exists rating;
CREATE TABLE `rating` (
  `rating_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_tx_id` int(11) unsigned NOT NULL,
  `score` int(11) unsigned NOT NULL,
  `data` varchar(256) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`rating_id`),
  UNIQUE KEY `pos_tx_id` (`pos_tx_id`),
  KEY `score` (`score`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




drop table if exists point_category;
CREATE TABLE `point_category` (
  `point_category_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `name` varchar(128) NOT NULL DEFAULT 'Points',
  `weight` int(11) unsigned NOT NULL DEFAULT 0 comment 'weight=0 says points of this type cannot be converted to others',
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`point_category_id`),
  UNIQUE KEY `customer_id_name` (`customer_id`, `name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `user_points_summary_temp` (
  `user_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `point_category_id` int(11) unsigned NOT NULL DEFAULT 0,
  `earned_balance` int(11) unsigned NOT NULL,
  `current_balance` int(11) unsigned NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_id`,`customer_id`, `point_category_id`),
  KEY `customer_id` (`customer_id`,`earned_balance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into user_points_summary_temp (user_id,customer_id,earned_balance,current_balance,updated,created) (select user_id,customer_id,earned_balance,current_balance,updated,created from user_points_summary);
drop table user_points_summary;
rename table user_points_summary_temp to user_points_summary;

alter table user_points_history add column point_category_id int(11) unsigned NOT NULL DEFAULT 0 after `customer_id`;

alter table checkin_option add column point_category_id int(11) unsigned NOT NULL DEFAULT 0 after `checkin_option_id`;
alter table reward add column point_category_id int(11) unsigned NOT NULL DEFAULT 0 after `reward_id`;


alter table user_checkin add column device_application_id int(11) unsigned DEFAULT 0 after checkin_option_id;
alter table application_observation add column device_application_id int(11) unsigned DEFAULT 0 after application_id;
alter table user_points_history add column address_id int(11) unsigned DEFAULT 0 after customer_id;


drop table if exists event_trigger;
 CREATE TABLE `event_trigger` (
  `event_trigger_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned DEFAULT NULL,
  `event_name` varchar(64) NOT NULL,
  `event_value` varchar(64) DEFAULT NULL,
  `event_hash` varchar(64) NOT NULL,
  `type` enum('DELETE_EVENT_TRIGGER','DELETE_SCHEDULED_TRIGGER','DELETE_USER_MESSAGE','API_REQUEST','URL_CALLBACK') NOT NULL,
  `type_id` int(11) unsigned DEFAULT NULL,
  `data` varchar(755) DEFAULT NULL,
  `triggered` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`event_trigger_id`),
  KEY `triggered_event_hash` (`triggered`,`event_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists scheduled_trigger;
 CREATE TABLE `scheduled_trigger` (
  `scheduled_trigger_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned DEFAULT NULL,
  `type` enum('DELETE_EVENT_TRIGGER','DELETE_SCHEDULED_TRIGGER','DELETE_USER_MESSAGE','API_REQUEST','URL_CALLBACK') NOT NULL,
  `type_id` int(11) unsigned DEFAULT NULL,
  `data` varchar(755) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `triggered` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`scheduled_trigger_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



delete up1.* from user_preference up1,user_preference up2 where up1.user_preference_id>up2.user_preference_id and up1.user_id=up2.user_id and up1.customer_id is null and up1.name=up2.name;
alter table user_preference change column customer_id customer_id int(11) unsigned not null default 0;
alter table customer_preference change column address_id address_id int(11) unsigned not null default 0;



alter table customer add column auth_code char(8) DEFAULT null after subdomain;
alter table customer add column user_id int(11) unsigned DEFAULT null after auth_code;
update customer set auth_code='123456';


drop table if exists calendar;
CREATE TABLE `calendar` (
  `calendar_id` int(11) unsigned not null AUTO_INCREMENT,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`calendar_id`),
  UNIQUE KEY (`created`)
) ENGINE=InnoDB CHARSET=utf8;
insert ignore into calendar (created) (select created from user_checkin group by date(created));

drop table if exists unlinked_device_application;
CREATE TABLE `unlinked_device_application` (
  `unlinked_device_application_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `application_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `checkin_option_id` int(11) unsigned DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`unlinked_device_application_id`),
  KEY `application_id` (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


drop table if exists scheduled_trigger;
 CREATE TABLE `scheduled_trigger` (
  `scheduled_trigger_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned DEFAULT NULL,
  `type` enum('DELETE_EVENT_TRIGGER','DELETE_SCHEDULED_TRIGGER','DELETE_USER_MESSAGE','API_REQUEST','URL_CALLBACK') NOT NULL,
  `type_id` int(11) unsigned DEFAULT NULL,
  `data` varchar(755) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `triggered` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`scheduled_trigger_id`)

drop table if exists lottery;
CREATE TABLE `lottery` (
	`lottery_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
	`customer_id` int(11) unsigned NOT NULL,
	`reward_id` int(11) unsigned NOT NULL,
  `number_of_prizes` int(11) unsigned NOT NULL,
  `percent_chance` decimal(5,3) NOT NULL COMMENT 'e.g. 25.322', 
	`updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
	PRIMARY KEY (`lottery_id`),
	KEY `customer_id_created` (`customer_id`, `created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists lottery_winners;
CREATE TABLE `lottery_winners` (
  `lottery_winners_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `lottery_id` int(11) unsigned NOT NULL,
	`created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,  
  PRIMARY KEY (`lottery_winners_id`),
  KEY `lottery_id_user_id_created` (`lottery_id`, `user_id`, `created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists segment;
CREATE TABLE `segment` (
  `segment_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned DEFAULT NULL,
  `name` varchar(64) NOT NULL,
  `description` varchar(512) NOT NULL,
  `definition` varchar(2048) NOT NULL,
  `archived` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`segment_id`),
  KEY customer_id_address_id (`customer_id`,`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists segment_to_user;
CREATE TABLE `segment_to_user` (
  `segment_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`segment_id`,`user_id`),
  KEY segment_id_user_id (`segment_id`, `user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists cardspring_transaction;
CREATE TABLE `cardspring_transaction` (
  `cardspring_transaction_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `event_type` enum("authorization","settlement") NOT NULL,
  `amount` decimal(8, 2) not null,
  `currency` varchar(200) NOT NULL,
  `purchase_time` date NOT NULL,
  `created` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE customer ADD COLUMN cardspring_business_id varchar(200) default null after subdomain;

ALTER TABLE address ADD COLUMN cardspring_store_id varchar(200) default null after address;






alter table event_trigger add column archived tinyint(1) unsigned default 0 after triggered;
alter table scheduled_trigger add column archived tinyint(1) unsigned default 0 after triggered;

alter table event_trigger drop KEY `triggered_event_hash`;
alter table event_trigger add KEY `triggered_event_hash` (`archived`,`triggered`,`event_hash`);


drop table if exists ab_cohort;
CREATE TABLE `ab_cohort` (
  `ab_test_id` int(11) unsigned NOT NULL,
  `display_cohort_id` int(11) unsigned NOT NULL,
  `ab_cohort_id` int(11) unsigned NOT NULL DEFAULT '0',
  `successes` int(11) unsigned NOT NULL,
  `views` int(11) unsigned NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`ab_cohort_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8; 

drop table if exists ab_cohort_link;
CREATE TABLE `ab_cohort_link` (
  `ab_test_id` int(11) unsigned NOT NULL,
  `ab_cohort_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists ab_test;
CREATE TABLE `ab_test` (
  `ab_test_id` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(500) DEFAULT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`ab_test_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

alter table customer add column stripe_customer_id varchar(200) after cardspring_business_id;
