alter table barcode change column type usage_type enum('STANDARD','ONCE_PER_USER') default 'STANDARD' not null;
alter table barcode add column action_type enum('ADDRESS','REWARD') default 'ADDRESS' not null;

create table barcode_to_reward (
	barcode_id int(11) unsigned not null,	
	reward_id int(11) unsigned not null,
	created timestamp default current_timestamp not null,
	primary key(barcode_id,reward_id),
	key(reward_id)
)engine=innodb default charset=utf8;

create table user_to_barcode (
	user_barcode_id int(11) unsigned not null auto_increment primary key,
	user_id int(11) unsigned not null,
	customer_id int(11) unsigned not null,
	barcode_id int(11) unsigned not null,
	created timestamp default current_timestamp not null,
	key(user_id, customer_id, barcode_id),
	key(user_id, barcode_id)
)engine=innodb default charset=utf8;
