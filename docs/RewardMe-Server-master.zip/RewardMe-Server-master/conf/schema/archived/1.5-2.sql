drop table if exists address_metadata;
create table address_metadata (
	address_metadata_id int(11) unsigned not null auto_increment primary key,
	address_id int(11) unsigned not null,
	provider enum('YELP') not null default 'YELP',
	provider_id varchar(64) default null,
	provider_link varchar(255) default null,
	name varchar(128) not null,
	category varchar(64) default null,
	image_url varchar(255) default null,
	image_url_small varchar(255) default null,
	rating_url varchar(255) default null,
	phone_number varchar(12) default null,
	total_reviews int(11) unsigned default null,
	created timestamp not null,
	unique key(address_id, provider),
	key(name),
	key(category)
)engine=innodb default charset=utf8;

alter table address drop column yelp_data;

alter table device add column api_version char(8) default null;

alter table barcode change column data data varchar(255) NOT NULL;
alter table barcode drop key data;
alter table barcode add UNIQUE KEY `data` (`data`(32)