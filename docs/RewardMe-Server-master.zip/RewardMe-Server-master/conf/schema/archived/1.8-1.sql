
-- leaderboards --
ALTER TABLE user_points_summary ADD index (customer_id, earned_balance);
ALTER TABLE user_checkin ADD index (address_id,user_id);