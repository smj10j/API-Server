drop table if exists customer_billing;
create table customer_billing (
	customer_billing_id int(11) unsigned not null auto_increment primary key,
	customer_id int(11) unsigned not null,
	name varchar(64) not null,
	amount decimal(10,2) unsigned not null default 0,
	created timestamp default current_timestamp not null,
	unique key(customer_id)
)engine=innodb default charset=utf8;

drop table if exists customer_billing_history;
create table customer_billing_history (
	customer_billing_history_id int(11) unsigned not null auto_increment primary key,
	customer_id int(11) unsigned not null,
	amount decimal(10,2) unsigned not null default 0,
	created timestamp default current_timestamp not null,
	unique key(customer_id,created)
)engine=innodb default charset=utf8;