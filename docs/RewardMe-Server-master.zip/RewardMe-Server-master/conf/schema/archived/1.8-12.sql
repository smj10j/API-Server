alter table user_message drop key recipient_id;
alter table user_message add key(recipient_id,viewed,created);
alter table user_message add key(recipient_id,created);