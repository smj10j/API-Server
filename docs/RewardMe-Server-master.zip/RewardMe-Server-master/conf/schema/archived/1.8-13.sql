alter table user_referral add key(referrer_id);
alter table user_referral_request add key(referrer_id);
alter table user_message add key(sender_id);
