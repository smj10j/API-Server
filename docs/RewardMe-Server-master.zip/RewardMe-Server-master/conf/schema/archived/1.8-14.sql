alter table user_referral_request add column responded tinyint(1) unsigned not null default 0;
