
-- referrals --
alter table user add column username varchar(64) default null;
update user set username=user_id;
alter table user add unique key username (username(16));
