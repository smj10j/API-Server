
-- one-off qr codes in store --
alter table barcode change column usage_type `usage_type` enum('STANDARD','ONCE_PER_USER','ONLY_BEFORE_FIRST_CHECKIN') NOT NULL DEFAULT 'STANDARD';

-- fix for address metadata defaults --
alter table address_metadata change column total_reviews total_reviews int(11) unsigned not null default 0;
