
-- broadcast messages -- 
drop table if exists customer_broadcast_message;
create table customer_broadcast_message (
	customer_broadcast_message_id int(11) unsigned not null auto_increment primary key,
	customer_id int(11) unsigned not null,
	message varchar(512) default null,
	longitude_radians decimal(10,9) default null,
	latitude_radians decimal(10,9) default null,	
	radius int(11) unsigned default null comment 'if radius is null, then all users of the customer will receive the broadcast',
	push tinyint(1) unsigned not null,
	enabled tinyint(1) unsigned not null default 1,
	start_time datetime default null,
	end_time datetime default null,
	created timestamp default current_timestamp not null,
	key(customer_id,start_time),
	key(enabled,latitude_radians,longitude_radians)
)engine=innodb default charset=utf8;

drop table if exists user_to_customer_broadcast_message;
create table user_to_customer_broadcast_message (
	user_to_customer_broadcast_message_id int(11) unsigned not null auto_increment primary key,
	user_id int(11) unsigned not null,
	customer_broadcast_message_id int(11) unsigned not null,
	created timestamp default current_timestamp not null,
	unique key(customer_broadcast_message_id,user_id),
	key(user_id,created)
)engine=innodb default charset=utf8;
