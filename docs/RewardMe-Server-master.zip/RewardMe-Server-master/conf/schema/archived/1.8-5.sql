
--maintain info about last known user location --
alter table user add column longitude_radians decimal(10,9) default null;
alter table user add column latitude_radians decimal(10,9) default null;
alter table user add key(latitude_radians,longitude_radians);

-- don't allow null usernames after 1.8?
-- alter table user change column username username varchar(64) not null;
