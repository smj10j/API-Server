alter table user_message add column toast tinyint(1) unsigned not null default 0;
