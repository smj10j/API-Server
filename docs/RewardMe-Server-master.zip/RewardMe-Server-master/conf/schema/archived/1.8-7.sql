
drop table if exists customer_feature;
create table customer_feature (
	customer_feature_id int(11) unsigned not null auto_increment primary key,
	customer_id int(11) unsigned not null,
	feature enum('PUSH_NOTIFICATION','ACTIVITY_NOTIFICATION') not null,
	amount int(11) unsigned not null default 0,
	created timestamp default current_timestamp not null,
	unique key(customer_id,feature),
	key(customer_id,feature,created)
)engine=innodb default charset=utf8;

drop table if exists customer_feature_usage;
create table customer_feature_usage (
	customer_feature_usage_id int(11) unsigned not null auto_increment primary key,
	customer_feature_id int(11) unsigned not null,
	created timestamp default current_timestamp not null,
	key(customer_feature_id,created)
)engine=innodb default charset=utf8;