drop table if exists pending_customer_broadcast_message;
CREATE TABLE `pending_customer_broadcast_message` (
  `pending_customer_broadcast_message_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `message` varchar(512) DEFAULT NULL,
  `longitude_radians` decimal(10,9) DEFAULT NULL,
  `latitude_radians` decimal(10,9) DEFAULT NULL,
  `radius` int(11) unsigned DEFAULT NULL COMMENT 'if radius is null, then all users of the customer will receive the broadcast',
  `push` tinyint(1) unsigned NOT NULL,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pending_customer_broadcast_message_id`),
  KEY `customer_id` (`customer_id`,`start_time`),
  KEY `enabled` (`enabled`,`latitude_radians`,`longitude_radians`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;