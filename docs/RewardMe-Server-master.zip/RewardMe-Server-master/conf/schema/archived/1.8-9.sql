
alter table customer_broadcast_message add column `number_sent` int(11) unsigned DEFAULT 0;
alter table customer_broadcast_message add column `number_viewed` int(11) unsigned DEFAULT 0;
alter table user_to_customer_broadcast_message add column `viewed` tinyint(1) unsigned NOT NULL DEFAULT '0';
alter table user_to_customer_broadcast_message add key (user_id,viewed,created);