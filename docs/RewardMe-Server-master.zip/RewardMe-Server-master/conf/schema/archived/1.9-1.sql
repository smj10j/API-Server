alter table user add column `phone_number` char(12) DEFAULT NULL;
alter table user add unique key (phone_number);
update device d1,device d2 set d1.phone_number=null where d1.device_id!=d2.device_id and d1.phone_number=d2.phone_number and d1.phone_number is not null and d1.created<d2.created;
update user u set phone_number=(select phone_number from device d where d.device_id=u.device_id);
