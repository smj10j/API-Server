drop table if exists `user_preference`;
CREATE TABLE `user_preference` (
  `user_preference_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  `value` varchar(1024) DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_preference_id`),
  UNIQUE KEY `user_id_name` (`user_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into user_preference(user_id,name,value) (select user_id,"name",name from user where name is not null and user_id not in(select user_id from user_preference));

drop table if exists `user_to_device`;
CREATE TABLE `user_to_device` (
  `user_id` int(11) unsigned NOT NULL,
  `device_id` char(64) NOT NULL,
  PRIMARY KEY (`user_id`,`device_id`),
  KEY `device_id` (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into user_to_device (user_id,device_id) (select user_id,device_id from user);

alter table user drop key device_id;
alter table user change column device_id device_id char(255) default null;

delete d1 from device d1,device d2 where d1.phone_number=d2.phone_number and d1.device_id!=d2.device_id and d1.device_id>d2.device_id;
update user set phone_number=null;
update user u set phone_number = (select phone_number from device d where d.device_id=u.device_id);