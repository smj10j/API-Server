 drop table if exists device_to_device;
 CREATE TABLE `device_to_device` (
  `device_to_device_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `device1_id` int(11) unsigned NOT NULL,
  `device2_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `subscribe_server_id` int(11) unsigned NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`device_to_device_id`),
  UNIQUE KEY `device1_id_to_device2_id` (`device1_id`,`device2_id`) comment 'device1_id should be alphabetically less than device2_id',
  KEY `customer_id_address_id` (`customer_id`,`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

 drop table if exists subscribe_server;
 CREATE TABLE `subscribe_server` (
  `subscribe_server_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `server` varchar(128) NOT NULL,
  `port` int(11) unsigned NOT NULL default 25785,
  `protocol` varchar(8) NOT NULL default 'https',
  `resource` varchar(64) NOT NULL default 'transaction',
  `subscriber_count` int(11) unsigned NOT NULL default 0,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`subscribe_server_id`),
  KEY `subscriber_count` (`subscriber_count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

