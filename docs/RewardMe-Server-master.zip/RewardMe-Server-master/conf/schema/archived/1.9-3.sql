alter table user_to_reward add column address_id int(11) unsigned not null after reward_id;
alter table user_to_reward add key address_id(address_id, updated);



DROP TABLE IF EXISTS `customer_billing`;
CREATE TABLE `customer_billing` (
  `customer_billing_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `customer_contact_id` int(11) unsigned NOT NULL,
  `freshbooks_client_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_billing_id`),
  UNIQUE KEY `customer_id` (`customer_id`),
  UNIQUE KEY `freshbooks_client_id` (`freshbooks_client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `customer_invoice`;
CREATE TABLE `customer_invoice` (
  `customer_invoice_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_billing_id` int(11) unsigned NOT NULL,
  `freshbooks_invoice_id` int(11) unsigned NOT NULL,
  `due_time` datetime NOT NULL,
  `paid` tinyint(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_invoice_id`),
  UNIQUE KEY `freshbooks_invoice_id` (`freshbooks_invoice_id`),
  KEY `customer_billing_id` (`customer_billing_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `customer_invoice_item`;
CREATE TABLE `customer_invoice_item` (
  `customer_invoice_item_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` varchar(4096) CHARACTER SET latin1 NOT NULL,
  `unit_cost` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `quantity` int(11) unsigned NOT NULL,
  `total_cost` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_invoice_item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `customer_invoice_recurring`;
CREATE TABLE `customer_invoice_recurring` (
  `customer_invoice_recurring_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_billing_id` int(11) unsigned NOT NULL,
  `freshbooks_recurring_id` int(11) unsigned NOT NULL,
  `stopped` tinyint(1) NOT NULL COMMENT 'Stopped means no longer generating invoices and is archive',
  `auto_bill` tinyint(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_invoice_recurring_id`),
  UNIQUE KEY `freshbooks_recurring_id` (`freshbooks_recurring_id`),
  KEY `customer_billing_id` (`customer_billing_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `customer_invoice_recurring_to_customer_invoice_item`;
CREATE TABLE `customer_invoice_recurring_to_customer_invoice_item` (
  `customer_invoice_recurring_id` int(11) unsigned NOT NULL,
  `customer_invoice_item_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_invoice_recurring_id`,`customer_invoice_item_id`),
  KEY `customer_invoice_item_id` (`customer_invoice_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `customer_invoice_to_customer_invoice_item`;
CREATE TABLE `customer_invoice_to_customer_invoice_item` (
  `customer_invoice_id` int(11) unsigned NOT NULL,
  `customer_invoice_item_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_invoice_id`,`customer_invoice_item_id`),
  KEY `customer_invoice_item_id` (`customer_invoice_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

