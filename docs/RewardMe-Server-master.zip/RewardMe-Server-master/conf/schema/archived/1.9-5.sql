alter table user_to_reward change column address_id address_id int(11) unsigned not null;
update user_to_reward ur set address_id=(select address_id from customer_to_address where customer_id=ur.customer_id limit 1) where address_id=0;
