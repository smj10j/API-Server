alter table customer_invoice_item add name varchar(128) not null after freshbooks_item_id;
alter table customer_invoice_item drop column freshbooks_item_id;
