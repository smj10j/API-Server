drop table if exists `server`;
CREATE TABLE `server` (
  `server_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('SUBSCRIBE') NOT NULL,
  `url` varchar(128) NOT NULL,
  `port` int(11) unsigned NOT NULL DEFAULT '25785',
  `protocol` varchar(8) NOT NULL DEFAULT 'https',
  `resource` varchar(64) NOT NULL DEFAULT 'transaction',
  `subscriber_count` int(11) unsigned NOT NULL DEFAULT '0',
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`server_id`),
  KEY `type_subscriber_count` (`type`,`subscriber_count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
