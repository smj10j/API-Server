alter table user drop key username;
