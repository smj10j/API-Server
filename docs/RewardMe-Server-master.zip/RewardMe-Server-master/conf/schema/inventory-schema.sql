
--model objects--
drop table if exists `pos_tx`;
CREATE TABLE `pos_tx` (
  `pos_tx_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `employee_id` int(11)unsigned  NOT NULL,
  `device_id` char(64) NOT NULL,
  `external_pos_tx_id` varchar(64) NOT NULL,
  `amount` decimal(10,2) unsigned NOT NULL,
  `amount_less_tax` decimal(10,2) unsigned NOT NULL,
  `amount_less_tax_and_discount` decimal(10,2) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_tx_id`),
  UNIQUE KEY `external_pos_tx_id` (`customer_id`,`external_pos_tx_id`),
  KEY `customer_id_address_id_created` (`customer_id`,`address_id`,`created`),
  KEY `customer_id_user_id_created` (`customer_id`,`user_id`,`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists `employee`;
CREATE TABLE `employee` (
  `employee_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `external_employee_id` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`employee_id`),
  UNIQUE KEY `external_employee_id` (`customer_id`,`external_employee_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists `pos_inventory_item`;
CREATE TABLE `pos_inventory_item` (
  `pos_inventory_item_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `external_pos_inventory_item_id` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `price` decimal(10,2) unsigned NOT NULL,
  `cost` decimal(10,2) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_inventory_item_id`),
  UNIQUE KEY `external_pos_inventory_item_id` (`customer_id`,`external_pos_inventory_item_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists `pos_inventory_item_mod`;
CREATE TABLE `pos_inventory_item_mod` (
  `pos_inventory_item_mod_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `external_pos_inventory_item_mod_id` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `price` decimal(10,2) unsigned NOT NULL,
  `cost` decimal(10,2) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_inventory_item_mod_id`),
  UNIQUE KEY `external_pos_inventory_item_mod_id` (`customer_id`,`external_pos_inventory_item_mod_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists `pos_inventory_category`;
CREATE TABLE `pos_inventory_category` (
  `pos_inventory_category_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `external_pos_inventory_category_id` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `parent_pos_inventory_category_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_inventory_category_id`),
  UNIQUE KEY `external_pos_inventory_category_id` (`customer_id`,`external_pos_inventory_category_id`),
  KEY `name` (`name`),
  KEY `parent_pos_inventory_category_id` (`parent_pos_inventory_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists `pos_discount`;
CREATE TABLE `pos_discount` (
  `pos_discount_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `external_pos_discount_id` varchar(64) NOT NULL,
  `type` enum('PERCENTAGE','VALUE') NOT NULL,
  `value` decimal(10,2) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_discount_id`),
  UNIQUE KEY `external_pos_discount_id` (`customer_id`,`external_pos_discount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--histories--
drop table if exists `pos_inventory_item_history`;
CREATE TABLE `pos_inventory_item_history` (
  `pos_inventory_item_history_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_inventory_item_id` int(11) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  `price` decimal(10,2) unsigned NOT NULL,
  `cost` decimal(10,2) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_inventory_item_history_id`),
  KEY `pos_inventory_item_id_created` (`pos_inventory_item_id`,`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists `pos_inventory_item_mod_history`;
CREATE TABLE `pos_inventory_item_mod_history` (
  `pos_inventory_item_mod_history_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_inventory_item_mod_id` int(11) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  `price` decimal(10,2) unsigned NOT NULL,
  `cost` decimal(10,2) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_inventory_item_mod_history_id`),
  KEY `pos_inventory_item_mod_id_created` (`pos_inventory_item_mod_id`,`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;







--transaction joins--

drop table if exists `favorite_pos_tx`;
CREATE TABLE `favorite_pos_tx` (
  `favorite_pos_tx_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `pos_tx_id` int(11) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`favorite_pos_tx_id`),
  KEY `user_id_created` (`user_id`,`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists `pos_tx_to_pos_inventory_item`;
CREATE TABLE `pos_tx_to_pos_inventory_item` (
  `pos_tx_to_pos_inventory_item_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_tx_id` int(11) unsigned NOT NULL,
  `pos_inventory_item_history_id` int(11) unsigned NOT NULL,
  `count` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_tx_to_pos_inventory_item_id`),
  KEY `pos_tx_id_pos_inventory_item_history_id` (`pos_tx_id`,`pos_inventory_item_history_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists `pos_tx_to_pos_inventory_item_to_pos_inventory_item_mod`;
CREATE TABLE `pos_tx_to_pos_inventory_item_to_pos_inventory_item_mod` (
  `pos_tx_to_pos_inventory_item_to_pos_inventory_item_mod_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_tx_to_pos_inventory_item_id` int(11) unsigned NOT NULL,
  `pos_inventory_item_mod_history_id` int(11) unsigned NOT NULL,
  `count` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_tx_to_pos_inventory_item_to_pos_inventory_item_mod_id`),
  KEY `pos_tx_to_pos_inventory_item_mod_history_id` (`pos_tx_to_pos_inventory_item_id`,`pos_inventory_item_mod_history_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists `pos_tx_to_pos_discount`;
CREATE TABLE `pos_tx_to_pos_discount` (
  `pos_tx_to_pos_discount_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_tx_id` int(11) unsigned NOT NULL,
  `pos_discount_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_tx_to_pos_discount_id`),
  KEY `pos_tx_id_pos_discount_id` (`pos_tx_id`,`pos_discount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists `pos_tx_to_pos_inventory_item_to_pos_discount`;
CREATE TABLE `pos_tx_to_pos_inventory_item_to_pos_discount` (
  `pos_tx_to_pos_inventory_item_to_pos_discount_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_tx_to_pos_inventory_item_id` int(11) unsigned NOT NULL,
  `pos_discount_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_tx_to_pos_inventory_item_to_pos_discount_id`),
  KEY `pos_tx_to_pos_inventory_item_id_pos_discount_id` (`pos_tx_to_pos_inventory_item_id`,`pos_discount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- model relationship joins --
/*
drop table if exists `pos_inventory_item_to_address`;
CREATE TABLE `pos_inventory_item_to_address` (
  `pos_inventory_item_to_address_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_inventory_item_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_inventory_item_to_address_id`),
  UNIQUE KEY `address_id_pos_inventory_item_id` (`address_id`,`pos_inventory_item_id`)
  KEY `pos_inventory_item_id` (`pos_inventory_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists `pos_inventory_item_mod_to_address`;
CREATE TABLE `pos_inventory_item_mod_to_address` (
  `pos_inventory_item_mod_to_address_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_inventory_item_mod_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_inventory_item_mod_id`),
  UNIQUE KEY `address_id_pos_inventory_item_mod_id` (`address_id`,`pos_inventory_item_mod_id`)
  KEY `pos_inventory_item_mod_id` (`pos_inventory_item_mod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists `pos_inventory_category_to_address`;
CREATE TABLE `pos_inventory_category_to_address` (
  `pos_inventory_category_to_address_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_inventory_category_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_inventory_category_to_address_id`),
  UNIQUE KEY `address_id_pos_inventory_category_id` (`address_id`,`pos_inventory_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists `pos_discount_to_address`;
CREATE TABLE `pos_discount_to_address` (
  `pos_discount_to_address_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_discount_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_discount_to_address_id`),
  UNIQUE KEY `address_id_pos_discount_id` (`address_id`,`pos_discount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
*/

drop table if exists `pos_inventory_item_to_pos_inventory_category`;
CREATE TABLE `pos_inventory_item_to_pos_inventory_category` (
  `pos_inventory_item_to_pos_inventory_category_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_inventory_item_id` int(11) unsigned NOT NULL,
  `pos_inventory_category_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_inventory_item_to_pos_inventory_category_id`),
  UNIQUE KEY `pos_inventory_item_id_pos_inventory_category_id` (`pos_inventory_item_id`,`pos_inventory_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



