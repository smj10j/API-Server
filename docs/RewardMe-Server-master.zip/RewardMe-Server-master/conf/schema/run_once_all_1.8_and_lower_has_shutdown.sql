-- FOR PRODUCTION --
alter table user_to_reward change column address_id address_id int(11) unsigned not null;
update user_to_reward ur set address_id=(select address_id from customer_to_address where customer_id=ur.customer_id limit 1) where address_id=0;


alter table reward drop column `points_required_within_time_period`;
alter table reward drop column `post_redeem_lifetime`;
alter table reward drop column `post_redeem_cooldown`;

insert ignore into user_preference(user_id,name,value) (select user_id,"name",name from user where name is not null and user_id not in(select user_id from user_preference));
insert ignore into user_to_device (user_id,device_id) (select user_id,device_id from user where user_id not in (select user_id from user_to_device));
delete from user_to_device where device_id ='';


alter table user drop column username;
alter table user drop column age_and_sex;
alter table user drop column name;
alter table user drop column device_id;
alter table user drop key device_id;

alter table address drop column yelp_data;


update user u set phone_number = (select phone_number from device d,user_to_device ud where d.device_id=ud.device_id and u.user_id=ud.user_id) where phone_number is null;
delete d1 from device d1,device d2 where d1.phone_number=d2.phone_number and d1.device_id!=d2.device_id and d1.device_id>d2.device_id;
alter table device drop column phone_number;

drop table app_usage_event;
drop table log_event;


drop table barcode;
drop table barcode_to_address;
drop table barcode_to_reward;
drop table user_to_barcode;



 -- TODO --
drop table user_message;
rename table user_message_NEW to user_message;
