-- MySQL dump 10.13  Distrib 5.5.5-m3, for Linux (i686)
--
-- Host: db-slave.rewardme.com    Database: rewardme
-- ------------------------------------------------------
-- Server version	5.5.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address` (
  `address_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `address` varchar(128) NOT NULL,
  `longitude_radians` decimal(10,9) NOT NULL,
  `latitude_radians` decimal(10,9) NOT NULL,
  `checkin_radius` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`address_id`),
  KEY `address` (`address`),
  KEY `latitude_radians` (`latitude_radians`,`longitude_radians`)
) ENGINE=InnoDB AUTO_INCREMENT=229 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `address_metadata`
--

DROP TABLE IF EXISTS `address_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address_metadata` (
  `address_metadata_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `address_id` int(11) unsigned NOT NULL,
  `provider` enum('YELP') NOT NULL DEFAULT 'YELP',
  `provider_id` varchar(64) DEFAULT NULL,
  `provider_link` varchar(255) DEFAULT NULL,
  `name` varchar(128) NOT NULL,
  `category` varchar(64) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `image_url_small` varchar(255) DEFAULT NULL,
  `rating_url` varchar(255) DEFAULT NULL,
  `phone_number` varchar(12) DEFAULT NULL,
  `total_reviews` int(11) unsigned NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`address_metadata_id`),
  UNIQUE KEY `address_id` (`address_id`,`provider`),
  KEY `name` (`name`),
  KEY `category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=224 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `application`
--

DROP TABLE IF EXISTS `application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application` (
  `application_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('KIOSK','COUNTER_SERVICE_LOYALTY','COUNTER_SERVICE_LOYALTY_EMPLOYEE_FACING','AD_NETWORK','TABLE_SERVICE_WAITING_LIST') NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `archived` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`application_id`),
  KEY `customer_id_archived_type_name` (`customer_id`,`archived`,`type`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `application_observation`
--

DROP TABLE IF EXISTS `application_observation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_observation` (
  `application_observation_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `application_id` int(11) unsigned NOT NULL,
  `observations_instance_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned DEFAULT NULL,
  `module` varchar(64) DEFAULT NULL,
  `element` varchar(64) DEFAULT NULL,
  `action` varchar(64) DEFAULT NULL,
  `data` varchar(64) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`application_observation_id`),
  KEY `application_id` (`application_id`,`observations_instance_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1526401 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `checkin_option`
--

DROP TABLE IF EXISTS `checkin_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `checkin_option` (
  `checkin_option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `point_category_id` int(11) unsigned NOT NULL DEFAULT '0',
  `point_award` int(11) NOT NULL,
  `referral_point_award` int(11) NOT NULL,
  `recurring_referral_point_award` int(11) NOT NULL,
  `cooldown_length` int(11) unsigned NOT NULL COMMENT 'how long before the user can checkin again - in seconds',
  `name` varchar(255) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` enum('VISIT_BASED','VALUE_BASED') NOT NULL DEFAULT 'VISIT_BASED',
  PRIMARY KEY (`checkin_option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `checkin_option_to_schedule`
--

DROP TABLE IF EXISTS `checkin_option_to_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `checkin_option_to_schedule` (
  `checkin_option_id` int(11) unsigned NOT NULL,
  `schedule_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`checkin_option_id`,`schedule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `customer_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `api_key` char(64) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(128) NOT NULL,
  `subdomain` varchar(32) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `secret_key` char(40) NOT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `api_key` (`api_key`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_billing`
--

DROP TABLE IF EXISTS `customer_billing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_billing` (
  `customer_billing_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `customer_contact_id` int(11) unsigned NOT NULL,
  `freshbooks_client_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_billing_id`),
  UNIQUE KEY `customer_id` (`customer_id`),
  UNIQUE KEY `freshbooks_client_id` (`freshbooks_client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_broadcast_message`
--

DROP TABLE IF EXISTS `customer_broadcast_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_broadcast_message` (
  `customer_broadcast_message_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned DEFAULT NULL,
  `message` varchar(512) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `sent` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_broadcast_message_id`),
  KEY `customer_id_timestamp` (`customer_id`,`timestamp`),
  KEY `customer_id_address_id` (`customer_id`,`address_id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_contact`
--

DROP TABLE IF EXISTS `customer_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_contact` (
  `customer_contact_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `password` varchar(64) DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_contact_id`),
  KEY `customer_id` (`customer_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_contact_to_permission`
--

DROP TABLE IF EXISTS `customer_contact_to_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_contact_to_permission` (
  `customer_contact_id` int(11) unsigned NOT NULL,
  `permission_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_contact_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_feature`
--

DROP TABLE IF EXISTS `customer_feature`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_feature` (
  `customer_feature_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `feature` enum('PUSH_NOTIFICATION','ACTIVITY_NOTIFICATION') NOT NULL,
  `amount` int(11) unsigned NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_feature_id`),
  UNIQUE KEY `customer_id` (`customer_id`,`feature`),
  KEY `customer_id_2` (`customer_id`,`feature`,`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_feature_usage`
--

DROP TABLE IF EXISTS `customer_feature_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_feature_usage` (
  `customer_feature_usage_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_feature_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_feature_usage_id`),
  KEY `customer_feature_id` (`customer_feature_id`,`created`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_invoice`
--

DROP TABLE IF EXISTS `customer_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_invoice` (
  `customer_invoice_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_billing_id` int(11) unsigned NOT NULL,
  `freshbooks_invoice_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `paid_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `due_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`customer_invoice_id`),
  UNIQUE KEY `freshbooks_invoice_id` (`freshbooks_invoice_id`),
  KEY `customer_billing_id` (`customer_billing_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_invoice_item`
--

DROP TABLE IF EXISTS `customer_invoice_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_invoice_item` (
  `customer_invoice_item_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` varchar(4096) CHARACTER SET latin1 NOT NULL,
  `unit_cost` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `quantity` int(11) unsigned NOT NULL,
  `total_cost` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_invoice_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_invoice_recurring`
--

DROP TABLE IF EXISTS `customer_invoice_recurring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_invoice_recurring` (
  `customer_invoice_recurring_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_billing_id` int(11) unsigned NOT NULL,
  `freshbooks_recurring_id` int(11) unsigned NOT NULL,
  `stopped` tinyint(1) NOT NULL COMMENT 'Stopped means no longer generating invoices and is archive',
  `auto_bill` tinyint(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_invoice_recurring_id`),
  UNIQUE KEY `freshbooks_recurring_id` (`freshbooks_recurring_id`),
  KEY `customer_billing_id` (`customer_billing_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_invoice_recurring_to_customer_invoice_item`
--

DROP TABLE IF EXISTS `customer_invoice_recurring_to_customer_invoice_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_invoice_recurring_to_customer_invoice_item` (
  `customer_invoice_recurring_id` int(11) unsigned NOT NULL,
  `customer_invoice_item_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_invoice_recurring_id`,`customer_invoice_item_id`),
  KEY `customer_invoice_item_id` (`customer_invoice_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_invoice_to_customer_invoice_item`
--

DROP TABLE IF EXISTS `customer_invoice_to_customer_invoice_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_invoice_to_customer_invoice_item` (
  `customer_invoice_id` int(11) unsigned NOT NULL,
  `customer_invoice_item_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_invoice_id`,`customer_invoice_item_id`),
  KEY `customer_invoice_item_id` (`customer_invoice_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_preference`
--

DROP TABLE IF EXISTS `customer_preference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_preference` (
  `customer_preference_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `name` varchar(128) NOT NULL,
  `value` varchar(1024) DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `address_id` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`customer_preference_id`),
  UNIQUE KEY `customer_id_address_id_name` (`customer_id`,`address_id`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_to_address`
--

DROP TABLE IF EXISTS `customer_to_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_to_address` (
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_id`,`address_id`),
  KEY `address_id` (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_to_checkin_option`
--

DROP TABLE IF EXISTS `customer_to_checkin_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_to_checkin_option` (
  `customer_id` int(11) unsigned NOT NULL,
  `checkin_option_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_id`,`checkin_option_id`),
  KEY `checkin_option_id` (`checkin_option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_to_reward`
--

DROP TABLE IF EXISTS `customer_to_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_to_reward` (
  `customer_id` int(11) unsigned NOT NULL,
  `reward_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_id`,`reward_id`),
  KEY `reward_id` (`reward_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device`
--

DROP TABLE IF EXISTS `device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device` (
  `device_id` char(64) NOT NULL,
  `remote_device_uuid` char(64) DEFAULT NULL COMMENT 'used for apns',
  `os_name` varchar(128) DEFAULT NULL,
  `os_version` varchar(128) DEFAULT NULL,
  `model` varchar(128) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `api_version` char(8) DEFAULT NULL,
  PRIMARY KEY (`device_id`),
  KEY `remote_device_uuid` (`remote_device_uuid`(8))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_application`
--

DROP TABLE IF EXISTS `device_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_application` (
  `device_application_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` char(64) NOT NULL,
  `application_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `checkin_option_id` int(11) unsigned DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`device_application_id`),
  UNIQUE KEY `device_id` (`device_id`),
  KEY `customer_id_address_id` (`address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_link`
--

DROP TABLE IF EXISTS `device_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_link` (
  `device_link_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `device1_id` char(64) NOT NULL,
  `device2_id` char(64) NOT NULL,
  `server_id` int(11) unsigned NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`device_link_id`),
  UNIQUE KEY `device1_id_to_device2_id` (`device1_id`,`device2_id`),
  KEY `device2_id` (`device2_id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_to_device`
--

DROP TABLE IF EXISTS `device_to_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_to_device` (
  `device_to_device_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `device1_id` int(11) unsigned NOT NULL,
  `device2_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `subscribe_server_id` int(11) unsigned NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`device_to_device_id`),
  UNIQUE KEY `device1_id_to_device2_id` (`device1_id`,`device2_id`) COMMENT 'device1_id should be alphabetically less than device2_id',
  KEY `customer_id_address_id` (`customer_id`,`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `employee_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `external_employee_id` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`employee_id`),
  UNIQUE KEY `external_employee_id` (`customer_id`,`address_id`,`external_employee_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=1653 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event` (
  `event_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `customer_id` int(11) unsigned DEFAULT NULL,
  `address_id` int(11) unsigned DEFAULT NULL,
  `name` varchar(64) NOT NULL,
  `value` varchar(64) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `admin` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `secret_key_id` int(11) unsigned DEFAULT NULL,
  `device_id` char(64) DEFAULT NULL,
  PRIMARY KEY (`event_id`),
  KEY `customer_id` (`customer_id`,`admin`,`created`),
  KEY `secret_key_name` (`secret_key_id`,`name`),
  KEY `name` (`name`,`created`)
) ENGINE=MyISAM AUTO_INCREMENT=3734183 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_trigger`
--

DROP TABLE IF EXISTS `event_trigger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_trigger` (
  `event_trigger_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned DEFAULT NULL,
  `event_name` varchar(64) NOT NULL,
  `event_value` varchar(64) NOT NULL,
  `type` enum('USER_MESSAGE') NOT NULL,
  `type_id` int(11) unsigned NOT NULL,
  `triggered` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `event_hash` varchar(64) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`event_trigger_id`),
  KEY `triggered_event_hash` (`triggered`,`event_hash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `favorite_pos_tx`
--

DROP TABLE IF EXISTS `favorite_pos_tx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `favorite_pos_tx` (
  `favorite_pos_tx_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `pos_tx_id` int(11) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`favorite_pos_tx_id`),
  KEY `user_id_created` (`user_id`,`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inventory_item`
--

DROP TABLE IF EXISTS `inventory_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_item` (
  `inventory_item_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `serial` varchar(32) NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `type` varchar(64) NOT NULL,
  `description` varchar(128) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`inventory_item_id`),
  UNIQUE KEY `serial` (`serial`),
  KEY `user_id` (`user_id`,`serial`,`created`)
) ENGINE=InnoDB AUTO_INCREMENT=362 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `npa_nxx_to_zipcode`
--

DROP TABLE IF EXISTS `npa_nxx_to_zipcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `npa_nxx_to_zipcode` (
  `npa_nxx_to_zipcode_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `npa_nxx` int(6) NOT NULL,
  `city` varchar(64) NOT NULL,
  `county` varchar(32) NOT NULL,
  `zipcode` int(11) NOT NULL,
  `state` char(2) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`npa_nxx_to_zipcode_id`),
  UNIQUE KEY `npa_nxx` (`npa_nxx`)
) ENGINE=InnoDB AUTO_INCREMENT=172174 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `peripheral`
--

DROP TABLE IF EXISTS `peripheral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `peripheral` (
  `peripheral_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `external_peripheral_id` varchar(64) NOT NULL,
  `type` enum('SAVERMINT') NOT NULL,
  `device_application_id` int(11) unsigned NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`peripheral_id`),
  UNIQUE KEY `external_peripheral_id` (`external_peripheral_id`),
  KEY `type_created` (`type`,`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission` (
  `permission_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`permission_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `point_category`
--

DROP TABLE IF EXISTS `point_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `point_category` (
  `point_category_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `name` varchar(128) NOT NULL DEFAULT 'Points',
  `weight` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'weight=0 says points of this type cannot be converted to others',
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`point_category_id`),
  UNIQUE KEY `customer_id_name` (`customer_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pos_discount`
--

DROP TABLE IF EXISTS `pos_discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_discount` (
  `pos_discount_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `external_pos_discount_id` varchar(64) NOT NULL,
  `type` enum('PERCENTAGE','VALUE') NOT NULL,
  `value` decimal(10,2) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_discount_id`),
  UNIQUE KEY `external_pos_discount_id` (`customer_id`,`external_pos_discount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pos_inventory_category`
--

DROP TABLE IF EXISTS `pos_inventory_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_inventory_category` (
  `pos_inventory_category_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `external_pos_inventory_category_id` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `parent_pos_inventory_category_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_inventory_category_id`),
  UNIQUE KEY `external_pos_inventory_category_id` (`customer_id`,`external_pos_inventory_category_id`),
  KEY `name` (`name`),
  KEY `parent_pos_inventory_category_id` (`parent_pos_inventory_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pos_inventory_item`
--

DROP TABLE IF EXISTS `pos_inventory_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_inventory_item` (
  `pos_inventory_item_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `external_pos_inventory_item_id` varchar(64) NOT NULL,
  `kitchen_item_name` varchar(64) DEFAULT NULL,
  `name` varchar(64) NOT NULL,
  `price` decimal(10,2) unsigned NOT NULL,
  `cost` decimal(10,2) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_inventory_item_id`),
  UNIQUE KEY `external_pos_inventory_item_id` (`customer_id`,`external_pos_inventory_item_id`),
  UNIQUE KEY `kitchen_item_name` (`customer_id`,`kitchen_item_name`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=952 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pos_inventory_item_history`
--

DROP TABLE IF EXISTS `pos_inventory_item_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_inventory_item_history` (
  `pos_inventory_item_history_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_inventory_item_id` int(11) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  `price` decimal(10,2) unsigned NOT NULL,
  `cost` decimal(10,2) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_inventory_item_history_id`),
  KEY `pos_inventory_item_id_created` (`pos_inventory_item_id`,`created`)
) ENGINE=InnoDB AUTO_INCREMENT=1164 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pos_inventory_item_mod`
--

DROP TABLE IF EXISTS `pos_inventory_item_mod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_inventory_item_mod` (
  `pos_inventory_item_mod_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `external_pos_inventory_item_mod_id` varchar(64) NOT NULL,
  `kitchen_item_name` varchar(64) DEFAULT NULL,
  `name` varchar(64) NOT NULL,
  `price` decimal(10,2) unsigned NOT NULL,
  `cost` decimal(10,2) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_inventory_item_mod_id`),
  UNIQUE KEY `external_pos_inventory_item_mod_id` (`customer_id`,`external_pos_inventory_item_mod_id`),
  UNIQUE KEY `kitchen_item_name` (`customer_id`,`kitchen_item_name`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pos_inventory_item_mod_history`
--

DROP TABLE IF EXISTS `pos_inventory_item_mod_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_inventory_item_mod_history` (
  `pos_inventory_item_mod_history_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_inventory_item_mod_id` int(11) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  `price` decimal(10,2) unsigned NOT NULL,
  `cost` decimal(10,2) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_inventory_item_mod_history_id`),
  KEY `pos_inventory_item_mod_id_created` (`pos_inventory_item_mod_id`,`created`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pos_inventory_item_to_pos_inventory_category`
--

DROP TABLE IF EXISTS `pos_inventory_item_to_pos_inventory_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_inventory_item_to_pos_inventory_category` (
  `pos_inventory_item_to_pos_inventory_category_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_inventory_item_id` int(11) unsigned NOT NULL,
  `pos_inventory_category_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_inventory_item_to_pos_inventory_category_id`),
  UNIQUE KEY `pos_inventory_item_id_pos_inventory_category_id` (`pos_inventory_item_id`,`pos_inventory_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pos_receipt`
--

DROP TABLE IF EXISTS `pos_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_receipt` (
  `pos_receipt_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_tx_id` int(11) unsigned NOT NULL,
  `raw_data` blob NOT NULL,
  `ascii_data` blob NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`pos_receipt_id`),
  UNIQUE KEY `pos_tx_id` (`pos_tx_id`)
) ENGINE=InnoDB AUTO_INCREMENT=75017 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pos_tx`
--

DROP TABLE IF EXISTS `pos_tx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_tx` (
  `pos_tx_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `employee_id` int(11) unsigned NOT NULL,
  `device_id` char(64) NOT NULL,
  `external_pos_tx_id` varchar(64) NOT NULL,
  `amount` decimal(10,2) unsigned NOT NULL,
  `amount_less_tax` decimal(10,2) unsigned NOT NULL,
  `amount_less_tax_and_discount` decimal(10,2) unsigned NOT NULL,
  `payment_method` enum('CREDIT','CHECK','CASH','GIFT_CARD','HOUSE_TAB','MOBILE','BARTER','DEBIT','UNKNOWN') NOT NULL DEFAULT 'UNKNOWN',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_tx_id`),
  UNIQUE KEY `external_pos_tx_id` (`customer_id`,`address_id`,`external_pos_tx_id`),
  KEY `customer_id_address_id_created` (`customer_id`,`address_id`,`created`),
  KEY `customer_id_user_id_created` (`customer_id`,`user_id`,`created`)
) ENGINE=InnoDB AUTO_INCREMENT=239934 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pos_tx_to_pos_discount`
--

DROP TABLE IF EXISTS `pos_tx_to_pos_discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_tx_to_pos_discount` (
  `pos_tx_to_pos_discount_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_tx_id` int(11) unsigned NOT NULL,
  `pos_discount_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_tx_to_pos_discount_id`),
  KEY `pos_tx_id_pos_discount_id` (`pos_tx_id`,`pos_discount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pos_tx_to_pos_inventory_item`
--

DROP TABLE IF EXISTS `pos_tx_to_pos_inventory_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_tx_to_pos_inventory_item` (
  `pos_tx_to_pos_inventory_item_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_tx_id` int(11) unsigned NOT NULL,
  `pos_inventory_item_history_id` int(11) unsigned NOT NULL,
  `count` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_tx_to_pos_inventory_item_id`),
  KEY `pos_tx_id_pos_inventory_item_history_id` (`pos_tx_id`,`pos_inventory_item_history_id`)
) ENGINE=InnoDB AUTO_INCREMENT=913319 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pos_tx_to_pos_inventory_item_to_pos_discount`
--

DROP TABLE IF EXISTS `pos_tx_to_pos_inventory_item_to_pos_discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_tx_to_pos_inventory_item_to_pos_discount` (
  `pos_tx_to_pos_inventory_item_to_pos_discount_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_tx_to_pos_inventory_item_id` int(11) unsigned NOT NULL,
  `pos_discount_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_tx_to_pos_inventory_item_to_pos_discount_id`),
  KEY `pos_tx_to_pos_inventory_item_id_pos_discount_id` (`pos_tx_to_pos_inventory_item_id`,`pos_discount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pos_tx_to_pos_inventory_item_to_pos_inventory_item_mod`
--

DROP TABLE IF EXISTS `pos_tx_to_pos_inventory_item_to_pos_inventory_item_mod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_tx_to_pos_inventory_item_to_pos_inventory_item_mod` (
  `pos_tx_to_pos_inventory_item_to_pos_inventory_item_mod_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_tx_to_pos_inventory_item_id` int(11) unsigned NOT NULL,
  `pos_inventory_item_mod_history_id` int(11) unsigned NOT NULL,
  `count` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pos_tx_to_pos_inventory_item_to_pos_inventory_item_mod_id`),
  KEY `pos_tx_to_pos_inventory_item_mod_history_id` (`pos_tx_to_pos_inventory_item_id`,`pos_inventory_item_mod_history_id`)
) ENGINE=InnoDB AUTO_INCREMENT=217 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rating`
--

DROP TABLE IF EXISTS `rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rating` (
  `rating_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_tx_id` int(11) unsigned NOT NULL,
  `score` int(11) unsigned NOT NULL,
  `data` varchar(256) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`rating_id`),
  UNIQUE KEY `pos_tx_id` (`pos_tx_id`),
  KEY `score` (`score`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report` (
  `report_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `group_name` varchar(128) NOT NULL,
  `description` varchar(512) NOT NULL,
  `definition` varchar(2048) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`report_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reward`
--

DROP TABLE IF EXISTS `reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reward` (
  `reward_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `point_category_id` int(11) unsigned NOT NULL DEFAULT '0',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `type` enum('FREE','DISCOUNT','SPECIAL_OFFER','VIP') NOT NULL,
  `headline` varchar(755) NOT NULL,
  `short_description` varchar(755) NOT NULL,
  `description` varchar(4096) NOT NULL,
  `instructions` varchar(4096) NOT NULL,
  `points_required` int(11) unsigned NOT NULL,
  `redemption_limit` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'number of times the reward can be claimed',
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `promoted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `image_url` varchar(255) DEFAULT NULL,
  `image_url_small` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`reward_id`),
  KEY `enabled` (`enabled`,`start_date`),
  KEY `end_date` (`end_date`)
) ENGINE=InnoDB AUTO_INCREMENT=471 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reward_to_schedule`
--

DROP TABLE IF EXISTS `reward_to_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reward_to_schedule` (
  `reward_id` int(11) unsigned NOT NULL,
  `schedule_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`reward_id`,`schedule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule` (
  `schedule_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `day_of_week` enum('SUNDAY','MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY') NOT NULL,
  `start_hour_minute` int(11) unsigned NOT NULL COMMENT 'hour*1000+minute',
  `end_hour_minute` int(11) unsigned NOT NULL COMMENT 'hour*1000+minute',
  `multiplier` decimal(4,2) NOT NULL DEFAULT '1.00',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`schedule_id`),
  UNIQUE KEY `day_of_week` (`day_of_week`,`start_hour_minute`,`end_hour_minute`,`multiplier`)
) ENGINE=InnoDB AUTO_INCREMENT=401 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `secret_key`
--

DROP TABLE IF EXISTS `secret_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `secret_key` (
  `secret_key_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `secret_key` char(64) NOT NULL,
  `type` enum('EVERYTHING','API','PUSH') NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`secret_key_id`),
  KEY `type` (`type`,`secret_key`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `server`
--

DROP TABLE IF EXISTS `server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server` (
  `server_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('SUBSCRIBE') NOT NULL,
  `url` varchar(128) NOT NULL,
  `port` int(11) unsigned NOT NULL DEFAULT '25785',
  `protocol` varchar(8) NOT NULL DEFAULT 'https',
  `resource` varchar(64) NOT NULL DEFAULT 'transaction',
  `subscriber_count` int(11) unsigned NOT NULL DEFAULT '0',
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`server_id`),
  KEY `type_subscriber_count` (`type`,`subscriber_count`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session` (
  `session_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`session_id`),
  KEY `user_id_customer_id_address_id_created` (`user_id`,`customer_id`,`address_id`,`created`)
) ENGINE=InnoDB AUTO_INCREMENT=81172 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `subscribe_server`
--

DROP TABLE IF EXISTS `subscribe_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscribe_server` (
  `subscribe_server_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `server` varchar(128) NOT NULL,
  `port` int(11) unsigned NOT NULL DEFAULT '25785',
  `protocol` varchar(8) NOT NULL DEFAULT 'https',
  `resource` varchar(64) NOT NULL DEFAULT 'transaction',
  `subscriber_count` int(11) unsigned NOT NULL DEFAULT '0',
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`subscribe_server_id`),
  KEY `subscriber_count` (`subscriber_count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `survey`
--

DROP TABLE IF EXISTS `survey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `survey` (
  `survey_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `content` varchar(1024) NOT NULL,
  `available_on_mobile` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `able_to_show_results` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`survey_id`),
  KEY `customer_id_enabled` (`customer_id`,`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `longitude_radians` decimal(10,9) DEFAULT NULL,
  `latitude_radians` decimal(10,9) DEFAULT NULL,
  `phone_number` char(12) DEFAULT NULL,
  `npa_nxx` int(6) DEFAULT NULL,
  `pin_code` char(32) DEFAULT NULL,
  `mobile` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `phone_number` (`phone_number`),
  KEY `latitude_radians` (`latitude_radians`,`longitude_radians`),
  KEY `npa_nxx` (`npa_nxx`),
  KEY `created` (`created`)
) ENGINE=InnoDB AUTO_INCREMENT=45552 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_checkin`
--

DROP TABLE IF EXISTS `user_checkin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_checkin` (
  `user_checkin_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `checkin_option_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_checkin_id`),
  KEY `user_id` (`user_id`,`customer_id`,`created`),
  KEY `customer_id` (`customer_id`,`created`),
  KEY `address_id` (`address_id`,`user_id`),
  KEY `customer_id_2` (`customer_id`,`address_id`,`created`)
) ENGINE=InnoDB AUTO_INCREMENT=50785 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_message`
--

DROP TABLE IF EXISTS `user_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_message` (
  `user_message_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `message` varchar(512) DEFAULT NULL,
  `sent` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_message_id`),
  KEY `customer_id_user_id_created` (`customer_id`,`user_id`,`created`),
  KEY `user_id_created` (`user_id`,`created`)
) ENGINE=InnoDB AUTO_INCREMENT=5053 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_points_history`
--

DROP TABLE IF EXISTS `user_points_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_points_history` (
  `user_points_history_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `point_category_id` int(11) unsigned NOT NULL DEFAULT '0',
  `points` int(11) NOT NULL,
  `type` enum('CHECKIN','REFERRAL','REDEEM','GIFT','SOCIAL','PROMOTIONAL','INCENTIVE','CHEATING','TRANSFER') NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_points_history_id`),
  KEY `user_id` (`user_id`,`customer_id`,`created`),
  KEY `user_id_2` (`user_id`,`customer_id`,`type`,`created`)
) ENGINE=InnoDB AUTO_INCREMENT=58687 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_points_summary`
--

DROP TABLE IF EXISTS `user_points_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_points_summary` (
  `user_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `point_category_id` int(11) unsigned NOT NULL DEFAULT '0',
  `earned_balance` int(11) unsigned NOT NULL,
  `current_balance` int(11) unsigned NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_id`,`customer_id`,`point_category_id`),
  KEY `customer_id` (`customer_id`,`earned_balance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_preference`
--

DROP TABLE IF EXISTS `user_preference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_preference` (
  `user_preference_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  `value` varchar(1024) DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `customer_id` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`user_preference_id`),
  UNIQUE KEY `user_id_customer_id_name` (`user_id`,`customer_id`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=58644 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_referral`
--

DROP TABLE IF EXISTS `user_referral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_referral` (
  `referred_id` int(11) unsigned NOT NULL,
  `referrer_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `first_used` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`referred_id`,`customer_id`),
  KEY `customer_id` (`customer_id`,`referred_id`),
  KEY `referrer_id` (`referrer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_referral_request`
--

DROP TABLE IF EXISTS `user_referral_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_referral_request` (
  `user_referral_request_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `referrer_id` int(11) unsigned NOT NULL,
  `referred_id` int(11) unsigned DEFAULT NULL,
  `referred_phone_number` char(12) DEFAULT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `responded` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_referral_request_id`),
  KEY `referred_id` (`referred_id`,`customer_id`),
  KEY `referred_phone_number` (`referred_phone_number`,`customer_id`),
  KEY `customer_id` (`customer_id`,`referred_id`),
  KEY `referrer_id` (`referrer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=407 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_social_checkin`
--

DROP TABLE IF EXISTS `user_social_checkin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_social_checkin` (
  `user_social_checkin_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `type` enum('facebook','foursquare','twitter') NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_social_checkin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_survey`
--

DROP TABLE IF EXISTS `user_survey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_survey` (
  `user_survey_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `survey_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned DEFAULT NULL,
  `response` varchar(255) DEFAULT NULL,
  `sent` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_survey_id`),
  UNIQUE KEY `user_id_survey_id` (`user_id`,`survey_id`),
  KEY `user_id_created` (`user_id`,`created`),
  KEY `survey_id_response` (`survey_id`,`response`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_to_customer_broadcast_message`
--

DROP TABLE IF EXISTS `user_to_customer_broadcast_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_to_customer_broadcast_message` (
  `user_to_customer_broadcast_message_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `customer_broadcast_message_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `viewed` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_to_customer_broadcast_message_id`),
  UNIQUE KEY `customer_broadcast_message_id` (`customer_broadcast_message_id`,`user_id`),
  KEY `user_id` (`user_id`,`created`),
  KEY `user_id_2` (`user_id`,`viewed`,`created`)
) ENGINE=InnoDB AUTO_INCREMENT=493 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_to_device`
--

DROP TABLE IF EXISTS `user_to_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_to_device` (
  `user_id` int(11) unsigned NOT NULL,
  `device_id` char(64) NOT NULL,
  PRIMARY KEY (`user_id`,`device_id`),
  KEY `device_id` (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_to_reward`
--

DROP TABLE IF EXISTS `user_to_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_to_reward` (
  `user_reward_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `reward_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned NOT NULL,
  `completed_redeem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_reward_id`),
  KEY `user_id` (`user_id`,`customer_id`,`completed_redeem`,`updated`),
  KEY `customer_id` (`customer_id`,`updated`),
  KEY `reward_id` (`reward_id`,`updated`),
  KEY `address_id` (`address_id`,`updated`)
) ENGINE=InnoDB AUTO_INCREMENT=5416 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warehouse_event_descriptor`
--

DROP TABLE IF EXISTS `warehouse_event_descriptor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouse_event_descriptor` (
  `warehouse_event_descriptor_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `dimensions` mediumblob,
  `facts` mediumblob,
  `filling` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`warehouse_event_descriptor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warehouse_session`
--

DROP TABLE IF EXISTS `warehouse_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouse_session` (
  `warehouse_session_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` int(11) unsigned NOT NULL,
  `data` mediumblob COMMENT 'map of clazz to object that stores all things linked to session',
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`warehouse_session_id`),
  UNIQUE KEY `session_id` (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=68209 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `zipcode_demographics`
--

DROP TABLE IF EXISTS `zipcode_demographics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zipcode_demographics` (
  `zipcode` int(11) unsigned NOT NULL,
  `households` int(11) NOT NULL,
  `population` int(11) NOT NULL,
  `population_white` int(11) NOT NULL,
  `population_black` int(11) NOT NULL,
  `population_hispanic` int(11) NOT NULL,
  `population_asian` int(11) NOT NULL,
  `population_hawaiian` int(11) NOT NULL,
  `population_indian` int(11) NOT NULL,
  `population_other` int(11) NOT NULL,
  `population_male` int(11) NOT NULL,
  `population_female` int(11) NOT NULL,
  `persons_per_household` decimal(4,2) NOT NULL,
  `average_house_value` int(11) NOT NULL,
  `average_income_per_household` int(11) NOT NULL,
  `median_age` decimal(4,1) NOT NULL,
  `median_age_male` decimal(4,1) NOT NULL,
  `median_age_female` decimal(4,1) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`zipcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-02-09  0:11:24
