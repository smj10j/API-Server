select date_format(u.created,"%b %D") as 'Period',count(distinct u.user_id) as 'New Users' from user u,user_checkin uc where u.user_id=uc.user_id and uc.customer_id=156 and u.created>=now()-interval 3 month group by week(u.created) order by u.created asc;

select date_format(created,"%b %D") as 'Period',count(*) as 'Checkins' from user_checkin where customer_id=156 and created>=now()-interval 3 month group by week(created) order by created asc;

select date_format(created,"%b %D") as 'Period',count(*) as 'Redemptions' from user_to_reward where customer_id=156 and created>=now()-interval 3 month group by week(created) order by created asc;

select date_format(created,"%b %D") as 'Period',sum(amount)/count(*) as 'Average Spend',if(user_id is null,'Non-RewardMe','RewardMe') as 'Status' from pos_tx tx where customer_id=156 and created>=now()-interval 3 month group by week(created),Status order by created asc;

select date_format(created,"%b %D") as 'Period',sum(amount) as 'Total Sales',if(user_id is null,'Non-RewardMe','RewardMe') as 'Status' from pos_tx tx where customer_id=156 and created>=now()-interval 3 month group by week(created),Status order by created asc;

select (select address from address a where a.address_id=tx.address_id) as 'address',sum(amount)/count(*) as 'avg_spend' from pos_tx tx where customer_id=156 and (user_id is not null and user_id not in (109,37)) group by address_id order by avg_spend desc;

select (select address from address a where a.address_id=tx.address_id) as 'address',sum(amount)/count(*) as 'avg_spend' from pos_tx tx where customer_id=156 and (user_id is null) group by address_id order by avg_spend desc;
