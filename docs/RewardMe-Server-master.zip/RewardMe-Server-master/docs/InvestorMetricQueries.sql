select date_format(created,"%b %D") as 'Period',count(*) as 'Total Stores with RewardMe being Live' from address where created>=now()-interval 3 month group by week(created) order by created asc;

select date_format(created,"%b %D") as 'Period',count(*) as 'New Users' from user where created>=now()-interval 3 month group by week(created) order by created asc;

select count(*) as 'Total Users at the end of this period' from user;

select date_format(created,"%b %D") as 'Period',count(*) as 'New Checkins' from user_checkin where created>=now()-interval 3 month group by week(created) order by created asc;

select count(*) as 'Total Checkins at the end of this period' from user_checkin;

select date_format(created,"%b %D") as 'Period',((count(*)/(select count(*) from pos_tx tx where week(created)=week(uc.created)))*100) as '% Checkins' from user_checkin uc where created>=now()-interval 3 month group by week(created) order by created asc;

select count(*) as 'Total Checkins before this period' from user_checkin where created<now()-interval 3 month;

select date_format(created,"%b %D") as 'Period',count(*) as 'New Redeems' from user_to_reward where created>=now()-interval 3 month group by week(created) order by created asc;

select count(*) as 'Total Redeems at the end of this period' from user_to_reward;

select sum(amount) as 'Total Sales through RewardMe' from pos_tx;

select sum(amount) as 'Total Sales through RewardMe with a checkin' from pos_tx where user_id is not null;

select sum(amount)/count(*) as 'Average Spend',if(user_id is null,'Non-RewardMe','RewardMe') as 'Status' from pos_tx tx group by Status;






-- # and amount of transaction for each customer
select (select name from customer c where c.customer_id=tx.customer_id) as 'Customer',count(*) as '# Transactions' from pos_tx tx group by customer_id;
select (select name from customer c where c.customer_id=tx.customer_id) as 'Customer',sum(amount) as '$ Transactions' from pos_tx tx group by customer_id;

-- text opt-in for each customer
select (select name from customer c where c.customer_id=up.customer_id) as 'Customer',
sum(if(value='true',1,0)) as 'opted-in',count(*) as 'total',(sum(if(value='true',1,0))/count(*))*100 as '%' 
from user_preference up where name='notification_text_all' group by customer_id;

-- overall aggregate trends by month
select concat(month(created),'/',year(created)) as 'Month',count(distinct user_id) as '# Users' from user_checkin group by Month order by created;
select concat(month(created),'/',year(created)) as 'Month',count(*) as '# Checkins' from user_checkin group by Month order by created;

-- users who became repeat visitors by month
select period as 'Month',count(*) as 'Users who became Repeat Visitors' from 
(select user_id,min(created) as 'created',concat(month(min(created)),'/',year(min(created))) as 'period',count(*) as 'Visits' from user_checkin uc1 
group by user_id having count(*)>1 order by min(created)) t group by period order by created;

