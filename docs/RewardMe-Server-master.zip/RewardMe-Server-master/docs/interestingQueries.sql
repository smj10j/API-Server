 
 -- users in each api version -- 
 select api_version,os_name,count(*) as 'total',(select count(*) from device where device_id in 
(select device_id from user u,user_checkin uc where uc.user_id=u.user_id) and d.api_version=api_version 
and d.os_name=os_name) as 'checked in once', (select count(*) from device where device_id in 
(select device_id from user u,user_checkin uc where uc.user_id=u.user_id) and 
d.api_version=api_version and d.os_name=os_name and created >= (now() -INTERVAL 7 DAY)) as 'checked in within the past week' 
from device d group by api_version,os_name order by api_version desc;
 
-- what users are redeeming and if they have text messages on -- 
select (select headline from reward r where r.reward_id=ur.reward_id) as 'reward', 
(select value from user_preference up where up.user_id=ur.user_id and name='notification_text_all') as 'text_enabled'
 from user_to_reward ur where customer_id=156 and user_id not in(37,109);
 
 -- average spend for RewardMe users -- 
select (select address from address a where a.address_id=tx.address_id) as 'address',sum(amount)/count(*) as 'avg_spend' from pos_tx tx where customer_id=156 and (user_id is not null and user_id not in (109,37)) group by address_id order by avg_spend desc;

 -- average spend for non-RewardMe users --
select (select address from address a where a.address_id=tx.address_id) as 'address',sum(amount)/count(*) as 'avg_spend' from pos_tx tx where customer_id=156 and (user_id is null) group by address_id order by avg_spend desc;

-- unique users by location -- 
select (select address from address a where a.address_id=uc.address_id) as 'address',count(distinct user_id) as 'count' from user_checkin uc 
where customer_id=156 group by address_id order by count desc;

-- average speed of line for RewardMe --
select sum(elapsed)/count(*) from (select (sum(data)/1000) as 'elapsed' from application_observation where action='unload' and 
application_id in (select application_id from application where customer_id=156) and user_id is not null 
group by observations_instance_id) t where elapsed < 300;

-- average speed of line for non-RewardMe --
select sum(elapsed)/count(*) from (select (sum(data)/1000) as 'elapsed' from application_observation where action='unload' and 
application_id in (select application_id from application where customer_id=156) and user_id is null 
group by observations_instance_id) t where elapsed < 300;

-- 2x repeat customers --
select user_id,count(*) as 'count' from user_checkin where customer_id=156 group by user_id having count=2;

-- average order value by location -- 
select (select address from address a where a.address_id=tx.address_id) as 'address', sum(amount)/count(*) as 'avg' 
from pos_tx tx where customer_id=156 and (user_id is null or user_id not in (109,37)) group by address_id order by avg desc;

-- basic demographic data of customers, grouped by address --
select (select address from address where address_id=uc.address_id) as 'Address',count(*) as 'Sample Size',
sum(average_income_per_household)/count(*) as 'avg income',sum(population_white)/sum(population)*100 as '% white',
sum(population_asian)/sum(population)*100 as '% asian', sum(population_black)/sum(population)*100 as '% black',
sum(population_hispanic)/sum(population)*100 as '% hispanic',sum(population_male)/sum(population)*100 as '% male' 
from zipcode_demographics zd, npa_nxx_to_zipcode nz, user u, user_checkin uc where uc.user_id=u.user_id and 
u.npa_nxx=nz.npa_nxx and nz.zipcode=zd.zipcode group by uc.address_id order by uc.customer_id,uc.address_id;

-- employee performance -- 
select e.name as 'Employee',e.address_id,sum(amount) as '$ Sales',count(*) as 'Transactions',count(distinct user_id) as 'Transactions w/ Checkin',
(count(distinct user_id)/count(*))*100 as 'Checkin %', (count(distinct user_id) * ((count(distinct user_id)/count(*))*100)) as 'Weighted Score' 
from employee e,pos_tx tx where e.employee_id=tx.employee_id and e.name not like '%$%' and e.name not in('1','2') and e.customer_id=159  
group by tx.employee_id order by `Weighted Score` desc;

-- a look at customer names and locations --
select u.phone_number,concat(value,if(nx.city!='',concat(' from ',nx.city), '')) as 'guest',up.created 
from user_preference up,user u,npa_nxx_to_zipcode nx where nx.npa_nxx=u.npa_nxx and u.user_id=up.user_id and name='name' 
and customer_id is null and up.created>now()-interval 24 hour;

-- ordered list of recently restarted devices
select device_application_id,(select address from address a,device_application da 
where da.address_id=a.address_id and da.device_application_id=ao.device_application_id) as 'address',(created-interval 7 hour) as 'created PST' 
from application_observation ao where module is null and element='init' order by created;

-- text opt-in rate
select sum(if(value='true',1,0)) as 'opted-in',count(*) as 'total',(sum(if(value='true',1,0))/count(*))*100 as '%' 
from user_preference where customer_id=159 and name='notification_text_all';

-- aov change over time --
select period,sum(val)/count(*) as 'avg' from (select concat(month(created),'/',day(created),'/',year(created)) as 'period',created,user_id,sum(amount)/count(*) as 'val' from pos_tx where customer_id=156 and user_id is not null group by period,user_id) t group by week(created) order by created;