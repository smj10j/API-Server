#!/bin/bash 
dir=/usr/jboss/server/rewardme
while [  1 -gt 0 ]; do
	if [ -e $dir/pre-deploy/ready ]; then
		 mv -f $dir/pre-deploy/* $dir/deploy/
	fi
	sleep 1	
done

