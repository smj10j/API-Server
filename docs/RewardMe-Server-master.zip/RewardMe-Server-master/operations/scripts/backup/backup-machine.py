#!/usr/bin/python

import os
import datetime

pem_file = '/root/ec2-creds/pk-S5EMNFHM6HBNYLGOY2XANFKZ2MSRTRXK.pem'
cert_file = '/root/ec2-creds/cert-S5EMNFHM6HBNYLGOY2XANFKZ2MSRTRXK.pem'
user_id = '125505437149'
platform = 'i386'
bucket = 'rewardme-machine-backups'

access_key = 'AKIAICTRX3WDNDCSJEMQ'
secret_key = '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'
ec2_path = '/home/ec2/bin/' #use trailing slash

# DO NOT EDIT BELOW THIS


now = datetime.datetime.now()
manifest = now.strftime("%Y-%m-%d.%H:%M")

step_1 = 'rm -f /mnt/%s*' % (manifest,)
step_2 = '%sec2-bundle-vol -p %s -d /mnt -k %s -c %s -u %s -r %s' % (ec2_path, manifest, pem_file, cert_file, user_id, platform)
step_3 = '%sec2-upload-bundle -b %s -m /mnt/%s.manifest.xml -a %s -s %s' % (ec2_path, bucket, manifest, access_key, secret_key)


#The following will take an image of the machine and then upload it to s3
print step_1
os.system(step_1)
print step_2
os.system(step_2)
print step_3
os.system(step_3)
