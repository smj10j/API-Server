#!/usr/bin/python

import os
import datetime

pem_file = '/root/ec2-creds/pk-S5EMNFHM6HBNYLGOY2XANFKZ2MSRTRXK.pem'
cert_file = '/root/ec2-creds/cert-S5EMNFHM6HBNYLGOY2XANFKZ2MSRTRXK.pem'
user_id = '125505437149'
platform = 'i386'
bucket = 'rewardme-database-backups'

access_key = 'AKIAICTRX3WDNDCSJEMQ'
secret_key = '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'
ec2_path = '/home/ec2/bin/' #use trailing slash

# DO NOT EDIT BELOW THIS

now = datetime.datetime.now()
manifest = now.strftime("%Y-%m-%d.%H:%M")

step_1 = 'mysqldump -u %s -p%s %s | gzip > /mnt/%s.sql.zip' % ('rewardme_admin', 'worknet', 'rewardme', manifest)
step_2 = '/root/s3cmd-1.0.0-rc1/s3cmd put /mnt/%s.sql.zip s3://%s' % (manifest, bucket)

#http://s3tools.org/s3cmd


#The following will take a dump of the rewardme database and upload it to s3
print step_1
os.system(step_1)
print step_2
os.system(step_2)
