wget http://apache.tradebit.com/pub//cassandra/1.0.8/apache-cassandra-1.0.8-bin.tar.gz
tar -xvzf apache-cassandra-1.0.8-bin.tar.gz
mv apache-cassandra-1.0.8-bin.tar.gz /mnt/cassandra
mkdir /mnt/cassandra/data
mkdir /mnt/cassandra/log

sed -i -e "s,/var/lib/cassandra/,/mnt/cassandra/," /mnt/cassandra/conf/cassandra.yaml
sed -i -e "s,/cassandra/commitlog,/cassandra/data/commitlog," /mnt/cassandra/conf/cassandra.yaml
sed -i -e "s,/cassandra/saved_caches,/cassandra/data/saved_caches," /mnt/cassandra/conf/cassandra.yaml
sed -i -e "s,/var/log/cassandra,/mnt/cassandra/log," /mnt/cassandra/conf/log4j-server.properties

echo "Be sure to setup the rpc_address and listen_address to appropriate values"