
APIKEYS=`echo "SELECT api_key FROM customer WHERE enabled" | mysql -u rewardme_admin -pworknet rewardme | awk '{ print $1 }'`

for APIKEY in $APIKEYS
do
        if [ "$APIKEY" != "api_key" ]
        then
                echo "Broadcasting all messages for $APIKEY"
                BROADCAST=`curl -s "http://localhost/rewardme/api?method=notification.broadcast&apiKey=$APIKEY&responseFormat=json"`
                echo $BROADCAST
        fi
done

