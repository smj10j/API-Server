tail -n 2000 /usr/jboss/server/rewardme/log/server.log &
