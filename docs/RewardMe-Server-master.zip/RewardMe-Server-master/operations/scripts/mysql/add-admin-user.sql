grant all privileges on `rewardme%`.* to 'rewardme_admin'@'%' identified by 'worknet';
grant all privileges on `rewardme%`.* to 'rewardme_admin'@'localhost' identified by 'worknet';