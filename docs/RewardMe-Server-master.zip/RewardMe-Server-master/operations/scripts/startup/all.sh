/etc/init.d/nginx restart
/etc/init.d/mysql restart
memcached -u root -d -m 48
screen /usr/jboss/bin/run.sh -b 0.0.0.0 -c rewardme
