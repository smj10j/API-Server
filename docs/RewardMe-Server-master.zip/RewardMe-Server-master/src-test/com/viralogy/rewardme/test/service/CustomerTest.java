package com.viralogy.rewardme.test.service;

import static org.junit.Assert.assertTrue;

import org.apache.commons.httpclient.NameValuePair;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.test.SimpleTestBase;
import com.viralogy.rewardme.util.SecurityUtil;
import com.viralogy.rewardme.util.StringUtil;

//Commented out until someone fixes this test.
public class CustomerTest extends SimpleTestBase{
    
	private static Logger logger = Logger.getLogger(CustomerTest.class);
	
	private static final String DEFAULT_DEVICE_ID = "TESTING_DEVICE_ID";
	
	private final String tempApiKey = "TEMP-" + StringUtil.getRandomNumber(10);

    @Before
    public void setup() throws FatalException {
	/*
		logger.debug("Creating customer with apiKey="+tempApiKey+ " for tests");
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD, "customer.save"),
    		new NameValuePair(Constants.Request.NEW_API_KEY, tempApiKey),
    		new NameValuePair(Constants.Request.NAME, "Temp Customer"),
    		new NameValuePair(Constants.Request.SUBDOMAIN, "temp"),
    		new NameValuePair(Constants.Request.ENABLED, "true")
    	);
		assertTrue(response.get().getCustomer().getApiKey().equals(tempApiKey));*/
    }			

    @After
    public void tearDown() throws FatalException {
	/*
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD, "customer.remove"),
    		new NameValuePair(Constants.Request.API_KEY, tempApiKey)
        );
		assertTrue(response.get().getStatus().equals("ok"));   
*/		
    }
    	/*
	@Test
    public void getCustomerTest() throws Exception {
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"customer.get"),
    		new NameValuePair(Constants.Request.API_KEY,tempApiKey)
    	);
		assertTrue(response.get().getCustomer().getApiKey().equals(tempApiKey));
    }
	
	@Test
    public void saveContactTest() throws Exception {
		
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"device.create"),
    		new NameValuePair(Constants.Request.API_KEY,tempApiKey),
    		new NameValuePair(Constants.Request.NEW_DEVICE_ID,DEFAULT_DEVICE_ID)
    	);		
		
		response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"customer.saveContact"),
    		new NameValuePair(Constants.Request.API_KEY,tempApiKey),
    		new NameValuePair(Constants.Request.NAME,"Temp"),
    		new NameValuePair(Constants.Request.EMAIL,"temp@rewardme.com"),
    		new NameValuePair(Constants.Request.PASSWORD,SecurityUtil.md5("temp")),
    		new NameValuePair(Constants.Request.NEW_DEVICE_ID,DEFAULT_DEVICE_ID)
    	);
		assertTrue(response.get().getCustomer().getCustomerContacts().getCustomerContact().get(0).getName().equals("Temp"));
    }		
	
	@Test
    public void queryTest() throws Exception {		
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"customer.query"),
    		new NameValuePair(Constants.Request.QUERY,"TEMP-")
    	);
		assertTrue(response.get().getCustomers().getCustomer().get(0).getApiKey().equals(tempApiKey));
    }	
	*/
	//TODO: permissions/admin auth need to be restructured before this works properly
	
	@Test
    public void getAdminEvents() throws Exception {
	/*
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"customer.getAdminEvents"),
    		new NameValuePair(Constants.Request.API_KEY,tempApiKey)
    	);
		logger.debug(response);
		assertTrue(response.get().getEvents().getEvent().size() == 1);
		*/
    }

}
