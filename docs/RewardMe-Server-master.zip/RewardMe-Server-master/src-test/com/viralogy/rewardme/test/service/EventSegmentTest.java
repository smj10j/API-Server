package com.viralogy.rewardme.test.service;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.httpclient.NameValuePair;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.test.SimpleTestBase;
import com.viralogy.rewardme.util.Cache;
import com.viralogy.rewardme.util.StringUtil;

public class EventSegmentTest extends SimpleTestBase{
    
	private static Logger logger = Logger.getLogger(EventSegmentTest.class);
	
	
	private final String tempApiKey = "TEMP-" + StringUtil.getRandomNumber(10);
	private final String phoneNumber = "19092405087";
	private final String customerName = "Temp Customer" + StringUtil.getRandomNumber(10);
	private final String address1 = StringUtil.getRandomNumber(8)+" California, Mountain View, CA 94040";
	private final String address2 = StringUtil.getRandomNumber(8)+" California, Mountain View, CA 94040";

	private static long rewardId;
	private static long addressId;
	private static long addressId2;
	private static long userId;
	private static long checkinOptionId;
	
    @Before
    public void setup() throws FatalException, JSONException {
    	testServer.clearCache();//currently needed
    	
		logger.debug("Creating customer with apiKey="+tempApiKey+ " for tests");
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD, "customer.save"),
    		new NameValuePair(Constants.Request.NEW_API_KEY, tempApiKey),
    		new NameValuePair(Constants.Request.NAME, customerName),
    		new NameValuePair(Constants.Request.SUBDOMAIN, "temp"),
    		new NameValuePair(Constants.Request.ENABLED, "true"),
    		new NameValuePair(Constants.Request.PHONE_NUMBER, "5555555555")
    	);
		assertTrue(response.get().getCustomer().getApiKey().equals(tempApiKey));
		
		
		logger.debug("Creating 1st address for tests: "+address1);
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "address.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.ADDRESS, address1),
	    		new NameValuePair(Constants.Request.FORCE, "true"),
	    		new NameValuePair(Constants.Request.ENABLED, "true")
	    	);
		assertTrue(response.get().getCustomer().getAddresses().getAddress().get(0).getAddress().equals(address1));
		addressId = response.get().getCustomer().getAddresses().getAddress().get(0).getAddressId();
		
		logger.debug("Creating 2nd address for tests:"+address2);//for some reason I think this is being added twice.
		response = testServer.get(
		        	new NameValuePair(Constants.Request.METHOD, "address.save"),
		    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
		    		new NameValuePair(Constants.Request.ADDRESS, address2),
		    		new NameValuePair(Constants.Request.FORCE, "true"),
		    		new NameValuePair(Constants.Request.ENABLED, "true")
		    	);
		assertTrue(response.get().getCustomer().getAddresses().getAddress().get(1).getAddress().equals(address2));
		addressId2 = response.get().getCustomer().getAddresses().getAddress().get(1).getAddressId();
		
		logger.debug("Creating user for tests with phone number: " + phoneNumber);
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "user.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NEW_USER_PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.ALLOW_LANDLINE, "true")
	    	);
		assertTrue(response.get().getUser().getPhoneNumber().equals("+"+phoneNumber));
		userId = response.get().getUser().getUserId();
		
		logger.debug("Creating checkin for tests...");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "checkinOption.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "temp"),
	    		new NameValuePair(Constants.Request.TYPE, "VALUE_BASED"),
	    		new NameValuePair(Constants.Request.POINT_AWARD, "10"),
	    		new NameValuePair(Constants.Request.IMAGE_URL, "TEMP"),
	    		new NameValuePair(Constants.Request.REFERRAL_POINT_AWARD, "20"),
	    		new NameValuePair(Constants.Request.RECURRING_REFERRAL_POINT_AWARD, "30"),
	    		new NameValuePair(Constants.Request.COOLDOWN_LENGTH, "0"),
	        	new NameValuePair(Constants.Request.ENABLED, "true")
	    	);
		checkinOptionId = response.get().getCustomer().getCheckinOptions().getCheckinOption().get(0).getCheckinOptionId();
		
		logger.debug("Creating reward for tests...");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "reward.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.HEADLINE, "tempHeadline"),
	    		new NameValuePair(Constants.Request.SHORT_DESCRIPTION, "tempSDESCRIPTION"),//?
	    		new NameValuePair(Constants.Request.DESCRIPTION, "tempDESCRIPTION"),
	    		new NameValuePair(Constants.Request.INSTRUCTIONS, "TempINSTRUCTION"),
	    		new NameValuePair(Constants.Request.TYPE, "FREE"),
	    		new NameValuePair(Constants.Request.POINTS_REQUIRED, "10"),//?
	    		new NameValuePair(Constants.Request.REDEMPTION_LIMIT, "0"),
	    		new NameValuePair(Constants.Request.ENABLED, "true")
	    	);
		rewardId = response.get().getCustomer().getRewards().getReward().get(0).getRewardId();
		
    }			

    @After
    public void tearDown() throws FatalException {
    	//currently causes error
    	try {
	    	Thread.sleep(2000);
	    	
	    	RewardMeResponse response;
			logger.debug("Removing User with phone number: "+phoneNumber);
	    	response = testServer.get(
	            	new NameValuePair(Constants.Request.METHOD, "user.remove"),
	            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	            	new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber)
	            );
			assertTrue(response.get().getStatus().equals("ok"));
		
	    	logger.debug("Removing customer: " + tempApiKey);
			response = testServer.get(
		        	new NameValuePair(Constants.Request.METHOD, "customer.remove"),
		    		new NameValuePair(Constants.Request.API_KEY, tempApiKey)
		        );
			assertTrue(response.get().getStatus().equals("ok"));
			
    	} catch(InterruptedException e) {
    		logger.warn(e);
    	}
    	
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    //extensive test of numberOfVisits.
	@Test
    public void segmentTestNumberOfVisits() throws Exception {
		RewardMeResponse response;
		logger.debug("STARTING EXTENSIVE VISIT TEST ========");
		logger.debug("Adding 6 different checkin segments");
		JSONObject jsonObject = new JSONObject("{\"checkin\": {\"visits\": [{\"numberOfVisits\": \"2\"}]}}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId1 = response.get().getSegment().getSegmentId();
		logger.debug("Segment A: " + jsonObject);
		
		jsonObject = new JSONObject("{\"checkin\": {\"visits\": [{\"numberOfVisits\": \">2\"}]}}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId2 = response.get().getSegment().getSegmentId();
		logger.debug("Segment B: " + jsonObject);
		
		jsonObject = new JSONObject("{\"checkin\": {\"visits\": [{\"numberOfVisits\": \">=2\"}]}}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId3 = response.get().getSegment().getSegmentId();
		logger.debug("Segment C: " + jsonObject);
		
		jsonObject = new JSONObject("{\"checkin\": {\"visits\": [{\"numberOfVisits\": \"<2\"}]}}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId4 = response.get().getSegment().getSegmentId();
		logger.debug("Segment D: " + jsonObject);
		
		jsonObject = new JSONObject("{\"checkin\": {\"visits\": [{\"numberOfVisits\": \"<=2\"}]}}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId5 = response.get().getSegment().getSegmentId();
		logger.debug("Segment E: " + jsonObject);
		
		jsonObject = new JSONObject("{\"checkin\": {\"visits\": [{\"numberOfVisits\": \"2\"}]}}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()));
		long segmentId6 = response.get().getSegment().getSegmentId();
		logger.debug("Segment F:(global) " + jsonObject);
		
		jsonObject = new JSONObject("{\"checkin\": {\"visits\": [{\"numberOfVisits\": \">3\"},{\"numberOfVisits\": \"<5\"}]}}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId7 = response.get().getSegment().getSegmentId();
		logger.debug("Segment G: " + jsonObject);
		
		Thread.sleep(2000);
		
		logger.debug("Checkin 1 to 1st address: <2, <=2 (D,E)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "user.checkin"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
	    		new NameValuePair(Constants.Request.CHECKIN_OPTION_ID, "" + checkinOptionId),
	    		new NameValuePair(Constants.Request.POINT_AWARD, "0")
    		);
		Thread.sleep(2000);
		
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		int sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		int sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 2);
		
		Thread.sleep(2000);
		
		logger.debug("Checkin 1 to 2nd address: Testing global segment: 2 (F)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "user.checkin"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId2),
	    		new NameValuePair(Constants.Request.CHECKIN_OPTION_ID, "" + checkinOptionId),
	    		new NameValuePair(Constants.Request.POINT_AWARD, "0")
    		);
		Thread.sleep(2000);
		
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 3);
		Thread.sleep(2000);
		
		logger.debug("Checkin 2 to 2nd address: Testing removal global segment: 2 (F)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "user.checkin"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId2),
	    		new NameValuePair(Constants.Request.CHECKIN_OPTION_ID, "" + checkinOptionId),
	    		new NameValuePair(Constants.Request.POINT_AWARD, "0")
    		);
		Thread.sleep(2000);
		
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 2);
		Thread.sleep(2000);
		
		logger.debug("Checkin 2 to 1st address: Testing <=2, >=2, 2, (E,C,A) and remove from <2 (D)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "user.checkin"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
	    		new NameValuePair(Constants.Request.CHECKIN_OPTION_ID, "" + checkinOptionId),
	    		new NameValuePair(Constants.Request.POINT_AWARD, "0")
	    		);
		Thread.sleep(2000);
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 3);
		Thread.sleep(2000);
		
		logger.debug("Checkin 3 to 1st address: Testing >=2, >2, (C,B) and removal of <=2, 2 (E,A)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "user.checkin"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
	    		new NameValuePair(Constants.Request.CHECKIN_OPTION_ID, "" + checkinOptionId),
	    		new NameValuePair(Constants.Request.POINT_AWARD, "0")
	    		);
		Thread.sleep(2000);
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 2);
		Thread.sleep(2000);
		
		logger.debug("Checkin 4 to 1st address: Testing >=2, >2, (>3,<5) (C,B,G)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "user.checkin"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
	    		new NameValuePair(Constants.Request.CHECKIN_OPTION_ID, "" + checkinOptionId),
	    		new NameValuePair(Constants.Request.POINT_AWARD, "0")
	    		);
		Thread.sleep(2000);
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 3);
		Thread.sleep(2000);
		
		logger.debug("Removing 7 different kinds of visit segments");
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId1)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId2)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId3)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId4)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId5)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId6)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		logger.debug("PASSED VISIT TEST ==================");
	}
	

    //extensive test of Transactions. Does not test discount.
	@Test
    public void segmentTestTransactions() throws Exception {
		RewardMeResponse response;
		logger.debug("STARTING EXTENSIVE TRANSACTION TEST ========");
		logger.debug("Adding 12 different transaction segments");
		JSONObject jsonObject = new JSONObject("{\"transactions\": [{\"amountSpent\": \"<=11.76\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId1 = response.get().getSegment().getSegmentId();
		logger.debug("Segment A: " + jsonObject);
		
		jsonObject = new JSONObject("{\"transactions\": [{\"amountSpent\": \">=11.76\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId2 = response.get().getSegment().getSegmentId();
		logger.debug("Segment B: " + jsonObject);
		
		jsonObject = new JSONObject("{\"transactions\": [{\"amountSpent\": \"<11.76\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId3 = response.get().getSegment().getSegmentId();
		logger.debug("Segment C: " + jsonObject);
		
		jsonObject = new JSONObject("{\"transactions\": [{\"amountSpent\": \">11.76\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId4 = response.get().getSegment().getSegmentId();
		logger.debug("Segment D: " + jsonObject);
		
		jsonObject = new JSONObject("{\"transactions\": [{\"amountSpent\": \"11.76\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId5 = response.get().getSegment().getSegmentId();
		logger.debug("Segment E: " + jsonObject);
		
		jsonObject = new JSONObject("{\"transactions\": [{\"amountSpent\": \"1.00\",\"paymentMethod\": \"CREDIT\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId6 = response.get().getSegment().getSegmentId();
		logger.debug("Segment F: " + jsonObject);
		
		jsonObject = new JSONObject("{\"transactions\": [{\"amountSpent\": \"1.00\",\"paymentMethod\": \"GIFT_CARD\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId7 = response.get().getSegment().getSegmentId();
		logger.debug("Segment G: " + jsonObject);
		
		jsonObject = new JSONObject("{\"transactions\": [{\"amountSpent\": \"1.00\",\"paymentMethod\": \"DEBIT\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId8 = response.get().getSegment().getSegmentId();
		logger.debug("Segment H: " + jsonObject);
		
		
		jsonObject = new JSONObject("{\"transactions\": [{\"amountSpent\": \"18.76\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId10 = response.get().getSegment().getSegmentId();
		logger.debug("Segment J: " + jsonObject);
		
		jsonObject = new JSONObject("{\"transactions\": [{\"amountSpent\": \"15.26\",\"paymentMethod\": \"CASH\",\"exclude\": \"\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId11 = response.get().getSegment().getSegmentId();
		logger.debug("Segment K: " + jsonObject);
		
		//global segment
		jsonObject = new JSONObject("{\"transactions\": [{\"amountSpent\": \"12.76\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()));
		long segmentId12 = response.get().getSegment().getSegmentId();
		logger.debug("Segment L:(global) " + jsonObject);
		
		jsonObject = new JSONObject("{\"transactions\": [{\"amountSpent\": \"<2.01\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"}, {\"amountSpent\": \">1.99\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId2));
		long segmentId13 = response.get().getSegment().getSegmentId();
		logger.debug("Segment M: " + jsonObject);
		
		Thread.sleep(2000);
		logger.debug("Paid Subtotal $0.01 to 1st address: <, <= (C,A)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "pos.receipt.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.DEVICE_ID, "1"),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
				new NameValuePair(Constants.Request.DATA, "          "+customerName
						+"\n				"
						+"\n				20 Emp 1"
						+"\n				--------------------------------"
						+"\n				      D"
						+"\n				Chk "+StringUtil.getRandomNumber(12)+"       Gst 1"
						+"\n				--------------------------------"
						+"\n				  HERE"
						+"\n				"
						+"\n				**** Tray 1 ****"
						+"\n				1   VB-Honey Wheat     0.01"
						+"\n				"
						+"\n				1   VB-Cinn Raisin     0.00"
						+"\n				"
						+"\n				1   VB-WildRice&Onio   0.00"
						+"\n				"
						+"\n               Subtotal            0.01"
						+"\n               Tax                  0.00"
						+"\n				 Cash                0.01"
						+"\n				Total 0.01"
						+"\n				"
						+"\n				--------------------------------"
						+"\n				            May1612 03:59PM"),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber)
	    		);
		long posReceiptId11 = response.get().getReceipt().getPosTxId();
		Thread.sleep(2000);
		
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		int sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		int sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 2);
		Thread.sleep(2000);
		
		logger.debug("Paid Subtotal $11.75 to 1st address: Testing <=,>=,==, (A,B,E) removal of < (C)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "pos.receipt.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.DEVICE_ID, "1"),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
				new NameValuePair(Constants.Request.DATA, "          "+customerName
						+"\n				"
						+"\n				20 Emp 1"
						+"\n				--------------------------------"
						+"\n				      D"
						+"\n				Chk "+StringUtil.getRandomNumber(12)+"       Gst 1"
						+"\n				--------------------------------"
						+"\n				  HERE"
						+"\n				"
						+"\n				**** Tray 1 ****"
						+"\n				1   VB-Honey Wheat     3.95"
						+"\n				"
						+"\n				1   VB-Cinn Raisin     4.95"
						+"\n				"
						+"\n				1   VB-WildRice&Onio   2.85"
						+"\n				"
						+"\n               Subtotal            11.75"
						+"\n               Tax                  1.50"
						+"\n				 Cash                12.75"
						+"\n				Total 12.75"
						+"\n				"
						+"\n				--------------------------------"
						+"\n				            May1612 03:59PM"),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber)
	    		);
		long posReceiptId1 = response.get().getReceipt().getPosTxId();
		Thread.sleep(2000);
		
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 3);
		Thread.sleep(2000);
		
		logger.debug("Paid Subtotal $1.00 to 2nd address: Testing <=,>=,==, (A,B,E) and the addition of global == (L)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "pos.receipt.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.DEVICE_ID, "1"),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId2),
				new NameValuePair(Constants.Request.DATA, "          "+customerName
						+"\n				"
						+"\n				20 Emp 1"
						+"\n				--------------------------------"
						+"\n				      D"
						+"\n				Chk "+StringUtil.getRandomNumber(12)+"       Gst 1"
						+"\n				--------------------------------"
						+"\n				  HERE"
						+"\n				"
						+"\n				**** Tray 1 ****"
						+"\n				1   VB-Honey Wheat     0.25"
						+"\n				"
						+"\n				1   VB-Cinn Raisin     0.50"
						+"\n				"
						+"\n				1   VB-WildRice&Onio   0.25"
						+"\n				"
						+"\n               Subtotal            1.00"
						+"\n               Tax                  1.50"
						+"\n				 Cash                2.00"
						+"\n				Total 2.00"
						+"\n				"
						+"\n				--------------------------------"
						+"\n				            May1612 03:59PM"),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber)
	    		);
		long posReceiptId2 = response.get().getReceipt().getPosTxId();
		Thread.sleep(2000);
		
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 4);
		Thread.sleep(2000);
		
		logger.debug("Paid Subtotal $1.00 to 1st address: Testing >=, > (B,D) and the removal of <=, ==, global == (A,E,L)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "pos.receipt.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.DEVICE_ID, "1"),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
				new NameValuePair(Constants.Request.DATA, "          "+customerName
						+"\n				"
						+"\n				20 Emp 1"
						+"\n				--------------------------------"
						+"\n				      D"
						+"\n				Chk "+StringUtil.getRandomNumber(12)+"       Gst 1"
						+"\n				--------------------------------"
						+"\n				  HERE"
						+"\n				"
						+"\n				**** Tray 1 ****"
						+"\n				1   VB-Honey Wheat     0.25"
						+"\n				"
						+"\n				1   VB-Cinn Raisin     0.50"
						+"\n				"
						+"\n				1   VB-WildRice&Onio   0.25"
						+"\n				"
						+"\n               Subtotal            1.00"
						+"\n               Tax                  0.00"
						+"\n				 Cash                1.00"
						+"\n				Total 1.00"
						+"\n				"
						+"\n				--------------------------------"
						+"\n				            May1612 03:59PM"),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber)
	    		);
		long posReceiptId3 = response.get().getReceipt().getPosTxId();
		Thread.sleep(2000);
		
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 2);
		Thread.sleep(2000);
		
		logger.debug("Paid Subtotal $1, Tax $0.50 to 1st address: Testing >=,>,w/ TAX (B,D,K)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "pos.receipt.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.DEVICE_ID, "1"),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
				new NameValuePair(Constants.Request.DATA, "          "+customerName
						+"\n				"
						+"\n				20 Emp 1"
						+"\n				--------------------------------"
						+"\n				      D"
						+"\n				Chk "+StringUtil.getRandomNumber(12)+"       Gst 1"
						+"\n				--------------------------------"
						+"\n				  HERE"
						+"\n				"
						+"\n				**** Tray 1 ****"
						+"\n				1   VB-Honey Wheat     0.25"
						+"\n				"
						+"\n				1   VB-Cinn Raisin     0.50"
						+"\n				"
						+"\n				1   VB-WildRice&Onio   0.25"
						+"\n				"
						+"\n               Subtotal            1.00"
						+"\n               Tax                  0.50"
						+"\n				 Cash                1.50"
						+"\n				Total 1.50"
						+"\n				"
						+"\n				--------------------------------"
						+"\n				            May1612 03:59PM"),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber)
	    		);
		long posReceiptId4 = response.get().getReceipt().getPosTxId();
		Thread.sleep(2000);
		
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 3);
		Thread.sleep(2000);
		
		logger.debug("Paid Subtotal $1, Tax $0 to 1st address: Testing >=,>, (B,D) removal of w/ TAX (K)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "pos.receipt.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.DEVICE_ID, "1"),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
				new NameValuePair(Constants.Request.DATA, "          "+customerName
						+"\n				"
						+"\n				20 Emp 1"
						+"\n				--------------------------------"
						+"\n				      D"
						+"\n				Chk "+StringUtil.getRandomNumber(12)+"       Gst 1"
						+"\n				--------------------------------"
						+"\n				  HERE"
						+"\n				"
						+"\n				**** Tray 1 ****"
						+"\n				1   VB-Honey Wheat     0.25"
						+"\n				"
						+"\n				1   VB-Cinn Raisin     0.50"
						+"\n				"
						+"\n				1   VB-WildRice&Onio   0.25"
						+"\n				"
						+"\n               Subtotal            1.00"
						+"\n               Tax                  0.00"
						+"\n				 Cash                1.00"
						+"\n				Total 1.00"
						+"\n				"
						+"\n				--------------------------------"
						+"\n				            May1612 03:59PM"),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber)
	    		);
		long posReceiptId5 = response.get().getReceipt().getPosTxId();
		Thread.sleep(2000);
		
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 2);		
		Thread.sleep(2000);
		
		logger.debug("Paid Subtotal $1 w/ CREDIT to 1st address: Testing >=,>, CREDIT (B,D,F)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "pos.receipt.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.DEVICE_ID, "1"),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
				new NameValuePair(Constants.Request.DATA, "          "+customerName
						+"\n				"
						+"\n				20 Emp 1"
						+"\n				--------------------------------"
						+"\n				      D"
						+"\n				Chk "+StringUtil.getRandomNumber(12)+"       Gst 1"
						+"\n				--------------------------------"
						+"\n				  HERE"
						+"\n				"
						+"\n				**** Tray 1 ****"
						+"\n				1   VB-Honey Wheat     0.25"
						+"\n				"
						+"\n				1   VB-Cinn Raisin     0.50"
						+"\n				"
						+"\n				1   VB-WildRice&Onio   0.25"
						+"\n				"
						+"\n               Subtotal             1.00"
						+"\n               Tax                  0.00"
						+"\n				 Visa               1.00"
						+"\n				Total 1.00"
						+"\n				"
						+"\n				--------------------------------"
						+"\n				            May1612 03:59PM"),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber)
	    		);
		long posReceiptId6 = response.get().getReceipt().getPosTxId();
		Thread.sleep(2000);
		
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 3);
		Thread.sleep(2000);
		
		logger.debug("Paid Subtotal $1 w/ CHECK to 1st address: Testing >=,>, CREDIT, DEBIT(B,D,F,H)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "pos.receipt.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.DEVICE_ID, "1"),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
				new NameValuePair(Constants.Request.DATA, "          "+customerName
						+"\n				"
						+"\n				20 Emp 1"
						+"\n				--------------------------------"
						+"\n				      D"
						+"\n				Chk "+StringUtil.getRandomNumber(12)+"       Gst 1"
						+"\n				--------------------------------"
						+"\n				  HERE"
						+"\n				"
						+"\n				**** Tray 1 ****"
						+"\n				1   VB-Honey Wheat     0.25"
						+"\n				"
						+"\n				1   VB-Cinn Raisin     0.50"
						+"\n				"
						+"\n				1   VB-WildRice&Onio   0.25"
						+"\n				"
						+"\n               Subtotal             1.00"
						+"\n               Tax                  0.00"
						+"\n				 debit                1.00"
						+"\n				Total 1.00"
						+"\n				"
						+"\n				--------------------------------"
						+"\n				            May1612 03:59PM"),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber)
	    		);
		long posReceiptId7 = response.get().getReceipt().getPosTxId();
		Thread.sleep(2000);
		
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 4);
		Thread.sleep(2000);
		
		logger.debug("Paid Subtotal $1 w/ GIFT CARD to 1st address: Testing >=,>, CREDIT, DEBIT, GIFT CARD (B,D,F,H,G)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "pos.receipt.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.DEVICE_ID, "1"),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
				new NameValuePair(Constants.Request.DATA, "          "+customerName
						+"\n				"
						+"\n				20 Emp 1"
						+"\n				--------------------------------"
						+"\n				      D"
						+"\n				Chk "+StringUtil.getRandomNumber(12)+"      Gst 1"
						+"\n				--------------------------------"
						+"\n				  HERE"
						+"\n				"
						+"\n				**** Tray 1 ****"
						+"\n				1   VB-Honey Wheat     0.25"
						+"\n				"
						+"\n				1   VB-Cinn Raisin     0.50"
						+"\n				"
						+"\n				1   VB-WildRice&Onio   0.25"
						+"\n				"
						+"\n               Subtotal             1.00"
						+"\n               Tax                  0.00"
						+"\n				 gift               1.00"
						+"\n				Total 1.00"
						+"\n				"
						+"\n				--------------------------------"
						+"\n				            May1612 03:59PM"),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber)
	    		);
		long posReceiptId8 = response.get().getReceipt().getPosTxId();
		Thread.sleep(2000);
		
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 5);
		Thread.sleep(2000);
		
		logger.debug("Paid Subtotal $1 w/ UNKNOWN to 1st address: Testing >=,>, CREDIT, DEBIT, GIFT CARD, UNKNOWN (B,D,F,H,G,I)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "pos.receipt.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.DEVICE_ID, "1"),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
				new NameValuePair(Constants.Request.DATA, "          "+customerName
						+"\n				"
						+"\n				20 Emp 1"
						+"\n				--------------------------------"
						+"\n				      D"
						+"\n				Chk "+StringUtil.getRandomNumber(12)+"       Gst 1"
						+"\n				--------------------------------"
						+"\n				  HERE"
						+"\n				"
						+"\n				**** Tray 1 ****"
						+"\n				1   VB-Honey Wheat     $0.25"
						+"\n				"
						+"\n				1   VB-Cinn Raisin     $0.50"
						+"\n				"
						+"\n				1   VB-WildRice&Onio   $0.25"
						+"\n				"
						+"\n               Subtotal             $1.00"
						+"\n               Tax                  $0.00"
						+"\n			   Total $1.00"
						+"\n				"
						+"\n				--------------------------------"
						+"\n				            May1612 03:59PM"),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber)
	    		);
		long posReceiptId9 = response.get().getReceipt().getPosTxId();		
		Thread.sleep(2000);
		
		logger.debug("Paid Subtotal $1 to 2nd address: Testing (<2.01, >1.99) (M)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "pos.receipt.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.DEVICE_ID, "1"),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId2),
				new NameValuePair(Constants.Request.DATA, "          "+customerName
						+"\n				"
						+"\n				20 Emp 1"
						+"\n				--------------------------------"
						+"\n				      D"
						+"\n				Chk "+StringUtil.getRandomNumber(12)+"       Gst 1"
						+"\n				--------------------------------"
						+"\n				  HERE"
						+"\n				"
						+"\n				**** Tray 1 ****"
						+"\n				1   VB-Honey Wheat     0.25"
						+"\n				"
						+"\n				1   VB-Cinn Raisin     0.50"
						+"\n				"
						+"\n				1   VB-WildRice&Onio   0.25"
						+"\n				"
						+"\n               Subtotal            1.00"
						+"\n               Tax                  0.00"
						+"\n				 Cash                1.00"
						+"\n				Total 1.00"
						+"\n				"
						+"\n				--------------------------------"
						+"\n				            May1612 03:59PM"),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber)
	    		);
		long posReceiptId10 = response.get().getReceipt().getPosTxId();
		Thread.sleep(2000);
		
		
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId2)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 1);		
		Thread.sleep(2000);
		
		logger.debug("Removing 13 different kinds of transactions segments");
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId1)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId2)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId3)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId4)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId5)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId6)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId7)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId8)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId10)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId11)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId12)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId13)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		/*
		logger.debug("Removing 14 transactions");
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.removeposreceipt"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair("posReceiptId", ""+posReceiptId1)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.removeposreceipt"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair("posReceiptId", ""+posReceiptId2)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.removeposreceipt"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair("posReceiptId", ""+posReceiptId3)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.removeposreceipt"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair("posReceiptId", ""+posReceiptId4)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.removeposreceipt"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair("posReceiptId", ""+posReceiptId5)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.removeposreceipt"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair("posReceiptId", ""+posReceiptId6)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.removeposreceipt"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair("posReceiptId", ""+posReceiptId7)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.removeposreceipt"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair("posReceiptId", ""+posReceiptId8)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.removeposreceipt"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair("posReceiptId", ""+posReceiptId9)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.removeposreceipt"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair("posReceiptId", ""+posReceiptId10)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		*/
		logger.debug("PASSED TRANSACTION TEST ==================");
	}
	
	//extensive test of points. Does not test anything related to pointCategory since we do not want to really implement pointCategories.
	@Test
    public void segmentTestPoints() throws Exception {
		RewardMeResponse response;
		logger.debug("STARTING EXTENSIVE POINTS TEST ========");
		logger.debug("Adding 6 different points segments");
		JSONObject jsonObject = new JSONObject("{\"checkin\": {\"points\": [{\"pointAmount\": \"51\"}]}}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId1 = response.get().getSegment().getSegmentId();
		logger.debug("Segment A: " + jsonObject);
		
		jsonObject = new JSONObject("{\"checkin\": {\"points\": [{\"pointAmount\": \"<51\"}]}}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId2 = response.get().getSegment().getSegmentId();
		logger.debug("Segment B: " + jsonObject);
		
		jsonObject = new JSONObject("{\"checkin\": {\"points\": [{\"pointAmount\": \"<=51\"}]}}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId3 = response.get().getSegment().getSegmentId();
		logger.debug("Segment C: " + jsonObject);
		
		jsonObject = new JSONObject("{\"checkin\": {\"points\": [{\"pointAmount\": \">51\"}]}}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId4 = response.get().getSegment().getSegmentId();
		logger.debug("Segment D: " + jsonObject);
		
		jsonObject = new JSONObject("{\"checkin\": {\"points\": [{\"pointAmount\": \">=51\"}]}}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId5 = response.get().getSegment().getSegmentId();
		logger.debug("Segment E: " + jsonObject);
		
		//global segment
		jsonObject = new JSONObject("{\"checkin\": {\"points\": [{\"pointAmount\": \"101\"}]}}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()));
    	long segmentId6 = response.get().getSegment().getSegmentId();
    	logger.debug("Segment F:(global) " + jsonObject);
    	
		jsonObject = new JSONObject("{\"checkin\": {\"points\": [{\"pointAmount\": \">200\"},{\"pointAmount\": \"<202\"}]}}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
    	long segmentId7 = response.get().getSegment().getSegmentId();
    	logger.debug("Segment G: " + jsonObject);
		Thread.sleep(2000);
		
		logger.debug("Gain of 1 points to 1st address: <51, <=51 (B,C)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "points.credit"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.AMOUNT, "1"),
	    		new NameValuePair(Constants.Request.TYPE, "CHECKIN"),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
	    	);
		Thread.sleep(2000);
		
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		int sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		int sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 2);
		Thread.sleep(2000);
		
		logger.debug("Gain of 50 points to 1st address: Testing <=51, >=51, 51,(C,E,A) and remove from <51 (B)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "points.credit"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.AMOUNT, "50"),
	    		new NameValuePair(Constants.Request.TYPE, "CHECKIN"),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
	    	);
		Thread.sleep(2000);
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 3);
		Thread.sleep(2000);
		
		logger.debug("Gain of another 50 points to 1st address: Testing >=51, >51, global 101 (C,D,F) and removal of <=51, 51 (C,A)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "points.credit"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.AMOUNT, "50"),
	    		new NameValuePair(Constants.Request.TYPE, "CHECKIN"),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
	    	);
		Thread.sleep(2000);
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 3);
		Thread.sleep(2000);
		
		logger.debug("Gain of another 50 points to 2nd address: Testing >=51, >51, (E,D) and removal of global 101 (F)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "points.credit"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.AMOUNT, "50"),
	    		new NameValuePair(Constants.Request.TYPE, "CHECKIN"),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId2)
	    	);
		Thread.sleep(2000);
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 2);
		Thread.sleep(2000);
		
		logger.debug("Redeem something for 100 points at 1st address: Testing >=51, 51, <=51,(E,A,C) and the removal of >51 (D)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "points.debit"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.AMOUNT, "100"),
	    		new NameValuePair(Constants.Request.TYPE, "REDEEM"),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
	    	);
		Thread.sleep(2000);
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 3);
		Thread.sleep(2000);
		
		logger.debug("Gain of 150 points at 1st address: Testing >=51, >51, (>200, <202) (E,D,G) and the removal of 51, <=51 (A,C)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "points.credit"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.AMOUNT, "150"),
	    		new NameValuePair(Constants.Request.TYPE, "CHECKIN"),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
	    	);
		Thread.sleep(2000);
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 3);
		Thread.sleep(2000);
		
		logger.debug("Removing 7 different kinds of visit segments");
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId1)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId2)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId3)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId4)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId5)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId6)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId7)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		logger.debug("PASSED POINTS TEST ==================");
	}
	
	//small test of AND ability.
	@Test
    public void segmentTestANDAbility() throws Exception {
		RewardMeResponse response;
		logger.debug("STARTING AND TEST ========");
		logger.debug("Adding 6 different AND segments");
		JSONObject jsonObject = new JSONObject(
				"{\"checkin\": {\"visits\": [{\"numberOfVisits\": \"1\"}]," +
								"\"points\": [{\"pointAmount\": \"50\"}]}," +
				"\"transactions\": [{\"amountSpent\": \"10\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId1 = response.get().getSegment().getSegmentId();
		logger.debug("Segment A: " + jsonObject);
		
		jsonObject = new JSONObject(
				"{\"checkin\": {\"visits\": [{\"numberOfVisits\": \"1\"}]," +
								"\"points\": [{\"pointAmount\": \"<50\"}]}," +
				"\"transactions\": [{\"amountSpent\": \"<10\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId2 = response.get().getSegment().getSegmentId();
		logger.debug("Segment B: " + jsonObject);
		
		jsonObject = new JSONObject(
				"{\"checkin\": {\"visits\": [{\"numberOfVisits\": \"<2\"}]}," +
				"\"transactions\": [{\"amountSpent\": \"<10\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId3 = response.get().getSegment().getSegmentId();
		logger.debug("Segment C: " + jsonObject);
		
		jsonObject = new JSONObject(
				"{\"checkin\": {\"visits\": [{\"numberOfVisits\": \"1\"}]," +
								"\"points\": [{\"pointAmount\": \"100\"}]}," +
				"\"transactions\": [{\"amountSpent\": \"10\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId2));
		long segmentId4 = response.get().getSegment().getSegmentId();
		logger.debug("Segment D: " + jsonObject);
		
		//global segment
		jsonObject = new JSONObject(
				"{\"checkin\": {\"visits\": [{\"numberOfVisits\": \"2\"}]," +
								"\"points\": [{\"pointAmount\": \"100\"}]}," +
				"\"transactions\": [{\"amountSpent\": \"20\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()));
		long segmentId5 = response.get().getSegment().getSegmentId();
		logger.debug("Segment E:(global) " + jsonObject);
		Thread.sleep(2000);
		
		jsonObject = new JSONObject(
				"{\"checkin\": {\"visits\": [{\"numberOfVisits\": \"<3\"}, {\"numberOfVisits\": \">1\"}]," +
								"\"points\": [{\"pointAmount\": \">149\"}, {\"pointAmount\": \"<151\"}]}," +
				"\"transactions\": [{\"amountSpent\": \"10\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"}, {\"amountSpent\": \"10\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"}, {\"amountSpent\": \"10\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		long segmentId6 = response.get().getSegment().getSegmentId();
		logger.debug("Segment F: " + jsonObject);
		
		logger.debug("Checkin 1 to 1st address: TESTING (C,B)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "user.checkin"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
	    		new NameValuePair(Constants.Request.CHECKIN_OPTION_ID, "" + checkinOptionId),
	    		new NameValuePair(Constants.Request.POINT_AWARD, "0")
	    		);
		Thread.sleep(2000);
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		int sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		int sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 2);
		Thread.sleep(2000);
		
		logger.debug("Paid Subtotal $10.00 to 1st address REMOVAL OF (C,B)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "pos.receipt.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.DEVICE_ID, "1"),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
				new NameValuePair(Constants.Request.DATA, "          "+customerName
						+"\n				"
						+"\n				20 Emp 1"
						+"\n				--------------------------------"
						+"\n				      D"
						+"\n				Chk "+StringUtil.getRandomNumber(12)+"       Gst 1"
						+"\n				--------------------------------"
						+"\n				  HERE"
						+"\n				"
						+"\n				**** Tray 1 ****"
						+"\n				1   VB-Honey Wheat     4.00"
						+"\n				"
						+"\n				1   VB-Cinn Raisin     4.00"
						+"\n				"
						+"\n				1   VB-WildRice&Onio   2.00"
						+"\n				"
						+"\n               Subtotal            10.00"
						+"\n               Tax                  0.00"
						+"\n				 Cash                10.00"
						+"\n				Total 10.00"
						+"\n				"
						+"\n				--------------------------------"
						+"\n				            May1612 03:59PM"),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber)
	    		);
		long posReceiptId1 = response.get().getReceipt().getPosTxId();
		Thread.sleep(2000);
		
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 0);
		Thread.sleep(2000);		
		
		logger.debug("Gain of another 50 points to 1st address, ADD (A)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "points.credit"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.AMOUNT, "50"),
	    		new NameValuePair(Constants.Request.TYPE, "CHECKIN"),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
	    	);
		Thread.sleep(2000);
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 1);
		Thread.sleep(2000);
		
		
		logger.debug("Testing global and 2nd address (E,D) and removal of usersegment (A)");
		logger.debug("Checkin 1 to 2nd address");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "user.checkin"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId2),
	    		new NameValuePair(Constants.Request.CHECKIN_OPTION_ID, "" + checkinOptionId),
	    		new NameValuePair(Constants.Request.POINT_AWARD, "0")
	    		);
		logger.debug("Gain of another 50 points to 2nd address");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "points.credit"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.AMOUNT, "50"),
	    		new NameValuePair(Constants.Request.TYPE, "CHECKIN"),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId2)
	    	);
		logger.debug("Paid Subtotal $10.00 to 2nd address");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "pos.receipt.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.DEVICE_ID, "1"),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId2),
				new NameValuePair(Constants.Request.DATA, "          "+customerName
						+"\n				"
						+"\n				20 Emp 1"
						+"\n				--------------------------------"
						+"\n				      D"
						+"\n				Chk "+StringUtil.getRandomNumber(12)+"       Gst 1"
						+"\n				--------------------------------"
						+"\n				  HERE"
						+"\n				"
						+"\n				**** Tray 1 ****"
						+"\n				1   VB-Honey Wheat     4.00"
						+"\n				"
						+"\n				1   VB-Cinn Raisin     4.00"
						+"\n				"
						+"\n				1   VB-WildRice&Onio   2.850"
						+"\n				"
						+"\n               Subtotal            10.00"
						+"\n               Tax                  0.00"
						+"\n				 Cash                10.00"
						+"\n				Total 10.00"
						+"\n				"
						+"\n				--------------------------------"
						+"\n				            May1612 03:59PM"),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber)
	    		);
		long posReceiptId2 = response.get().getReceipt().getPosTxId();
		Thread.sleep(2000);
		
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId2)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 2);
		Thread.sleep(2000);		
		
		logger.debug("Checkin 2 to 1st address: removal of (A, (global) E)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "user.checkin"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
	    		new NameValuePair(Constants.Request.CHECKIN_OPTION_ID, "" + checkinOptionId),
	    		new NameValuePair(Constants.Request.POINT_AWARD, "0")
	    		);
		Thread.sleep(2000);
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 0);
		Thread.sleep(2000);
		
		logger.debug("Gain of another 50 points to 1st address: Add (F)");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "points.credit"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.AMOUNT, "50"),
	    		new NameValuePair(Constants.Request.TYPE, "CHECKIN"),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
	    	);
		Thread.sleep(2000);
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId),
	        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
				);
		sizeFromNonGlobal = response.get().getUserSegments().getUserSegment().size();
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD,"segment.getAvailableToUser"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.USER_ID,""+ userId)
				);
		sizeFromGlobal = response.get().getUserSegments().getUserSegment().size();
		assertTrue(sizeFromNonGlobal + sizeFromGlobal == 1);
		Thread.sleep(2000);
		
		/*
		logger.debug("Removing 2 transactions");
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.removeposreceipt"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair("posReceiptId", ""+posReceiptId1)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.removeposreceipt"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair("posReceiptId", ""+posReceiptId2)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		*/
		
		logger.debug("Removing 6 different kinds of AND segments");
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId1)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId2)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId3)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId4)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId5)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentId6)
            );
		assertTrue(response.get().getStatus().equals("ok"));
		logger.debug("PASSED AND TEST ==================");
	}
	
    
    /*
    @Test
    public void segmentTimeTest() throws Exception {
		RewardMeResponse response;
		logger.debug("STARTING TIME TEST ========");
		int ITERATIONS = 1000;
		JSONObject jsonObject;
		long segmentId;
		List<Long> listOfSegments = new ArrayList<Long>(1000);
		jsonObject = new JSONObject(
				"{\"checkin\": {\"visits\": [{\"numberOfVisits\": \">0\"},{\"numberOfVisits\": \"<2\"}]," +
								"\"points\": [{\"pointAmount\": \">49\"},{\"pointAmount\": \"<51\"}]}," +
				"\"transactions\": [{\"amountSpent\": \"10\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"},{\"amountSpent\": \"10\",\"paymentMethod\": \"CASH\",\"exclude\": \"tax\"}]}");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "segment.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.NAME, "TEMPName"),
	    		new NameValuePair(Constants.Request.DESCRIPTION, "TEMPDescription"),
	    		new NameValuePair(Constants.Request.DEFINITION, jsonObject.toString()),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, ""+ addressId));
		listOfSegments.add(response.get().getSegment().getSegmentId());
		
		logger.debug("Checkin 1 to 1st address");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "user.checkin"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
	    		new NameValuePair(Constants.Request.CHECKIN_OPTION_ID, "" + checkinOptionId),
	    		new NameValuePair(Constants.Request.POINT_AWARD, "0")
	    		);
		
		logger.debug("Paid Subtotal $10.00 to 1st address");
		response = testServer.get(
	        	new NameValuePair(Constants.Request.METHOD, "pos.receipt.save"),
	    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	    		new NameValuePair(Constants.Request.DEVICE_ID, "1"),
	    		new NameValuePair(Constants.Request.ADDRESS_ID, "" + addressId),
				new NameValuePair(Constants.Request.DATA, "          "+customerName
						+"\n				"
						+"\n				20 Emp 1"
						+"\n				--------------------------------"
						+"\n				      D"
						+"\n				Chk "+StringUtil.getRandomNumber(12)+"       Gst 1"
						+"\n				--------------------------------"
						+"\n				  HERE"
						+"\n				"
						+"\n				**** Tray 1 ****"
						+"\n				1   VB-Honey Wheat     4.00"
						+"\n				"
						+"\n				1   VB-Cinn Raisin     4.00"
						+"\n				"
						+"\n				1   VB-WildRice&Onio   2.00"
						+"\n				"
						+"\n               Subtotal            10.00"
						+"\n               Tax                  0.00"
						+"\n				 Cash                10.00"
						+"\n				Total 10.00"
						+"\n				"
						+"\n				--------------------------------"
						+"\n				            May1612 03:59PM"),
	    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber)
	    		);
		long posReceiptId1 = response.get().getReceipt().getPosTxId();
		Thread.sleep(1000);
		
		for(int i = 0; i < ITERATIONS; i++) {
			response = testServer.get(
		        	new NameValuePair(Constants.Request.METHOD, "points.credit"),
		    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
		    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
		    		new NameValuePair(Constants.Request.AMOUNT, "50"),
		    		new NameValuePair(Constants.Request.TYPE, "CHECKIN"),
		        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
		    	);
			Thread.sleep(2000);
			response = testServer.get(
		        	new NameValuePair(Constants.Request.METHOD, "points.debit"),
		    		new NameValuePair(Constants.Request.API_KEY, tempApiKey),
		    		new NameValuePair(Constants.Request.PHONE_NUMBER, phoneNumber),
		    		new NameValuePair(Constants.Request.AMOUNT, "50"),
		    		new NameValuePair(Constants.Request.TYPE, "REDEEM"),
		        	new NameValuePair(Constants.Request.ADDRESS_ID,""+addressId)
		    	);
			Thread.sleep(2000);
		}
		
		response = testServer.get(
            	new NameValuePair(Constants.Request.METHOD, "segment.removeposreceipt"),
            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
            	new NameValuePair("posReceiptId", ""+posReceiptId1)
            );
		assertTrue(response.get().getStatus().equals("ok"));

		for (Long segmentLong : listOfSegments) {
			response = testServer.get(
	            	new NameValuePair(Constants.Request.METHOD, "segment.remove"),
	            	new NameValuePair(Constants.Request.API_KEY, tempApiKey),
	            	new NameValuePair(Constants.Request.SEGMENT_ID, ""+segmentLong)
	            );
		}
		
    }*/
    
}