package com.viralogy.rewardme.test.service;

import static org.junit.Assert.assertTrue;

import org.apache.commons.httpclient.NameValuePair;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.UserPoints;
import com.viralogy.rewardme.test.SimpleTestBase;

//Commented out until someone fixes this test.
public class PointsTest extends SimpleTestBase{
    
	private static Logger logger = Logger.getLogger(PointsTest.class);
	
	private static final String DEFAULT_DEVICE_ID = "TESTING_DEVICE_ID";
	private static final String DEFAULT_PHONE_NUMBER = "5555555555";
	private static final String DEFAULT_API_KEY = "viralogy";
	private static final String DEFAULT_ADDRESS_ID = "5";
	

	@Before
    public void setup() throws FatalException {
		
    }			
    
    @After
    public void tearDown() throws FatalException {
	
    }
    	
	@Test
    public void creditAndDebitTest() throws Exception {
		/*
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"points.get"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.PHONE_NUMBER, DEFAULT_PHONE_NUMBER)
    	);
		long initialBalance = response.get().getUser().getPoints().getCurrentBalance();
		
		testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"points.credit"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.PHONE_NUMBER, DEFAULT_PHONE_NUMBER),
    		new NameValuePair(Constants.Request.AMOUNT, "500"),
    		new NameValuePair(Constants.Request.TYPE, UserPoints.Type.PROMOTIONAL.toString())
    	);
		response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"points.get"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.PHONE_NUMBER, DEFAULT_PHONE_NUMBER)
    	);
		long postCreditBalance = response.get().getUser().getPoints().getCurrentBalance();

		assertTrue(postCreditBalance == (initialBalance+500));		
		
		testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"points.debit"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.PHONE_NUMBER, DEFAULT_PHONE_NUMBER),
    		new NameValuePair(Constants.Request.AMOUNT, "500"),
    		new NameValuePair(Constants.Request.TYPE, UserPoints.Type.CHEATING.toString())
    	);
		response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"points.get"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.PHONE_NUMBER, DEFAULT_PHONE_NUMBER)
    	);
		long postDebitBalance = response.get().getUser().getPoints().getCurrentBalance();

		assertTrue(postDebitBalance == initialBalance);		
			*/
    }	
	
}
