package com.viralogy.rewardme.test.servlet;

import static org.junit.Assert.assertTrue;

import org.apache.commons.httpclient.NameValuePair;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.social.Social;
import com.viralogy.rewardme.test.SimpleTestBase;

public class GatewayTest extends SimpleTestBase{
    
	private static Logger logger = Logger.getLogger(GatewayTest.class);
	
	private static final String DEFAULT_DEVICE_ID = "TESTING_DEVICE_ID";
	private static final String DEFAULT_PHONE_NUMBER = "5555555555";
	private static final String DEFAULT_API_KEY = "viralogy";
	private static final String DEFAULT_ADDRESS_ID = "5";
	

	@Before
    public void setup() throws FatalException {
		
    }			
    
    @After
    public void tearDown() throws FatalException {
	
    }
    	
	@Test
    public void nonEmptyTest() throws Exception {
		System.out.println("");
		/*
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"address.get"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.ADDRESS_ID,DEFAULT_ADDRESS_ID)
    	);
		assertTrue(response.get().getStatus().equals("ok"));
	
		response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"address.get"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.ADDRESS_ID,"")
    	);
		assertTrue(response.get().getError().getCode().equals(Constants.Error.GATEWAY.MISSING_REQUIRED_PARAMETER));
		*/
    }	
	/*
	@Test
    public void jsonTest() throws Exception {
		
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"device.create"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.NEW_DEVICE_ID,DEFAULT_DEVICE_ID)
    	);
		
		response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"pos.tx.save"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.DEVICE_ID,DEFAULT_DEVICE_ID),
    		new NameValuePair(Constants.Request.DATA,"{}")
    	);
		assertTrue(response.get().getError().getCode().equals(Constants.Error.GENERAL.DEVICE_NO_DEVICE_APPLICATION_EXISTS));	
	
		response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"pos.tx.save"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.DEVICE_ID,DEFAULT_DEVICE_ID),
    		new NameValuePair(Constants.Request.DATA,"5")
    	);
		assertTrue(response.get().getError().getCode().equals(Constants.Error.GENERAL.INVALID_JSON));	
    }		
	
	@Test
    public void typesTest() throws Exception {
				
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"social.checkin"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.PHONE_NUMBER,DEFAULT_PHONE_NUMBER),
    		new NameValuePair(Constants.Request.ADDRESS_ID,DEFAULT_ADDRESS_ID),
    		new NameValuePair(Constants.Request.TYPE,"meow")
    	);
		assertTrue(response.get().getError().getCode().equals(Constants.Error.GATEWAY.INVALID_PARAMETER_TYPE));	
	
		response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"social.checkin"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.PHONE_NUMBER,DEFAULT_PHONE_NUMBER),
    		new NameValuePair(Constants.Request.ADDRESS_ID,DEFAULT_ADDRESS_ID),
    		new NameValuePair(Constants.Request.TYPE,Social.Type.FOURSQUARE.toString())
    	);
		assertTrue(!response.get().getError().getCode().equals(Constants.Error.GATEWAY.INVALID_PARAMETER_TYPE));	
    }		
	
	@Test
    public void userIdentifierTest() throws Exception {
				
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"user.get"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.PHONE_NUMBER,DEFAULT_PHONE_NUMBER)
    	);
		assertTrue(response.get().getStatus().equals("ok"));	
	
		response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"user.get"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.PHONE_NUMBER,"bubbles")
    	);
		assertTrue(response.get().getError().getCode().equals(Constants.Error.PHONE.INVALID_PHONE_NUMBER));	
    }		
	
	@Test
    public void booleanTest() throws Exception {
		
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"user.getCheckins"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.PHONE_NUMBER,DEFAULT_PHONE_NUMBER),
    		new NameValuePair(Constants.Request.SHORT_FORMAT, "true")
    	);
		assertTrue(response.get().getStatus().equals("ok"));	
		assertTrue(response.get().getUser().getShortCheckins() != null);	
	
		response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"user.getCheckins"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.PHONE_NUMBER,DEFAULT_PHONE_NUMBER),
    		new NameValuePair(Constants.Request.SHORT_FORMAT, "bubbles")
    	);
		assertTrue(response.get().getError().getCode().equals(Constants.Error.GATEWAY.INVALID_PARAMETER_TYPE));			
    }		
	
	@Test
    public void longAndIntegerTest() throws Exception {
		
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"customer.getAdminEvents"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.RETURN_COUNT,"ab415")
    	);
		assertTrue(response.get().getError().getCode().equals(Constants.Error.GATEWAY.INVALID_PARAMETER_TYPE));			
		
		response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"address.get"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.ADDRESS_ID,"hello")
    	);
		assertTrue(response.get().getError().getCode().equals(Constants.Error.GATEWAY.INVALID_PARAMETER_TYPE));
		
		response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"address.get"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.ADDRESS_ID,"24.23")
	    );
		assertTrue(response.get().getError().getCode().equals(Constants.Error.GATEWAY.INVALID_PARAMETER_TYPE));			
		
		response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"customer.getAdminEvents"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.RETURN_COUNT,((long)(Integer.MAX_VALUE)+1)+"")
    	);
		assertTrue(response.get().getError().getCode().equals(Constants.Error.GATEWAY.INVALID_PARAMETER_TYPE));	
	
		response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"customer.getAdminEvents"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.RETURN_COUNT,"10")
    	);
		assertTrue(response.get().getStatus().equals("ok"));
    }	
		
	@Test
    public void defaultsTest() throws Exception {
		
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"customer.getAdminEvents"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY)
    	);
		assertTrue(response.get().getEvents().getEvent().size()>0);			
		
		response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"customer.getAdminEvents"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.RETURN_COUNT, "1")
    	);
		assertTrue(response.get().getEvents().getEvent().size()==1);			
    }	
	
	@Test
    public void positiveAndNegativeTest() throws Exception {
		
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"customer.getAdminEvents"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.RETURN_COUNT,"-5")	
    	);
		assertTrue(response.get().getError().getCode().equals(Constants.Error.GATEWAY.INVALID_PARAMETER_TYPE));	
    }	
	
	@Test
    public void dateTest() throws Exception {
		
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"points.get"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.PHONE_NUMBER, DEFAULT_PHONE_NUMBER),
    		new NameValuePair(Constants.Request.START_DATE,"0")	
    	);
		assertTrue(response.get().getStatus().equals("ok"));	
		
		response = testServer.get(
			new NameValuePair(Constants.Request.METHOD,"points.get"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.PHONE_NUMBER, DEFAULT_PHONE_NUMBER),
    		new NameValuePair(Constants.Request.START_DATE,"454")	
    	);
		assertTrue(response.get().getError().getCode().equals(Constants.Error.GATEWAY.INVALID_PARAMETER_TYPE));	
		
		response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"points.get"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.PHONE_NUMBER, DEFAULT_PHONE_NUMBER),
    		new NameValuePair(Constants.Request.START_DATE,"04/25/2011 4:30 PM")	
    	);
		assertTrue(response.get().getStatus().equals("ok"));			
    }	
	
	@Test
    public void postAndGetParameterTest() throws Exception {
		
		RewardMeResponse response = testServer.get(
        	new NameValuePair(Constants.Request.METHOD,"points.get"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.PHONE_NUMBER, DEFAULT_PHONE_NUMBER)
    	);
		assertTrue(response.get().getUser().getPhoneNumber().equals("+1"+DEFAULT_PHONE_NUMBER));	
		
		response = testServer.post(
        	new NameValuePair(Constants.Request.METHOD,"points.get"),
    		new NameValuePair(Constants.Request.API_KEY,DEFAULT_API_KEY),
    		new NameValuePair(Constants.Request.PHONE_NUMBER, DEFAULT_PHONE_NUMBER)
    	);
		assertTrue(response.get().getUser().getPhoneNumber().equals("+1"+DEFAULT_PHONE_NUMBER));	
    }		
*/
}
