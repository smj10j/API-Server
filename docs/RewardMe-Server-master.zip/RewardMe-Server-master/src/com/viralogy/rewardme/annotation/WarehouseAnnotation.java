package com.viralogy.rewardme.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface WarehouseAnnotation {
	String[] dimensions();
	String[] dimensionsToMany();
	String[] facts();
}
