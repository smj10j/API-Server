package com.viralogy.rewardme.conf;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import com.viralogy.rewardme.model.MethodParameter;
import com.viralogy.rewardme.model.SecretKey;
import com.viralogy.rewardme.social.Social;

public abstract class Constants {

	public static final String API_VERSION = "1.9";

	public static class URL {
		public static final String MY_REWARDME = "MyRewardMe.com";
	}

	public static final boolean DEBUG_MODE = false;

	public static final long DAY_IN_MS = 1000 * 60 * 60 * 24;
	public static final double PI = 3.14159;

	public static final String YES = "true";
	public static final String NO = "false";

	public static final String DATE_FORMAT = "yyyy-MM-dd";

	public static final String MEMCACHED_STARTUP_SCRIPT = "/root/startup/memcached-start.sh";
	public static final String[] memcacheServers = { "api-cache-1.rewardme.com:11211" };

	public static String SERVLET_CONTEXT_PATH = null;

	public static class PushNotifications {
		public static class Action {
			public static final int ADMIN_NOTICE = 0;
			public static final int REFERRAL_REQUEST = 1;
			public static final int CUSTOMER_BROADCAST = 2;

		}
	}

	public static enum NotificationType {

		// Customer
		TEXT_APP, 
		TEXT_PROMO, 
		EMAIL_APP, 
		EMAIL_PROMO,

		// RewardMe only
		EMAIL_UPDATES, 
		EMAIL_NEWSLETTER,

		// System-level
		TEXT_SYSTEM, 
		EMAIL_SYSTEM
	}

	public static class Demo {
		public static Set<String> numberIsAlwaysANewUser = new HashSet<String>();
		static {
			numberIsAlwaysANewUser.add("+15555551234");
		}
		
		public static final long DEMO_UNLINKED_DEVICE_APPLICATION_ID = 1;
	}

	public static class CardSpring {
		public static final String SUFFIX = ".json";

		public static class TEST {
			public static final String API_ID = "APNU3Yc9wQjUPo724fDtieDa9M5Tm2rt";
			public static final String API_SECRET = "AnhS4FuByYNfT9thdHrrbsWicVPwZKaY";
			public static final String BASE_URL = "https://api-test.cardspring.com/v1";
			public static final String AUTH_URL = "https://" + API_ID + ":"
					+ API_SECRET + "@api-test.cardspring.com/v1";
		}

		public static class LIVE {
			public static final String API_ID = "";
			public static final String API_SECRET = "";
			public static final String BASE_URL = "https://api.cardspring.com/v1";
		}
	}
	
	public static class Prices {
		public static final int EMAIL = 4;
	}
	
	public static class Request {

		/* Generally required in all requests */
		public static final String METHOD = "method";
		public static final String API_KEY = "apiKey";
		public static final String RESPONSE_FORMAT = "responseFormat";
		public static final String JSCALLBACK = "jsCallback";
		public static final String ASYNC_TOKEN = "asyncToken";
		public static final String VALUE = "value";
		public static final String ADMIN_EMAIL = "adminEmail";
		public static final String ADMIN_PASSWORD = "adminPassword";
		public static final String SIGNATURE = "signature";
		public static final String TIMESTAMP = "timestamp";

		/* Inventory items */
		public static final String SERIAL = "serial";

		/* Internal */
		public static final String INTERNAL_RETRY_FOR_RACE_CONDITION = "retryAfterPotentialRaceCondition";

		/* Permission */
		public static final String PUBLIC_ONLY = "publicOnly";
		public static final String PRIVATE = "private";

		/* General */
		public static final String DATA = "data";
		public static final String DATA2 = "data2";
		public static final String TOKEN = "token";
		public static final String CHECKIN_RADIUS = "checkinRadius";
		public static final String EMAIL = "email";
		public static final String PASSWORD = "password";
		public static final String SECONDS_AGO = "secondsAgo";
		public static final String ENABLED = "enabled";
		public static final String AMOUNT = "amount";
		public static final String FEATURE = "feature";
		public static final String URL = "url";
		public static final String FORMAT = "format";
		public static final String DELIVERY_TIMESTAMP = "deliveryTime";
		public static final String EVENT_NAME = "eventName";
		public static final String EVENT_VALUE = "eventValue";
		public static final String ASYNC = "async";
		public static final String SHORT_FORMAT = "shortFormat";
		public static final String UNIQUE_CUSTOMERS_ONLY = "uniqueCustomersOnly";
		public static final String SHOW_ALL_CUSTOMERS = "showAllCustomers";
		public static final String AUTH_CODE = "authCode";
		public static final String AUTH_CODE_TIMESTAMP = "authCodeTimestamp";
		public static final String SUBDOMAIN = "subdomain";
		public static final String OBSERVATIONS = "observations";
		public static final String HTML = "html";
		public static final String OPTIONS = "options";
		public static final String REQUEST = "request";
		public static final String WITH_AUTHENTICATED_CUSTOMERS = "withAuthenticatedCustomers";
		public static final String ALLOW_LANDLINE = "allowLandline";
		public static final String POINT_CATEGORY = "pointCategory";
		public static final String POINT_CATEGORY_ID = "pointCategoryId";
		public static final String TRIGGER_DATE = "triggerDate";
		public static final String DEFINITION = "definition";

		/* IDs */
		public static final String USER_ID = "userId";
		public static final String DEVICE_ID = "deviceId";
		public static final String NEW_DEVICE_ID = "newDeviceId";
		public static final String OTHER_DEVICE_ID = "otherDeviceId";
		public static final String RECIPIENT_DEVICE_ID = "recipientDeviceId";
		public static final String SCHEDULE_ID = "scheduleId";
		public static final String ADDRESS_ID = "addressId";
		public static final String CHECKIN_OPTION_ID = "checkinOptionId";
		public static final String REWARD_ID = "rewardId";
		public static final String LOTTERY_ID = "lotteryId";
		public static final String SERVER_ID = "serverId";
		public static final String CUSTOMER_CONTACT_ID = "customerContactId";
		public static final String CUSTOMER_ID = "customerId";
		public static final String ADMIN = "admin";
		public static final String USER_REFERRAL_REQUEST_ID = "userReferralRequestId";
		public static final String CUSTOMER_BILLING_ID = "customerBillingId";
		public static final String NEW_USER_PHONE_NUMBER = "newUserPhoneNumber";
		public static final String SURVEY_ID = "surveyId";
		public static final String USER_MESSAGE_ID = "userMessageId";
		public static final String CUSTOMER_FEATURE_ID = "customerFeatureId";
		public static final String ADMIN_SECRET_KEY_ID = "adminSecretKeyId";
		public static final String SECRET_KEY_ID = "secretKeyId";
		public static final String PERIPHERAL_ID = "peripheralId";
		public static final String EXTERNAL_PERIPHERAL_ID = "externalPeripheralId";
		public static final String APPLICATION_ID = "applicationId";
		public static final String DEVICE_APPLICATION_ID = "deviceApplicationId";
		public static final String NEW_API_KEY = "newApiKey";
		public static final String INVENTORY_ITEM_ID = "inventoryItemId";
		public static final String POS_TX_ID = "posTxId";
		public static final String SCHEDULED_TRIGGER_ID = "scheduledTriggerId";
		public static final String UNLINKED_DEVICE_APPLICATION_ID = "unlinkedDeviceApplicationId";
		public static final String SEGMENT_ID = "segmentId";

		
		//ABTest stuff
		public static final String AB_TEST_ID = "abTestId";
		public static final String DISPLAY_COHORT_ID = "displayCohortId";
		public static final String COHORT_ID = "cohortId";
		public static final String AB_TEST_NAME = "testName";
		public static final String METRIC = "metric";
		public static final String CRITERION = "criterion";
		public static final String NUM_COHORTS = "numCohorts";
		public static final String METRIC_TYPE = "metricType";
		public static final String TIMES_SEEN = "timesSeen";
		
		//Stripe stuff
		public static final String CARD_TOKEN = "cardToken";
		public static final String CURRENCY = "currency";
		public static final String OFFSET = "offset";
		public static final String PLAN = "plan";
		public static final String STRIPE_API_KEY = "nSgoEg8zfEDgMeewNRKrvYB6I7ynqlPn"; //test key
		
		/* Mostly Address */
		public static final String NAME = "name";
		public static final String TYPE = "type";
		public static final String ADDRESS = "address";
		public static final String QUERY = "query";
		public static final String RETURN_COUNT = "returnCount";
		public static final String START_PAGE_INDEX = "startPageIndex";
		public static final String LATITUDE = "latitude";
		public static final String LONGITUDE = "longitude";
		public static final String RADIUS = "radius";
		public static final String FORCE = "force";
		public static final String IMAGE_URL = "imageUrl";
		public static final String IMAGE_URL_SMALL = "imageUrlSmall";
		public static final String COOLDOWN_LENGTH = "cooldownLength";
		public static final String LOCATION = "location";

		/* Mostly Schedule */
		public static final String DAY_OF_WEEK = "dayOfWeek";
		public static final String START_TIME = "startTime";
		public static final String END_TIME = "endTime";
		public static final String IGNORE_SCHEDULES = "ignoreSchedules";
		public static final String MULTIPLIER = "multiplier";

		/* Mostly Reward */
		public static final String HEADLINE = "headline";
		public static final String SHORT_DESCRIPTION = "shortDescription";
		public static final String DESCRIPTION = "description";
		public static final String INSTRUCTIONS = "instructions";
		public static final String POINTS_REQUIRED = "pointsRequired";
		public static final String REDEMPTION_LIMIT = "redemptionLimit";
		public static final String START_DATE = "startDate";
		public static final String END_DATE = "endDate";
		public static final String CODE = "code";
		public static final String IS_PROMOTED = "isPromoted";
		public static final String MD5_PIN_CODE = "md5PinCode";
		public static final String NEW_MD5_PIN_CODE = "newMd5PinCode";
		public static final String AUTO_COMPLETE = "autoComplete";
		public static final String ATTRIBUTE_NAME = "attributeName";
		public static final String COUNT = "count";

		/* Mostly Demographics */
		public static final String DEVICE_OSNAME = "device.osName";
		public static final String DEVICE_OSVERSION = "device.osVersion";
		public static final String DEVICE_MODEL = "device.model";
		public static final String DEVICE_PHONE_NUMBER = "device.phoneNumber";
		public static final String DEVICE_REMOTE_UUID = "device.remoteUUID";
		public static final String USER_DISPLAY_NAME = "user.displayName";
		public static final String USER_USERNAME = "user.username";
		public static final String API_VERSION = "app.apiVersion";

		/* Mostly Checkin Options */
		public static final String POINT_AWARD = "pointAward";
		public static final String REFERRAL_POINT_AWARD = "referralPointAward";
		public static final String RECURRING_REFERRAL_POINT_AWARD = "recurringReferralPointAward";

		/* Mostly Phone and Notifications */
		public static final String PHONE_NUMBER = "phoneNumber";
		public static final String MESSAGE = "message";
		public static final String ACTION = "action";
		public static final String BODY = "body";
		public static final String FIRST_NAME = "firstName";
		public static final String PUSH = "push";
		public static final String UNREAD_ONLY = "unreadOnly";
		public static final String CUSTOMER_BROADCAST_MESSAGE_ID = "customerBroadcastMessageId";
		public static final String USERNAME = "username";
		public static final String REFERRED_PHONE_NUMBER = "referredPhoneNumber";
		public static final String NOTIFICATION_TYPE = "notificationType";

		/* Freshbooks Webhooks */
		public static final String SYSTEM = "system";
		public static final String FRESHBOOKS_METHOD = "name";

		/* Social Integration */
		public static final String SOCIAL_TYPE = "type";
		public static final String FACEBOOK_ID = "facebookId";
		public static final String TWITTER_ID = "twitterId";
		public static final String FOURSQUARE_ID = "foursquareId";

		/* Survey */
		public static final String AVAILABLE_ON_MOBILE = "availableOnMobile";
		public static final String CONTENT = "content";
		public static final String ABLE_TO_SHOW_RESULTS = "ableToShowResults";
		public static final String USER_SURVEY_ID = "userSurveyId";
		public static final String RESPONSE = "response";
		public static final String ENABLED_ONLY = "enabledOnly";
		public static final String SUBJECT = "subject";

		/* Session */
		public static final String SESSION_ID = "sessionId";

		/* Rating */
		public static final String SCORE = "score";

		public static final String REMOVE_ON_SUCCESS = "removeOnSuccess";

		public static final class POS {
			public static final String EXTERNAL_POS_ITEM_ID = "externalPosItemId";
			public static final String EXTERNAL_POS_ITEM_MOD_ID = "externalPosItemModId";
		}

		public static final class Reporting {
			public static final String REPORT_ID = "reportId";
			public static final String DEFINITION = "definition";
			public static final String PERIOD_TYPE = "periodType";
			public static final String GROUP_NAME = "groupName";
		}

		/* Set by the initialization servlet */
		public static Map<String, List<String>> methodFilters = new HashMap<String, List<String>>();
		public static final String METHOD_FILTER_NO_API_REQUIRED = "NoApiKeyRequired";
		public static final String METHOD_FILTER_REQUIRES_ADMIN_AUTHENTICATION = "RequiresAdminAuthentication";
		public static final String METHOD_FILTER_REQUIRES_SIGNATURE = "RequiresSignature";
		public static final String METHOD_FILTER_REQUIRES_ADMIN_SIGNATURE = "RequiresAdminSignature";

		public static List<SecretKey> ADMIN_SECRET_KEYS = new ArrayList<SecretKey>();
		public static Map<String, String> WHITELISTED_SERVERS = new HashMap<String, String>();
		
		/* SES email stuff */
		public static final String EMAIL_RECIPIENTS = "recipients";
		public static final String FILE_FORMAT = "fileFormat";
		public static final String SENDER = "sender";
		
		/* Device-specific */
		public static final String REMOTE_DEVICE_UUID = "remoteDeviceUUID";
		public static final String OS_NAME = "osName";
		public static final String OS_VERSION = "osVersion";
		public static final String MODEL = "model";
		

	}

	public static class Freshbooks {

		public static final float DEFAULT_TABLET_FEE = .15f;
		public static final float DEFAULT_SERVICE_FEE_PER_ADDRESS = 1.05f;
		public static final long DEFAULT_USER_ID = 1;
		public static final int NUMBER_TABLETS_PER_ADDRESS = 2;

		public static final int DAYS_TILL_REMINDER = 30;

		public static final String SERVICE_FEE_ITEM_NAME = "Service Fee";
		public static final String TABLET_ITEM_NAME = "Tablet Leasing";

		public static final String SERVICE_FEE_ITEM_DESCRIPTION = "The RewardMe service cost for each business location.";
		public static final String TABLET_ITEM_DESCRIPTION = "The leasing fee for each RewardMe tablet";

		public static final String REQUEST = "request";
		public static final String METHOD = "method";
		public static final String METHOD_SUCCESSFUL = "ok";
		public static final String STATUS = "status";
		public static final String PAID = "paid";
		public static final String DATE = "date";
		public static final String AMOUNT = "amount";

		// Freshbook methods
		public static final String CREATE_CLIENT = "client.create";
		public static final String UPDATE_CLIENT = "client.update";
		public static final String DELETE_CLIENT = "client.delete";
		public static final String GET_RECURRING = "recurring.get";
		public static final String CREATE_RECURRING = "recurring.create";
		public static final String DELETE_RECURRING = "recurring.delete";
		public static final String CREATE_INVOICE = "invoice.create";
		public static final String GET_INVOICE = "invoice.get";
		public static final String LIST_INVOICE = "invoice.list";
		public static final String CREATE_PAYMENT = "payment.create";
		public static final String GET_PAYMENT = "payment.get";

		public static final String OBJECT_ID = "object_id";

		public static final String CLIENT = "client";
		public static final String CLIENT_ID = "client_id";
		public static final String FIRST_NAME = "first_name";
		public static final String LAST_NAME = "last_name";
		public static final String ORGANIZATION = "organization";
		public static final String EMAIL = "email";
		public static final String USERNAME = "username";
		public static final String PASSWORD = "password";

		public static final String RECURRING = "recurring";
		public static final String RECURRING_ID = "recurring_id";
		public static final String FREQUENCY = "frequency";
		public static final String MONTHLY = "monthly";

		public static final String INVOICE = "invoice";
		public static final String INVOICE_ID = "invoice_id";

		public static final String USER_ID = "user_id";

		public static final String PAYMENT = "payment";
		public static final String PAYMENT_ID = "payment_id";

		public static final String LINES = "lines";
		public static final String LINE = "line";
		public static final String NAME = "name";
		public static final String DESCRIPTION = "description";
		public static final String UNIT_COST = "unit_cost";
		public static final String QUANTITY = "quantity";

		public static Map<String, String> methodToRequestType = new ConcurrentHashMap<String, String>();
		static {
			methodToRequestType.put(CREATE_CLIENT, CLIENT);
			methodToRequestType.put(UPDATE_CLIENT, CLIENT);
			methodToRequestType.put(GET_RECURRING, RECURRING_ID);
			methodToRequestType.put(GET_INVOICE, INVOICE_ID);
			methodToRequestType.put(CREATE_RECURRING, RECURRING);
			methodToRequestType.put(GET_PAYMENT, PAYMENT_ID);
			methodToRequestType.put(DELETE_CLIENT, CLIENT_ID);
		}
	   
	    public static Map<String, String> methodToResponseType = new ConcurrentHashMap<String, String>();
	    static {
	        methodToResponseType.put( CREATE_CLIENT, CLIENT_ID );
	        methodToResponseType.put( CREATE_RECURRING, RECURRING_ID );
	        methodToResponseType.put( GET_INVOICE, INVOICE );
	        methodToResponseType.put( GET_PAYMENT, PAYMENT);
	    }
	    	    
	}

	public static class UserPreference {

		public static final String EMAIL = "email";
		public static final String CHANGED_PIN = "changed_pin";

		public static final String FACEBOOK_INTENT_TO_SHARE = "facebook_intent_to_share";
		public static final String TWITTER_INTENT_TO_SHARE = "twitter_intent_to_share";
		public static final String FOURSQUARE_INTENT_TO_SHARE = "foursquare_intent_to_share";

		public static final String FACEBOOK_ACCESS_TOKEN = "facebook_access_token";
		public static final String TWITTER_ACCESS_TOKEN = "twitter_access_token";
		public static final String TWITTER_ACCESS_TOKEN_SECRET = "twitter_access_token_secret";
		public static final String FOURSQUARE_ACCESS_TOKEN = "foursquare_access_token";

		public static final String NOTIFICATION_TEXT_OPT_IN_INITIATED = "notification_text_opt_in_initiated";

		public static final String NOTIFICATION_TEXT_ALL = "notification_text_all";
		public static final String NOTIFICATION_TEXT_PROMO = "notification_text_promo";
		public static final String NOTIFICATION_TEXT_APP = "notification_text_app";

		public static final String NOTIFICATION_EMAIL_ALL = "notification_email_all";
		public static final String NOTIFICATION_EMAIL_PROMO = "notification_email_promo";
		public static final String NOTIFICATION_EMAIL_APP = "notification_email_app";
		public static final String NAME = "name";

		public static final String FAVORITE_ADDRESS_ID = "favorite_address_id";

		public static Map<Social.Type, String> socialTypeToAccessTokenPreferenceName = new ConcurrentHashMap<Social.Type, String>();
		static {
			socialTypeToAccessTokenPreferenceName.put(Social.Type.FACEBOOK,
					FACEBOOK_ACCESS_TOKEN);
			socialTypeToAccessTokenPreferenceName.put(Social.Type.TWITTER,
					TWITTER_ACCESS_TOKEN);
			socialTypeToAccessTokenPreferenceName.put(Social.Type.FOURSQUARE,
					FOURSQUARE_ACCESS_TOKEN);
		}
	}

	public static class CustomerPreference {

		public static class Keys {
			public static final String FACEBOOK_PLACE_ID = "facebook_place_id";
			public static final String FACEBOOK_FAN_PAGE_ID = "facebook_fan_page_id";
			public static final String FACEBOOK_CHECKIN_MESSAGE = "facebook_checkin_message";

			public static final String TWITTER_ID = "twitter_id";
			public static final String TWITTER_CHECKIN_MESSAGE = "twitter_checkin_message";

			public static final String FOURSQUARE_VENUE_ID = "foursquare_venue_id";
			public static final String FOURSQUARE_CHECKIN_MESSAGE = "foursquare_checkin_message";

			public static final String NEW_USER_SIGNUP_MESSAGE = "new_user_signup_message";
		}

		public static class Default {
			public static final String NEW_USER_SIGNUP_MESSAGE = "Welcome to %NAME% Rewards!\nReply YES to join text club.\nManage your account at %SUBDOMAIN%."
					+ Constants.URL.MY_REWARDME;

		}
	}

	public static class Oauth {

		public static final String OAUTH = "OAuth";

		public static final String CLIENT_ID = "client_id";
		public static final String REDIRECT_URI = "redirect_uri";
		public static final String AUTH_CODE = "code";
		public static final String RESPONSE_TYPE = "response_type";
		public static final String CLIENT_SECRET = "client_secret";
		public static final String ACCESS_TOKEN = "access_token";

		public static final String GRANT_TYPE = "grant_type";
		public static final String AUTHORIZATION_CODE = "authorization_code";

		public static final String OAUTH_TOKEN = "oauth_token";
		public static final String OAUTH_CALLBACK = "oauth_callback";
		public static final String OAUTH_CONSUMER_KEY = "oauth_consumer_key";
		public static final String OAUTH_NONCE = "oauth_nonce";
		public static final String OAUTH_SIGNATURE_METHOD = "oauth_signature_method";
		public static final String OAUTH_TIMESTAMP = "oauth_timestamp";
		public static final String OAUTH_VERSION = "oauth_version";
		public static final String OAUTH_SIGNATURE = "oauth_signature";
		public static final String OAUTH_VERIFIER = "oauth_verifier";

		public static final String SUCCESSFUL_CONNECT_CONFIRMATION_URL = "http://"
				+ Constants.URL.MY_REWARDME + "/page/Social";
	}

	public static class SocialSite {

		public static final String DEFAULT_CHECKIN_MESSAGE = "I'm at %s!";
	}

	public static class Facebook {

		// in meters
		public static final int SEARCH_DISTANCE = 1000;

		public static final String ID = "id";

		public static final String PERMISSIONS = "scope";

		public static final String TYPE = "type";
		public static final String MESSAGE = "message";
		public static final String TAGS = "tags";

		public static final String PLACE = "place";
		public static final String COORDINATES = "coordinates";
		public static final String CENTER = "center";
		public static final String DISTANCE = "distance";
		public static final String QUERY = "q";
		public static final String LOCATION = "location";
		public static final String STREET = "street";
		public static final String CHECKINS = "checkins";

		public static final String ERROR = "error";
		public static final String DATA = "data";

	}

	public static class Twitter {

		public static final String POST = "POST";
		public static final String AUTHORIZATION = "Authorization";
		public static final String STATUS = "status";

		public static final String ERROR = "error";
	}

	public static class Foursquare {
		public static final String QUERY = "query";
		public static final String COORDINATES = "ll";
		public static final String VERSION = "v";

		public static final String RESPONSE = "response";
		public static final String VENUES = "venues";
		public static final String ID = "id";
		public static final String VENUE_ID = "venueId";
		public static final String SHOUT = "shout";
		public static final String BROADCAST_TYPE = "broadcast";
		public static final String PUBLIC = "public";

		public static final String LOCATION = "location";
		public static final String ADDRESS = "address";
		public static final String POSTAL_CODE = "postalCode";
		public static final String DISTANCE = "distance";
		public static final String STATS = "stats";
		public static final String CHECKINS_COUNT = "checkinsCount";

	}

	public static class Time {
		public static final long MINUTE = 60;
		public static final long HOUR = MINUTE * 60;
	}

	// all in meters
	public static class Distance {
		public static final double RADIUS_OF_EARTH = 6371010.0; // in meters
		public static final double FEET_PER_METER = 3.2808;
		public static final double METERS_PER_MILE = 1609.344;

		public static final int DEFAULT_CHECKIN = 1000;
		public static final int NEARBY = (int) (METERS_PER_MILE * 25.0);
	}

	public static class Path {
		public static final String JaxbPackage = "com.viralogy.rewardme.jaxb";
	}

	public static class Error {

		public static final class GENERAL {
			public static final int YELP_NO_BUSINESS_FOUND_FOR_ADDRESS_AND_NAME = 100;
			public static final int CUSTOMER_ALREADY_EXISTS = 101;
			public static final int INVALID_COORDS_FOR_REVERSE_GEOCODING = 102;
			public static final int INVALID_SCHEDULE_VALUES = 103;
			public static final int INVALID_JSON = 104;
			public static final int TWILIO_API_ERROR = 105;
			public static final int INVALID_APNS_PAYLOAD = 107;
			public static final int INVALID_SCHEDULE_TIMES = 108;
			public static final int DISABLED_CUSTOMER = 109;
			public static final int CUSTOMER_BROADCAST_MESSAGE_ALREADY_SENT = 110;
			public static final int FEATURE_EXISTS_ALREADY = 111;
			public static final int FEATURE_CANNOT_USE_FEATURE = 112;
			public static final int INVALID_MESSAGE_LENGTH = 113;
			public static final int CONTACT_CUSTOMER_HAS_NO_CUSTOMER_CONTACT = 114;
			public static final int USER_ALREADY_EXISTS_WITH_PHONE_NUMBER = 115;
			public static final int INVALID_USER_PREFERENCE_NAME = 116;
			public static final int DEVICE_ALREADY_EXISTS = 117;
			public static final int DEVICE_NO_DEVICE_APPLICATION_EXISTS = 118;
			public static final int DEVICE_NO_DEVICE_LINK_EXISTS = 119;
			public static final int DEVICE_NO_DEVICE_LINK_EXISTS_FOR_DEVICES = 120;
			public static final int INVALID_USER_AND_PREFERENCE_NAME_COMBINATION = 121;
			public static final int USER_MESSAGE_ALREADY_SENT = 122;
			public static final int INVALID_EVENT_TRIGGER_TYPE = 123;
			public static final int INVALID_CUSTOMER_PREFERENCE_NAME = 124;
			public static final int BATCH_CHAIN_LOOP = 125;
			public static final int BATCH_CHAIN_BAD_FORMAT_APICALL = 126;
			public static final int PHONE_NUMBER_ALREADY_IN_USE = 127;
			public static final int REQUEST_REPLAY_BAD_FORMAT_APICALL = 128;
			public static final int INVALID_SQL_QUERY = 129;
			public static final int NAME = 130;
			public static final int SCHEDULED_TRIGGER_ALREADY_ARCHIVED_OR_TRIGGERED = 131;
		}				


		public static final class PERMISSIONS {
			public static final int INVALID_AUTHENTICATION = 200;
			public static final int CANNOT_RESPOND_TO_SOMEONE_ELSES_REFERRAL = 201;
			public static final int CONTACT_DOESNT_MATCH_CUSTOMER = 202;
			public static final int INVALID_CUSTOMER_PERMISSIONS_READ = 203;
			public static final int INVALID_CUSTOMER_PERMISSIONS_WRITE = 204;
			public static final int CUSTOMER_DOES_NOT_MATCH = 205;
			public static final int INVALID_GENERAL = 206;
			public static final int INVALID_ADDRESS_FOR_CUSTOMER = 207;
			public static final int INVALID_PINCODE_AUTHENTICATION = 208;
			public static final int INVALID_DEVICE_APPLICATION_PERMISSIONS_READ = 209;
			public static final int INVALID_AUTH_CODE = 210;
			public static final int SIGNATURE_INVALID_AUTH_CODE_IN_THE_FUTURE = 211;
			public static final int INVALID_AUTH_CODE_EXPIRED = 212;
		}

		public static final class SURVEY {
			public static final int INVALID_SURVEY_LENGTH = 220;
			public static final int USER_SURVEY_ALREADY_SENT = 221;
			public static final int USER_ALREADY_TAKING_SURVEY = 222;
			public static final int CUSTOMER_HAS_NO_SURVEY = 223;
			public static final int USER_ALREADY_RESPONDED_TO_SURVEY = 224;
			public static final int CUSTOMER_HAS_NO_UNTAKEN_SURVEYS = 225;
		}

		public static final class SOCIAL {
			public static final int INVALID_TYPE = 240;
			public static final int NOT_ENABLED = 241;
			public static final int ALREADY_ENABLED = 242;
			public static final int ALREADY_DISABLED = 243;
			public static final int FACEBOOK_NO_PLACEID_FOUND_OR_SETUP = 244;
			public static final int INVALID_ACCESS_TOKEN = 245;
			public static final int FACEBOOK_ONLY = 246;
		}

		public static final class CHECKIN {
			public static final int INVALID_CHECKIN_INFORMATION = 260;
			public static final int TOO_FREQUENT = 261;
			public static final int NOT_AVAILABLE_AT_THIS_TIME = 262;
			public static final int POINT_AWARD_MUST_BE_SPECIFIED_FOR_VALUE_BASED_CHECKINS = 263;
			public static final int POINT_AWARD_MUST_NOT_BE_SPECIFIED_FOR_VISIT_BASED_CHECKINS = 264;
		}

		public static final class REFERRAL {
			public static final int ALREADY_VISITED = 280;
			public static final int REFERRAL_SELF = 281;
			public static final int ALREADY_REFERRED = 282;
			public static final int LOCATION_NOT_VISITED_BY_REFERRER = 283;
		}

		public static final class BILLING {
			public static final int NO_INVOICE_ITEM_WITH_PROVIDED_PARAMETERS = 300;
			public static final int NO_BILLING_FOR_CUSTOMER = 301;
			public static final int FRESHBOOKS_NOT_SYNCED = 302;
			public static final int CUSTOMER_HAS_NO_BILLING = 303;
			public static final int NO_RECURRING_FOR_CUSTOMER = 304;
		}

		public static final class REDEEM {
			public static final int REWARD_IS_ALREADY_ACTIVE = 320;
			public static final int REWARD_IS_NOT_AVAILABLE = 321;
			public static final int REWARD_CAN_NOT_BE_REDEEMED = 322;
			public static final int USER_HAS_NOT_CHECKED_IN_BUT_TRIED_TO_REDEEM = 323;
		}

		public static final class POINTS {
			public static final int INSUFFICIENT_POINTS = 340;
			public static final int ONLY_ONE_TRANSFER_PER_ACCOUNT_ALLOWED = 341;
		}

		public static final class PHONE {
			public static final int INVALID_MOBILE_PHONE_NUMBER = 360;
			public static final int INVALID_PHONE_NUMBER = 361;
			public static final int UNKNOWN_PHONE_NUMBER = 362;
		}

		public static final class INVALID_ID {

			public static final int API_KEY = 400;
			public static final int USER_ID = 401;
			public static final int DEVICE_ID = 402;
			public static final int ADDRESS_ID = 403;
			public static final int REWARD_ID = 404;
			public static final int ADDRESS_STRING = 405;
			public static final int CUSTOMER_ID = 406;
			public static final int CHECKIN_OPTION_ID = 407;
			public static final int DEVICE_LINK_EVENT_ID = 408;
			public static final int CUSTOMER_CONTACT_ID = 409;
			public static final int SCHEDULE_ID = 410;
			public static final int DEVICE_PHONE_NUMBER = 411;
			public static final int DEVICE_REMOTE_UUID = 412;
			public static final int USER_REFERRAL_REQUEST_ID = 413;
			public static final int CUSTOMER_BROADCAST_MESSAGE_ID = 414;
			public static final int USERNAME = 415;
			public static final int CUSTOMER_FEATURE_ID = 416;
			public static final int CUSTOMER_FEATURE_CUSTOMER_AND_FEATURE = 417;
			public static final int RECURRING_ID = 418;
			public static final int CUSTOMER_BILLING_ID = 419;
			public static final int INVOICE_ID = 420;
			public static final int SERVER_ID = 421;
			public static final int FRESHBOOKS_INVOICE_ID = 422;
			public static final int USER_PHONE_NUMBER = 423;
			public static final int USER_MESSAGE_ID = 424;
			public static final int SURVEY_ID = 425;
			public static final int USER_SURVEY_ID = 426;
			public static final int USER_ID_AND_SURVEY_ID = 427;
			public static final int EMPLOYEE_ID = 428;
			public static final int INVENTORY_ITEM_ID = 429;
			public static final int INVENTORY_ITEM_MOD_ID = 430;
			public static final int INVENTORY_CATEGORY_ID = 431;
			public static final int DISCOUNT_ID = 432;
			public static final int INVENTORY_ITEM_MOD_EXTERNAL_ID = 433;
			public static final int INVENTORY_ITEM_EXTERNAL_ID = 434;
			public static final int EXTERNAL_EMPLOYEE_ID = 435;
			public static final int USER_ID_AND_CUSTOMER_ID_AND_ADDRESS_ID = 436;
			public static final int SESSION_ID = 437;
			public static final int SECRET_KEY_ID = 438;
			public static final int POS_TX_ID = 439;
			public static final int PERIPHERAL_ID = 440;
			public static final int EXTERNAL_PERIPHERAL_ID = 441;
			public static final int DEVICE_APPLICATION_ID = 442;
			public static final int APPLICATION_ID = 443;
			public static final int DEVICE_APPLICATION_FOR_APPLICATION_ID = 444;
			public static final int SECRET_KEY_KEY_AND_TYPE = 445;
			public static final int EXTERNAL_TX_ID = 447;
			public static final int INVENTORY_ITEM_KITCHEN_ITEM_ID = 448;
			public static final int INVENTORY_ITEM_MOD_KITCHEN_ITEM_ID = 449;
			public static final int CUSTOMER_CONTACT_USER_ID = 450;
			public static final int SERIAL = 451;
			public static final int REPORT_ID = 452;
			public static final int POINT_CATEGORY_ID = 453;
			public static final int POINT_CATEGORY_CUSTOMER_NAME = 454;
			public static final int EVENT_TRIGGER_ID = 455;
			public static final int SCHEDULED_TRIGGER_ID = 456;
			public static final int USER_CHECKIN_BY_DEVICE_APPLICATION_ID = 457;
			public static final int TRANSACTION_BY_DEVICE_APPLICATION_ID = 458;
			public static final int UNLINKED_DEVICE_APPLICATION_ID = 459;
			public static final int SEGMENT_ID = 460;
			public static final int SEGMENT_ID_AND_USER_ID = 461;
			public static final int LOTTERY_ID = 462;
			public static final int AB_TEST_ID = 463;
			public static final int COHORT_ID = 464;
			public static final int STRIPE_CUSTOMER_ID = 465;
			public static final int CHARGE_ID = 466;
			public static final int EVENT_ID = 467;
		}

		public static final class GATEWAY {
			public static final int INTERNAL_SERVER_ERROR = 500;
			public static final int INVALID_METHOD = 501;
			public static final int INVALID_REQUEST_MISSING_APIKEY = 502;
			public static final int MISSING_REQUIRED_PARAMETER = 503;
			public static final int METHOD_NOT_YET_IMPLEMENTED = 504;
			public static final int INVALID_PARAMETER_TYPE = 505;
			public static final int ALL_METHODS_DISABLED_TEMPORARILY = 506;
			public static final int METHOD_DISABLED_TEMPORARILY = 507;
			public static final int INVALID_AUTHENTICATION = 508;
			public static final int INVALID_SIGNATURE = 509;
			public static final int INVALID_SIGNATURE_EXPIRED = 510;
			public static final int SIGNATURE_INVALID_SIGNATURE_IN_THE_FUTURE = 511;
			public static final int SERVER_NOT_WHITELISTED = 512;
			public static final int INVALID_REQUEST_FORMAT = 513;
		}

		public static final class POS {
			public static final int NO_RECEIPT_DATA = 601;
			public static final int NO_EXTERNAL_TX_ID_ON_RECEIPT = 602;
			public static final int NO_TOTAL_FOUND_ON_RECEIPT = 603;
			public static final int TRANSACTION_ALREADY_LINKED = 604;
		}

		public static final class RATING {
			public static final int INVALID_SCORE = 710;
		}
		
		public static final class ABTEST {
			public static final int INVALID_CRITERION = 800;
			public static final int NO_COHORTS_EXIST = 801;
			public static final int NO_TESTS_EXIST = 802;
		}
		
		public static final class STRIPE {
			public static final int NO_PARAMETERS_PROVIDED = 900;
		}
		
		public static final class EMAIL {
			public static final int INVALID_BYTE_STREAM = 1000;
		}
		
		public static final Map<Integer, String> map = new LinkedHashMap<Integer, String>();
		static {

			map.put(GENERAL.YELP_NO_BUSINESS_FOUND_FOR_ADDRESS_AND_NAME, "No business information found for customer with name %s and address %s. If attempting to add this address, you can set the \"force\" parameter to true to add this address with no Yelp data.");
			map.put(GENERAL.CUSTOMER_ALREADY_EXISTS, "A customer already exists with the apiKey \"%s\". Its name is \"%s\"");
			map.put(GENERAL.INVALID_COORDS_FOR_REVERSE_GEOCODING, "Invalid coordinates for reverse geocoding - (%s)");
			map.put(GENERAL.INVALID_SCHEDULE_VALUES, "Invalid Schedule Values - Day of Week %s, Start Time %s, End Time %s");
			map.put(GENERAL.INVALID_JSON, "Invalid JSON for parameter %s. The JSON parser said \"%s\"");
			map.put(GENERAL.TWILIO_API_ERROR, "Error handling text messages - Twilio said %s");
			map.put(GENERAL.INVALID_APNS_PAYLOAD, "Invalid APNS payload size (%s) - %s");
			map.put(GENERAL.INVALID_SCHEDULE_TIMES, "The start time of a schedule must come before the end time. You provided startTime %s and endTime %s. Make sure you use 24-hour time.");
			map.put(GENERAL.DISABLED_CUSTOMER, "That customer is disabled");
			map.put(GENERAL.CUSTOMER_BROADCAST_MESSAGE_ALREADY_SENT, "That customer broadcast message has already been sent - %s");
			map.put(GENERAL.FEATURE_EXISTS_ALREADY, "Feature exists already customerId=%s, feature=%s");
			map.put(GENERAL.FEATURE_CANNOT_USE_FEATURE, "The allowed number of uses this month has been exceeded.");
			map.put(GENERAL.INVALID_MESSAGE_LENGTH, "Invalid message length. The max length is %s and your message is %s characters");
			map.put(GENERAL.CONTACT_CUSTOMER_HAS_NO_CUSTOMER_CONTACT, "Customer (%s) has no corresponding contact");
			map.put(GENERAL.USER_ALREADY_EXISTS_WITH_PHONE_NUMBER, "A user already exists with that phone number %s");
			map.put(GENERAL.INVALID_USER_PREFERENCE_NAME, "Unable to find a preference with name %s for that user");
			map.put(GENERAL.DEVICE_ALREADY_EXISTS, "A device already exists with that device id %s");
			map.put(GENERAL.DEVICE_NO_DEVICE_APPLICATION_EXISTS, "Invalid Device Id - %s. No matching Device Application found");
			map.put(GENERAL.DEVICE_NO_DEVICE_LINK_EXISTS, "Invalid Device Link Id - %s.");
			map.put(GENERAL.DEVICE_NO_DEVICE_LINK_EXISTS_FOR_DEVICES, "Invalid Device Id pair - %s, %s. No matching Device Link found");
			map.put(GENERAL.INVALID_USER_AND_PREFERENCE_NAME_COMBINATION, "Invalid user - %s and preference name - %s combination. Check that the preference has been created");
			map.put(GENERAL.USER_MESSAGE_ALREADY_SENT, "That user message has already been sent - %s");
			map.put(GENERAL.INVALID_EVENT_TRIGGER_TYPE, "Invalid eventTrigger type - %s. We currently support MESSAGE");
			map.put(GENERAL.INVALID_CUSTOMER_PREFERENCE_NAME, "Unable to find a preference with name %s for that customer");
			map.put(GENERAL.BATCH_CHAIN_LOOP, "batch.chain tried to call itself recursively. Make sure every request has a method parameter set!");
			map.put(GENERAL.BATCH_CHAIN_BAD_FORMAT_APICALL, "batch.chain expects all api calls in the chain to be valid UTF-8 encoded strings. %s was not valid.");
			map.put(GENERAL.PHONE_NUMBER_ALREADY_IN_USE, "That phone number is already in use by another user - %s");
			map.put(GENERAL.INVALID_SQL_QUERY, "Invalid SQL query. MySQL said - %s");
			map.put(GENERAL.NAME, "Invalid Event Name - %s");
			map.put(GENERAL.SCHEDULED_TRIGGER_ALREADY_ARCHIVED_OR_TRIGGERED, "That scheduled triggere has already been archived or triggered - %s");

			map.put(PERMISSIONS.INVALID_PINCODE_AUTHENTICATION, "Invalid pincode");
			map.put(PERMISSIONS.INVALID_AUTHENTICATION, "The credentials you provided were incorrect. If you're trying to use user/pincode credentials, remove the adminEmail parameter as it takes precedence over any User Identifier.");
			map.put(PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_READ, "Unable to fetch that %s for customer with apiKey %s due to invalid read permissions");
			map.put(PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE, "Unable to save that %s for customer with apiKey %s due to invalid write permissions");
			map.put(PERMISSIONS.CUSTOMER_DOES_NOT_MATCH, "That %s's customer does not match the provided apiKey %s");
			map.put(PERMISSIONS.INVALID_GENERAL, "User \"%s\" does not have the required permission \"%s\" to perform that action");
			map.put(PERMISSIONS.INVALID_ADDRESS_FOR_CUSTOMER, "The addressId (%s) does not correspond to the customer with apiKey (%s). ");
			map.put(PERMISSIONS.CONTACT_DOESNT_MATCH_CUSTOMER, "The given customer contact (%s) does not correspond to the customer (%s).");
			map.put(PERMISSIONS.CANNOT_RESPOND_TO_SOMEONE_ELSES_REFERRAL, "You cannot respond to someone else's referral request. The referral request with id %s must be dealt with by the user who has id %s");
			map.put(PERMISSIONS.INVALID_DEVICE_APPLICATION_PERMISSIONS_READ, "Unable to fetch that %s for device with device application id %s due to invalid read permissions");
			map.put(PERMISSIONS.INVALID_AUTH_CODE, "Invalid authCode for the given authCodeTimestamp");
			map.put(PERMISSIONS.INVALID_AUTH_CODE_EXPIRED, "Invalid authCode - it has expired. Please set your clock forward %s seconds");
			map.put(PERMISSIONS.SIGNATURE_INVALID_AUTH_CODE_IN_THE_FUTURE, "Invalid authCode - it is in the future. Please set your clock back %s seconds");

			map.put(SURVEY.INVALID_SURVEY_LENGTH, "Invalid survey content length. The max length is %s for availableOnMobile surveys and your survey is %s characters");
			map.put(SURVEY.USER_SURVEY_ALREADY_SENT, "That user survey has already been sent - %s");
			map.put(SURVEY.USER_ALREADY_TAKING_SURVEY, "User id - %s is already taking survey id - %s");
			map.put(SURVEY.CUSTOMER_HAS_NO_SURVEY, "Customer - %s has no enabled surveys");
			map.put(SURVEY.USER_ALREADY_RESPONDED_TO_SURVEY, "User id - %s has already responded to survey id - %s");
			map.put(SURVEY.CUSTOMER_HAS_NO_UNTAKEN_SURVEYS, "Customer %s has no untaken surveys for user id - %s");

			map.put(SOCIAL.INVALID_TYPE, "Invalid social type - %s. We currently support Facebook, Twitter, and Foursquare");
			map.put(SOCIAL.NOT_ENABLED, "The social account for the site - %s is not enabled.");
			map.put(SOCIAL.ALREADY_ENABLED, "The social account for the site - %s is already enabled.");
			map.put(SOCIAL.ALREADY_DISABLED, "The social account for the site - %s is already disabled.");
			map.put(SOCIAL.FACEBOOK_NO_PLACEID_FOUND_OR_SETUP, "No Facebook placeId could be found for addressId %s. Talk to your RewardMe account manager to manually set your Facebook Place Id");
			map.put(SOCIAL.INVALID_ACCESS_TOKEN, "The authentication information for the social site (%s) is invalid. Please verify that the RewardMe application is enabled on %s.");
			map.put(SOCIAL.FACEBOOK_ONLY, "This is a Facebook only feature. Please set Type to facebook to use it.");

			map.put(CHECKIN.INVALID_CHECKIN_INFORMATION, "We were unable to check you in - try again and make sure you're using a RewardMe QR Code.");
			map.put(CHECKIN.TOO_FREQUENT, "This checkin is too close to the last time you checked in - you can next check in again at approximately %s");
			map.put(CHECKIN.NOT_AVAILABLE_AT_THIS_TIME, "That Checkin option is not available at this time - you may be outside its allowed time period.");
			map.put(CHECKIN.POINT_AWARD_MUST_BE_SPECIFIED_FOR_VALUE_BASED_CHECKINS, "pointAward must be specified when using a value-based checkin option");
			map.put(CHECKIN.POINT_AWARD_MUST_NOT_BE_SPECIFIED_FOR_VISIT_BASED_CHECKINS, "pointAward must NOT be specified when using a visit-based checkin option");

			map.put(REFERRAL.ALREADY_VISITED, "You can't refer a user to somewhere they've already been.");
			map.put(REFERRAL.REFERRAL_SELF,	"You can't refer yourself, although support for persons with multiple personality disorder is planned for future releases of RewardMe");
			map.put(REFERRAL.ALREADY_REFERRED, "Your friend has already been referred to that location.");
			map.put(REFERRAL.LOCATION_NOT_VISITED_BY_REFERRER, "A referral can't be made to someplace you haven't checked into yet.");

			map.put(BILLING.NO_INVOICE_ITEM_WITH_PROVIDED_PARAMETERS, "There is no invoice item matching the parameters provided - %s %s %s %s.");
			map.put(BILLING.NO_BILLING_FOR_CUSTOMER, "The given customer (%s) does not have a customer billing account yet.");
			map.put(BILLING.FRESHBOOKS_NOT_SYNCED, "The freshbooks account is not synced with the current database for object containing - %s.");
			map.put(BILLING.CUSTOMER_HAS_NO_BILLING, "The given customer(%s) does not have a billing");
			map.put(BILLING.NO_RECURRING_FOR_CUSTOMER, "The given customer with id %s does not have a recurring.");

			map.put(REDEEM.REWARD_IS_ALREADY_ACTIVE, "That Reward is already active. Please wait until it is inactive to redeem again - Reward Id %s");
			map.put(REDEEM.REWARD_IS_NOT_AVAILABLE, "That Reward is not available. It may be that you are early, the reward is disabled, the reward has expired, or you've hit the redemption limit. - Reward Id %s");
			map.put(REDEEM.REWARD_CAN_NOT_BE_REDEEMED, "That Reward is not a redeemable reward. Some rewards are automatically redeemeed, such as those with a rolling time period window - Reward Id %s");
			map.put(REDEEM.USER_HAS_NOT_CHECKED_IN_BUT_TRIED_TO_REDEEM, "Please checkin to this location first before trying to redeem a reward");

			map.put(POINTS.INSUFFICIENT_POINTS, "Not enough points - %s are required and you only have %s available (%s are reserved)");
			map.put(POINTS.ONLY_ONE_TRANSFER_PER_ACCOUNT_ALLOWED, "Only one transfer is allowed. Last transfer was %s points");

			map.put(PHONE.INVALID_PHONE_NUMBER, "Invalid phone number (%s) - It should be a 10 digit long US number.");
			map.put(PHONE.INVALID_MOBILE_PHONE_NUMBER, "Invalid mobile phone number (%s) - it appears to be a landline.");
			map.put(PHONE.UNKNOWN_PHONE_NUMBER, "Unknown mobile phone number (%s) - it doesn't appear to exist.");

			map.put(INVALID_ID.API_KEY, "Invalid Customer API Key - %s");
			map.put(INVALID_ID.USER_ID, "Invalid User Id - %s");
			map.put(INVALID_ID.DEVICE_ID, "Invalid Device Id - %s");
			map.put(INVALID_ID.ADDRESS_ID, "Invalid Address Id - %s");
			map.put(INVALID_ID.REWARD_ID, "Invalid Reward Id - %s");
			map.put(INVALID_ID.ADDRESS_STRING, "Invalid Address String - %s");
			map.put(INVALID_ID.CUSTOMER_ID, "Invalid Customer Id - %s");
			map.put(INVALID_ID.CHECKIN_OPTION_ID, "Invalid Checkin Option Id - %s");
			map.put(INVALID_ID.DEVICE_LINK_EVENT_ID, "Invalid Device Link Id - %s");
			map.put(INVALID_ID.CUSTOMER_CONTACT_ID, "Invalid customer contact id - %s");
			map.put(INVALID_ID.SCHEDULE_ID, "Invalid Schedule Id - %s"); 
			map.put(INVALID_ID.DEVICE_REMOTE_UUID, "Invalid Remote Device UUID (used with Apple Push Notifications) for user with id %s - %s.");
			map.put(INVALID_ID.USER_REFERRAL_REQUEST_ID, "Invalid User Referral Request Id - %s. You may have already responded to this request.");
			map.put(INVALID_ID.CUSTOMER_BROADCAST_MESSAGE_ID, "Invalid customer broadcast message id - %s");
			map.put(INVALID_ID.CUSTOMER_FEATURE_ID, "Invalid customer feature id - %s");
			map.put(INVALID_ID.RECURRING_ID, "Invalid recurring invoice id - %s");
			map.put(INVALID_ID.CUSTOMER_BILLING_ID, "Invalid customer billing id - %s");
			map.put(INVALID_ID.SERVER_ID, "Invalid Server Id - %s");
			map.put(INVALID_ID.FRESHBOOKS_INVOICE_ID, "Invalid Freshbooks Invoice Id = %s ");
			map.put(INVALID_ID.USER_MESSAGE_ID, "Invalid user message id - %s");
			map.put(INVALID_ID.SURVEY_ID, "Invalid survey id - %s");
			map.put(INVALID_ID.USER_SURVEY_ID, "Invalid user survey id - %s");
			map.put(INVALID_ID.USER_ID_AND_SURVEY_ID, "Invalid survey id - %s for user id - %s");
			map.put(INVALID_ID.EMPLOYEE_ID, "Invalid Employee Id - %s");
			map.put(INVALID_ID.DEVICE_PHONE_NUMBER, "Invalid phone number - %s");
			map.put(INVALID_ID.CUSTOMER_FEATURE_CUSTOMER_AND_FEATURE, "Invalid customer feature customerId=%s, feature=%s");
			map.put(INVALID_ID.USERNAME, "Invalid username - %s");
			map.put(INVALID_ID.USER_PHONE_NUMBER, "Invalid phone number - %s");
			map.put(INVALID_ID.INVENTORY_ITEM_ID, "Invalid Invetory Item Id - %s");
			map.put(INVALID_ID.INVENTORY_ITEM_MOD_ID, "Invalid Inventory Item Mod Id - %s");
			map.put(INVALID_ID.INVENTORY_CATEGORY_ID, "Invalid Inventory Category Id - %s");
			map.put(INVALID_ID.DISCOUNT_ID, "Invalid Discount Id - %s");
			map.put(INVALID_ID.INVENTORY_ITEM_MOD_EXTERNAL_ID, "Invalid External Inventory Item Mod Id - %s");
			map.put(INVALID_ID.INVENTORY_ITEM_EXTERNAL_ID, "Invalid External Inventory Item Id - %s");
			map.put(INVALID_ID.EXTERNAL_EMPLOYEE_ID, "Invalid External Employee Id - %s");
			map.put(INVALID_ID.USER_ID_AND_CUSTOMER_ID_AND_ADDRESS_ID, "Invalid User Id - %s, Customer Id - %s, and Address Id - %s for a session");
			map.put(INVALID_ID.SESSION_ID, "Invalid Session Id - %s");
			map.put(INVALID_ID.SECRET_KEY_ID, "Invalid Secret Key Id - %s");
			map.put(INVALID_ID.POS_TX_ID, "Invalid Transaction Id - %s");
			map.put(INVALID_ID.PERIPHERAL_ID, "Invalid Peripheral Id - %s");
			map.put(INVALID_ID.DEVICE_APPLICATION_ID, "Invalid Device Application Id - %s");
			map.put(INVALID_ID.APPLICATION_ID, "Invalid Application Id - %s");
			map.put(INVALID_ID.DEVICE_APPLICATION_FOR_APPLICATION_ID, "No Device Application for Application Id - %s");
			map.put(INVALID_ID.SECRET_KEY_KEY_AND_TYPE, "No secretKey with that key and value - %s, %s");
			map.put(INVALID_ID.EXTERNAL_TX_ID, "Invalid External Transaction Id - %s");
			map.put(INVALID_ID.INVENTORY_ITEM_KITCHEN_ITEM_ID, "Invalid Kitchen Item Id - %s");
			map.put(INVALID_ID.INVENTORY_ITEM_MOD_KITCHEN_ITEM_ID, "Invalid Kitchen Item Mod Id - %s");
			map.put(INVALID_ID.CUSTOMER_CONTACT_USER_ID, "No Customer Contact exists for User Id - %s");
			map.put(INVALID_ID.REPORT_ID, "No Report exists for Report Id - %s");
			map.put(INVALID_ID.POINT_CATEGORY_ID, "No Point Category exists for Point Category Id - %s");
			map.put(INVALID_ID.POINT_CATEGORY_CUSTOMER_NAME, "No Point Category exists for Customer %s named %s");
			map.put(INVALID_ID.EVENT_TRIGGER_ID, "No Event Trigger exists for Event Trigger Id %s");
			map.put(INVALID_ID.SCHEDULED_TRIGGER_ID, "No Scheduled Trigger exists for Scheduled Trigger Id %s");
			map.put(INVALID_ID.USER_CHECKIN_BY_DEVICE_APPLICATION_ID, "No User Checkin exists for Device Application Id %s");
			map.put(INVALID_ID.TRANSACTION_BY_DEVICE_APPLICATION_ID, "No Tranaction exists for Device Application Id %s");
			map.put(INVALID_ID.UNLINKED_DEVICE_APPLICATION_ID, "No Unlinked Device Application for Unlinked Device Application Id - %s");
			map.put(INVALID_ID.LOTTERY_ID, "Invalid Lottery ID %s");
			map.put(INVALID_ID.SEGMENT_ID, "Invalid Segment Id - %s");
			map.put(INVALID_ID.SEGMENT_ID_AND_USER_ID, "User - %s is not bucketed into segment - %s");

			map.put(INVALID_ID.AB_TEST_ID, "Test ID does not exist in database.");
			map.put(INVALID_ID.COHORT_ID, "The cohort ID you wanted is not in the database.");
			map.put(INVALID_ID.STRIPE_CUSTOMER_ID, "The Stripe Customer ID you wanted is not in the database.");
			map.put(INVALID_ID.CHARGE_ID, "The charge with the given ID does not exist.");
			map.put(INVALID_ID.EVENT_ID, "The event with the given ID does not exist.");
			
			
			map.put(GATEWAY.INVALID_METHOD, "Invalid method name - %s");
			map.put(GATEWAY.INVALID_REQUEST_MISSING_APIKEY, "An apiKey is required for this request.");
			map.put(GATEWAY.MISSING_REQUIRED_PARAMETER, "Missing required parameter - %s");
			map.put(GATEWAY.METHOD_NOT_YET_IMPLEMENTED, "Method not yet implemented - %s");
			map.put(GATEWAY.INVALID_PARAMETER_TYPE, "Invalid parameter type for parameter %s - we expected type %s and you provided value \"%s\"");
			map.put(GATEWAY.ALL_METHODS_DISABLED_TEMPORARILY, "All API access is temporarily disabled. We will resume service shortly! Please contact support@rewardmeapp.com for more information.");
			map.put(GATEWAY.METHOD_DISABLED_TEMPORARILY, "Access to this API method is temporarily disabled. We will resume service shortly! Please contact support@rewardmeapp.com for more information.");
			map.put(GATEWAY.INVALID_AUTHENTICATION, "The credentials you provided were incorrect.");
			map.put(GATEWAY.INVALID_SIGNATURE, "Invalid signature for the given apiKey, request parameters, and timestamp");
			map.put(GATEWAY.INVALID_SIGNATURE_EXPIRED, "Invalid signature - it has expired. Please set your clock forward %s seconds");
			map.put(GATEWAY.SIGNATURE_INVALID_SIGNATURE_IN_THE_FUTURE, "Invalid signature - it is in the future. Please set your clock back %s seconds");
			map.put(GATEWAY.SERVER_NOT_WHITELISTED, "This request is only allowed from trusted RewardMe servers. Request came from IP %s");
			map.put(GATEWAY.INVALID_REQUEST_FORMAT, "Invalid request format - %s");
			map.put(GATEWAY.INTERNAL_SERVER_ERROR, "Sorry, but RewardMe is having some problems. Our engineers are working on it pronto.");

			map.put(POS.NO_RECEIPT_DATA, "The received receipt was empty");
			map.put(POS.NO_EXTERNAL_TX_ID_ON_RECEIPT, "The received receipt didn't contain a valid transaction id");
			map.put(POS.NO_TOTAL_FOUND_ON_RECEIPT, "The received receipt didn't contain a valid total or subtotal");
			map.put(POS.TRANSACTION_ALREADY_LINKED, "User %s has already been linked to Transaction %s");

			map.put(RATING.INVALID_SCORE, "Invalid rating score - %s. Was expecting a value between 1 and 5 inclusive.");

			map.put(ABTEST.INVALID_CRITERION, "Invalid criterion input.  Try using userId, deviceId, or addressId.");
			map.put(ABTEST.NO_COHORTS_EXIST, "You haven't created cohorts for the test specified.");
			map.put(ABTEST.NO_TESTS_EXIST, "No test exists with the given testId.");
			

			map.put(STRIPE.NO_PARAMETERS_PROVIDED, "You input empty strings as all parameters.");

			map.put(EMAIL.INVALID_BYTE_STREAM, "You input an invalid byte stream to convert.");

		}	
		
	}

	public static Map<String, Method> allMethods = new ConcurrentHashMap<String, Method>();
	public static Map<String, Method> privateMethods = new ConcurrentHashMap<String, Method>();
	public static Map<String, Method> publicMethods = new ConcurrentHashMap<String, Method>();
	public static Map<String, String> methodDescriptions = new ConcurrentHashMap<String, String>();
	public static Map<String, List<MethodParameter>> methodParameters = new ConcurrentHashMap<String, List<MethodParameter>>();
	
	
	
}

