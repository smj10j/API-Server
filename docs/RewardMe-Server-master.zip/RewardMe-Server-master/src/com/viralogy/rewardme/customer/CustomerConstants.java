package com.viralogy.rewardme.customer;

public abstract class CustomerConstants {

	public static final String MOOYAH = "mooyah";
	public static final String FRAICHE = "fraiche";
	public static final String LE_BOULANGER = "leboulanger";
	public static final String REWARDME = "viralogy";
	
}
