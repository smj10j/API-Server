package com.viralogy.rewardme.customer;

import org.apache.log4j.Logger;


public abstract class Fraiche {

	private static Logger logger = Logger.getLogger(Fraiche.class);


}
