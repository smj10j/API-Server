package com.viralogy.rewardme.customer;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.provider.CellitProvider;
import com.viralogy.rewardme.servlet.GatewayServlet;

public abstract class Mooyah {

	private static Logger logger = Logger.getLogger(Mooyah.class);
	
	private static class Cellit {
		//subscribe web form
		private static final String shortCode = "30364";
		private static final String aid = "1549";
		private static final String storeCodePrefix = "Mooyah";
		
		//message sending api
		private static final String customerName = "mooyah";
		private static final String username = "mooyahapi";
		private static final String password = "9Hwu!6";
		
		private static Map<Long, Integer> storeCodeMap = new HashMap<Long, Integer>(); 
		static {
			//RewardMe => Cellit
			storeCodeMap.put(203L, 123);
			storeCodeMap.put(204L, 111);
			storeCodeMap.put(205L, 110);
			storeCodeMap.put(206L, 118);
			storeCodeMap.put(207L, 121);
			storeCodeMap.put(208L, 112);
			storeCodeMap.put(209L, 101);
			storeCodeMap.put(212L, 107);
			storeCodeMap.put(213L, 104);
			storeCodeMap.put(214L, 113);
			storeCodeMap.put(215L, 119);
			storeCodeMap.put(217L, 109);
			storeCodeMap.put(218L, 108);
			storeCodeMap.put(219L, 120);
			storeCodeMap.put(220L, 136);
			storeCodeMap.put(221L, 102);
		}		
	}

	public static void subscribe(User user, Customer customer, Address address) throws FatalException, InvalidParameterException {
	
		if(!GatewayServlet.isProduction()) {
			logger.debug("Not using Cellit text-messaging because we're not on production");
			return;
		}
		logger.debug("Using custom Cellit text-messaging system to subscribe user with phoneNumber="+user.getPhoneNumber());
				
		//store the subscribe with Cellit by posting to their webform
		Long addressId = address == null ? null : address.getAddressId();
		int cellitStoreCode = (Integer)Cellit.storeCodeMap.values().toArray()[0];
		if(addressId != null) {
			//map the addressId to the cellit store code
			if(Cellit.storeCodeMap.containsKey(addressId)) {
				cellitStoreCode = Cellit.storeCodeMap.get(addressId);
			}else {
				logger.warn("NO CELLIT STORE CODE FOR addressId="+addressId+", using cellitStoreCode="+ cellitStoreCode);
			}
		}
		
		CellitProvider.subscribe(user, customer, address, Cellit.storeCodePrefix+cellitStoreCode, Cellit.shortCode, Cellit.aid);
	}

	public static void sendSMS(User user, String eventHash) {
		
		Integer messageId = null;
		try {
			String cellitCode = eventHash.replace("Mooyah-Cellit-", "").replace("_CELLIT_", "");;
			messageId = Integer.parseInt(cellitCode);
		}catch(NumberFormatException e) {
			logger.error("Invalid messageId with eventHash="+eventHash);
			return;
		}
		logger.info("WILL USE CELLIT MESSAGE ID = " + messageId + " FOR EVENTHASH="+ eventHash);
		
		if(messageId != null) {
			CellitProvider.send(user, Cellit.customerName, Cellit.username, Cellit.password, messageId.toString());
		}
	}	
}
