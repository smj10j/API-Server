package com.viralogy.rewardme.dao;

import java.util.ArrayList;
import java.util.List;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.ABCohort;
import com.viralogy.rewardme.model.ABTest;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.User;

public class ABTestDAO {
	
	
	public static List<ABTest> getAllAbTests(int returnCount) throws InvalidParameterException, FatalException {

		List<ABTest> tests = new ArrayList<ABTest>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" + "SELECT * FROM " + MySQL.TABLES.AB_TEST + " LIMIT ?;", returnCount);
		
		while(mysql.nextRow()) {
			tests.add(ABTest.from(mysql));
		}
		
		return tests;
	}
	
	public static ABTest getAbTest(long abTestId) throws InvalidParameterException, FatalException {
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" + "SELECT * FROM " + MySQL.TABLES.AB_TEST + " WHERE ab_test_id=? " + "LIMIT 1;", abTestId);
		
		ABTest test = null;
		if(mysql.nextRow()) {
			test = ABTest.from(mysql);
		}
		return test;
	}
	
	
	public static ABTest getAbTest(Customer customer) throws InvalidParameterException, FatalException {
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" + "SELECT * FROM " + MySQL.TABLES.AB_TEST + " WHERE customer_id=? ", customer.getCustomerId());
		
		ABTest test = null;
		if(mysql.nextRow()) {
			test = ABTest.from(mysql);
		}
		return test;
	}
	
	
	
	public static List<ABCohort> getAllAbCohorts(ABTest test) throws InvalidParameterException, FatalException {

		List<ABCohort> cohorts = new ArrayList<ABCohort>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" + "SELECT * FROM " + MySQL.TABLES.AB_COHORT + " WHERE ab_test_id=?;", test.getAbTestId());
		
		while(mysql.nextRow()) {
			cohorts.add(ABCohort.from(mysql));
		}
		
		return cohorts;
	}
	
	public static List<ABCohort> getAbCohortsById(ABTest test, long displayCohortId) throws InvalidParameterException, FatalException {

		List<ABCohort> cohorts = new ArrayList<ABCohort>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" + "SELECT * FROM " + MySQL.TABLES.AB_COHORT + " WHERE ab_test_id=? and ab_cohort_id=?;", test.getAbTestId(), displayCohortId);
		
		while(mysql.nextRow()) {
			cohorts.add(ABCohort.from(mysql));
		}
		
		return cohorts;
	}
	
	
	
	
	
	
	
	
	public static long getLinkedCohort(ABTest test, User user) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" + "SELECT * FROM " + MySQL.TABLES.AB_COHORT_LINK + " WHERE ab_test_id=? AND user_id=?;", test.getAbTestId(), user.getUserId());
		
		if(mysql.nextRow()) {
			return (Long)mysql.getColumn("ab_cohort_id");
		}
		else {
			return -1;
		}
	}
	
	public static void newLinkedCohort(ABTest test, User user, long displayCohortId) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);

		mysql.query("" + "INSERT INTO " + MySQL.TABLES.AB_COHORT_LINK + " (ab_test_id, ab_cohort_id, user_id) VALUES (?, ?, ?);", test.getAbTestId(), displayCohortId, user.getUserId());
		
	}
	
}
