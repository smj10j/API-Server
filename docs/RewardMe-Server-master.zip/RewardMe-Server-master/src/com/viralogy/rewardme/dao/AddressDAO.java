package com.viralogy.rewardme.dao;


import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.AddressMetaData;
import com.viralogy.rewardme.model.AddressMetaData.Provider;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.GeoCoord;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.OutputUtil;
import com.viralogy.rewardme.util.StringUtil;

public abstract class AddressDAO {
	
	private static Logger logger = Logger.getLogger(AddressDAO.class);

	public static void addAddressToCustomer(Customer customer, Address address) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
	
		//link up the customer and address
		try {
			mysql.query("" +
				"INSERT INTO " + MySQL.TABLES.CUSTOMER_TO_ADDRESS + " " +
				"(customer_id, address_id) VALUES (?,?)",
			customer.getCustomerId(), address.getAddressId());
		}catch(FatalException e) {
			throw new InvalidParameterException(e);
		}
	}
	
	public static void removeAddressFromCustomer(Customer customer, Address address) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
				
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.CUSTOMER_TO_ADDRESS + " " +
				"WHERE customer_id=? AND address_id=?",
				customer.getCustomerId(), address.getAddressId());		
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_CHECKIN + " " +
				"WHERE customer_id=? AND address_id=?",
				customer.getCustomerId(), address.getAddressId());
		
		// do we want to do this?
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.ADDRESS + " " +
				"WHERE address_id=?",
				address.getAddressId());
	}	
	
	public static Address getAddress(long addressId, boolean enabledOnly) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.ADDRESS + " " +
				"WHERE address_id=? LIMIT 1",
				addressId);
		if(mysql.nextRow()) {
			Address address = Address.from(mysql, null);
			if(enabledOnly && (address.getCustomer() != null && !address.getCustomer().isEnabled())) {
				throw new InvalidParameterException(Constants.Error.GENERAL.DISABLED_CUSTOMER);
			}
			return address;
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.ADDRESS_ID, ListUtil.from(addressId+""));
		}
	}

	public static Long getAddressId(String addressStr) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);

		mysql.query("" +
				"SELECT address_id FROM " + MySQL.TABLES.ADDRESS + " " +
				"WHERE address=? LIMIT 1",
				addressStr);
		if(mysql.nextRow()) {
			return (Long)(mysql.getColumn("address_id"));
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.ADDRESS_STRING, ListUtil.from(addressStr));
		}
	}
	
	public static Address getAddressFromCardspring(String cardspringStoreId,Customer customer) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);

		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.ADDRESS + " " +
				"WHERE cardspring_store_id=? LIMIT 1",
				cardspringStoreId);
		if(mysql.nextRow()) {
			return Address.from(mysql,customer);
		}else {
			return null;
		}
	}
	
	public static AddressMetaData getAddressMetaData(Address address) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);

		AddressMetaData addressMetaData = new AddressMetaData(Provider.YELP);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.ADDRESS_METADATA + " " +
				"WHERE address_id=? LIMIT 1",
				address.getAddressId());
		if(mysql.nextRow()) {
			return AddressMetaData.from(mysql);
		}else {
			//there's nothing here 
			addressMetaData.setAddressId(address.getAddressId());
			addressMetaData.setName(address.getCustomer().getName());
			
			//create a facade
			mysql.query("INSERT INTO " + MySQL.TABLES.ADDRESS_METADATA + " (address_id,provider,name) VALUES (?,?,?)",
				addressMetaData.getAddressId(), 
				addressMetaData.getProvider().toString(), 
				addressMetaData.getName()
			);

			return addressMetaData;
		}
	}
	
	public static List<Address> getAllAddresses(Customer customer) throws FatalException, InvalidParameterException {
		List<Address> addresses = new ArrayList<Address>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.ADDRESS + " a, " + MySQL.TABLES.CUSTOMER_TO_ADDRESS + " ca " + 
				"WHERE ca.address_id=a.address_id AND ca.customer_id=?",
				customer.getCustomerId());
		while(mysql.nextRow()) {
			addresses.add(Address.from(mysql, customer));
		}	
		
		return addresses;
	}		
	
	public static Address getNearest(GeoCoord geoCoord, Customer customer) throws FatalException, InvalidParameterException {
		//find all the places in this area
		if(geoCoord == null) {
			if(customer.getAddresses().size() > 0) {
				return customer.getAddresses().get(0);				
			}
			return null;
		}
		List<Address> allAddresses = AddressManager.query(geoCoord, customer, null, null, 1, 0, true);
		logger.debug("Found " + allAddresses.size() + " addresses near " + geoCoord + OutputUtil.getElapsedString());
		
		return allAddresses.size() > 0 ? allAddresses.get(0) : null;
	}
	
	public static List<Address> query(GeoCoord geoCoord, Customer customer, Integer radius, String query, int returnCount, int startPageIndex, boolean sortByDistance) throws FatalException, InvalidParameterException {
		List<Address> addresses = new ArrayList<Address>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		double latitudeRadians = geoCoord.getLatitudeRadians();
		double longitudeRadians = geoCoord.getLongitudeRadians();
		
		//great circle radius in radians
		double r = (radius == null ? Constants.Distance.RADIUS_OF_EARTH : (double)radius) / Constants.Distance.RADIUS_OF_EARTH;
		
		//change in longitude
		double dLng = Math.asin(Math.sin(r)/Math.cos(latitudeRadians));
		if(Double.isNaN(dLng)) {
			dLng = 1;
		}
		
		//latitude is easily calculated
		double minLatitude = latitudeRadians - r;
		double maxLatitude = latitudeRadians + r;
						
		//due to great circle calculations - we must take special care with longitude - this is the broad stroke calculation
		//further conditions occur in the SQL
		double minLongitude = longitudeRadians - dLng;
		double maxLongitude = longitudeRadians + dLng;
		
		if(!StringUtil.isNullOrEmpty(query)) {
			query = query.trim();
		}
		
		logger.debug("Searching for \"" + query + "\" within Min/Max - Latitude: " + minLatitude + "/" + maxLatitude + ", Longitude: " + minLongitude + ", " + maxLongitude + OutputUtil.getElapsedString());
		
		if(StringUtil.isNullOrEmpty(query)) {
			
			List<Object> parameters = new ArrayList<Object>();
			parameters.add(minLongitude);
			parameters.add(maxLongitude);
			parameters.add(minLatitude);
			parameters.add(maxLatitude);
			parameters.add(latitudeRadians);
			parameters.add(latitudeRadians);
			parameters.add(longitudeRadians);
			parameters.add(r);
			parameters.add(customer != null ? customer.getCustomerId() : null);
			
			mysql.query("" +
					"SELECT a.* FROM " + MySQL.TABLES.ADDRESS + " a" + " " + 
					"WHERE longitude_radians >= ? AND longitude_radians <= ? AND latitude_radians >= ? AND latitude_radians <=?" + " " + 
					"AND (acos(sin(?) * sin(latitude_radians) + cos(?) * cos(latitude_radians) * cos(longitude_radians - ?)) <= ?)" + " " + //special longitude conditions
					(customer != null ? "AND address_id IN (SELECT address_id FROM " + MySQL.TABLES.CUSTOMER_TO_ADDRESS + " ca WHERE ca.customer_id=?)" : ""),
					parameters.toArray());			
		}else {
			//make search efficient eventually (not use %query%)
			String queryMatchString = "";
			String[] tokens = query.split(" ");
			List<String> doubleTokens = new ArrayList<String>();
			for(int i = 0; i < tokens.length; i++) {
				String token = tokens[i].trim();
				if(i > 0) queryMatchString+= " UNION ";
				queryMatchString+= "(SELECT address_id FROM " + MySQL.TABLES.ADDRESS_METADATA + " WHERE name LIKE concat('%',?,'%')) UNION ";
				queryMatchString+= "(SELECT address_id FROM " + MySQL.TABLES.ADDRESS_METADATA + " WHERE category LIKE concat('%',?,'%')) UNION ";
				queryMatchString+= "(SELECT address_id FROM " + MySQL.TABLES.ADDRESS + " WHERE address LIKE concat('%',?,'%')) ";
				doubleTokens.add(token);
				doubleTokens.add(token);
				doubleTokens.add(token);
			}
			
			List<Object> parameters = new ArrayList<Object>();
			parameters.add(minLongitude);
			parameters.add(maxLongitude);
			parameters.add(minLatitude);
			parameters.add(maxLatitude);
			parameters.add(latitudeRadians);
			parameters.add(latitudeRadians);
			parameters.add(longitudeRadians);
			parameters.add(r);
			parameters.addAll(doubleTokens);
			parameters.add(customer != null ? customer.getCustomerId() : null);
			
			mysql.debugNext();
			mysql.query("" +
					"SELECT * FROM " + MySQL.TABLES.ADDRESS + " " + 
					"WHERE longitude_radians >= ? AND longitude_radians <= ? AND latitude_radians >= ? AND latitude_radians <=?" + " " + 
					"AND (acos(sin(?) * sin(latitude_radians) + cos(?) * cos(latitude_radians) * cos(longitude_radians - ?)) <= ?)" + " " + //special longitude conditions
					"AND address_id IN (SELECT * FROM(" + queryMatchString + ") as t) " +
					(customer != null ? "AND address_id IN (SELECT address_id FROM " + MySQL.TABLES.CUSTOMER_TO_ADDRESS + " ca WHERE ca.customer_id=?)" : ""),
					parameters.toArray());
		}
		while(mysql.nextRow()) {
			Address address = Address.from(mysql, null);
			try {
				if(address.getCustomer() != null && !address.getCustomer().isEnabled()) {
					throw new InvalidParameterException(Constants.Error.GENERAL.DISABLED_CUSTOMER);
				}
				addresses.add(address);
			} catch (InvalidParameterException e) {
				//toss this result because the address is dead
				logger.warn("Tossing " + address.toString() + " because we couldn't find a valid customer for it.");
			}
		}	
		logger.debug("Found " + addresses.size() + " address" + (addresses.size() != 1 ? "es" : "") + OutputUtil.getElapsedString());
		
		if(sortByDistance) {
			return Address.sortByDistance(addresses, geoCoord, returnCount, startPageIndex);
		}else {
			return addresses.subList(0, addresses.size() > returnCount ? returnCount : addresses.size());
		}
	}
}
