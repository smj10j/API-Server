package com.viralogy.rewardme.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.SecretKey;
import com.viralogy.rewardme.model.SecretKey.Type;
import com.viralogy.rewardme.util.ListUtil;

public abstract class AdminDAO {
	
	private static Logger logger = Logger.getLogger(AdminDAO.class);

	public static SecretKey getSecretKey(long secretKeyId) throws InvalidParameterException, FatalException {	
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.SECRET_KEY + " " +
				"WHERE secret_key_id=? LIMIT 1",
				secretKeyId);
		if(mysql.nextRow()) {
			return SecretKey.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.SECRET_KEY_ID, ListUtil.from(secretKeyId+""));
		}
	}
	
	public static SecretKey getSecretKey(String secretKeyValue, Type type) throws InvalidParameterException, FatalException {	
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.SECRET_KEY + " " +
				"WHERE secret_key=? AND type=? LIMIT 1",
				secretKeyValue, type.toString());
		if(mysql.nextRow()) {
			return SecretKey.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.SECRET_KEY_KEY_AND_TYPE, ListUtil.from(secretKeyValue,type.toString()));
		}
	}
	
	public static List<SecretKey> getSecretKeys(Type type) throws InvalidParameterException, FatalException {
        List<SecretKey> secretKeys = new ArrayList<SecretKey>();
        
        MySQL mysql = MySQL.getInstance(true);
        
        mysql.query("SELECT * FROM " + MySQL.TABLES.SECRET_KEY + " WHERE type=?",
        		type.toString());
        
        while(mysql.nextRow()) {
        	secretKeys.add(SecretKey.from(mysql));
        }
        return secretKeys;
    }
	

}
