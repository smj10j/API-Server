package com.viralogy.rewardme.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Application;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.util.ListUtil;

public abstract class ApplicationDAO {

	private static Logger logger = Logger.getLogger(ApplicationDAO.class);
		
	public static Application getApplication(long applicationId) throws InvalidParameterException, FatalException {	
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.APPLICATION + " " +	
				"WHERE application_id=? AND archived=0 LIMIT 1",					
				applicationId);	
		if(mysql.nextRow()) {
			return Application.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.APPLICATION_ID, ListUtil.from(applicationId+""));			
		}
	}		
	
	public static List<Application> getApplications(Customer customer) throws InvalidParameterException, FatalException {	
		
		List<Application> applications = new ArrayList<Application>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.APPLICATION + " " +	
				"WHERE customer_id=? AND archived=0",					
				customer.getCustomerId());	
		while(mysql.nextRow()) {
			applications.add(Application.from(mysql));
		}
		
		return applications;
	}

}
