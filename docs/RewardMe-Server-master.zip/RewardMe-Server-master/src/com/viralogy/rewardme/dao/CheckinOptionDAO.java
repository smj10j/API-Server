package com.viralogy.rewardme.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.manager.CheckinOptionManager;
import com.viralogy.rewardme.model.CheckinOption;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Schedule;
import com.viralogy.rewardme.util.ListUtil;

public abstract class CheckinOptionDAO {
	
	private static Logger logger = Logger.getLogger(CheckinOptionDAO.class);

	public static void addCheckinOptionToCustomer(Customer customer, CheckinOption checkinOption) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		// add the schedules
		for(Schedule schedule : checkinOption.getSchedules()) {
			CheckinOptionManager.addScheduleToCheckinOption(customer, checkinOption, schedule);
		}
				
		//link to the customer
		mysql.query("" +
				"INSERT INTO " + MySQL.TABLES.CUSTOMER_TO_CHECKIN_OPTION + " " +
				"(customer_id, checkin_option_id) VALUES (?,?)",
				customer.getCustomerId(), checkinOption.getCheckinOptionId());
	}
	
	public static void removeCheckinOptionFromCustomer(Customer customer, CheckinOption checkinOption) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
				
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.CHECKIN_OPTION_TO_SCHEDULE + " " +
				"WHERE checkin_option_id=?",
				checkinOption.getCheckinOptionId());

		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.CUSTOMER_TO_CHECKIN_OPTION + " " +
				"WHERE customer_id=? AND checkin_option_id=?",
				customer.getCustomerId(), checkinOption.getCheckinOptionId());		

		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.CHECKIN_OPTION + " " +
				"WHERE checkin_option_id=?",
				checkinOption.getCheckinOptionId());		
	}	
	
	public static CheckinOption getCheckinOption(long checkinOptionId) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.CHECKIN_OPTION + " " +
				"WHERE checkin_option_id=? LIMIT 1",
				checkinOptionId);
		if(mysql.nextRow()) {
			return CheckinOption.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.CHECKIN_OPTION_ID, ListUtil.from(checkinOptionId+""));
		}
	}
	
	public static List<CheckinOption> getAllCheckinOptions(Customer customer, boolean ignoreSchedules) throws FatalException, InvalidParameterException {
		List<CheckinOption> checkinOptions = new ArrayList<CheckinOption>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		if(!ignoreSchedules) {
			//add all the checkin options that are available all the time
			mysql.query("" +
					"SELECT co.* FROM " + MySQL.TABLES.CHECKIN_OPTION + " co, " + MySQL.TABLES.CUSTOMER_TO_CHECKIN_OPTION + " cco " + 
					"WHERE cco.checkin_option_id=co.checkin_option_id AND cco.customer_id=? " +
					"AND co.checkin_option_id NOT IN (SELECT cos.checkin_option_id FROM " + MySQL.TABLES.CHECKIN_OPTION_TO_SCHEDULE + " cos WHERE cos.checkin_option_id=co.checkin_option_id)",
					customer.getCustomerId());
			while(mysql.nextRow()) {
				checkinOptions.add(
					CheckinOption.from(mysql)
				);
			}		
			
			//add all the checkin options that follow a schedule
			mysql.query("" +
					"SELECT co.* FROM " + MySQL.TABLES.CHECKIN_OPTION + " co, " + MySQL.TABLES.CUSTOMER_TO_CHECKIN_OPTION + " cco, " + MySQL.TABLES.CHECKIN_OPTION_TO_SCHEDULE + " cos, " + MySQL.TABLES.SCHEDULE + " s " +
					"WHERE cco.checkin_option_id=co.checkin_option_id AND cos.checkin_option_id=co.checkin_option_id AND cos.schedule_id=s.schedule_id AND cco.customer_id=? " +
					"AND s.day_of_week=DAYOFWEEK(utc_timestamp()) AND start_hour_minute <= hour(utc_timestamp())*1000+minute(utc_timestamp()) AND end_hour_minute >= hour(utc_timestamp())*1000+minute(utc_timestamp())",
					customer.getCustomerId());
			while(mysql.nextRow()) {
				checkinOptions.add(
					CheckinOption.from(mysql)
				);
			}	
		}else {
			mysql.query("" +
					"SELECT co.* FROM " + MySQL.TABLES.CHECKIN_OPTION + " co, " + MySQL.TABLES.CUSTOMER_TO_CHECKIN_OPTION + " cco " + 
					"WHERE cco.checkin_option_id=co.checkin_option_id AND cco.customer_id=? ",
					customer.getCustomerId());
			while(mysql.nextRow()) {
				checkinOptions.add(
					CheckinOption.from(mysql)
				);
			}					
		}
		
		return checkinOptions;
	}		
	
	public static void removeScheduleFromCheckinOption(CheckinOption checkinOption, Schedule schedule) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
				
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.CHECKIN_OPTION_TO_SCHEDULE + " " +
				"WHERE checkin_option_id=? AND schedule_id=?",
				checkinOption.getCheckinOptionId(), schedule.getScheduleId());			
	}

	public static void addScheduleToCheckinOption(CheckinOption checkinOption, Schedule schedule) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);

		mysql.query("" +
				"INSERT IGNORE INTO " + MySQL.TABLES.CHECKIN_OPTION_TO_SCHEDULE + " " +
				"(checkin_option_id, schedule_id) " +
				"VALUES (?,?)",
				checkinOption.getCheckinOptionId(), schedule.getScheduleId());		
	}

}
