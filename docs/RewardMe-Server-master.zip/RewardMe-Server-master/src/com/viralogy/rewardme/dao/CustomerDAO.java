package com.viralogy.rewardme.dao;



import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerBilling;
import com.viralogy.rewardme.model.CustomerBroadcastMessage;
import com.viralogy.rewardme.model.CustomerContact;
import com.viralogy.rewardme.model.Event;
import com.viralogy.rewardme.model.Permission;
import com.viralogy.rewardme.model.Reward;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserReward;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.OutputUtil;
import com.viralogy.rewardme.util.StringUtil;

public abstract class CustomerDAO {
	
	private static Logger logger = Logger.getLogger(CustomerDAO.class);

	public static Customer getCustomer(long customerId) throws InvalidParameterException, FatalException {
	
		MySQL mysql = MySQL.getInstance(true);
		
		//create the user if they don't exist
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.CUSTOMER + " " +
				"WHERE customer_id=? LIMIT 1",
				customerId);
		if(mysql.nextRow()) {
			return Customer.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.CUSTOMER_ID, ListUtil.from(customerId+""));
		}
	}
	
	public static Customer getCustomerFromCardspring(String cardspringBusinessId) throws InvalidParameterException, FatalException {
	
		MySQL mysql = MySQL.getInstance(true);
		
		//create the user if they don't exist
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.CUSTOMER + " " +
				"WHERE cardspring_business_id=? LIMIT 1",
				cardspringBusinessId);
		if(mysql.nextRow()) {
			return Customer.from(mysql);
		}else {
			return null;
		}
	}
	public static long getCustomerId(String apiKey) throws InvalidParameterException, FatalException {
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT customer_id FROM " + MySQL.TABLES.CUSTOMER + " " +
				"WHERE api_key=? LIMIT 1",
				apiKey);
		if(mysql.nextRow()) {
			return (Long)mysql.getColumn("customer_id");
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.API_KEY, ListUtil.from(apiKey));
		}
	}	
	
	public static long getCustomerId(Address address) throws InvalidParameterException, FatalException {
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT customer_id FROM " + MySQL.TABLES.CUSTOMER_TO_ADDRESS + " " +
				"WHERE address_id=? LIMIT 1",
				address.getAddressId());
		if(mysql.nextRow()) {
			return (Long)mysql.getColumn("customer_id");
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.ADDRESS_ID, ListUtil.from(address.getAddressId()+""));
		}
	}
	
	public static long getCustomerId(Reward reward) throws InvalidParameterException, FatalException {
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT customer_id FROM " + MySQL.TABLES.CUSTOMER_TO_REWARD + " " +
				"WHERE reward_id=? LIMIT 1",
				reward.getRewardId());
		if(mysql.nextRow()) {
			return (Long)mysql.getColumn("customer_id");
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.REWARD_ID, ListUtil.from(reward.getRewardId()+""));
		}
	}	
	
	public static Customer getCustomerByStripeCustomerId(String stripeCustomerId) throws InvalidParameterException, FatalException {
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.CUSTOMER + " " +
				"WHERE stripe_customer_id=? LIMIT 1",
				stripeCustomerId);
		if(mysql.nextRow()) {
			return Customer.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.STRIPE_CUSTOMER_ID, ListUtil.from(stripeCustomerId));
		}
	}	
	
	public static void removeCustomer(Customer customer) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
					
		
		//all user-specific stuff
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_TO_REWARD + " " +
				"WHERE customer_id=?",
				customer.getCustomerId());						
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_CHECKIN + " " +
				"WHERE customer_id=?",
				customer.getCustomerId());				
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_POINTS_HISTORY + " " +
				"WHERE customer_id=?",
				customer.getCustomerId());					

		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_POINTS_SUMMARY + " " +
				"WHERE customer_id=?",
				customer.getCustomerId());			
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_REFERRAL + " " +
				"WHERE customer_id=?",
				customer.getCustomerId());					
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.CUSTOMER_CONTACT + " " +
				"WHERE customer_id=?",
				customer.getCustomerId());					
				
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_TO_CUSTOMER_BROADCAST_MESSAGE + " " +
				"WHERE customer_broadcast_message_id IN (SELECT customer_broadcast_message_id FROM "+MySQL.TABLES.CUSTOMER_BROADCAST_MESSAGE+" WHERE customer_id=?)",
				customer.getCustomerId());			
		
		
		
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.CUSTOMER + " " +
				"WHERE customer_id=?",
				customer.getCustomerId());
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.CUSTOMER_TO_ADDRESS + " " +
				"WHERE customer_id=?",
				customer.getCustomerId());		
		
		//delete dangling addresses
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.ADDRESS + " " +
				"WHERE address_id NOT IN (SELECT address_id FROM " + MySQL.TABLES.CUSTOMER_TO_ADDRESS + ")");				
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.CUSTOMER_TO_CHECKIN_OPTION + " " +
				"WHERE customer_id=?",
				customer.getCustomerId());	
		
		//delete dangling checkin options
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.CHECKIN_OPTION + " " +
				"WHERE checkin_option_id NOT IN (SELECT checkin_option_id FROM " + MySQL.TABLES.CUSTOMER_TO_CHECKIN_OPTION + ")");			
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.CUSTOMER_TO_REWARD + " " +
				"WHERE customer_id=?",
				customer.getCustomerId());		
		
		//delete dangling rewards
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.REWARD + " " +
				"WHERE reward_id NOT IN (SELECT reward_id FROM " + MySQL.TABLES.CUSTOMER_TO_REWARD + ")");				
		

		//delete dangling broadcast messages
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.CUSTOMER_BROADCAST_MESSAGE + " " +
				"WHERE customer_id=?",
				customer.getCustomerId());				

		//delete dangling features
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.CUSTOMER_FEATURE + " " +
				"WHERE customer_id=?",
				customer.getCustomerId());	

		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.CUSTOMER_FEATURE_USAGE + " " +
				"WHERE customer_feature_id NOT IN (SELECT customer_feature_id FROM " + MySQL.TABLES.CUSTOMER_FEATURE + ")");				
		
	}
	
	
	public static CustomerContact getContact(String email, String password, User user, String md5PinCode, Customer customer) throws InvalidParameterException, FatalException {
		CustomerContact customerContact = new CustomerContact();
		
		MySQL mysql = MySQL.getInstance(true);
		
		if(!StringUtil.isNullOrEmpty(email) && !StringUtil.isNullOrEmpty(password)) {
			//use the email/password
			mysql.query("" +
					"SELECT * FROM " + MySQL.TABLES.CUSTOMER_CONTACT + " " +
					"WHERE email=? AND password=? AND (customer_id=? OR customer_id=0) LIMIT 1",
					email, 
					password, 
					customer == null ? 0 : customer.getCustomerId());	
		}else if(user != null){
			//use the device id
			mysql.query("" +
					"SELECT * FROM " + MySQL.TABLES.CUSTOMER_CONTACT + " " +
					"WHERE user_id IN " +
						"(SElECT user_id FROM " + MySQL.TABLES.USER + " WHERE user_id=? AND pin_code=?) " +
					"AND (customer_id=? OR customer_id=0) LIMIT 1",
					user.getUserId(), 
					md5PinCode, 
					customer == null ? 0 : customer.getCustomerId());			
		}else {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_AUTHENTICATION);				
		}

		if(mysql.nextRow()) {
			customerContact = CustomerContact.from(mysql, customer, user);
			//logger.debug("Found admin user: " + customerContact.getEmail() + OutputUtil.getElapsedString());
		}else {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_AUTHENTICATION);				
		}

		return customerContact;
	}
	
	public static CustomerContact getContact(long customerContactId) throws InvalidParameterException, FatalException {
		CustomerContact customerContact = new CustomerContact();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.CUSTOMER_CONTACT + " " +
				"WHERE customer_contact_id=? LIMIT 1",
				customerContactId);			

		if(mysql.nextRow()) {
			customerContact = CustomerContact.from(mysql, null, null);
			//logger.debug("Found admin user: " + customerContact.getEmail() + OutputUtil.getElapsedString());
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.CUSTOMER_CONTACT_ID,ListUtil.from(customerContactId+""));				
		}

		return customerContact;
	}	
	
	public static CustomerContact getContact(User user) throws InvalidParameterException, FatalException {
		CustomerContact customerContact = new CustomerContact();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.CUSTOMER_CONTACT + " " +
				"WHERE user_id=? LIMIT 1",
				user.getUserId());			

		if(mysql.nextRow()) {
			customerContact = CustomerContact.from(mysql, null, user);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.CUSTOMER_CONTACT_USER_ID,ListUtil.from(user.getUserId()+""));				
		}

		return customerContact;
	}	
	
	
	public static List<CustomerContact> getContacts(Customer customer) throws InvalidParameterException, FatalException {
		List<CustomerContact> customerContacts = new ArrayList<CustomerContact>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.CUSTOMER_CONTACT + " " +
				"WHERE customer_id=?",
				customer.getCustomerId());			

		while(mysql.nextRow()) {
			customerContacts.add(CustomerContact.from(mysql, customer, null));
		}

		return customerContacts;
	}	
	
	public static void removeContact(CustomerContact customerContact) throws InvalidParameterException, FatalException {
		
		MySQL mysql = MySQL.getInstance(true);

		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.CUSTOMER_CONTACT + " " +
				"WHERE customer_contact_id=?",
				customerContact.getCustomerContactId());		
	}			
	
	public static CustomerBroadcastMessage getCustomerBroadcastMessage(long customerBroadcastMessageId) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);

		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.CUSTOMER_BROADCAST_MESSAGE + " " +
				"WHERE customer_broadcast_message_id=? LIMIT 1",
				customerBroadcastMessageId);
		if(mysql.nextRow()) {
			return CustomerBroadcastMessage.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.CUSTOMER_BROADCAST_MESSAGE_ID, ListUtil.from(customerBroadcastMessageId+""));
		}
	}
	
	public static CustomerBroadcastMessage getLastCustomerBroadcastMessage(User user) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);

		mysql.query("" +
				"SELECT cbm.* FROM " + MySQL.TABLES.CUSTOMER_BROADCAST_MESSAGE + " cbm, " + MySQL.TABLES.USER_TO_CUSTOMER_BROADCAST_MESSAGE + " ucbm " +
				"WHERE user_id=? AND cbm.customer_broadcast_message_id=ucbm.customer_broadcast_message_id ORDER BY cbm.timestamp DESC LIMIT 1",
				user.getUserId());
		if(mysql.nextRow()) {
			return CustomerBroadcastMessage.from(mysql);
		}else {
			return null;
		}
	}
	
	public static List<Customer> query(String query, int returnCount) throws FatalException, InvalidParameterException {
		List<Customer> customers = new ArrayList<Customer>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		if(!StringUtil.isNullOrEmpty(query)) {
			query = query.trim();
		}
			
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.CUSTOMER + " " +
				"WHERE name like concat('%',?,'%') OR api_key like concat('%',?,'%') " +
				"LIMIT ?",
				query, query, returnCount);
		while(mysql.nextRow()) {
			Customer customer = Customer.from(mysql);
			customers.add(customer);
		}	
		logger.debug("Found " + customers.size() + " address" + (customers.size() != 1 ? "es" : "") + OutputUtil.getElapsedString());
		
		Collections.sort(customers, new Customer.NameComparator());
		return customers;
	}			
	
	public static CustomerBilling getBilling(Customer customer) throws FatalException, InvalidParameterException {		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.CUSTOMER_BILLING + " " +
				"WHERE customer_id=? LIMIT 1",
				customer.getCustomerId());
		if(mysql.nextRow()) {
			return CustomerBilling.from(mysql);
		}else {
		    //TODO: Freshbooks: return the proper contact and freshbooks client code
			throw new InvalidParameterException(Constants.Error.INVALID_ID.CUSTOMER_ID, ListUtil.from(customer.getCustomerId()+""));
		}
	}
	
	public static CustomerBilling getBilling(long customerBillingId) throws FatalException, InvalidParameterException {     
        MySQL mysql = MySQL.getInstance(true);
        
        mysql.query("" +
                "SELECT * FROM " + MySQL.TABLES.CUSTOMER_BILLING + " " +
                "WHERE customer_billing_id=? LIMIT 1",
                customerBillingId);
        if(mysql.nextRow()) {
            return CustomerBilling.from(mysql);
        }
        
        throw new InvalidParameterException(Constants.Error.INVALID_ID.CUSTOMER_BILLING_ID,ListUtil.from(customerBillingId+""));               
        
    }
	
	public static List<Event> getAdminEvents(Customer customer, int returnCount) throws FatalException, InvalidParameterException {

		List<Event> events = new ArrayList<Event>();
		
		MySQL mysql = MySQL.getInstance(true);
					
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.EVENT + " " +
				"WHERE customer_id=? " +
				"AND admin=1 " + 
				"ORDER BY created DESC " + 
				"LIMIT ?",
				customer.getCustomerId(), returnCount);
		while(mysql.nextRow()) {
			Event event = Event.from(mysql);
			events.add(event);
		}	
		
		return events;
	}
	
	public static List<UserReward> getRedeemedRewards( Customer customer, int returnCount ) throws FatalException, InvalidParameterException {
        List<UserReward> userRewards = new ArrayList<UserReward>();
        
        MySQL mysql = MySQL.getInstance(true);
        
        mysql.query("" +
                "SELECT * FROM " + MySQL.TABLES.USER_TO_REWARD + " " + 
                "WHERE customer_id=? and " +
                "user_id NOT IN (37,109,26141) and " +
                "completed_redeem=1 " + 
                "ORDER BY updated DESC LIMIT ?",	//37 and 109 are Steve and Justin
                customer.getCustomerId(), returnCount);
        
        while(mysql.nextRow()) {
            UserReward userReward = UserReward.from(mysql);
            userRewards.add(userReward);
        }
        return userRewards;
    }
	
	public static Map<String, Permission> getPermissions(CustomerContact customerContact) throws FatalException, InvalidParameterException {
		Map<String, Permission> permissions = new HashMap<String, Permission>();
        
        MySQL mysql = MySQL.getInstance(true);
        
        mysql.query("" +
                "SELECT p.* FROM " + MySQL.TABLES.PERMISSION + " p, " + MySQL.TABLES.CUSTOMER_CONTACT_TO_PERMISSION + " ccp " +  
                "WHERE ccp.customer_contact_id=? AND ccp.permission_id=p.permission_id",
                customerContact.getCustomerContactId());
        
        while(mysql.nextRow()) {
            Permission permission = Permission.from(mysql);
            permissions.put(permission.getName(), permission);
        }
        return permissions;
	}
	
	public static List<Customer> getModifiableCustomers(CustomerContact customerContact) throws FatalException, InvalidParameterException {
		List<Customer> customers = new ArrayList<Customer>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		if(customerContact.getCustomer() == null) {
			//super-admin
			mysql.query("SELECT * FROM " + MySQL.TABLES.CUSTOMER);
			
		}else {
			//not a super-admin
			mysql.query("" +
					"SELECT * FROM " + MySQL.TABLES.CUSTOMER + " " +
					"WHERE customer_id IN (SELECT customer_id FROM " + MySQL.TABLES.CUSTOMER_CONTACT + " WHERE user_id=?) " +
					"OR user_id=?",
					customerContact.getUser().getUserId(), customerContact.getUser().getUserId());
			
		}
		
		while(mysql.nextRow()) {
			Customer customer = Customer.from(mysql);
			customers.add(customer);
		}	
		
		Collections.sort(customers, new Customer.NameComparator());
		return customers;
	}

}
