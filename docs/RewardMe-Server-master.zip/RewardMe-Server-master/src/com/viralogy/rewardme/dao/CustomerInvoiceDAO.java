package com.viralogy.rewardme.dao;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerBilling;
import com.viralogy.rewardme.model.CustomerInvoice;
import com.viralogy.rewardme.model.CustomerInvoiceItem;
import com.viralogy.rewardme.model.CustomerInvoiceRecurring;
import com.viralogy.rewardme.util.ListUtil;

public abstract class CustomerInvoiceDAO
{
    private static Logger logger = Logger.getLogger(CustomerInvoiceDAO.class);
    
    @Deprecated
    public static CustomerInvoiceRecurring getCustomerInvoiceRecurring(Customer customer ) throws InvalidParameterException, FatalException{
        MySQL mysql = MySQL.getInstance( true );
       
        //select * from customer_invoice_recurring where customer_invoice_recurring.customer_billing_id=(select customer_billing.customer_billing_id from customer_billing where customer_billing.customer_id=1);
        mysql.query("" + 
            "SELECT * FROM " + MySQL.TABLES.CUSTOMER_INVOICE_RECURRING + " " + 
            "WHERE customer_billing_id = (" +
            "SELECT customer_billing_id FROM " + MySQL.TABLES.CUSTOMER_BILLING + " " + 
            "WHERE customer_id=?)", 
            customer.getCustomerId());
        if(mysql.nextRow()) {
            return CustomerInvoiceRecurring.from( mysql );
        } else {
            throw new InvalidParameterException(Constants.Error.INVALID_ID.CUSTOMER_ID, ListUtil.from( customer.getCustomerId()+""));
        }
    }
    
    public static CustomerInvoiceRecurring getCustomerInvoiceRecurring(long customerBillingId) throws InvalidParameterException, FatalException{
        
        MySQL mysql = MySQL.getInstance( true );
        
        mysql.query( "" + 
            "SELECT * FROM " + MySQL.TABLES.CUSTOMER_INVOICE_RECURRING + " " + 
            "WHERE customer_billing_id=?",
            customerBillingId);
        if(mysql.nextRow()) {
            return CustomerInvoiceRecurring.from( mysql );
        } else {
            throw new InvalidParameterException(Constants.Error.INVALID_ID.CUSTOMER_BILLING_ID, ListUtil.from( customerBillingId+""));
        }
    }
    
    public static CustomerInvoice getCustomerInvoice(long freshbooksInvoiceId) throws InvalidParameterException, FatalException{
        
        MySQL mysql = MySQL.getInstance( true );
        
        mysql.query( "" + 
            "SELECT * FROM " + MySQL.TABLES.CUSTOMER_INVOICE + " " + 
            "WHERE freshbooks_invoice_id=?",
            freshbooksInvoiceId);
        if(mysql.nextRow()) {
            return CustomerInvoice.from( mysql );
        } else {
            throw new InvalidParameterException(Constants.Error.INVALID_ID.FRESHBOOKS_INVOICE_ID, ListUtil.from( freshbooksInvoiceId+""));
        }
    }
    
    public static CustomerInvoiceItem getCustomerInvoiceItem( String name, String description, float unitCost, long quantity ) throws FatalException, InvalidParameterException {
        MySQL mysql = MySQL.getInstance(true);
        
        mysql.query("" + 
            "SELECT * FROM " + MySQL.TABLES.CUSTOMER_INVOICE_ITEM + " " + 
            "WHERE name=? AND description=? AND unit_cost=? AND quantity=? LIMIT 1",
            name, description, unitCost, quantity);
        if( mysql.nextRow()) {
            return CustomerInvoiceItem.from( mysql );
        } else {
            throw new InvalidParameterException(Constants.Error.BILLING.NO_INVOICE_ITEM_WITH_PROVIDED_PARAMETERS, ListUtil.from( name, description, unitCost+"", quantity+"" ));
        }
    }

    public static List<CustomerInvoiceItem> getCustomerInvoiceItemsOfRecurring( long customerInvoiceRecurringId ) throws FatalException, InvalidParameterException {
    	MySQL mysql = MySQL.getInstance(true);
    	
    	mysql.query("" + 
    			"SELECT * FROM " + MySQL.TABLES.CUSTOMER_INVOICE_RECURRING_TO_CUSTOMER_INVOICE_ITEM + " " +
    			"WHERE customer_invoice_recurring_id=?",
    			customerInvoiceRecurringId);
    	return null;
    }
    
    public static CustomerBilling getBilling(long freshbooksClientId) throws FatalException, InvalidParameterException {     
        MySQL mysql = MySQL.getInstance(true);
        
        mysql.query("" +
                "SELECT * FROM " + MySQL.TABLES.CUSTOMER_BILLING + " " +
                "WHERE freshbooks_client_id=? LIMIT 1",
                freshbooksClientId);
        if(mysql.nextRow()) {
            return CustomerBilling.from(mysql);
        }
        
        throw new InvalidParameterException(Constants.Error.INVALID_ID.CUSTOMER_BILLING_ID,ListUtil.from(freshbooksClientId+""));               
        
    }
    
    public static void addCustomerInvoiceItemToCustomerInvoiceRecurring( long customerInvoiceItemId, long customerInvoiceRecurringId) throws FatalException, InvalidParameterException {
    	MySQL mysql = MySQL.getInstance(true);
    	
    	try {
	    	mysql.query("" + 
	    			"INSERT INTO " + MySQL.TABLES.CUSTOMER_INVOICE_RECURRING_TO_CUSTOMER_INVOICE_ITEM + " " +
	    			"(customer_invoice_recurring_id, customer_invoice_item_id) " +
	    			"values (?,?)", 
	    			customerInvoiceRecurringId, customerInvoiceItemId);
    	} catch (FatalException e ) {
    		throw new InvalidParameterException( e );
    	}
    }
    
    public static void addCustomerInvoiceItemToCustomerInvoice( long customerInvoiceItemId, long customerInvoiceId) throws FatalException, InvalidParameterException {
        MySQL mysql = MySQL.getInstance(true);
        
        try {
            mysql.query("" + 
                    "INSERT INTO " + MySQL.TABLES.CUSTOMER_INVOICE_TO_CUSTOMER_INVOICE_ITEM + " " +
                    "(customer_invoice_id, customer_invoice_item_id) " +
                    "values (?,?)", 
                    customerInvoiceId, customerInvoiceItemId);
        } catch (FatalException e ) {
            throw new InvalidParameterException( e );
        }
    }

}
