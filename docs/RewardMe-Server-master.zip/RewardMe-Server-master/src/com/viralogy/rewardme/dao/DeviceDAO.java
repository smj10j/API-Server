package com.viralogy.rewardme.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Application;
import com.viralogy.rewardme.model.Device;
import com.viralogy.rewardme.model.DeviceApplication;
import com.viralogy.rewardme.model.DeviceLink;
import com.viralogy.rewardme.model.UnlinkedDeviceApplication;
import com.viralogy.rewardme.model.UserCheckin;
import com.viralogy.rewardme.pos.Transaction;
import com.viralogy.rewardme.util.ListUtil;

public abstract class DeviceDAO {

	private static Logger logger = Logger.getLogger(DeviceDAO.class);
	
	public static Device getDevice(String deviceId) throws InvalidParameterException, FatalException {
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.DEVICE + " " +
				"WHERE device_id=? LIMIT 1",
				deviceId);
		if(mysql.nextRow()) {
			return Device.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.DEVICE_ID, ListUtil.from(deviceId));			
		}
	}
	
	public static Device getDeviceByPhoneNumber(String phoneNumber) throws InvalidParameterException, FatalException {
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.DEVICE + " " +	
				"WHERE phone_number=? LIMIT 1",	
				phoneNumber);
		if(mysql.nextRow()) {
			return Device.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.DEVICE_PHONE_NUMBER, ListUtil.from(phoneNumber));			
		}
	}	
	
	public static void create(Device device) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"INSERT INTO " + MySQL.TABLES.DEVICE + " " +	
				"(device_id) VALUES (?)",				
				device.getDeviceId());
	}

	public static DeviceApplication getDeviceApplication(Device device) throws InvalidParameterException, FatalException {	
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.DEVICE_APPLICATION + " " +	
				"WHERE device_id=? LIMIT 1",					
				device.getDeviceId());	
		if(mysql.nextRow()) {
			return DeviceApplication.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.GENERAL.DEVICE_NO_DEVICE_APPLICATION_EXISTS, ListUtil.from(device.getDeviceId()));			
		}
	}	
	
	public static List<DeviceApplication> getDeviceApplications(Application application) throws InvalidParameterException, FatalException {	
		
		List<DeviceApplication> deviceApplications = new ArrayList<DeviceApplication>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.DEVICE_APPLICATION + " " +	
				"WHERE application_id=?",					
				application.getApplicationId());	
		while(mysql.nextRow()) {
			deviceApplications.add(DeviceApplication.from(mysql));
		}

		return deviceApplications;
	}	
	
	public static DeviceApplication getDeviceApplication(long deviceApplicationId) throws InvalidParameterException, FatalException {	
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.DEVICE_APPLICATION + " " +	
				"WHERE device_application_id=? LIMIT 1",					
				deviceApplicationId);	
		if(mysql.nextRow()) {
			return DeviceApplication.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.DEVICE_APPLICATION_ID, ListUtil.from(deviceApplicationId+""));			
		}
	}		

	public static UnlinkedDeviceApplication getUnlinkedDeviceApplication(long unlinkedDeviceApplicationId) throws InvalidParameterException, FatalException {	
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.UNLINKED_DEVICE_APPLICATION + " " +	
				"WHERE unlinked_device_application_id=? LIMIT 1",					
				unlinkedDeviceApplicationId);	
		if(mysql.nextRow()) {
			return UnlinkedDeviceApplication.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.UNLINKED_DEVICE_APPLICATION_ID, ListUtil.from(unlinkedDeviceApplicationId+""));			
		}
	}		
	
	public static Set<DeviceLink> getDeviceLinks(Device device) throws InvalidParameterException, FatalException {	
		
		MySQL mysql = MySQL.getInstance(true);
		
		Set<DeviceLink> deviceLinks = new HashSet<DeviceLink>();
		
		//TODO: DeviceLink: optimize query using a set join
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.DEVICE_LINK + " " +	
				"WHERE device1_id=? OR device2_id=?",					
				device.getDeviceId(), device.getDeviceId());	
		while(mysql.nextRow()) {
			DeviceLink deviceLink = DeviceLink.from(mysql);
			deviceLinks.add(deviceLink);
		}
		
		return deviceLinks;
	}	

	public static DeviceLink getDeviceLink(long deviceLinkId) throws InvalidParameterException, FatalException {	
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.DEVICE_LINK + " " +	
				"WHERE device_link_id=? LIMIT 1",					
				deviceLinkId);	
		if(mysql.nextRow()) {
			return DeviceLink.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.GENERAL.DEVICE_NO_DEVICE_LINK_EXISTS, ListUtil.from(deviceLinkId+""));			
		}
	}	
	
	public static DeviceLink getDeviceLink(Device device1, Device device2) throws InvalidParameterException, FatalException {	
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.DEVICE_LINK + " " +	
				"WHERE device1_id=? AND device2_id=? LIMIT 1",					
				device1.getDeviceId(), device2.getDeviceId());	
		if(mysql.nextRow()) {
			return DeviceLink.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.GENERAL.DEVICE_NO_DEVICE_LINK_EXISTS_FOR_DEVICES, ListUtil.from(device1.getDeviceId(), device2.getDeviceId()));			
		}
	}	

	
	public static UserCheckin getLastCheckin(DeviceApplication deviceApplication) throws InvalidParameterException, FatalException {	
        MySQL mysql = MySQL.getInstance(true);
	    mysql.query("" +
	            "SELECT * FROM " + MySQL.TABLES.USER_CHECKIN + " " + 
	            "WHERE device_application_id=? " + 
	    		"ORDER BY created DESC LIMIT 1",
	    		deviceApplication.getDeviceApplicationId());
		
		if(mysql.nextRow()) {
	    	return UserCheckin.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.USER_CHECKIN_BY_DEVICE_APPLICATION_ID, ListUtil.from(deviceApplication.getDeviceApplicationId()+""));			
		}
	}	        
	
	public static Transaction getLastTransaction(DeviceApplication deviceApplication) throws InvalidParameterException, FatalException {	
        MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
		        "SELECT * FROM " + MySQL.TABLES.POS.TX + " " + 
		        "WHERE device_id=? " +
		        "ORDER by created DESC LIMIT 1",
		        deviceApplication.getDevice().getDeviceId());
		
		if(mysql.nextRow()) {
	    	return Transaction.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.TRANSACTION_BY_DEVICE_APPLICATION_ID, ListUtil.from(deviceApplication.getDeviceApplicationId()+""));			
		}
	}
}
