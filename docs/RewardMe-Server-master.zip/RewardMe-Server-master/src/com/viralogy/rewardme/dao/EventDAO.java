package com.viralogy.rewardme.dao;


import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Event;
import com.viralogy.rewardme.model.EventTrigger;
import com.viralogy.rewardme.model.ScheduledTrigger;
import com.viralogy.rewardme.util.ListUtil;

public abstract class EventDAO {

	private static Logger logger = Logger.getLogger(EventDAO.class);
	
	public static Set<EventTrigger> getEventTriggers(Event event) throws FatalException, InvalidParameterException {
		Set<EventTrigger> eventTriggers = new HashSet<EventTrigger>();

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.EVENT_TRIGGER + " " + 
				"WHERE event_hash=? AND triggered=0 AND archived=0",
				event.hash()
		);
		while(mysql.nextRow()) {
			eventTriggers.add(EventTrigger.from(mysql));
		}
		
		return eventTriggers;
	}
	
	public static EventTrigger getEventTrigger(long eventTriggerId) throws FatalException, InvalidParameterException {

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.EVENT_TRIGGER + " " +
				"WHERE event_trigger_id=? LIMIT 1",
				eventTriggerId);
		if(mysql.nextRow()) {
			return EventTrigger.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.EVENT_TRIGGER_ID, ListUtil.from(eventTriggerId+""));
		}
	}	
	
	
	public static ScheduledTrigger getScheduledTrigger(long scheduledTriggerId) throws FatalException, InvalidParameterException {

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.SCHEDULED_TRIGGER + " " +
				"WHERE scheduled_trigger_id=? LIMIT 1",
				scheduledTriggerId);
		if(mysql.nextRow()) {
			return ScheduledTrigger.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.SCHEDULED_TRIGGER_ID, ListUtil.from(scheduledTriggerId+""));
		}
	}		
}
