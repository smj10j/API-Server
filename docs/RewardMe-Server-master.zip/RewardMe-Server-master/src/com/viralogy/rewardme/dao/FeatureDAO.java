package com.viralogy.rewardme.dao;



import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerFeature;
import com.viralogy.rewardme.model.CustomerFeatureUsage;
import com.viralogy.rewardme.model.CustomerFeature.Feature;
import com.viralogy.rewardme.util.ListUtil;

public abstract class FeatureDAO {
	
	private static Logger logger = Logger.getLogger(FeatureDAO.class);
	
	public static CustomerFeature getCustomerFeature(long customerFeaturedId) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);

		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.CUSTOMER_FEATURE + " " +
				"WHERE customer_feature_id=? LIMIT 1",
				customerFeaturedId);
		if(mysql.nextRow()) {
			return CustomerFeature.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.CUSTOMER_FEATURE_ID,ListUtil.from(customerFeaturedId+""));
		}
	}
	
	public static CustomerFeature getCustomerFeature(Customer customer, Feature feature) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.CUSTOMER_FEATURE + " " +
				"WHERE customer_id=? AND feature=? LIMIT 1",
				customer.getCustomerId(), feature.toString());
		if(mysql.nextRow()) {
			return CustomerFeature.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.CUSTOMER_FEATURE_CUSTOMER_AND_FEATURE,ListUtil.from(customer.getCustomerId()+"", feature.toString()));
		}
	}

	public static long getFeatureUsage(CustomerFeature customerFeature) throws FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT count(*) as 'count' FROM " + MySQL.TABLES.CUSTOMER_FEATURE_USAGE + " " +
				"WHERE customer_feature_id=? AND month(created) = month(utc_timestamp()) GROUP BY customer_feature_id",
				customerFeature.getCustomerFeatureId());
		if(mysql.nextRow()) {
			long count = (Long)mysql.getColumn("count");
			return count;
		}else {
			//they haven't used any this month, allow it
			return 0;
		}
	}	
	
	public static CustomerFeatureUsage getLastCustomerFeatureUsage(CustomerFeature customerFeature) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.CUSTOMER_FEATURE_USAGE + " " +
				"WHERE customer_feature_id=? ORDER BY customer_feature_usage_id DESC LIMIT 1",
				customerFeature.getCustomerFeatureId());
		if(mysql.nextRow()) {
			return CustomerFeatureUsage.from(mysql);
		}else {
			return null;
		}
	}	
	
	public static List<CustomerFeature> getFeatures(Customer customer) throws FatalException, InvalidParameterException {
		List<CustomerFeature> customerFeatures = new ArrayList<CustomerFeature>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.CUSTOMER_FEATURE + " " + 
				"WHERE customer_id=? ",
				customer.getCustomerId());
		while(mysql.nextRow()) {
			customerFeatures.add(
				CustomerFeature.from(mysql)
			);
		}					
		
		return customerFeatures;

	}
}
