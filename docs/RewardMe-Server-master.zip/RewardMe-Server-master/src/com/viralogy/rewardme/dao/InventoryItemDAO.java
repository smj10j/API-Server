package com.viralogy.rewardme.dao;


import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Device;
import com.viralogy.rewardme.model.InventoryItem;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.util.ListUtil;

public abstract class InventoryItemDAO {

	private static Logger logger = Logger.getLogger(InventoryItemDAO.class);
	
	public static List<InventoryItem> getInventoryItems(User user, String type) throws FatalException, InvalidParameterException {

		List<InventoryItem> inventoryItems = new ArrayList<InventoryItem>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		if (user != null && type != null) {
			mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.INVENTORY_ITEM + " " +
				"WHERE user_id=? AND type=? ",
				user.getUserId(),type);
		}
		else if(user != null) {
			mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.INVENTORY_ITEM + " " +
				"WHERE user_id=? ",
				user.getUserId());
		}else if(type != null) {
			mysql.query("" +
					"SELECT * FROM "+ MySQL.TABLES.INVENTORY_ITEM + " " +
					"WHERE type=? ", 
					type);
		}else {
			mysql.query("" +
					"SELECT * FROM "+ MySQL.TABLES.INVENTORY_ITEM + " ");
		}
		while(mysql.nextRow()) {
			inventoryItems.add(InventoryItem.from(mysql));
		}
		return inventoryItems;
	}
	
	public static InventoryItem getInventoryItem(String serial) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.INVENTORY_ITEM + " " +
				"WHERE serial=? LIMIT 1 ",
				serial);
		
		if(mysql.nextRow()) {
			return InventoryItem.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.SERIAL, ListUtil.from(serial+""));
		}
	}
	
		
	
	public static void removeInventoryItem(String serial) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
			"DELETE FROM " + MySQL.TABLES.INVENTORY_ITEM + " " +
			"WHERE serial=? LIMIT 1",
			serial);
		}
	

}