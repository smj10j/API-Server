package com.viralogy.rewardme.dao;


import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Lottery;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.util.ListUtil;

public abstract class LotteryDAO {
	
	private static Logger logger = Logger.getLogger(LotteryDAO.class);
	
	public static Lottery getLottery(long lotteryId) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" + "SELECT * FROM " + MySQL.TABLES.LOTTERY + " " + "WHERE lottery_id=? LIMIT 1", lotteryId);
		
		if(mysql.nextRow()) {
			Lottery lottery = Lottery.from(mysql);
			return lottery;
		} else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.LOTTERY_ID, ListUtil.from(lotteryId+""));
		}
	}

	public static List<Lottery> getAllLotteries(Customer customer) throws FatalException, InvalidParameterException {
		List<Lottery> lotteries = new ArrayList<Lottery>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" + "SELECT * FROM " + MySQL.TABLES.LOTTERY + " " + "WHERE customer_id=?", customer.getCustomerId());
		
		while (mysql.nextRow()) {
			Lottery lottery = Lottery.from(mysql);
			lotteries.add(lottery);
		}
		return lotteries;
	}
	
	public static void recordWin(User user, Lottery lottery) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" + "INSERT INTO " + MySQL.TABLES.LOTTERY_WINNERS + " " + "(user_id, lottery_id) VALUES (?, ?)", user.getUserId(), lottery.getLotteryId());
	}

	public static long getNumberOfWinners(Lottery lottery) throws FatalException, InvalidParameterException {
		long numberOfLotteries = 0;
		
		MySQL mysql = MySQL.getInstance(true);
	
		mysql.query("" + "SELECT COUNT(*) as number_of_lotteries FROM " + MySQL.TABLES.LOTTERY_WINNERS + " " + "WHERE lottery_id=?", lottery.getLotteryId());
		
		if (mysql.nextRow()) {
			numberOfLotteries = (Long)(mysql.getColumn("number_of_lotteries"));
		}
		
		return (long)numberOfLotteries;
	}
}
