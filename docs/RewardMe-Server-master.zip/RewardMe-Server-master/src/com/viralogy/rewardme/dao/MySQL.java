package com.viralogy.rewardme.dao;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.servlet.GatewayServlet;
import com.viralogy.rewardme.util.EmailUtil;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.OutputUtil;

public class MySQL {

	private static Logger logger = Logger.getLogger(MySQL.class);

	public static class TABLES {
		public static final String INVENTORY_ITEM = "inventory_item";

		public static final String CUSTOMER_CONTACT = "customer_contact";
		public static final String PERMISSION = "permission";
		public static final String CUSTOMER_CONTACT_TO_PERMISSION = "customer_contact_to_permission";

		public static final String CUSTOMER = "customer";
		public static final String ADDRESS = "address";
		public static final String ADDRESS_METADATA = "address_metadata";
		public static final String DEVICE = "device";
		public static final String USER = "user";
		public static final String REWARD = "reward";
		public static final String LOTTERY = "lottery";
		public static final String LOTTERY_WINNERS = "lottery_winners";
		public static final String REPORT = "report";
		public static final String SURVEY = "survey";
		public static final String POINT_CATEGORY = "point_category";
		public static final String CHECKIN_OPTION = "checkin_option";
		public static final String SCHEDULE = "schedule";
		public static final String CUSTOMER_FEATURE_USAGE = "customer_feature_usage";
		public static final String CUSTOMER_FEATURE = "customer_feature";
		public static final String CUSTOMER_PREFERENCE = "customer_preference";

		public static final String CUSTOMER_BILLING = "customer_billing";
		public static final String CUSTOMER_INVOICE = "customer_invoice";
		public static final String CUSTOMER_INVOICE_ITEM = "customer_invoice_item";
		public static final String CUSTOMER_INVOICE_RECURRING = "customer_invoice_recurring";
		public static final String CUSTOMER_INVOICE_TO_CUSTOMER_INVOICE_ITEM = "customer_invoice_to_customer_invoice_item";
		public static final String CUSTOMER_INVOICE_RECURRING_TO_CUSTOMER_INVOICE_ITEM = "customer_invoice_recurring_to_customer_invoice_item";

		public static final String CUSTOMER_TO_ADDRESS = "customer_to_address";
		public static final String CUSTOMER_TO_REWARD = "customer_to_reward";
		public static final String CUSTOMER_TO_CHECKIN_OPTION = "customer_to_checkin_option";
		public static final String REWARD_TO_SCHEDULE = "reward_to_schedule";
		public static final String CHECKIN_OPTION_TO_SCHEDULE = "checkin_option_to_schedule";

		public static final String USER_CHECKIN = "user_checkin";
		public static final String USER_TO_REWARD = "user_to_reward";
		public static final String USER_TO_LOTTERY = "user_to_lottery";
		public static final String USER_TO_CUSTOMER_BROADCAST_MESSAGE = "user_to_customer_broadcast_message";
		public static final String CUSTOMER_BROADCAST_MESSAGE = "customer_broadcast_message";
		public static final String USER_SURVEY = "user_survey";
		public static final String USER_MESSAGE = "user_message";
		public static final String USER_REFERRAL = "user_referral";
		public static final String USER_REFERRAL_REQUEST = "user_referral_request";
		public static final String USER_POINTS_SUMMARY = "user_points_summary";
		public static final String USER_POINTS_HISTORY = "user_points_history";
		public static final String USER_PREFERENCE = "user_preference";
		public static final String USER_TO_DEVICE = "user_to_device";
		public static final String USER_SOCIAL_CHECKIN = "user_social_checkin";
		public static final String SEGMENT = "segment";
		public static final String SEGMENT_TO_USER = "segment_to_user";

		public static final String EVENT = "event";
		public static final String EVENT_TRIGGER = "event_trigger";

		public static final String SCHEDULED_TRIGGER = "scheduled_trigger";

		public static final String PERIPHERAL = "peripheral";

		public static final String SESSION = "session";
		public static final String WAREHOUSE_SESSION = "warehouse_session";
		public static final String WAREHOUSE_EVENT_DESCRIPTOR = "warehouse_event_descriptor";

		public static final String SECRET_KEY = "secret_key";

		public static final String EMPLOYEE = "employee";

		public static final String RATING = "rating";

		public static final String CARDSPRING_TRANSACTION = "cardspring_transaction";

		public static final class POS {
			public static final String TX = "pos_tx";
			public static final String RECEIPT = "pos_receipt";
			public static final String INVENTORY_ITEM = "pos_inventory_item";
			public static final String INVENTORY_ITEM_MOD = "pos_inventory_item_mod";
			public static final String INVENTORY_CATEGORY = "pos_inventory_category";
			public static final String DISCOUNT = "pos_discount";
			public static final String INVENTORY_ITEM_HISTORY = "pos_inventory_item_history";
			public static final String INVENTORY_ITEM_MOD_HISTORY = "pos_inventory_item_mod_history";
			public static final String TX_TO_INVENTORY_ITEM = "pos_tx_to_pos_inventory_item";
			public static final String TX_TO_INVENTORY_ITEM_TO_POS_INVENTORY_ITEM_MOD = "pos_tx_to_pos_inventory_item_to_pos_inventory_item_mod";
			public static final String TX_TO_DISCOUNT = "pos_tx_to_pos_discount";

			public static final String TX_TO_INVENTORY_ITEM_TO_DISCOUNT = "pos_tx_to_pos_inventory_item_to_pos_discount";
			public static final String INVENTORY_ITEM_TO_ADDRESS = "pos_inventory_item_to_address";
			public static final String INVENTORY_ITEM_MOD_TO_ADDRESS = "pos_inventory_item_mod_to_address";
			public static final String INVENTORY_CATEGORY_TO_ADDRESS = "pos_inventory_category_to_address";
			public static final String DISCOUNT_TO_ADDRESS = "pos_discount_to_address";
			public static final String INVENTORY_ITEM_TO_INVENTORY_CATEGORY = "pos_inventory_item_to_pos_inventory_category";
			public static final String FAVORITE_TX = "favorite_pos_tx";
		}

		public static final String APPLICATION = "application";
		public static final String APPLICATION_OBSERVATION = "application_observation";
		public static final String DEVICE_APPLICATION = "device_application";
		public static final String DEVICE_LINK = "device_link";
		public static final String UNLINKED_DEVICE_APPLICATION = "unlinked_device_application";

		public static final String SERVER = "server";
		
		public static final String SCHEDULED_TASK = "scheduled_task";

		public static final String CALENDAR = "calendar";

		public static final String AB_TEST = "ab_test";
		public static final String AB_COHORT = "ab_cohort";
		public static final String AB_DEVICE = "ab_device";
		public static final String AB_COHORT_LINK = "ab_cohort_link";
	}

	private enum DataSourceType {
		MASTER, SLAVE
	}

	private static final Map<DataSourceType, String> dataSourceStrings = new HashMap<DataSourceType, String>();
	static {
		// set in jboss/server/rewardme/deploy/mysql-ds.xml
		dataSourceStrings.put(DataSourceType.MASTER, "java:/MySqlDS");
		dataSourceStrings.put(DataSourceType.SLAVE, "java:/MySqlDSSlave");
	}

	// should be cross-thread
	private static Map<DataSourceType, DataSource> dataSources = new HashMap<DataSourceType, DataSource>();
	private static Map<DataSourceType, InitialContext> contexts = new HashMap<DataSourceType, InitialContext>();
	private static Map<String, Object> threadToMySQLInstance = new ConcurrentHashMap<String, Object>();

	// we don't want this to be static or concurrent... we want them just for
	// this thread
	private DataSourceType dataSourceType;
	private Connection connection;

	private Map<String, Long> lastInsertedIds = new HashMap<String, Long>();
	private Map<String, ResultSet> callerToResultSet = new HashMap<String, ResultSet>();
	private Map<String, PreparedStatement> callerToStatement = new HashMap<String, PreparedStatement>();

	private long totalTime;
	private boolean writeMade = false;
	private boolean debugNext;

	public static MySQL getInstance(boolean createIfNoneExists)
			throws FatalException {
		return getInstance(createIfNoneExists, DataSourceType.MASTER);
	}

	public static MySQL getSlaveInstance(boolean createIfNoneExists)
			throws FatalException {
		return getInstance(createIfNoneExists, DataSourceType.SLAVE);
	}

	private static MySQL getInstance(boolean createIfNoneExists,
			DataSourceType dataSourceType) throws FatalException {
		MySQL mysql = (MySQL) threadToMySQLInstance.get(dataSourceType.toString() + Thread.currentThread().getId());
		if (mysql == null && createIfNoneExists) {
			if (Constants.DEBUG_MODE)
				logger.info("Opening new " + dataSourceType.toString() + " transaction for thread" + OutputUtil.getElapsedString());
			mysql = new MySQL(dataSourceType);
		} else if (mysql != null) {
			if (Constants.DEBUG_MODE)
				logger.debug("Using existing " + dataSourceType.toString() + " transaction" + OutputUtil.getElapsedString());
			mysql.isValid();
		}
		return mysql;
	}

	private MySQL(DataSourceType dataSourceType) throws FatalException {
		long startTime = System.currentTimeMillis();
		try {

			totalTime = 0;
			this.dataSourceType = dataSourceType;

			// Register the JDBC driver for MySQL.
			Class.forName("com.mysql.jdbc.Driver");

			String datasourceString = dataSourceStrings
					.get(this.dataSourceType);
			DataSource datasource = dataSources.get(this.dataSourceType);
			InitialContext context = contexts.get(this.dataSourceType);

			if (context == null || datasource == null) {
				try {
					logger.info("Connecting to the MySQL Datasource at " + datasourceString + ": " + OutputUtil.getElapsedString());
					context = new InitialContext();
					datasource = (DataSource) context.lookup(datasourceString);

					dataSources.put(this.dataSourceType, datasource);
					contexts.put(this.dataSourceType, context);

				} catch (Exception e) {
					logger.error("Failed to connect to the MySQL datasource...");
					context = null;
					datasource = null;
					throw new FatalException(e);
				}
			}

			// for transaction management
			threadToMySQLInstance.put(dataSourceType.toString()	+ Thread.currentThread().getId(), this);

			this.fetchConnection();

		} catch (ClassNotFoundException e) {
			throw new FatalException(e);
		} finally {
			totalTime += (System.currentTimeMillis() - startTime);
		}

		debugNext = false;
	}

	private void fetchConnection() throws FatalException {
		try {
			DataSource datasource = dataSources.get(this.dataSourceType);

			connection = (Connection) datasource.getConnection();
			connection.setAutoCommit(false);
		} catch (SQLException e) {
			throw new FatalException(e);
		}
	}

	public boolean isValid() throws FatalException {
		try {
			return this.connection.isValid(5);
		} catch (SQLException e) {
			this.fetchConnection();
			try {
				return this.connection.isValid(5);
			} catch (SQLException e1) {
				throw new FatalException(e);
			}
		}
	}

	public static boolean wasWriteMade() throws FatalException {
		MySQL mysql = MySQL.getInstance(false);
		return mysql != null && mysql.writeMade;
	}

	public static void commit() throws FatalException {
		long startTime = System.currentTimeMillis();

		// commit the master
		MySQL mysqlMaster = MySQL.getInstance(false);
		try {
			if (mysqlMaster != null) {
				if (Constants.DEBUG_MODE)
					logger.info("Committing transaction" + OutputUtil.getElapsedString());
				if (mysqlMaster.connection != null && !mysqlMaster.connection.isClosed()) {
					mysqlMaster.connection.commit();
				} else {
					if (Constants.DEBUG_MODE)
						logger.info("No commit because connection is closed" + OutputUtil.getElapsedString());
				}
				mysqlMaster.close();
			}
		} catch (SQLException e) {
			throw new FatalException(e);
		} finally {
			if (mysqlMaster != null)
				mysqlMaster.totalTime += (System.currentTimeMillis() - startTime);
		}

		// and close the slave
		MySQL mysqlSlave = MySQL.getSlaveInstance(false);
		try {
			if (mysqlSlave != null) {
				mysqlSlave.close();
			}
		} finally {
			if (mysqlSlave != null)
				mysqlSlave.totalTime += (System.currentTimeMillis() - startTime);
		}
	}

	public static void rollback() throws FatalException {
		long startTime = System.currentTimeMillis();

		// rollback the master
		MySQL mysqlMaster = MySQL.getInstance(false);
		try {
			if (mysqlMaster != null) {
				if (Constants.DEBUG_MODE)
					logger.info("Rolling back transaction" + OutputUtil.getElapsedString());
				if (mysqlMaster.connection != null && !mysqlMaster.connection.isClosed()) {
					mysqlMaster.connection.rollback();
				} else {
					if (Constants.DEBUG_MODE)
						logger.info("No rollback because connection is closed" + OutputUtil.getElapsedString());
				}
				mysqlMaster.close();
			}
		} catch (SQLException e) {
			throw new FatalException(e);
		} finally {
			if (mysqlMaster != null)
				mysqlMaster.totalTime += (System.currentTimeMillis() - startTime);
		}

		// and close the slave
		MySQL mysqlSlave = MySQL.getSlaveInstance(false);
		try {
			if (mysqlSlave != null) {
				mysqlSlave.close();
			}
		} finally {
			if (mysqlSlave != null)
				mysqlSlave.totalTime += (System.currentTimeMillis() - startTime);
		}
	}

	private void close() throws FatalException {
		try {
			for (ResultSet callerResultSet : callerToResultSet.values()) {
				callerResultSet.close();
			}
			callerToResultSet.clear();

			for (PreparedStatement statement : callerToStatement.values()) {
				statement.close();
			}
			callerToStatement.clear();

			if (connection != null) {
				connection.close();
				connection = null;
			}

			threadToMySQLInstance.remove(dataSourceType.toString() + Thread.currentThread().getId());

			logger.info("Total time interacting with MySQL - Thread " + Thread.currentThread().getId() + ": " + totalTime + "ms");

		} catch (SQLException e) {
			throw new FatalException(e);
		}
	}

	private static String getUnescapedQueryForDebugging(String sql,
			Object[] parameters) {
		return OutputUtil.tokenReplace(sql, "\\?", ListUtil.from(parameters)) + OutputUtil.getElapsedString();
	}

	/*
	 * Generalized query method - if you're issuing a select statement you can
	 * access the returned results using nextRow() and getColumn()
	 */
	public void query(String sql, Object... parameters) throws FatalException {
		long startTime = System.currentTimeMillis();

		try {

			sql += " "; // this is for parameter splitting by '?'
			String baseSQLStr = sql.toUpperCase();

			if (baseSQLStr.contains("LOAD ") || baseSQLStr.contains("TRUNCATE ") || baseSQLStr.contains("DROP ") || baseSQLStr.contains("ALTER ") || baseSQLStr.contains("CREATE ")) {
				throw new FatalException("Unable to use commands like DROP and ALTER: " + sql);
			}

			if (dataSourceType.equals(DataSourceType.SLAVE)) {
				if (baseSQLStr.contains("INSERT ") || baseSQLStr.contains("UPDATE ") || baseSQLStr.contains("DELETE ")) {
					throw new FatalException("You cannot use INSERT/UPDATE/DELETE on the SLAVE database: " + sql);
				}
			}

			String caller = getCaller(false); // creates a new resultset in the
												// top level method
			if (Constants.DEBUG_MODE)
				logger.debug("Performing query for caller " + caller + OutputUtil.getElapsedString());
			ResultSet callerResultSet = callerToResultSet.get(caller);
			PreparedStatement statement = callerToStatement.get(caller);
			if (statement != null) {
				if (Constants.DEBUG_MODE)
					logger.debug("Closed statement for caller " + caller + OutputUtil.getElapsedString());
				statement.close();
			}
			// Get a Statement object
			statement = (PreparedStatement) connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			callerToStatement.put(caller, statement);
			if (Constants.DEBUG_MODE)
				logger.debug("Opened new statement for caller " + caller + OutputUtil.getElapsedString());

			int parameterIndex = 1;
			for (Object parameter : parameters) {
				if (parameter != null || (parameters.length == sql.split("\\?").length - 1)) {
					// we ignore null items in the list if there are optional
					// params
					statement.setObject(parameterIndex++, parameter);
				}
			}
			// debugNext = true;
			if (debugNext) {
				logger.debug("About to execute (unescaped) query: "	+ getUnescapedQueryForDebugging(sql, parameters));
				debugNext = false;
			}
			if (baseSQLStr.contains("INSERT ") || baseSQLStr.contains("UPDATE ") || baseSQLStr.contains("DELETE ")) {
				writeMade = true;
				statement.executeUpdate();
				if (baseSQLStr.contains("INSERT ")) {
					String tableName = baseSQLStr.substring(baseSQLStr.indexOf("INTO") + 4).trim();
					tableName = tableName.substring(0, tableName.indexOf(" "))	.trim();
					ResultSet generatedKeys = statement.getGeneratedKeys();
					if (generatedKeys.next()) {
						long insertId = (Long) generatedKeys.getObject(1);
						logger.debug("Inserted row into " + tableName + " with id: " + insertId	+ OutputUtil.getElapsedString());
						lastInsertedIds.put(tableName, insertId);
					}
				}
			} else {
				if (callerResultSet != null) {
					if (Constants.DEBUG_MODE)
						logger.debug("Closed resultSet for caller " + caller + OutputUtil.getElapsedString());
					callerResultSet.close();
				}
				callerResultSet = statement.executeQuery();
				callerToResultSet.put(caller, callerResultSet);
				if (Constants.DEBUG_MODE)
					logger.debug("Opened new resultSet for caller " + caller + OutputUtil.getElapsedString());
			}
		} catch (SQLException e) {
			throw new FatalException("SQL Exception on query: " + getUnescapedQueryForDebugging(sql, parameters), e);
		} finally {
			long elapsed = (System.currentTimeMillis() - startTime);
			totalTime += elapsed;
			if (elapsed > 1000) {
				// slow query!
				logger.warn("SLOW QUERY: " + getUnescapedQueryForDebugging(sql, parameters));
				// email a notice to admins
				try {
					String subject = "SLOW Query on RewardMe (" + GatewayServlet.getHostname() + ")";
					String body = "" + "SLOW Query: " + getUnescapedQueryForDebugging(sql, parameters);

					EmailUtil.email(null, "slowquery-notifier", ListUtil.from(EmailUtil.getInternalAdminEmail()), subject, body.getBytes(), "txt", null);

				} catch (FatalException e) {
					// oh bonkers
					logger.error("Error while trying to email admins about slow query!", e);
				} catch (InvalidParameterException e) {
					logger.error("Error while trying to email admins about slow query!", e);
				}
			}
		}
	}

	/*
	 * Returns true if there is another row and advance the internal pointer Use
	 * getColumn() to select items for the row
	 */
	public boolean nextRow() throws FatalException {
		long startTime = System.currentTimeMillis();
		String caller = getCaller(true); // expects to find a result set on the
											// stack
		try {
			if (Constants.DEBUG_MODE)
				logger.debug("Trying to access resultSet for caller " + caller + OutputUtil.getElapsedString());
			ResultSet callerResultSet = callerToResultSet.get(caller);
			if (callerResultSet != null) {
				if (!callerResultSet.next()) {

					closeResultSet();

					return false;
				}
				return true;
			} else {
				throw new FatalException("Tried to GET THE NEXT ROW from a resultSet that was null with caller=" + caller + "!");
			}
		} catch (SQLException e) {
			// logger.error("Tried to GET THE NEXT ROW from a non-null resultSet with caller="
			// + caller + "!");
			throw new FatalException(e);
		} finally {
			totalTime += (System.currentTimeMillis() - startTime);
		}
	}

	private void closeResultSet() throws FatalException {
		try {
			String caller = getCaller(true); // expects to find a result set on
												// the stack

			ResultSet callerResultSet = callerToResultSet.get(caller);
			if (callerResultSet != null) {
				callerResultSet.close();
				callerToResultSet.remove(caller);
			}
			PreparedStatement statement = callerToStatement.get(caller);
			if (statement != null) {
				statement.close();
				callerToStatement.remove(caller);
			}

			if (Constants.DEBUG_MODE)
				logger.debug("Closed statement and resultSet for caller " + caller + OutputUtil.getElapsedString());

		} catch (SQLException e) {
			throw new FatalException(e);
		}
	}

	public long lastInsertId(String tableName) {
		return lastInsertedIds.get(tableName.toUpperCase());
	}

	public Object getColumn(String columnLabel) throws FatalException {
		long startTime = System.currentTimeMillis();
		String caller = getCaller(true); // expects to find a result set on the
											// stack
		ResultSet callerResultSet = callerToResultSet.get(caller);
		try {
			if (callerResultSet == null) {
				throw new FatalException("Tried to GET A COLUMN from a resultSet that was null with caller=" + caller + "!");
			}

			Object resultObject = null;
			try {
				resultObject = callerResultSet.getObject(columnLabel);
			} catch (SQLException e) {
				e.fillInStackTrace();
				if (e.getMessage().contains("can not be represented as java.sql.Date")) {
					resultObject = null;
				} else if (e.getMessage().contains("to TIMESTAMP")) {
					resultObject = null;
				} else {
					throw e;
				}
			}

			return resultObject;

		} catch (SQLException e) {
			// logger.error("Tried to GET A COLUMN from a non-null resultSet with caller="
			// + caller + "!");
			throw new FatalException(e);
		} finally {
			totalTime += (System.currentTimeMillis() - startTime);
		}
	}

	public static <T> byte[] serialize(T object) throws FatalException {
		try {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(bos);
			oos.writeObject(object);
			byte[] output = bos.toByteArray();
			oos.close();
			return output;
		} catch (IOException e) {
			throw new FatalException(e);
		}

	}

	public void debugNext() {
		this.debugNext = true;
	}

	public static Object getValue(MySQL mysql, String columnName)
			throws FatalException {
		Object value;
		Object rawValue = mysql.getColumn(columnName);
		try {
			value = (String) rawValue;
		} catch (ClassCastException e) {
			try {
				value = new String((byte[]) rawValue);
			} catch (ClassCastException e2) {
				try {
					value = (Integer) rawValue;
				} catch (ClassCastException e3) {
					try {
						value = (Long) rawValue;
					} catch (ClassCastException e4) {
						try {
							value = (Date) rawValue;
						} catch (ClassCastException e5) {
							value = getCountValue(mysql, columnName);
						}
					}
				}
			}
		}
		return value;
	}

	public static double getCountValue(MySQL mysql, String columnName)
			throws FatalException {
		double count;
		Object rawValue = mysql.getColumn(columnName);
		try {
			count = (Double) rawValue;
		} catch (ClassCastException e) {
			try {
				count = ((BigDecimal) rawValue).doubleValue();
			} catch (ClassCastException e2) {
				try {
					count = ((BigInteger) rawValue).doubleValue();
				} catch (ClassCastException e3) {
					logger.warn("Failed to guess type of columnName=" + columnName);
					throw e3;
				}
			}
		}
		return count;
	}

	@SuppressWarnings("unchecked")
	public static <T> T deserialize(byte[] input) throws FatalException {
		try {
			ByteArrayInputStream bis = new ByteArrayInputStream(input);
			ObjectInputStream ois = new ObjectInputStream(bis);
			Object object = ois.readObject();
			return (T) object;
		} catch (IOException e) {
			throw new FatalException(e);
		} catch (ClassNotFoundException e) {
			throw new FatalException(e);
		}
	}

	private String getCaller(boolean withResultSet) {
		Throwable t = new Throwable();
		StackTraceElement[] elements = t.getStackTrace();

		// find the most recently opened result set
		for (int depth = 2; depth < elements.length; depth++) {
			String callerMethodName = elements[depth].getMethodName();
			String callerClassName = elements[depth].getClassName();
			String caller = callerClassName + "." + callerMethodName;
			if (!withResultSet || callerToResultSet.containsKey(caller)) {
				return caller;
			}
		}
		String caller = elements[2].getClassName() + "." + elements[2].getMethodName();
		return caller;
	}

}
