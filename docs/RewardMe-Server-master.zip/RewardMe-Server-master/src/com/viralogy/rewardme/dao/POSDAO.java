package com.viralogy.rewardme.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.math.BigDecimal;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Receipt;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.pos.Discount;
import com.viralogy.rewardme.pos.Employee;
import com.viralogy.rewardme.pos.InventoryCategory;
import com.viralogy.rewardme.pos.InventoryItem;
import com.viralogy.rewardme.pos.InventoryItemMod;
import com.viralogy.rewardme.pos.Transaction;
import com.viralogy.rewardme.util.ListUtil;


public abstract class POSDAO {

	private static Logger logger = Logger.getLogger(POSDAO.class);
	
	public static Transaction getTransaction(long transactionId) throws InvalidParameterException, FatalException {

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.POS.TX + " " +
				"WHERE pos_tx_id=? LIMIT 1",
				transactionId);
		if(mysql.nextRow()) {
			return Transaction.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.POS_TX_ID, ListUtil.from(transactionId+""));
		}
	}	
	
	public static Transaction getTransaction(Customer customer, Address address, String externalTxId) throws InvalidParameterException, FatalException {	
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.POS.TX + " " +
				"WHERE customer_id=? AND address_id=? AND external_pos_tx_id=? LIMIT 1",
				customer.getCustomerId(), address.getAddressId(), externalTxId);
		if(mysql.nextRow()) {
			return Transaction.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.EXTERNAL_TX_ID, ListUtil.from(externalTxId+""));
		}
	}	
	
	
	public static Employee getEmployee(long employeeId) throws InvalidParameterException, FatalException {

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.EMPLOYEE + " " +
				"WHERE employee_id=? LIMIT 1",
				employeeId);
		if(mysql.nextRow()) {
			return Employee.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.EMPLOYEE_ID, ListUtil.from(employeeId+""));
		}
	}	
	
	public static Employee getEmployee(Customer customer, Address address, String externalEmployeeId) throws InvalidParameterException, FatalException {

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.EMPLOYEE + " " +
				"WHERE customer_id=? AND address_id=? AND external_employee_id=? LIMIT 1",
				customer.getCustomerId(), address.getAddressId(), externalEmployeeId);
		if(mysql.nextRow()) {
			return Employee.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.EXTERNAL_EMPLOYEE_ID, ListUtil.from(externalEmployeeId+""));
		}
	}
	
	public static InventoryItem getInventoryItem(long inventoryItemId) throws InvalidParameterException, FatalException {	

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.POS.INVENTORY_ITEM + " " +
				"WHERE pos_inventory_item_id=? LIMIT 1",
				inventoryItemId);
		if(mysql.nextRow()) {
			return InventoryItem.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.INVENTORY_ITEM_ID, ListUtil.from(inventoryItemId+""));
		}
	}
	
	public static InventoryItem getInventoryItem(Customer customer, String externalInventoryItemId) throws InvalidParameterException, FatalException {	

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.POS.INVENTORY_ITEM + " " +
				"WHERE customer_id=? AND external_pos_inventory_item_id=? LIMIT 1",
				customer.getCustomerId(), externalInventoryItemId);
		if(mysql.nextRow()) {
			return InventoryItem.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.INVENTORY_ITEM_EXTERNAL_ID, ListUtil.from(externalInventoryItemId+""));
		}
	}
	
	public static InventoryItem getInventoryItemFromKitchenItemName(Customer customer, String kitchenItemName) throws InvalidParameterException, FatalException {	

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.POS.INVENTORY_ITEM + " " +
				"WHERE customer_id=? AND kitchen_item_name=? LIMIT 1",
				customer.getCustomerId(), kitchenItemName);
		if(mysql.nextRow()) {
			return InventoryItem.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.INVENTORY_ITEM_KITCHEN_ITEM_ID, ListUtil.from(kitchenItemName+""));
		}
	}
	
	public static InventoryItemMod getInventoryItemMod(long inventoryItemModId) throws InvalidParameterException, FatalException {	

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.POS.INVENTORY_ITEM_MOD + " " +
				"WHERE pos_inventory_item_mod_id=? LIMIT 1",
				inventoryItemModId);
		if(mysql.nextRow()) {
			return InventoryItemMod.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.INVENTORY_ITEM_MOD_ID, ListUtil.from(inventoryItemModId+""));
		}
	}
	
	public static InventoryItemMod getInventoryItemModFromKitchenItemName(Customer customer, String kitchenItemName) throws InvalidParameterException, FatalException {	

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.POS.INVENTORY_ITEM_MOD + " " +
				"WHERE customer_id=? AND kitchen_item_name=? LIMIT 1",
				customer.getCustomerId(), kitchenItemName);
		if(mysql.nextRow()) {
			return InventoryItemMod.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.INVENTORY_ITEM_MOD_KITCHEN_ITEM_ID, ListUtil.from(kitchenItemName+""));
		}
	}
	
	public static InventoryItemMod getInventoryItemMod(Customer customer, String externalInventoryItemModId) throws InvalidParameterException, FatalException {	

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.POS.INVENTORY_ITEM_MOD + " " +
				"WHERE customer_id=? AND external_pos_inventory_item_mod_id=? LIMIT 1",
				customer.getCustomerId(), externalInventoryItemModId);
		if(mysql.nextRow()) {
			return InventoryItemMod.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.INVENTORY_ITEM_MOD_EXTERNAL_ID, ListUtil.from(externalInventoryItemModId+""));
		}
	}
	
	public static InventoryCategory getInventoryCategory(long inventoryCategoryId) throws InvalidParameterException, FatalException {	

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.POS.INVENTORY_CATEGORY + " " +
				"WHERE pos_inventory_category_id=? LIMIT 1",
				inventoryCategoryId);
		if(mysql.nextRow()) {
			return InventoryCategory.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.INVENTORY_CATEGORY_ID, ListUtil.from(inventoryCategoryId+""));
		}
	}
	
	public static Discount getDiscount(long discountId) throws InvalidParameterException, FatalException {	
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.POS.DISCOUNT + " " +
				"WHERE pos_discount_id=? LIMIT 1",
				discountId);
		if(mysql.nextRow()) {
			return Discount.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.DISCOUNT_ID, ListUtil.from(discountId+""));
		}
	}
	
	public static Set<InventoryCategory> getInventoryCategories(InventoryItem inventoryItem) throws InvalidParameterException, FatalException {	

		Set<InventoryCategory> inventoryCategories = new HashSet<InventoryCategory>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT c.* FROM " + MySQL.TABLES.POS.INVENTORY_CATEGORY + " c,  " + MySQL.TABLES.POS.INVENTORY_ITEM_TO_INVENTORY_CATEGORY + " ic " +
				"WHERE ic.pos_inventory_item_id=? AND " +
				"ic.pos_inventory_category_id=c.pos_inventory_category_id",
				inventoryItem.getPosInventoryItemId());
		while(mysql.nextRow()) {
			inventoryCategories.add(InventoryCategory.from(mysql));
		}
		
		return inventoryCategories;
	}
	
	public static Set<InventoryItem> getInventoryItems(Transaction transaction) throws InvalidParameterException, FatalException {	
		
		Set<InventoryItem> inventoryItems = new HashSet<InventoryItem>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT i.* FROM " + MySQL.TABLES.POS.INVENTORY_ITEM_HISTORY + " ih,  " + 
									MySQL.TABLES.POS.INVENTORY_ITEM + " i,  " + 
									MySQL.TABLES.POS.TX_TO_INVENTORY_ITEM + " itx " +
				"WHERE itx.pos_tx_id=? AND " +
				"i.pos_inventory_item_id=ih.pos_inventory_item_id AND " + 
				"itx.pos_inventory_item_history_id=ih.pos_inventory_item_history_id",
				transaction.getPosTxId());
		while(mysql.nextRow()) {
			inventoryItems.add(InventoryItem.from(mysql));
		}
		
		return inventoryItems;
	}
	
	public static Set<InventoryItemMod> getInventoryItemMods(Transaction transaction, InventoryItem inventoryItem) throws InvalidParameterException, FatalException {	
		Set<InventoryItemMod> inventoryItemMods = new HashSet<InventoryItemMod>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT m.* FROM " + MySQL.TABLES.POS.INVENTORY_ITEM_MOD_HISTORY + " mh, " + 
									MySQL.TABLES.POS.INVENTORY_ITEM_MOD + " m, " + 
									MySQL.TABLES.POS.TX_TO_INVENTORY_ITEM + " itx, " + 
									MySQL.TABLES.POS.INVENTORY_ITEM_HISTORY + " ih, " + 
									MySQL.TABLES.POS.TX_TO_INVENTORY_ITEM_TO_POS_INVENTORY_ITEM_MOD + " itxm " +
				"WHERE itx.pos_tx_id=? AND " +
				"ih.pos_inventory_item_id=? AND " +
				"ih.pos_inventory_item_history_id=itx.pos_inventory_item_history_id AND " +
				"itx.pos_tx_to_pos_inventory_item_id=itxm.pos_tx_to_pos_inventory_item_id AND " +
				"mh.pos_inventory_item_mod_id=m.pos_inventory_item_mod_id AND " +
				"mh.pos_inventory_item_mod_history_id=itxm.pos_inventory_item_mod_history_id",
				transaction.getPosTxId(), inventoryItem.getPosInventoryItemId());
		while(mysql.nextRow()) {
			inventoryItemMods.add(InventoryItemMod.from(mysql));
		}
		
		return inventoryItemMods;
	}
	
	
	public static Set<Discount> getInventoryItemDiscounts(Transaction transaction, InventoryItem inventoryItem) throws InvalidParameterException, FatalException {	
		Set<Discount> inventoryItemDiscounts = new HashSet<Discount>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT d.* FROM " + MySQL.TABLES.POS.DISCOUNT + " d, " + 
									MySQL.TABLES.POS.TX_TO_INVENTORY_ITEM + " itx, " + 
									MySQL.TABLES.POS.INVENTORY_ITEM_HISTORY + " ih, " + 
									MySQL.TABLES.POS.TX_TO_INVENTORY_ITEM_TO_DISCOUNT + " itxd " +
				"WHERE itx.pos_tx_id=? AND " +
				"ih.pos_inventory_item_id=? AND " +
				"ih.pos_inventory_item_history_id=itx.pos_inventory_item_history_id AND " +
				"itx.pos_tx_to_pos_inventory_item_id=itxd.pos_tx_to_pos_inventory_item_id AND " +
				"d.pos_discount_id=itxd.pos_discount_id",
				transaction.getPosTxId(), inventoryItem.getPosInventoryItemId());
		while(mysql.nextRow()) {
			inventoryItemDiscounts.add(Discount.from(mysql));
		}
		
		return inventoryItemDiscounts;
	}
	
	public static Set<Discount> getDiscounts(Transaction transaction) throws InvalidParameterException, FatalException {	

		Set<Discount> discounts = new HashSet<Discount>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT d.* FROM " + MySQL.TABLES.POS.DISCOUNT + " d,  " + MySQL.TABLES.POS.TX_TO_DISCOUNT + " dtx " +
				"WHERE dtx.pos_tx_id=? AND " +
				"dtx.pos_discount_id=d.pos_discount_id",
				transaction.getPosTxId());
		while(mysql.nextRow()) {
			discounts.add(Discount.from(mysql));
		}
		
		return discounts;
	}
	
	public static void saveInventoryItemsAndMods(Transaction transaction) throws FatalException, InvalidParameterException {

		MySQL mysql = MySQL.getInstance(true);
		
		for(InventoryItem inventoryItem : transaction.getInventoryItems()) {
			
			logger.debug("Adding inventoryItemId: " + inventoryItem.getPosInventoryItemId() + " to transactionId: " + transaction.getPosTxId());

			mysql.query("INSERT INTO " + MySQL.TABLES.POS.TX_TO_INVENTORY_ITEM + " " + 
					"(pos_tx_id, pos_inventory_item_history_id, count) VALUES (?," +
						"(SELECT pos_inventory_item_history_id FROM " + MySQL.TABLES.POS.INVENTORY_ITEM_HISTORY + " " +
						"WHERE pos_inventory_item_id=? LIMIT 1)" +
					",?)", 
					transaction.getPosTxId(), inventoryItem.getPosInventoryItemId(), inventoryItem.getCount());
						
			long insertId = mysql.lastInsertId(MySQL.TABLES.POS.TX_TO_INVENTORY_ITEM);
			
			Set<InventoryItemMod> inventoryItemMods = transaction.getInventoryItemMods().get(inventoryItem.getPosInventoryItemId());
			if(inventoryItemMods != null) {
				for(InventoryItemMod inventoryItemMod : inventoryItemMods) {

					logger.debug("Adding inventoryItemMod: " + inventoryItemMod.getPosInventoryItemModId() + " to transactionToInventoryItemId: " + insertId);

					mysql.query("INSERT INTO " + MySQL.TABLES.POS.TX_TO_INVENTORY_ITEM_TO_POS_INVENTORY_ITEM_MOD + " " + 
							"(pos_tx_to_pos_inventory_item_id, pos_inventory_item_mod_history_id, count) VALUES (?," +
								"(SELECT pos_inventory_item_mod_history_id FROM " + MySQL.TABLES.POS.INVENTORY_ITEM_MOD_HISTORY + " " +
								"WHERE pos_inventory_item_mod_id=? LIMIT 1)" +
							",?)", 
							insertId, inventoryItemMod.getPosInventoryItemModId(), inventoryItemMod.getCount());	
										
				}
			}
		}
	}
	
	public static List<Transaction> getTransactions(Customer customer, Address address, User user) throws FatalException, InvalidParameterException {
		List<Transaction> transactions = new ArrayList<Transaction>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.POS.TX + " WHERE " +
					(customer == null ? "" : "customer_id=? AND ") +
					(address == null ? "" : "address_id=? AND ") +
					(user == null ? "" : "user_id=?"),
				customer == null ? null : customer.getCustomerId(), 
				address == null ? null : address.getAddressId(), 
				user == null ? null : user.getUserId());
		while(mysql.nextRow()) {
			transactions.add(Transaction.from(mysql));
		}
		return transactions;
	}
	
	public static void save(Transaction transaction, Receipt receipt) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);

		mysql.query("INSERT INTO " + MySQL.TABLES.POS.RECEIPT + " " + 
					"(pos_tx_id, raw_data, ascii_data, created) VALUES (?, ?, ?, utc_timestamp())", 
					transaction.getPosTxId(), receipt.getRawData(), receipt.getAsciiData());
	}

	public static float getAmountSumOfUser(Customer customer, Address address,
						User user, boolean doNotIncludeTax, boolean doNotIncludeDiscount,
						String paymentMethod) throws FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		if (doNotIncludeTax && doNotIncludeDiscount) {
			mysql.query("" +
					"SELECT SUM(amount_less_tax_and_discount) FROM " + MySQL.TABLES.POS.TX + " WHERE " +
					"customer_id=? AND address_id=? AND user_id=?" +
					(paymentMethod == null ? "" : " AND payment_method=?"),
					customer.getCustomerId(), address.getAddressId(), user.getUserId(),
					(paymentMethod == null ? null : paymentMethod));
		} else if (doNotIncludeTax && !doNotIncludeDiscount) {
			mysql.query("" +
					"SELECT SUM(amount_less_tax) FROM " + MySQL.TABLES.POS.TX + " WHERE " +
					"customer_id=? AND address_id=? AND user_id=?" +
					(paymentMethod == null ? "" : " AND payment_method=?"),
					customer.getCustomerId(), address.getAddressId(), user.getUserId(),
					(paymentMethod == null ? null : paymentMethod));
		} else if (!doNotIncludeTax && doNotIncludeDiscount) {
			return getAmountSumOfUserLessDiscount(mysql, customer, address, user, paymentMethod);
		} else {//include both
			mysql.query("" +
					"SELECT SUM(amount) FROM " + MySQL.TABLES.POS.TX + " WHERE " +
					"customer_id=? AND address_id=? AND user_id=?" +
					(paymentMethod == null ? "" : " AND payment_method=?"),
					customer.getCustomerId(), address.getAddressId(), user.getUserId(),
					(paymentMethod == null ? null : paymentMethod));
		}
		
		if(mysql.nextRow()) {
			if (doNotIncludeTax && doNotIncludeDiscount) {
				Object sum = mysql.getColumn("sum(amount_less_tax_and_discount)");
				return (sum == null ? 0f : ((BigDecimal) sum)).floatValue();
			} else if (doNotIncludeTax && !doNotIncludeDiscount) {
				Object sum = mysql.getColumn("sum(amount_less_tax)");
				return (sum == null ? 0f : ((BigDecimal) sum)).floatValue();
			} else if (!doNotIncludeTax && doNotIncludeDiscount) {
				//already dealt with
			} else {//include both
				Object sum = mysql.getColumn("sum(amount)");
				return (sum == null ? 0f : ((BigDecimal) sum)).floatValue();
			}
		}else {
			throw new FatalException("Summing query in POS_TX failed");//sum always returns a nextRow(). Thus if this happens, it is not because of the invalid parameters.
		}
		return 0.0f;
	}

	//convenience function
	//since there is no column for amount_less_discount, this will take the full amount - amount w/o tax to get tax, and then (amount w/o tax and discount) + tax to get amount w/o discount.
	private static float getAmountSumOfUserLessDiscount(MySQL mysql, Customer customer,
			Address address, User user, String paymentMethod) throws FatalException {
		
		mysql.query("" +
				"SELECT SUM(amount) FROM " + MySQL.TABLES.POS.TX + " WHERE " +
				"customer_id=? AND address_id=? AND user_id=?" +
				(paymentMethod == null ? "" : " AND payment_method=?"),
				customer.getCustomerId(), address.getAddressId(), user.getUserId(),
				(paymentMethod == null ? null : paymentMethod));
		
		if(mysql.nextRow()) {
			Float withTaxAndDiscount = (mysql.getColumn("sum(amount)") == null ? 0f : ((BigDecimal) mysql.getColumn("sum(amount)")).floatValue());
			
			mysql.query("" +
					"SELECT SUM(amount_less_tax) FROM " + MySQL.TABLES.POS.TX + " WHERE " +
					"customer_id=? AND address_id=? AND user_id=?" +
					(paymentMethod == null ? "" : " AND payment_method=?"),
					customer.getCustomerId(), address.getAddressId(), user.getUserId(),
					(paymentMethod == null ? null : paymentMethod));
			
			if(mysql.nextRow()) {
				Float tax = withTaxAndDiscount - (mysql.getColumn("sum(amount_less_tax)") == null ? 0f : ((BigDecimal) mysql.getColumn("sum(amount_less_tax)")).floatValue());
				
				mysql.query("" +
						"SELECT SUM(amount_less_tax_and_discount) FROM " + MySQL.TABLES.POS.TX + " WHERE " +
						"customer_id=? AND address_id=? AND user_id=?" +
						(paymentMethod == null ? "" : " AND payment_method=?"),
						customer.getCustomerId(), address.getAddressId(), user.getUserId(),
						(paymentMethod == null ? null : paymentMethod));
				
				if(mysql.nextRow()) {
					return (mysql.getColumn("sum(amount_less_tax_and_discount)") == null ? 0f : ((BigDecimal) mysql.getColumn("sum(amount_less_tax_and_discount)")).floatValue()) + tax;
				} else {
					throw new FatalException("Summing query in POS_TX failed");//sum always returns a nextRow(). Thus if this happens, it is not because of the invalid parameters.
				}
			} else {
				throw new FatalException("Summing query in POS_TX failed");//sum always returns a nextRow(). Thus if this happens, it is not because of the invalid parameters.
			}
		}
		return 0.0f;
	}

}
