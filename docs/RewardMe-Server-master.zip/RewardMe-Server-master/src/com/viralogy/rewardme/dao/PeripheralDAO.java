package com.viralogy.rewardme.dao;


import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Peripheral;
import com.viralogy.rewardme.util.ListUtil;

public abstract class PeripheralDAO {

	private static Logger logger = Logger.getLogger(PeripheralDAO.class);
	
	public static Peripheral getPeripheral(long peripheralId) throws InvalidParameterException, FatalException {	
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.PERIPHERAL + " " +
				"WHERE peripheral_id=? LIMIT 1",
				peripheralId);
		if(mysql.nextRow()) {
			return Peripheral.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.PERIPHERAL_ID, ListUtil.from(peripheralId+""));
		}	
	}
	
	public static Peripheral getPeripheral(String externalPeripheralId) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.PERIPHERAL + " " +
				"WHERE external_peripheral_id=? LIMIT 1",
				externalPeripheralId);
		if(mysql.nextRow()) {
			return Peripheral.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.EXTERNAL_PERIPHERAL_ID, ListUtil.from(externalPeripheralId));
		}
	}
}
