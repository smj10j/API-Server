package com.viralogy.rewardme.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.PointCategory;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserPoints;
import com.viralogy.rewardme.model.UserPoints.Type;
import com.viralogy.rewardme.util.ListUtil;

public abstract class PointsDAO {

	private static Logger logger = Logger.getLogger(PointsDAO.class);

	public static UserPoints getUserPoints(User user, Type type, PointCategory pointCategory, Long secondsAgo) throws FatalException, InvalidParameterException {
		return getUserPoints(user, null, type, pointCategory, secondsAgo);
	}
	
	public static UserPoints getUserPoints(User user, Customer customer, Type type, PointCategory pointCategory, Long secondsAgo) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);
		
		UserPoints userPoints = null;
		
		if(secondsAgo == null) {
			//use the summary tables
			mysql.query("" +
					"SELECT * FROM " + MySQL.TABLES.USER_POINTS_SUMMARY + " " +
					"WHERE user_id=? AND customer_id=? " + 
					"AND point_category_id=? " +
					"LIMIT 1",
					user.getUserId(), 
					customer == null ? 0 : customer.getCustomerId(),
					pointCategory == null ? 0 : pointCategory.getPointCategoryId()
			);
			
			if(mysql.nextRow()) {
				//don't use UserPoints.from() here because it starts a loop due to getUser > loadUserData > getUserAddresses > getUserPoints
				userPoints = new UserPoints(
					user, 
					customer,
					pointCategory, 
					type,
					(Long)mysql.getColumn("earned_balance"), 
					(Long)mysql.getColumn("current_balance")
				);
			}else {
				//create a new entry for the summary table since none exists
				userPoints = new UserPoints(user, customer, pointCategory, type, 0, 0);
				saveUserPointsSummary(userPoints);
			}
			
		}else {
			//use the history tables
			mysql.query("" +
					"SELECT type,sum(points) as 'current_balance',sum(if(points>0,points,0)) as 'earned_balance' FROM " + MySQL.TABLES.USER_POINTS_HISTORY + " " +
					"WHERE user_id=? AND customer_id=? " + (type != null ? "AND type=? " : "") + 
					"AND created>=(DATE_SUB(utc_timestamp(),INTERVAL ? SECOND)) " +
					"AND point_category_id=? " +
					"LIMIT 1",
					user.getUserId(), 
					customer == null ? 0 : customer.getCustomerId(), 
					type != null ? type.toString() : null, 
					secondsAgo,
					pointCategory == null ? 0 : pointCategory.getPointCategoryId());
			
			if(mysql.nextRow()) {
				//don't use UserPoints.from() here because it starts a loop due to getUser > loadUserData > getUserAddresses > getUserPoints
				userPoints = new UserPoints(
					user, 
					customer, 
					pointCategory,
					mysql.getColumn("type") != null ? Type.valueOf((String)mysql.getColumn("type")) : null,
					mysql.getColumn("earned_balance") != null ? ((BigDecimal)mysql.getColumn("earned_balance")).longValue() : 0, 
					mysql.getColumn("current_balance") != null ? ((BigDecimal)mysql.getColumn("current_balance")).longValue() : 0
				);
			}else {
				//nothing in this range
				userPoints = new UserPoints(user, customer, pointCategory, type, 0, 0);
			}
			
		}
		
		return userPoints;
	}
	
	public static void credit(UserPoints userPoints, Address address, long points) throws FatalException, InvalidParameterException {
		
		userPoints.credit(points);
		saveUserPointsSummary(userPoints);
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"INSERT INTO " + MySQL.TABLES.USER_POINTS_HISTORY + " " +
				"(user_id, customer_id, address_id, point_category_id, type, points) VALUES (?,?,?,?,?,?)",
				userPoints.getUser().getUserId(),
				userPoints.getCustomer() == null ? 0 : userPoints.getCustomer().getCustomerId(),
				address == null ? 0 : address.getAddressId(),
				userPoints.getPointCategory() == null ? 0 : userPoints.getPointCategory().getPointCategoryId(),
				userPoints.getType().toString(),
				points);
	}
	
	public static void debit(UserPoints userPoints, Address address, long points) throws FatalException, InvalidParameterException {
		
		userPoints.debit(points);
		saveUserPointsSummary(userPoints);
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"INSERT INTO " + MySQL.TABLES.USER_POINTS_HISTORY + " " +
				"(user_id, customer_id, address_id, point_category_id, type, points) VALUES (?,?,?,?,?,?)",
				userPoints.getUser().getUserId(),
				userPoints.getCustomer() == null ? 0 : userPoints.getCustomer().getCustomerId(),
				address == null ? 0 : address.getAddressId(),
				userPoints.getPointCategory() == null ? 0 : userPoints.getPointCategory().getPointCategoryId(),
				userPoints.getType().toString(),
				-1*points);
	}	
	
	public static void saveUserPointsSummary(UserPoints userPoints) throws FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"INSERT INTO " + MySQL.TABLES.USER_POINTS_SUMMARY + " " +
				"(user_id, customer_id, point_category_id, earned_balance, current_balance, created) VALUES (?,?,?,?,?,utc_timestamp()) " +
				"ON DUPLICATE KEY UPDATE " + 
				"earned_balance=?, current_balance=?",
				userPoints.getUser().getUserId(), 
				userPoints.getCustomer() == null ? 0 : userPoints.getCustomer().getCustomerId(),
				userPoints.getPointCategory() == null ? 0 : userPoints.getPointCategory().getPointCategoryId(),
				userPoints.getEarnedBalance(), 
				userPoints.getCurrentBalance(), 
				userPoints.getEarnedBalance(), 
				userPoints.getCurrentBalance()
		);
	}
	
	public static PointCategory getPointCategory(long pointCategoryId) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);
				
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.POINT_CATEGORY + " " +
				"WHERE point_category_id=? LIMIT 1",
				pointCategoryId);
		if(mysql.nextRow()) {
			return PointCategory.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.POINT_CATEGORY_ID, ListUtil.from(pointCategoryId+""));
		}
	}
	
	public static PointCategory getPointCategory(Customer customer, String name) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.POINT_CATEGORY + " " +
				"WHERE customer_id=? AND name=? LIMIT 1",
				customer.getCustomerId(), name);
		if(mysql.nextRow()) {
			return PointCategory.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.POINT_CATEGORY_CUSTOMER_NAME, ListUtil.from(customer.getApiKey(), name));
		}
	}
	
	public static List<PointCategory> getAllPointCategories(Customer customer) throws FatalException, InvalidParameterException {
		List<PointCategory> pointCategories = new ArrayList<PointCategory>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.POINT_CATEGORY + " " +
				"WHERE customer_id=? ORDER BY weight ASC,created ASC",
				customer.getCustomerId());
		
		while(mysql.nextRow()) {
			PointCategory pointCategory = PointCategory.from(mysql);
			pointCategories.add(pointCategory);
		}				
		
		return pointCategories;
	}
}
