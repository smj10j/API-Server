package com.viralogy.rewardme.dao;


import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerPreference;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserPreference;

public abstract class PreferencesDAO {

	private static Logger logger = Logger.getLogger(PreferencesDAO.class);
	
	public static Map<String, UserPreference> getUserPreferences(User user, Customer customer) throws FatalException, InvalidParameterException {
		Map<String, UserPreference> userPreferences = new HashMap<String, UserPreference>();

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER_PREFERENCE + " " + 
				"WHERE user_id=? AND customer_id=?",
				user.getUserId(), customer == null ? 0 : customer.getCustomerId());
		while(mysql.nextRow()) {
			UserPreference userPreference = UserPreference.from(mysql);
			userPreferences.put(userPreference.getName(), userPreference);
		}
		
		return userPreferences;
	}
	
	public static Map<String, CustomerPreference> getCustomerPreferences(Customer customer, Address address) throws FatalException, InvalidParameterException {
		Map<String, CustomerPreference> customerPreferences = new HashMap<String, CustomerPreference>();
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" + 
				"SELECT * FROM " + MySQL.TABLES.CUSTOMER_PREFERENCE + " " +
				"WHERE customer_id=? AND address_id=?",
				customer.getCustomerId(), address == null ? 0 : address.getAddressId());
		while(mysql.nextRow()) {
			CustomerPreference customerPreference = CustomerPreference.from(mysql);
			customerPreferences.put(customerPreference.getName(), customerPreference);
		}
		
		return customerPreferences;
		
	}
}
