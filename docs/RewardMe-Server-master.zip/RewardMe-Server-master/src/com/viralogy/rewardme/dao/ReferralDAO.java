package com.viralogy.rewardme.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.CheckinOption;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserReferral;
import com.viralogy.rewardme.model.UserReferralRequest;
import com.viralogy.rewardme.util.ListUtil;

public abstract class ReferralDAO {

	private static Logger logger = Logger.getLogger(ReferralDAO.class);

	public static List<UserReferralRequest> getUserReferralRequests(User referred, int returnCount) throws FatalException, InvalidParameterException {
		List<UserReferralRequest> userReferralRequests = new ArrayList<UserReferralRequest>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER_REFERRAL_REQUEST + " " +
				"WHERE (referred_id=? OR referred_phone_number=?) AND responded=0 LIMIT ?",
				referred.getUserId(), referred.getPhoneNumber(), returnCount);
		while(mysql.nextRow()) {
			userReferralRequests.add(UserReferralRequest.from(mysql));
		}
		return userReferralRequests;
	}
	
	public static UserReferralRequest getUserReferralRequest(User referred, Customer customer) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER_REFERRAL_REQUEST + " " +
				"WHERE referred_id=? AND customer_id=? AND responded=0 LIMIT 1",
				referred.getUserId(), customer.getCustomerId());
		if(mysql.nextRow()) {
			return UserReferralRequest.from(mysql);
		}
		return null;
	}	
	
	public static UserReferralRequest getUserReferralRequest(long userReferralRequestId) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER_REFERRAL_REQUEST + " " +
				"WHERE user_referral_request_id=? AND responded=0 LIMIT 1",
				userReferralRequestId);
		if(mysql.nextRow()) {
			return UserReferralRequest.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.USER_REFERRAL_REQUEST_ID, ListUtil.from(userReferralRequestId+""));
		}
	}		
	
	public static UserReferralRequest getUserReferralRequest(String referredPhoneNumber, Customer customer) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER_REFERRAL_REQUEST + " " +
				"WHERE referred_phone_number=? AND customer_id=? AND responded=0 LIMIT 1",
				referredPhoneNumber, customer.getCustomerId());
		if(mysql.nextRow()) {
			return UserReferralRequest.from(mysql);
		}
		return null;
	}
	
	public static UserReferralRequest createUserReferralRequest(User referrer, User referred, String referredPhoneNumber, Customer customer) throws FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"INSERT INTO " + MySQL.TABLES.USER_REFERRAL_REQUEST + " " +
				"(referrer_id, referred_id, referred_phone_number, customer_id) VALUES (?,?,?,?)",
				referrer.getUserId(), referred != null ? referred.getUserId() : null, referredPhoneNumber, customer.getCustomerId());
		
		UserReferralRequest userRefferalRequest = new UserReferralRequest(referrer, referred, referredPhoneNumber, customer);
		userRefferalRequest.setUserReferralRequestId(mysql.lastInsertId(MySQL.TABLES.USER_REFERRAL_REQUEST));
		return userRefferalRequest;
	}	
	
	public static void archiveUserReferralRequest(UserReferralRequest userReferralRequest) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"UPDATE " + MySQL.TABLES.USER_REFERRAL_REQUEST + " SET responded=1 " +
				"WHERE referrer_id=? AND (referred_phone_number=? OR referred_id=?) AND customer_id=? AND responded=0",
				userReferralRequest.getReferrer().getUserId(), userReferralRequest.getReferred().getPhoneNumber(), userReferralRequest.getReferred().getUserId(), userReferralRequest.getCustomer().getCustomerId());			
	}
	
	public static UserReferral getUserReferral(User referred, Customer customer) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER_REFERRAL + " " +
				"WHERE referred_id=? AND customer_id=? LIMIT 1",
				referred.getUserId(), customer.getCustomerId());
		if(mysql.nextRow()) {
			return UserReferral.from(mysql);
		}
		return null;
	}
	
	public static UserReferral createUserReferral(User referrer, User referred, Customer customer) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);
		
		//add an entry to the checkin table so the user can see it in their rewards list
		//post date it so the user can checkin immediately
		Address address = customer.getAddresses().get(0);
		AddressManager.getNearest(referred.getGeoCoord(), customer);
		CheckinOption checkinOption = customer.getCheckinOptions().get(0);
		checkinOption.setPointAward(0);
		UserDAO.checkin(referred, address, customer, checkinOption, null, checkinOption.getCooldownLength());
		
		//create the referral
		mysql.query("" +
				"INSERT IGNORE INTO " + MySQL.TABLES.USER_REFERRAL + " " +
				"(referrer_id, referred_id, customer_id, first_used) VALUES (?,?,?,'0000-00-00 00:00:00')",
				referrer.getUserId(), referred.getUserId(), customer.getCustomerId());
		
		UserReferral userRefferal = new UserReferral(referrer, referred, customer, null);
		return userRefferal;
	}
	
	public static void setFirstTimeReferralUse(UserReferral userReferral) throws FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"UPDATE " + MySQL.TABLES.USER_REFERRAL + " " +
				"SET first_used=utc_timestamp() WHERE referrer_id=? AND referred_id=? AND customer_id=?",
				userReferral.getReferrer().getUserId(), userReferral.getReferred().getUserId(), userReferral.getCustomer().getCustomerId());
		userReferral.setFirstUsed(new Date());
	}	
}
