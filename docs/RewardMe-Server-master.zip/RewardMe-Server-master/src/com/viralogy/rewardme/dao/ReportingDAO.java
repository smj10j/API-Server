package com.viralogy.rewardme.dao;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.RewardManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Report;
import com.viralogy.rewardme.model.ReportDataRow;
import com.viralogy.rewardme.model.Reward;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.StringUtil;

public abstract class ReportingDAO {

	private static Logger logger = Logger.getLogger(ReportingDAO.class);
	
	public static Report getReport(long reportId) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.REPORT + " " +
				"WHERE report_id=? LIMIT 1",
				reportId);
		if(mysql.nextRow()) {
			return Report.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.REPORT_ID, ListUtil.from(reportId+""));
		}
	}
	
	public static List<Report> getReports() throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		List<Report> reports = new ArrayList<Report>();
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.REPORT + " ");
		while(mysql.nextRow()) {
			reports.add(Report.from(mysql));
		}

		return reports;
	}
	
	public static void run(Report report) throws InvalidParameterException, FatalException {
		
		/*
		 * Notes about how the `definition` field is used
		 * 
		 * TABLES, SELECTS, WHERES, and GROUPBYS are required (but WHERES and GROUPBYS can be empty)
		 * 
		 * TABLES
		 * The first table used must have a `created` field because startDate, endDate, and periodType will act on that field
		 * 
		 * WHERES
		 * if "customer_id=?" or "address_id=?" is present, then the appropriate customerId and addressId values will be substituted
		 * 
		 * Row names will be created based on the GROUPBYS
		 * 
		 * X values are based on the time period
		 * Y values are based on the last item in the SELECTS
		 * 
		 */
		

		StringBuilder query = new StringBuilder();
		StringBuilder selectsQuery = new StringBuilder();
		StringBuilder tablesQuery = new StringBuilder();
		StringBuilder wheresQuery = new StringBuilder();
		StringBuilder groupBysQuery = new StringBuilder();
		StringBuilder orderBysQuery = new StringBuilder();
		StringBuilder havingsQuery = new StringBuilder();
		List<Object> queryParameters = new ArrayList<Object>();
		
		String groupByPeriodString = "period";
		List<String> selectAliases = new ArrayList<String>();
		List<String> groupBysList = new ArrayList<String>();
				
		Boolean isTableView = null;
		String primaryTable = null;
		String finalQuery = null;
		JSONArray selects = new JSONArray();
		JSONArray groupBys = new JSONArray();
		try {
			finalQuery = report.getDefinition().getString("query");
			primaryTable = report.getDefinition().getString("primaryTable");
			selects = report.getDefinition().getJSONArray("selects");
			for(int i = 0; i < selects.length(); i++) {
				String select = selects.getString(i);
				selectAliases.add(select);
			}
			groupBys = report.getDefinition().getJSONArray("groupBys");
			for(int i = 0; i < groupBys.length(); i++) {
				String groupBy = groupBys.getString(i);
				groupBysList.add(groupBy);
			}			
		}catch(JSONException e) {
			//ignore - we're using the query builder
		}
		
		if(StringUtil.isNullOrEmpty(finalQuery)) {
			try {
				
				//tables
				JSONArray tables = report.getDefinition().getJSONArray("tables");
				for(int i = 0; i < tables.length(); i++) {
					String table = tables.getString(i);
					if(tablesQuery.length() != 0) {
						tablesQuery.append(",");
					}
					if(primaryTable == null) {
						String[] temp = table.split(" ");
						if(temp.length > 1) {
							primaryTable = temp[1];	//use the alias if possible
						}else {
							primaryTable = temp[0];
						}
					}
					tablesQuery.append(table);
				}				
				
				//selects
				selects = report.getDefinition().getJSONArray("selects");
				if(selects.length() > 0) {
					//prepend
					JSONArray selects2 = new JSONArray();
					selects2.put(report.getPeriodDisplayString(primaryTable) + " as '" + groupByPeriodString + "'");
					for(int i = 0; i < selects.length(); i++) {
						selects2.put(selects.get(i));
					}
					selects = selects2;
				}else {
					selects.put(report.getPeriodDisplayString(primaryTable) + " as '" + groupByPeriodString + "'");
				}			
				for(int i = 0; i < selects.length(); i++) {
					String select = selects.getString(i);
					if(selectsQuery.length() != 0) {
						selectsQuery.append(",");
					}
					
					String[] temp = select.split(" ");
					selectAliases.add(temp[temp.length-1].trim().replace("'", ""));
					
					selectsQuery.append(select);
				}			
							
				//wheres
				JSONArray wheres = report.getDefinition().getJSONArray("wheres");
				wheres.put(primaryTable+".created >= FROM_UNIXTIME(" + (report.getStartDate().getTime() + "/1000)"));
				wheres.put(primaryTable+".created <= FROM_UNIXTIME(" + (report.getEndDate().getTime() +"/1000)"));
				for(int i = 0; i < wheres.length(); i++) {
					String where = wheres.getString(i);
					if(where.contains("customer_id=?") && report.getCustomer() == null) {
						//ignore
						continue;
					}else if(where.contains("address_id=?") && report.getAddress() == null) {
						//ignore
						continue;
					}
					if(wheresQuery.length() != 0) {
						wheresQuery.append(" AND ");
					}
					wheresQuery.append(where);								
				}	
				
				//group bys
				groupBys = report.getDefinition().getJSONArray("groupBys");
				if(groupBys.length() > 0) {
					//prepend
					JSONArray groupBys2 = new JSONArray();
					groupBys2.put(report.getPeriodGroupingString(primaryTable));
					for(int i = 0; i < groupBys.length(); i++) {
						groupBys2.put(groupBys.get(i));
						groupBysList.add(groupBys.getString(i));
					}
					groupBys = groupBys2;
				}else {
					groupBys.put(report.getPeriodGroupingString(primaryTable));
				}
				for(int i = 0; i < groupBys.length(); i++) {
					String groupBy = groupBys.getString(i);
					if(groupBysQuery.length() != 0) {
						groupBysQuery.append(",");
					}
					groupBysQuery.append(groupBy);
				}	
				
				//havings
				try {
					JSONArray havings = report.getDefinition().getJSONArray("havings");
					for(int i = 0; i < havings.length(); i++) {
						String having = havings.getString(i);
						if(havingsQuery.length() != 0) {
							havingsQuery.append(" AND ");
						}
						havingsQuery.append(having);
					}					
				}catch(JSONException e) {
					//ignore
				}
				
				//order bys
				JSONArray orderBys = new JSONArray();
				try {
					orderBys = report.getDefinition().getJSONArray("orderBys");
					if(orderBys.length() > 0) {
						//prepend
						JSONArray orderBys2 = new JSONArray();
						orderBys2.put(report.getOrderByString(primaryTable));
						for(int i = 0; i < orderBys.length(); i++) {
							orderBys2.put(orderBys.get(i));
						}
						orderBys = orderBys2;
					}else {
						orderBys.put(report.getOrderByString(primaryTable));
					}
				}catch(JSONException e) {
					orderBys.put(report.getOrderByString(primaryTable));
				}
				for(int i = 0; i < orderBys.length(); i++) {
					String orderBy = orderBys.getString(i);
					if(orderBysQuery.length() != 0) {
						orderBysQuery.append(",");
					}
					orderBysQuery.append(orderBy);
				}
					
				
	
				query.append(" SELECT ");
				query.append(selectsQuery);
				query.append(" FROM ");
				query.append(tablesQuery);
				if(wheresQuery.length() > 0) {
					query.append(" WHERE ");
					query.append(wheresQuery);
				}
				if(groupBysQuery.length() > 0) {
					query.append(" GROUP BY ");
					query.append(groupBysQuery);
				}
				if(havingsQuery.length() > 0) {
					query.append(" HAVING ");
					query.append(havingsQuery);
				}
				if(orderBysQuery.length() > 0) {
					query.append(" ORDER BY ");
					query.append(orderBysQuery);
				}
				
				finalQuery = query.toString();				
				
			} catch (JSONException e) {
				throw new InvalidParameterException(Constants.Error.GENERAL.INVALID_JSON, ListUtil.from(Constants.Request.Reporting.DEFINITION, e.getMessage()));
			}				
		}else {
			
			//put in the start and end dates
			finalQuery = finalQuery.replaceFirst("START_DATE", "FROM_UNIXTIME(" + (report.getStartDate().getTime() +"/1000)"));
			finalQuery = finalQuery.replaceFirst("END_DATE", "FROM_UNIXTIME(" + (report.getEndDate().getTime() +"/1000)"));
			
			finalQuery = finalQuery.replaceFirst("PERIOD_GROUP_FUNCTION", report.getPeriodGroupingString(primaryTable));
			finalQuery = finalQuery.replaceFirst("PERIOD_SELECT_FUNCTION", report.getPeriodDisplayString(primaryTable));
		}
		
		//now do some generic ID replacement
		while(finalQuery.contains("customer_id=?")) {
			if(report.getCustomer() != null) {
				finalQuery = finalQuery.replaceFirst("customer\\_id=\\?", "customer_id="+report.getCustomer().getCustomerId());
			}else {
				finalQuery = finalQuery.replaceFirst(("(\\w+\\.)?") + "customer\\_id=\\?", "1");				
			}
		}
		while(finalQuery.contains("address_id=?")) {
			if(report.getAddress() != null) {
				finalQuery = finalQuery.replaceFirst("address\\_id=\\?", "address_id="+report.getAddress().getAddressId());
			}else {
				finalQuery = finalQuery.replaceFirst(("(\\w+\\.)?") + "address\\_id=\\?", "1");				
			}
		}
		
		logger.debug("About to run reporting query: " + finalQuery);
		
		if(finalQuery.toLowerCase().matches(".*(drop|truncate|delete|update|alter|create|grant|insert|lock|load|trigger|upgrade)\\s.*")) {
			logger.warn("Aborting execution of a potentially dangerous query!");
			//return silently to obfuscate
			return;
		}
				
		MySQL mysql = MySQL.getSlaveInstance(true);
		try {
			mysql.query(
				finalQuery,
				queryParameters.toArray()
			);
		}catch(FatalException e) {
			if(e.getMessage().contains("MySQLSyntaxErrorException")) {
				throw new InvalidParameterException(Constants.Error.GENERAL.INVALID_SQL_QUERY, ListUtil.from(e.getMessage()));
			}else {
				throw e;
			}
		}
		
		/*
		 * Calculate the number of columns we have
		 * 
		 * If we only have 1 column, then:
		 * x = period
		 * y = terminating value
		 * 
		 * TODO:
		 * If we have 2 or more columns then:
		 * x = period
		 * y = ReportDataRow
		 * 		x = column 1
		 * 		y = remainingColumns > 1 ? ReportDataRow : remainingColumnValue
		 * 
		 * FOR NOW:
		 * remainingColumns are represented as JSON
		 * 
		 */
		
		List<String> remainingSelectColumns = new ArrayList<String>();
		for(String selectAlias : selectAliases) {
			if(groupBysList.contains(selectAlias) || selectAlias.equals(groupByPeriodString)) {
				continue;
			}
			remainingSelectColumns.add(selectAlias);
		}
		
		isTableView = isTableView == null ? remainingSelectColumns.size() > 1 : isTableView;
		
		while(mysql.nextRow()) {
			
			//get the name of the row (lines on a line chart)
			String rowName = "";
			for(String groupBy : groupBysList) {
				if(rowName.length() > 0) {
					rowName+= " > ";
				}
				rowName+= getHumanFriendlyValue(mysql, report, groupBy, true);
			}

			//get a reference to the row
			ReportDataRow reportDataRow = report.getRows().get(rowName);
			if(reportDataRow == null) {
				reportDataRow = new ReportDataRow(rowName, isTableView);
				report.getRows().put(rowName, reportDataRow);
			}
			
			if(isTableView) {
				//create a JSON object to hold the columns
				try {
					JSONObject columnValue = new JSONObject();
					for(String selectAlias : remainingSelectColumns) {	
						String prettySelectAlias = selectAlias;
						int index = selectAlias.indexOf(".");
						if(index != -1) {
							prettySelectAlias = selectAlias.substring(index+1);
							prettySelectAlias = prettySelectAlias.replace("_id", "");
						}
						columnValue.put(prettySelectAlias, getHumanFriendlyValue(mysql, report, selectAlias, false));
					}
					
					//and add the column value for the current time period
					reportDataRow.addColumn(
							MySQL.getValue(mysql, groupByPeriodString), 
							columnValue
					);					
					
				} catch (JSONException e) {
					throw new InvalidParameterException(Constants.Error.GENERAL.INVALID_JSON, ListUtil.from("Generated table view data", e.getMessage()));
				}
			}else {
				//dump the column in!
				StringBuilder columnValue = new StringBuilder();
				for(String selectAlias : remainingSelectColumns) {
					if(columnValue.length() > 0) {
						columnValue.append(" AND ");
					}
					columnValue.append(getHumanFriendlyValue(mysql, report, selectAlias, false));
				}
				
				//and add the column value for the current time period
				reportDataRow.addColumn(
						MySQL.getValue(mysql, groupByPeriodString), 
						columnValue.toString()
				);
			}
		}
	}
	
	private static String getHumanFriendlyValue(MySQL mysql, Report report, String columnName, boolean prependColumnName) throws FatalException {
		
		String prettyColumnName = columnName;
		if(prependColumnName) {
			int index = columnName.indexOf(".");
			if(index != -1) {
				prettyColumnName = columnName.substring(index+1);
				prettyColumnName = prettyColumnName.replace("_id", "");
			}
		}

		if(columnName.contains("address_id")) {
			//get a more useful name here
			long addressId = (Long)MySQL.getValue(mysql, columnName);
			try {
				Address address = AddressManager.getAddress(addressId, false);
				return address.getAddress();
			}catch(InvalidParameterException e) {
				//no address?
				logger.warn("Failed to lookup addressId="+addressId+" when running reportId="+report.getReportId());
				return(prependColumnName ? prettyColumnName+"=" : "")+MySQL.getValue(mysql, columnName);
			}
		}else if(columnName.contains("customer_id")) {
			//get a more useful name here
			long customerId = (Long)MySQL.getValue(mysql, columnName);
			try {
				Customer customer = CustomerManager.getCustomer(customerId);
				return customer.getName();
			}catch(InvalidParameterException e) {
				//no customer?
				logger.warn("Failed to lookup customerId="+customerId+" when running reportId="+report.getReportId());
				return (prependColumnName ? prettyColumnName+"=" : "")+MySQL.getValue(mysql, columnName);
			}
		}else if(columnName.contains("reward_id")) {
			//get a more useful name here
			long rewardId = (Long)MySQL.getValue(mysql, columnName);
			try {
				Reward reward = RewardManager.getReward(rewardId);
				return reward.getHeadline();
			}catch(InvalidParameterException e) {
				//no reward?
				logger.warn("Failed to lookup rewardId="+rewardId+" when running reportId="+report.getReportId());
				return(prependColumnName ? prettyColumnName+"=" : "")+MySQL.getValue(mysql, columnName);
			}
		}else if(columnName.contains("user_id")) {
			//get a more useful name here
			long userId = (Long)MySQL.getValue(mysql, columnName);
			try {
				User user = UserManager.getUser(userId);
				return user.getPhoneNumber();
			}catch(InvalidParameterException e) {
				//no user?
				logger.warn("Failed to lookup userId="+userId+" when running reportId="+report.getReportId());
				return(prependColumnName ? prettyColumnName+"=" : "")+MySQL.getValue(mysql, columnName);
			}
		}else if(columnName.contains("created") || columnName.contains("updated")) {
			//get a timestamp for easier conversion
			Date date = (Date)MySQL.getValue(mysql, columnName);
			return String.valueOf(date.getTime());
		}else {
			Object value = null;
			try {
				value = MySQL.getValue(mysql, columnName);
			}catch(FatalException e) {
				logger.warn("Failed to lookup columnName="+columnName+". This report may be bad... or this could be perfectly acceptable.");
				value = 0;
			}
			return (prependColumnName ? prettyColumnName+"=" : "")+value;			
		}		
	}
}
