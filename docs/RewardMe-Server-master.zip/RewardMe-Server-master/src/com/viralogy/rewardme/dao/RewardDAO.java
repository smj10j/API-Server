package com.viralogy.rewardme.dao;


import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Reward;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserReward;
import com.viralogy.rewardme.util.ListUtil;

public abstract class RewardDAO {
	
	private static Logger logger = Logger.getLogger(RewardDAO.class);

	public static void addRewardToCustomer(Customer customer, Reward reward) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"INSERT INTO " + MySQL.TABLES.REWARD + " " +
				"(enabled, type, headline, short_description, description, instructions, " +
				"points_required, redemption_limit, " +
				"start_date, end_date, promoted) " +
				"VALUES (?,?,?,?,?,?,?,?,?,?,?)",
				reward.isEnabled(), 
				reward.getType().toString(), 
				reward.getHeadline(), 
				reward.getShortDescription(),
				reward.getDescription(), 
				reward.getInstructions(), 
				reward.getPointsRequired(), 
				reward.getRedemptionLimit(), 
				reward.getStartDate() != null ? reward.getStartDate() : "0000-00-00 00:00:00", 
				reward.getEndDate() != null ? reward.getEndDate() : "0000-00-00 00:00:00",
				reward.isPromoted());
		reward.setRewardId(mysql.lastInsertId(MySQL.TABLES.REWARD));
		reward.setCustomer(customer);
		
		//link up the customer and address
		mysql.query("" +
				"INSERT INTO " + MySQL.TABLES.CUSTOMER_TO_REWARD + " " +
				"(customer_id, reward_id) VALUES (?,?)",
				customer.getCustomerId(), reward.getRewardId());
	}
	
	public static void removeRewardFromCustomer(Customer customer, Reward reward) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
	
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.CUSTOMER_TO_REWARD + " " +
				"WHERE customer_id=? AND reward_id=?",
				customer.getCustomerId(), reward.getRewardId());
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.REWARD + " " +
				"WHERE reward_id=?",
				reward.getRewardId());		
	}
	
	public static Reward getReward(long rewardId) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		//create the user if they don't exist
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.REWARD + " " +
				"WHERE reward_id=? LIMIT 1",
				rewardId);
		if(mysql.nextRow()) {
			Reward reward = Reward.from(mysql);			
			return reward;
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.REWARD_ID, ListUtil.from(rewardId+""));
		}
	}
	
	//this gets all the rewards for a customer and can be limited to only ones that are currently available
	public static List<Reward> getAllCustomerRewards(Customer customer) throws FatalException, InvalidParameterException {
		List<Reward> rewards = new ArrayList<Reward>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT r.* FROM " + MySQL.TABLES.REWARD + " r, " + MySQL.TABLES.CUSTOMER_TO_REWARD + " cr " + 
				"WHERE cr.reward_id=r.reward_id AND cr.customer_id=? ORDER BY points_required ASC",
				customer.getCustomerId());
		
		while(mysql.nextRow()) {
			Reward reward = Reward.from(mysql);
			reward.setCustomer(customer);
			rewards.add(reward);
		}				
		
		return rewards;
	}		
	
	
	public static List<UserReward> getActiveRewards( Customer customer, User user ) throws FatalException, InvalidParameterException {
        List<UserReward> userRewards = new ArrayList<UserReward>();
        
        MySQL mysql = MySQL.getInstance(true);
        
        mysql.query("" +
                "SELECT * FROM " + MySQL.TABLES.USER_TO_REWARD + " " + 
                "WHERE customer_id=? and " +
                "user_id=? and " +
                "completed_redeem=0 " + 
                "ORDER BY updated DESC",
                customer.getCustomerId(), 
        		user.getUserId());
        
        while(mysql.nextRow()) {
            UserReward userReward = UserReward.from(mysql);
            userRewards.add(userReward);
        }
        return userRewards;
    }
	
	public static boolean isRedemptionLimitHit(User user, Reward reward) throws FatalException {
		MySQL mysql = MySQL.getInstance(true);

		mysql.query("" +
				"SELECT count(*) as 'redemptions' FROM " + MySQL.TABLES.USER_TO_REWARD + " ur, " + MySQL.TABLES.REWARD + " r "+ 
				"WHERE user_id=? AND r.reward_id=? AND ur.reward_id=r.reward_id AND completed_redeem=1 GROUP BY user_id",
				user.getUserId(), reward.getRewardId());
		if(mysql.nextRow()) {
			long redemptions = (Long)mysql.getColumn("redemptions");
			return redemptions >= reward.getRedemptionLimit();
		}
		return false;
	}
	

	public static UserReward redeem(User user, Reward reward, Address address) throws FatalException, InvalidParameterException{
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"INSERT INTO " + MySQL.TABLES.USER_TO_REWARD + " " +
				"(user_id, reward_id, customer_id, address_id, created) VALUES (?,?,?,?,utc_timestamp())",
				user.getUserId(), reward.getRewardId(), reward.getCustomer().getCustomerId(), address.getAddressId());
				
		UserReward userReward = new UserReward(user, reward, reward.getCustomer(), address);
		
		return userReward;
	}

	public static void completeRedeem(User user, Reward reward, Address address) throws FatalException {
		MySQL mysql = MySQL.getInstance(true);

		mysql.query("" +
				"UPDATE " + MySQL.TABLES.USER_TO_REWARD + " " +
				"SET completed_redeem=1, address_id=? " +
				"WHERE user_id=? and reward_id=? and completed_redeem=0",
				address.getAddressId(),
				user.getUserId(), 
				reward.getRewardId());
	}
	
}
