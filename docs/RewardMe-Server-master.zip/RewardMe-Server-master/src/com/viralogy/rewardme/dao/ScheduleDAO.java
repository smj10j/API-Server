package com.viralogy.rewardme.dao;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Schedule;
import com.viralogy.rewardme.model.ScheduleTime;
import com.viralogy.rewardme.model.Schedule.DayOfWeekType;
import com.viralogy.rewardme.util.ListUtil;

public abstract class ScheduleDAO {
	
	private static Logger logger = Logger.getLogger(ScheduleDAO.class);

	public static void addSchedule(Schedule schedule) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"INSERT INTO " + MySQL.TABLES.SCHEDULE + " " +
				"(day_of_week, start_hour_minute, end_hour_minute, multiplier) " +
				"VALUES (?,?,?,?)",
				schedule.getDayOfWeek().toString(), schedule.getStartTime().toHourMinute(),  schedule.getEndTime().toHourMinute(), schedule.getMultiplier());
		schedule.setScheduleId(mysql.lastInsertId(MySQL.TABLES.SCHEDULE));
	}
	
	public static Schedule getSchedule(long scheduleId) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);

		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.SCHEDULE +" " + 
				"WHERE schedule_id=? LIMIT 1",
				scheduleId);
		
		if(mysql.nextRow()) {
			return Schedule.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.SCHEDULE_ID, ListUtil.from(scheduleId+""));
		}
	}
	
	public static Schedule getSchedule(DayOfWeekType dayOfWeekType, ScheduleTime startTime, ScheduleTime endTime, double multiplier) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);

		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.SCHEDULE +" " + 
				"WHERE day_of_week=? AND start_hour_minute=? AND end_hour_minute=? AND multiplier=? LIMIT 1",
				dayOfWeekType.toString(),
				startTime==null ? "0000-00:00 00:00:00" : startTime.toHourMinute(),
				endTime==null ? "0000-00:00 00:00:00" : endTime.toHourMinute(),
				multiplier
		);
		
		if(mysql.nextRow()) {
			return Schedule.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.GENERAL.INVALID_SCHEDULE_VALUES, ListUtil.from(dayOfWeekType.toString(), startTime==null ? "0000-00:00 00:00:00" : startTime.toHourMinute()+"", endTime==null ? "0000-00:00 00:00:00" : endTime.toHourMinute()+""));
		}
	}
}
