package com.viralogy.rewardme.dao;


import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.scheduler.ScheduledTask;

public abstract class ScheduledTaskDAO {

	private static Logger logger = Logger.getLogger(ScheduledTaskDAO.class);
	
	public static Set<ScheduledTask> getScheduledTasksToExecute() throws InvalidParameterException, FatalException {
		Set<ScheduledTask> scheduledTasks = new HashSet<ScheduledTask>();

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.SCHEDULED_TASK + " " + 
				"WHERE archived=0 AND timestamp<=utc_timestamp()"
		);
		while(mysql.nextRow()) {
			scheduledTasks.add(ScheduledTask.from(mysql));
		}
		
		return scheduledTasks;
	}
}
