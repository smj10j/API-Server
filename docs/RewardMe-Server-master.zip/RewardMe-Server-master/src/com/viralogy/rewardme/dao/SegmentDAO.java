package com.viralogy.rewardme.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Segment;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserSegment;
import com.viralogy.rewardme.util.ListUtil;

public abstract class SegmentDAO {
	private static Logger logger = Logger.getLogger(RewardDAO.class);
	
	public static Segment getSegment(long segmentId, boolean onlyUnArchived) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.SEGMENT + " " +
				"WHERE segment_id=? " +
				(onlyUnArchived ? "AND archived=false " : " ") +
				"LIMIT 1", 
				segmentId);
		if(mysql.nextRow()) {
			Segment segment = Segment.from(mysql);			
			return segment;
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.SEGMENT_ID, ListUtil.from(segmentId+""));
		}
	}
	
	//returns only nonArchived segment
	public static Segment getSegment(long segmentId) throws InvalidParameterException, FatalException {
		return getSegment(segmentId, true);
	}
	
	//this gets all the global segments for a customer, including archived segments if no address is provided,
	//else, this gets all the segments for a specific address, including archived segments if onlyUnArchived=false
	public static List<Segment> getAllSegments(Customer customer, Address address, boolean onlyUnArchived) throws FatalException, InvalidParameterException {
		List<Segment> segments = new ArrayList<Segment>();	
		MySQL mysql = MySQL.getInstance(true);
		
		if (address == null) {
			mysql.query("" +
					"SELECT * FROM " + MySQL.TABLES.SEGMENT + " " +
					"WHERE customer_id=? AND address_id is NULL" +
					(onlyUnArchived ? " AND archived=false" : ""),
					customer.getCustomerId());
		} else {
			mysql.query("" +
					"SELECT * FROM " + MySQL.TABLES.SEGMENT + " " +
					"WHERE customer_id=? AND address_id=?" +
					(onlyUnArchived ? " AND archived=false" : ""),
					customer.getCustomerId(), address.getAddressId());
		}
		
		while(mysql.nextRow()) {
			Segment segment = Segment.from(mysql);
			segments.add(segment);
		}
		return segments;
	}
	
	//returns only nonArchived segments
	public static List<Segment> getAllSegments(Customer customer, Address address) throws FatalException, InvalidParameterException {
		return getAllSegments(customer,address,true);
	}	
	
	//Gets customer global segments that user is in if address is null
	//else, gets the address's segments that users is in. Returns archived segments as well.
	public static List<UserSegment> getUserSegments( Customer customer, Address address, User user) throws FatalException, InvalidParameterException {
        List<UserSegment> userSegments = new ArrayList<UserSegment>();
        
        MySQL mysql = MySQL.getInstance(true);
        
        if (address == null) {
	        mysql.query("" +
	                "SELECT su.* FROM " + MySQL.TABLES.SEGMENT_TO_USER + " su, " + MySQL.TABLES.SEGMENT + " s " +
	                "WHERE su.segment_id=s.segment_id AND s.customer_id=? AND su.user_id=? AND s.address_id is NULL",
	        		customer.getCustomerId(), user.getUserId());
        } else {
        	mysql.query("" +
                    "SELECT su.* FROM " + MySQL.TABLES.SEGMENT_TO_USER + " su, " + MySQL.TABLES.SEGMENT + " s " +
                    "WHERE su.segment_id=s.segment_id AND s.customer_id=? AND su.user_id=? AND s.address_id=?",
            		customer.getCustomerId(), user.getUserId(), address.getAddressId());
        }
        
        while(mysql.nextRow()) {
            UserSegment userSegment = UserSegment.from(mysql);
            userSegments.add(userSegment);
        }
        return userSegments;
    }	

	public static UserSegment getUserSegment(User user, Segment segment) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT su.* FROM " + MySQL.TABLES.SEGMENT_TO_USER + " su, " + MySQL.TABLES.SEGMENT + " s " +
				"WHERE s.segment_id=su.segment_id AND s.segment_id=? AND su.user_id=? AND s.archived=false",
				segment.getSegmentId(), user.getUserId());
		
        if(mysql.nextRow()) {
			UserSegment userSegment = UserSegment.from(mysql);			
			return userSegment;
        } else {
        	throw new InvalidParameterException(Constants.Error.INVALID_ID.SEGMENT_ID_AND_USER_ID, ListUtil.from(user.getUserId()+"", segment.getSegmentId()+""));
        }
	}
	
	
	public static void removeFromSegmentToUserTable(Segment segment) throws FatalException {
		MySQL mysql = MySQL.getInstance(true);
        
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.SEGMENT_TO_USER + " " +
				"WHERE segment_id=?",
				segment.getSegmentId());
	}
	
	//cannot be archived segment
	public static void addUserToSegment(User user, Segment segment) throws FatalException, InvalidParameterException {
		if (segment.isArchived()) {//this check is necessary because insert will not allow duplicates and we do not remove userSegements when a segment is deleted.
			throw new InvalidParameterException(Constants.Error.INVALID_ID.SEGMENT_ID, ListUtil.from(segment.getSegmentId()+""));
		}
		MySQL mysql = MySQL.getInstance(true);

		logger.info("Adding user: " + user.getUserId() + " into segment: " + segment.getSegmentId() + " with Thread: " + Thread.currentThread().getId());
		
		mysql.query("" +
				"INSERT INTO " + MySQL.TABLES.SEGMENT_TO_USER + " " +
				"(segment_id, user_id)" + " " +
				"VALUES (?,?)",
				segment.getSegmentId(), user.getUserId());
	}
	
	public static void removeUserFromSegment(User user, Segment segment) throws FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		logger.info("Removing user: " + user.getUserId() + " from segment: " + segment.getSegmentId() + " with Thread: " + Thread.currentThread().getId());
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.SEGMENT_TO_USER + " " +
				"WHERE segment_id=? AND user_id=?",
				segment.getSegmentId(), user.getUserId());
	}

}
