package com.viralogy.rewardme.dao;


import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Server;
import com.viralogy.rewardme.util.ListUtil;

public abstract class ServerDAO {

	private static Logger logger = Logger.getLogger(ServerDAO.class);
	
	public static Server getServer(long serverId) throws InvalidParameterException, FatalException {

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.SERVER + " " +
				"WHERE server_id=? LIMIT 1",
				serverId);
		if(mysql.nextRow()) {
			return Server.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.SERVER_ID, ListUtil.from(serverId+""));
		}
	}
	
	public static List<Server> getServers(Server.Type type, int returnCount) throws InvalidParameterException, FatalException {

		List<Server> servers = new ArrayList<Server>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.SERVER + " " +
						(type != null ? "WHERE type=? " : "") +
						"LIMIT ?",
					type == null ? null : type.toString(), returnCount);
		while(mysql.nextRow()) {
			servers.add(Server.from(mysql));
		}
		
		return servers;
	}
}
