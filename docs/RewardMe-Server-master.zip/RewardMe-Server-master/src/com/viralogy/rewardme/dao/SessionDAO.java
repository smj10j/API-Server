package com.viralogy.rewardme.dao;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Session;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.util.ListUtil;

public abstract class SessionDAO {
	
	public static Session getSession(User user, Customer customer, Address address) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		if( address == null ) {
			mysql.query("" + 
						"SELECT * FROM " + MySQL.TABLES.SESSION + " " +
						"WHERE user_id=? AND customer_id=? AND address_id IS NULL " + 
						"AND created >= utc_timestamp() - interval 2 hour LIMIT 1", 
						user.getUserId(), customer.getCustomerId());
		} else {
			mysql.query("" + 
					"SELECT * FROM " + MySQL.TABLES.SESSION + " " +
					"WHERE user_id=? AND customer_id=? AND address_id=? " + 
					"AND created >= utc_timestamp() - interval 2 hour LIMIT 1", 
					user.getUserId(), customer.getCustomerId(), address == null ? "" : address.getAddressId());
		}
		
		if(mysql.nextRow()) {
			return Session.from(mysql);
		}
		throw new InvalidParameterException(Constants.Error.INVALID_ID.USER_ID_AND_CUSTOMER_ID_AND_ADDRESS_ID, 
											ListUtil.from(user.getUserId() + "", customer.getCustomerId() + "", address != null ? address.getAddressId() + "" : "" ));
	}
	
	public static Session getSession(long sessionId ) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" + 
					"SELECT * FROM " + MySQL.TABLES.SESSION + " " +
					"WHERE session_id=? LIMIT 1",
					sessionId);
		if(mysql.nextRow()) {
			return Session.from(mysql);
		}
		throw new InvalidParameterException(Constants.Error.INVALID_ID.SESSION_ID, ListUtil.from(sessionId + ""));
	}
	
}
