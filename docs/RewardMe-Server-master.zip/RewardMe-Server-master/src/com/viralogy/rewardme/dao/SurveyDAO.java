package com.viralogy.rewardme.dao;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Survey;
import com.viralogy.rewardme.model.SurveyResult;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserSurvey;
import com.viralogy.rewardme.util.ListUtil;

public abstract class SurveyDAO {

	private static Logger logger = Logger.getLogger(SurveyDAO.class);
		
	public static List<Survey> getSurveys(Customer customer, int returnCount, boolean enabledOnly) throws FatalException, InvalidParameterException {

		List<Survey> surveys = new ArrayList<Survey>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.SURVEY + " " +
				"WHERE customer_id=? " + (enabledOnly ? "AND enabled " : "") + 
				"LIMIT ?",
				customer.getCustomerId(), returnCount);
		while(mysql.nextRow()) {
			surveys.add(Survey.from(mysql));
		}
		
		return surveys;
	}
	
	
	public static Survey getSurvey(long surveyId) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.SURVEY + " " +
				"WHERE survey_id=? LIMIT 1",
				surveyId);
		if(mysql.nextRow()) {
			return Survey.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.SURVEY_ID, ListUtil.from(surveyId+""));
		}
	}
	
	public static UserSurvey getLatestUserSurvey(User user) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER_SURVEY + " " +
				"WHERE user_id=? ORDER BY created DESC LIMIT 1",
				user.getUserId());
		if(mysql.nextRow()) {
			return UserSurvey.from(mysql);
		}
		return null;
	}
	
	public static UserSurvey getUserSurvey(long userSurveyId) throws InvalidParameterException, FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER_SURVEY + " " +
				"WHERE user_survey_id=? LIMIT 1",
				userSurveyId);
		if(mysql.nextRow()) {
			return UserSurvey.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.USER_SURVEY_ID, ListUtil.from(userSurveyId+""));
		}
	}
	
	public static UserSurvey getUserSurvey(User user, Survey survey) throws FatalException, InvalidParameterException {
	
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER_SURVEY + " " +
				"WHERE user_id=? AND survey_id=? LIMIT 1",
				user.getUserId(), survey.getSurveyId());
		if(mysql.nextRow()) {
			return UserSurvey.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.USER_ID_AND_SURVEY_ID, ListUtil.from(survey.getSurveyId()+"", user.getUserId()+""));
		}
	}	
	
	public static Set<UserSurvey> getUserSurveys(Survey survey) throws FatalException, InvalidParameterException {
		
		Set<UserSurvey> userSurveys = new HashSet<UserSurvey>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER_SURVEY + " " +
				"WHERE survey_id=?",
				survey.getSurveyId());
		while(mysql.nextRow()) {
			userSurveys.add(UserSurvey.from(mysql));
		}
		
		return userSurveys;
	}
	
	public static List<SurveyResult> getSurveyResults(Survey survey) throws FatalException, InvalidParameterException {
		
		List<SurveyResult> surveyResults = new ArrayList<SurveyResult>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		int total = 0;
		mysql.query("" +
				"SELECT response,count(*) as 'count' FROM " + MySQL.TABLES.USER_SURVEY + " " +
				"WHERE survey_id=? AND response IS NOT NULL " +
				"GROUP BY survey_id,response " + 
				"ORDER BY count DESC",
				survey.getSurveyId());
		while(mysql.nextRow()) {
			SurveyResult surveyResult = SurveyResult.from(mysql);
			total+= surveyResult.getCount();
			surveyResults.add(surveyResult);
		}
		
		for(SurveyResult surveyResult : surveyResults) {
			surveyResult.setPercentage((int)((surveyResult.getCount()*1.0f / total)*100.0f));
		}
		
		return surveyResults;
	}
	
}
