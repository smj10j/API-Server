package com.viralogy.rewardme.dao;


import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.CheckinOption;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Device;
import com.viralogy.rewardme.model.DeviceApplication;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserCheckin;
import com.viralogy.rewardme.model.UserMessage;
import com.viralogy.rewardme.model.UserReward;
import com.viralogy.rewardme.util.ListUtil;

public abstract class UserDAO {

	private static Logger logger = Logger.getLogger(UserDAO.class);
	
	public static User getUser(long userId) throws InvalidParameterException, FatalException {

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER + " " +
				"WHERE user_id=? LIMIT 1",
				userId);
		if(mysql.nextRow()) {
			return User.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.USER_ID, ListUtil.from(userId+""));
		}
	}
		
	public static User getUserByUsername(String username) throws InvalidParameterException, FatalException {

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER + " " +
				"WHERE username=? LIMIT 1",
				username);
		if(mysql.nextRow()) {
			return User.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.USERNAME, ListUtil.from(username+""));
		}
	}
	
	public static User getUserByPhoneNumber(String phoneNumber) throws InvalidParameterException, FatalException {

		//TODO: uncomment for testing Cassandra
		//Cassandra.cf("Users").put("bubbles", new Column("phoneNumber", phoneNumber));
		
		MySQL mysql = MySQL.getInstance(true);
		
		//create the user if they don't exist
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER + " " +
				"WHERE phone_number=? LIMIT 1",
				phoneNumber);
		if(mysql.nextRow()) {
			return User.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.USER_PHONE_NUMBER, ListUtil.from(phoneNumber+""));
		}
	}
	
	public static void reset(User user) throws FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		/* -- no key on user_id
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.LOG_EVENT + " " +
				"WHERE user_id=?",
				user.getUserId());*/

		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_CHECKIN + " " +
				"WHERE user_id=?",
				user.getUserId());
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_MESSAGE + " " +
				"WHERE user_id=?",
				user.getUserId());
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_POINTS_HISTORY + " " +
				"WHERE user_id=?",
				user.getUserId());
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_POINTS_SUMMARY + " " +
				"WHERE user_id=?",
				user.getUserId());
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_REFERRAL + " " +
				"WHERE referred_id=?",
				user.getUserId());
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_REFERRAL + " " +
				"WHERE referrer_id=?",
				user.getUserId());
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_REFERRAL_REQUEST + " " +
				"WHERE referred_id=?",
				user.getUserId());
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_REFERRAL_REQUEST + " " +
				"WHERE referrer_id=?",
				user.getUserId());
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_TO_CUSTOMER_BROADCAST_MESSAGE + " " +
				"WHERE user_id=?",
				user.getUserId());
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_TO_REWARD + " " +
				"WHERE user_id=?",
				user.getUserId());		
		
		mysql.query("" +
				"DELETE FROM " + MySQL.TABLES.USER_TO_DEVICE + " " +
				"WHERE user_id=?",
				user.getUserId());				
	}

	
	@Deprecated
	public static boolean isUsernameAvailable(String username) throws FatalException {
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER + " " +
				"WHERE username=? LIMIT 1",
				username);
		return !mysql.nextRow();
	}
	
	public static UserCheckin getLastCheckin(User user, Customer customer, boolean onlyThoseThatAreNotCooledDown) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);
		
		UserCheckin userCheckin = null;
		
		//selects the last checkin that occurred 
		mysql.query("" +
				"SELECT *,TIMESTAMPDIFF(SECOND,created,utc_timestamp()) as 'time_passed' FROM " + MySQL.TABLES.USER_CHECKIN + " uc " +
				"WHERE user_id=? " + (customer == null ? "" : "AND customer_id=? ") +
						(onlyThoseThatAreNotCooledDown ? 
								"AND (utc_timestamp() <= (created + INTERVAL " +
								"(SELECT cooldown_length FROM " + MySQL.TABLES.CHECKIN_OPTION + " co " +
								"WHERE co.checkin_option_id=uc.checkin_option_id LIMIT 1) SECOND))" + " "
						: "") +
				"ORDER BY created DESC LIMIT 1",
				user.getUserId(), customer == null ? null : customer.getCustomerId());
		if(mysql.nextRow()) {
			userCheckin = UserCheckin.from(mysql, customer, user);
			long timePassed = (Long)(mysql.getColumn("time_passed"));
			userCheckin.setTimeRemainingInCooldown(timePassed < userCheckin.getCheckinOption().getCooldownLength() ? userCheckin.getCheckinOption().getCooldownLength() - timePassed : 0);			
		}
		
		return userCheckin;
	}
	
	public static UserReward getLastRedeem(User user, Customer customer, boolean onlyThoseThatAreNotCooledDown) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);
		
		UserReward userReward = null;
		
		//selects the last reward redemption that occurred 
		mysql.query("" +
				"SELECT *,TIMESTAMPDIFF(SECOND,updated,utc_timestamp()) as 'time_passed' FROM " + MySQL.TABLES.USER_TO_REWARD + " ur " +
				"WHERE user_id=? " + (customer == null ? "" : "AND customer_id=? ") +
						(onlyThoseThatAreNotCooledDown ? 
								"AND (utc_timestamp() <= (updated + INTERVAL " +
								"(SELECT cooldown_length FROM " + MySQL.TABLES.REWARD + " r " +
								"WHERE r.reward_id=ur.reward_id LIMIT 1) SECOND))" + " "
						: "") +
				"ORDER BY created DESC LIMIT 1",
				user.getUserId(), customer == null ? null : customer.getCustomerId());
		if(mysql.nextRow()) {
			userReward = UserReward.from(mysql);
		}
		
		return userReward;
	}
	
	public static UserCheckin checkin(User user, Address address, Customer customer, CheckinOption checkinOption, DeviceApplication deviceApplication, Long postDateSeconds) throws FatalException {
		MySQL mysql = MySQL.getInstance(true);
				
		mysql.query("" +
				"INSERT INTO " + MySQL.TABLES.USER_CHECKIN + " " +
				"(user_id, address_id, customer_id, device_application_id, checkin_option_id"+(postDateSeconds != null ? ",created" : "")+") VALUES (?,?,?,?,?"+(postDateSeconds != null ? ",(DATE_SUB(utc_timestamp(),INTERVAL ? SECOND))" : "")+")",
			user.getUserId(), 
			address.getAddressId(), 
			customer.getCustomerId(),
			deviceApplication == null ? 0 : deviceApplication.getDeviceApplicationId(),
			checkinOption.getCheckinOptionId(), 
			postDateSeconds);	
		
		UserCheckin userCheckin = new UserCheckin(user, address, customer, checkinOption, deviceApplication);
		userCheckin.setCreated(new Date(System.currentTimeMillis()));
		return userCheckin;
	}
	
	
	public static List<Device> getDevices(User user) throws FatalException, InvalidParameterException {
		List<Device> devices = new ArrayList<Device>();

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER_TO_DEVICE + " ud, " + MySQL.TABLES.DEVICE + " d " +  
				"WHERE user_id=? AND d.device_id=ud.device_id",
				user.getUserId());
		while(mysql.nextRow()) {
			Device device = Device.from(mysql);
			devices.add(device);
		}
		
		return devices;
	}
	
	public static void saveDeviceToUser(User user, Device device) throws FatalException, InvalidParameterException {

		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"INSERT IGNORE INTO " + MySQL.TABLES.USER_TO_DEVICE + " " + 
				"(user_id,device_id) VALUES (?,?)",
				user.getUserId(), device.getDeviceId());
			
	}
	
	public static List<UserMessage> getUserMessages(Customer customer, User user, int returnCount) throws FatalException, InvalidParameterException {
		List<UserMessage> userMessages = new ArrayList<UserMessage>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER_MESSAGE + " " +
				"WHERE customer_id=? AND user_id=? " +
				"ORDER BY created DESC " +
				"LIMIT ?",
				customer.getCustomerId(), user.getUserId(), returnCount);
		while(mysql.nextRow()) {
			userMessages.add(UserMessage.from(mysql));
		}
		return userMessages;
	}		

	public static Set<User> getUsersWithCheckin(Customer customer, Address address) throws FatalException, InvalidParameterException {
		Set<User> users = new HashSet<User>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER + " WHERE user_id IN " +
						"(SELECT user_id FROM " + MySQL.TABLES.USER_CHECKIN + " WHERE " + (address==null ? "customer_id" : "address_id") + "=?)",
				address==null ? customer.getCustomerId() : address.getAddressId()
		);
		while(mysql.nextRow()) {
			users.add(User.from(mysql));
		}
		return users;
	}
	
	public static List<UserCheckin> getCheckins(User user, Customer customer, boolean uniqueCustomersOnly, int returnCount) throws FatalException, InvalidParameterException {
		List<UserCheckin> userCheckins = new ArrayList<UserCheckin>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER_CHECKIN + " WHERE user_id=? " +
				(customer == null ? "" : "AND customer_id=?") + " " +
				(uniqueCustomersOnly ? "GROUP BY customer_id" : "") + " " +
				"ORDER BY created DESC " +
				"LIMIT ?",
				user.getUserId(),
				customer == null ? null : customer.getCustomerId(),
				returnCount
		);
		while(mysql.nextRow()) {
			try {
				userCheckins.add(UserCheckin.from(mysql, customer, user));
			}catch(InvalidParameterException e) {
				//if the address or checkin option is FOR SOME REASON removed, this can error
				//let's ignore for now
				//TODO: user.getCheckins - we may want to just archive checkin options and addresses to avoid this problem
			}
		}
		return userCheckins;
	}
	
	public static List<UserCheckin.ShortFormat> getShortCheckins(User user, Customer customer, boolean uniqueCustomersOnly, int returnCount) throws FatalException, InvalidParameterException {
		List<UserCheckin.ShortFormat> shortUserCheckins = new ArrayList<UserCheckin.ShortFormat>();
		
		MySQL mysql = MySQL.getInstance(true);
		
		mysql.query("" +
				"SELECT address_id,customer_id,created FROM " + MySQL.TABLES.USER_CHECKIN + " WHERE user_id=? " +
				(customer == null ? "" : "AND customer_id=?") + " " +
				(uniqueCustomersOnly ? "GROUP BY customer_id" : "") + " " +
				"ORDER BY created DESC " +
				"LIMIT ?",
				user.getUserId(),
				customer == null ? null : customer.getCustomerId(),
				returnCount
		);
		while(mysql.nextRow()) {
			shortUserCheckins.add(UserCheckin.ShortFormat.from(mysql));
		}
		return shortUserCheckins;
	}
	
	
	public static Long countUserCheckins(User user, Customer customer, Address address) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);
		if (customer == null && address!= null) {
			customer = address.getCustomer();
		}
		mysql.query("" +
				"SELECT count(*) FROM " + MySQL.TABLES.USER_CHECKIN + " WHERE user_id=? " +
				(customer == null ? "" : "AND customer_id=?") + " " +
				(address == null ? "" : "AND address_id=?"),
				user.getUserId(),
				customer == null ? null : customer.getCustomerId(),
				address == null ? null : address.getAddressId()
		);
		if(mysql.nextRow()) {
			Object obj = mysql.getColumn("count(*)");
			return (obj == null ? 0 : (Long) obj);
		} else {
			//This shouldn't ever happen because count(*) will return 0 if there doesn't exist a row with given parameters.
			throw new FatalException("Counting rows in user_checkin failed");
		}
	}
	
	
	public static UserMessage getLastUserMessage(User user) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);

		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER_MESSAGE + " " +
				"WHERE user_id=? ORDER BY created DESC LIMIT 1",
				user.getUserId());
		if(mysql.nextRow()) {
			return UserMessage.from(mysql);
		}else {
			return null;
		}
	}
	
	public static UserMessage getUserMessage(long userMessageId) throws FatalException, InvalidParameterException {
		MySQL mysql = MySQL.getInstance(true);

		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.USER_MESSAGE + " " +
				"WHERE user_message_id=? LIMIT 1",
				userMessageId);
		if(mysql.nextRow()) {
			return UserMessage.from(mysql);
		}else {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.USER_MESSAGE_ID, ListUtil.from(userMessageId+""));
		}
	}
}
