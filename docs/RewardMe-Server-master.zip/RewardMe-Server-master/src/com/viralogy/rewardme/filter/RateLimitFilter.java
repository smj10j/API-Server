package com.viralogy.rewardme.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.servlet.GatewayServlet;
import com.viralogy.rewardme.util.ServletUtil;

public final class RateLimitFilter implements Filter {
	
	private FilterConfig filterConfig = null;
	private static Logger logger = Logger.getLogger(RateLimitFilter.class);
	
	private static final JSONObject errorResponse = new JSONObject();
	static {
		try {
			JSONObject rewardme = new JSONObject();
			JSONObject error = new JSONObject();
			error.put("code", 500);
			error.put("message", "Rate Limit Hit - Please try again later");
			rewardme.put("error", error);
			rewardme.put("status", "error");
			errorResponse.put("rewardme", rewardme);
		} catch (JSONException e) {
			logger.error("FAILED TO CREATE DEFAULT JSON ERROR RESPONSE IN RATE LIMIT FILTER");
		}
	}
	
	public void init(FilterConfig filterConfig) throws ServletException {
		this.filterConfig = filterConfig;
	}

	public void destroy() {
		this.filterConfig = null;
	}

	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain) throws IOException, ServletException {
		
		if (filterConfig == null) {
			return;
		}
		
		if(GatewayServlet.isSandbox()) {
			chain.doFilter(servletRequest, servletResponse);
			return;
		}
		
		HttpServletRequest httpServletRequest = (HttpServletRequest)servletRequest;
		RewardMeRequest request = new RewardMeRequest(httpServletRequest);

		/*
		 * TODO: Rate limit by deviceId when no userId is present
		 * We have to be careful to get the right number here, but adding in a deviceId 
		 * rate limit will prevent server harm from negligent setups (like tablet circular references)
		 */
		try {
			request.setUserFromRequest();
			request.setCustomerFromRequest();
			
			User user = request.getUser();
			Customer customer = request.getCustomer();
			String methodName = request.getParameter(Constants.Request.METHOD);
			
			if(customer != null && user != null) {
				if(ServletUtil.isRateLimitHit(customer, user, methodName)) {
					logger.warn("Aborting request");
					HttpServletResponse httpServletResponse = (HttpServletResponse)servletResponse;
					PrintWriter out = httpServletResponse.getWriter();
					out.write(errorResponse.toString());
					out.close();
					return;
				}
			}
			
		} catch (FatalException e) {
			logger.error(e);
			e.printStackTrace();
		} catch (InvalidParameterException e) {
			
			/*HttpServletResponse httpServletResponse = (HttpServletResponse)servletResponse;
			PrintWriter out = httpServletResponse.getWriter();
			out.write(e.toString());
			out.close();*/
			
			logger.error(e);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e);
		}finally {

		}

		chain.doFilter(servletRequest, servletResponse);
	}
	  
}
