package com.viralogy.rewardme.manager;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.ABTestDAO;
import com.viralogy.rewardme.dao.GeneralDAO;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.util.Cache;
import com.viralogy.rewardme.model.ABCohort;
import com.viralogy.rewardme.model.ABTest;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.DatabaseBackedObject;
import com.viralogy.rewardme.model.Device;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.service.ABTestService;

public class ABTestManager {

	private static Logger logger = Logger.getLogger(ABTestManager.class);
	
	public static ABCohort assignUser(ABTest test, User user, Customer customer) throws InvalidParameterException, FatalException{
		
		//AB Testing
		/*long linkedCohort = ABTestDAO.getLinkedCohort(abTestId, userId);
		
		if(linkedCohort != -1) {
			return linkedCohort;
		}

		List<ABCohort> cohorts = getCohortsById(abTestId, -1);
		if(cohorts.size() == 0) {
			throw new FatalException("You haven't created cohorts for the test specified.");
		}
		long cohort = (int)(Math.random()*cohorts.size()) + 1;
		ABTestDAO.newLinkedCohort(abTestId, userId, cohort);
		return cohort;*/
		
		//many armed bandit testing
		long linkedCohort = ABTestDAO.getLinkedCohort(test, user);
		
		if(linkedCohort != -1) {
			ABCohort cohort = getAbCohorts(test, linkedCohort, customer).get(0);
			logger.debug("cohort.getViews() is " + cohort.getViews());
			cohort.setViews(cohort.getViews() + 1);
			cohort.save();
			return cohort;
		}
		
		List<ABCohort> cohorts = getAbCohorts(test, -1, customer);
		if(cohorts.size() == 0) {
			throw new InvalidParameterException(Constants.Error.ABTEST.NO_COHORTS_EXIST);
		}
		
		long displayCohortId;
		if(Math.random() < 0.1) {
			displayCohortId = (int)(Math.random() * (cohorts.size() + 1));
			ABTestDAO.newLinkedCohort(test, user, displayCohortId);
		}
		else {
			long max = 0;
			displayCohortId = 0;
			for(int i = 0; i < cohorts.size(); i++) {
				long temp = cohorts.get(i).getSuccesses() / cohorts.get(i).getViews();
				if(temp > max) {
					max = temp;
				}
				displayCohortId = i;
			}
			ABTestDAO.newLinkedCohort(test, user, displayCohortId);
		}
		ABCohort cohort = getAbCohorts(test, displayCohortId, customer).get(0);
		logger.debug("cohort.getViews() is " + cohort.getViews());
		cohort.setViews(cohort.getViews() + 1);
		cohort.save();
		return cohort;
	}
	
	public static boolean logSuccess(ABCohort cohort, ABTest test, Customer customer) throws InvalidParameterException, FatalException {
		cohort.setSuccesses(cohort.getSuccesses() + 1);
		cohort.save();
		return true;
	}
	
	
	
	
	
	
	
	public static List<ABTest> getAllAbTests(int returnCount) throws InvalidParameterException, FatalException {	
		return ABTestDAO.getAllAbTests(returnCount);
	}


	public static ABTest getAbTest(long abTestId, Customer customer) throws InvalidParameterException, FatalException {
		List<ABTest> tests = null;
		if(customer != null){
			tests = Cache.get(customer.getApiKey(), Cache.namespace.AB_TESTS);
		}
		
		if(tests == null) {
			return ABTestDAO.getAbTest(abTestId);
		}
		else {		
			for(int i= 0; i < tests.size(); i++){
				if(tests.get(i).getAbTestId() != abTestId) {
					tests.remove(i);
					i--;
				}
			}
			if(tests.size() == 0) {
				return ABTestDAO.getAbTest(abTestId);
			}
			else{
				return tests.get(0);
			}
		}

	}
	
	public static ABTest getAbTest(Customer customer) throws InvalidParameterException, FatalException {
		List<ABTest> tests = null;
		if(customer != null){
			tests = Cache.get(customer.getApiKey(), Cache.namespace.AB_TESTS);
		}
		
		if(tests == null) {
			return ABTestDAO.getAbTest(customer);
		}
		else {		
			for(int i= 0; i < tests.size(); i++){
				if(tests.get(i).getCustomer().getCustomerId() != customer.getCustomerId()) {
					tests.remove(i);
					i--;
				}
			}
			if(tests.size() == 0) {
				return ABTestDAO.getAbTest(customer);
			}
			else{
				return tests.get(0);
			}
		}

	}
	
	public static boolean saveAbTest(ABTest test) throws InvalidParameterException, FatalException {
		//test.save();
		
		ABTest target = getAbTest(test.getAbTestId(), test.getCustomer());
		if(target != null) { //replacing
			if(test.getName() == null) {
				test.setName(target.getName());
			}
			if(test.getDescription() == null) {
				test.setDescription(target.getDescription());
			}
			if(test.getCustomer() == null) {
				test.setCustomer(target.getCustomer());
			}
			if(test.getAddress() == null) {
				test.setAddress(target.getAddress());
			}
		}
		test.save();		
		return true;
	}
	
	
	
	
	
	
	public static List<ABCohort> getAllAbCohorts(ABTest test) throws InvalidParameterException, FatalException {
		return ABTestDAO.getAllAbCohorts(test);
	}
	
	public static List<ABCohort> getAbCohorts(ABTest test, long displayCohortId, Customer customer) throws InvalidParameterException, FatalException {

		/*List<ABCohort> cohorts = Cache.get(customer.getApiKey(), Cache.namespace.AB_COHORTS);
		
		if(cohorts == null) {
			if(displayCohortId == -1) {
				cohorts = ABTestDAO.getAllAbCohorts(test);
			}
			else {
				cohorts = ABTestDAO.getAbCohortsById(test, displayCohortId);
			}
			Cache.put(cohorts, customer.getApiKey(), Cache.namespace.AB_COHORTS);
		}
		else{
			for(int i = 0; i < cohorts.size(); i++) {
				if(cohorts.get(i).getAbTest().getAbTestId() != test.getAbTestId()) {
					cohorts.remove(i);
					i--;
				}
				if(displayCohortId != -1 && cohorts.get(i).getDisplayCohortId() != displayCohortId) {
					cohorts.remove(i);
					i--;
				}
			}
			if(cohorts.size() == 0) {
				if(displayCohortId == -1) {
					cohorts = ABTestDAO.getAllAbCohorts(test);
				}
				else {
					cohorts = ABTestDAO.getAbCohortsById(test, displayCohortId);
				}
				Cache.put(cohorts, customer.getApiKey(), Cache.namespace.AB_COHORTS);
			}
		}
		
		return cohorts;*/
		
		return ABTestDAO.getAbCohortsById(test, displayCohortId);
	}
	
	public static boolean saveAbCohort(ABCohort cohort, Customer customer) throws InvalidParameterException, FatalException {
		List<ABCohort> cohorts = getAbCohorts(cohort.getAbTest(), cohort.getDisplayCohortId(), customer);
		logger.debug("you are in saveCohort");
		if(cohort.getDisplayCohortId() == -1) { //only testId present, so you could get a lot of potential cohorts.  assume you want to save a new one.
			cohort.setDisplayCohortId(cohorts.size() + 1);
			logger.debug("displayCohortId is -1 in saveCohort");
		}
		else if(cohorts.size() != 0) { //only one cohort found, since cohortId and testId are both present
			logger.debug("only one cohort found for saveCohort");
			ABCohort target = cohorts.get(0);
			if(cohort.getAbTest().getAbTestId() == target.getAbTest().getAbTestId() && cohort.getDisplayCohortId() == target.getDisplayCohortId()) {
				cohort.setAbCohortId(target.getAbCohortId());
				cohort.setSuccesses(target.getSuccesses());
				cohort.setViews(target.getViews());
			}
			if(cohort.getDescription() == null) {
				cohort.setDescription(target.getDescription());
			}
		}
		logger.debug("testId: " + cohort.getAbTest().getAbTestId());
		logger.debug("displayCohortId: " + cohort.getDisplayCohortId());
		logger.debug("cohortId: " + cohort.getAbCohortId());
		logger.debug("successes: " + cohort.getSuccesses());
		logger.debug("views: " + cohort.getViews());
		logger.debug("description: " + cohort.getDescription());
		
		cohort.save();
		logger.debug("cohort saved.");
		return true;
	}
}
