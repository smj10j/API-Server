package com.viralogy.rewardme.manager;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.AddressDAO;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.AddressMetaData;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.GeoCoord;
import com.viralogy.rewardme.util.Cache;

public abstract class AddressManager {
	
	private static Logger logger = Logger.getLogger(AddressManager.class);

	public static Address getAddress(long addressId, boolean enabledOnly) throws FatalException, InvalidParameterException {
		Address address = Cache.get(addressId+"|"+enabledOnly, Cache.namespace.ADDRESS);
		if(address == null) {
			address = AddressDAO.getAddress(addressId, enabledOnly);
			Cache.put(address, addressId+"|"+enabledOnly, Cache.namespace.ADDRESS);
		}
		//logger.debug("Got addressId: " + address.getAddressId() + OutputUtil.getElapsedString());
		return address;
	}
	
	public static Address getAddress(String addressStr) throws FatalException, InvalidParameterException {
		Long addressId = Cache.get(addressStr, Cache.namespace.ADDRESS_STRING_TO_ADDRESS_ID);
		if(addressId == null) {
			addressId = AddressDAO.getAddressId(addressStr);
			Cache.put(addressId, addressStr, Cache.namespace.ADDRESS_STRING_TO_ADDRESS_ID);
		}
		return getAddress(addressId, true);
	}
	
	public static Address getAddressFromCardspring(String cardspringStoreId, Customer customer) throws FatalException, InvalidParameterException {
		return AddressDAO.getAddressFromCardspring(cardspringStoreId, customer);
	}
	
	public static AddressMetaData getAddressMetaData(Address address) throws FatalException, InvalidParameterException {
		AddressMetaData addressMetaData = Cache.get(address.getAddressId()+"", Cache.namespace.ADDRESS_META_DATA);
		if(addressMetaData == null) {
			addressMetaData = AddressDAO.getAddressMetaData(address);
			Cache.ignoreCacheOnNext();
			Cache.put(addressMetaData, address.getAddressId()+"", Cache.namespace.ADDRESS_META_DATA);
		}
		return addressMetaData;
	}
	
	public static List<Address> getAllAddresses(Customer customer) throws FatalException, InvalidParameterException {
		List<Address> addresses = Cache.get(customer.getApiKey(), Cache.namespace.CUSTOMER_ADDRESSES);
		if(addresses == null) {
			addresses = AddressDAO.getAllAddresses(customer);
			Cache.put(addresses, customer.getApiKey(), Cache.namespace.CUSTOMER_ADDRESSES);
		}
		//logger.debug("Got all addresses for customerId: " + customer.getCustomerId() + OutputUtil.getElapsedString());
		return addresses;
	}	
	
	public static List<Address> query(GeoCoord geoCoord, Customer customer, Integer radius, String query, int returnCount, int startPageIndex, boolean sortByDistance) throws FatalException, InvalidParameterException {
		List<Address> addresses = Cache.get(geoCoord.getRegionId()+"",customer==null?"null":customer.getCustomerId()+"",query,radius+"",returnCount+"",startPageIndex+"",sortByDistance+"", Cache.namespace.QUERY_ADDRESSES);
		if(addresses == null) {
			addresses = AddressDAO.query(geoCoord, customer, radius, query, returnCount, startPageIndex, sortByDistance);
			Cache.put(geoCoord.getRegionId()+"",customer==null?"null":customer.getCustomerId()+"",query,radius+"",returnCount+"",startPageIndex+"",sortByDistance+"", Cache.namespace.QUERY_ADDRESSES);
		}
		return addresses;
	}
	
	public static Address getNearest(GeoCoord geoCoord, Customer customer) throws FatalException, InvalidParameterException {
		Address address = Cache.get(geoCoord == null ? "null" : geoCoord.getRegionId()+"",customer==null?"null":customer.getCustomerId()+"", Cache.namespace.NEARBY_ADDRESSES);
		if(address == null) {		
			address = AddressDAO.getNearest(geoCoord, customer);
			Cache.put(address, geoCoord == null ? "null" : geoCoord.getRegionId()+"",customer==null?"null":customer.getCustomerId()+"", Cache.namespace.NEARBY_ADDRESSES);
		}
		return address;
	}
	
	public static void addAddressToCustomer(Address address, boolean force) throws InvalidParameterException, FatalException {
		
		address.refresh();
		if(!force) {
			address.refreshMetaData();
		}
		address.save();
		logger.debug("Created new address: " + address.getAddress());
		
		try {
			AddressDAO.addAddressToCustomer(address.getCustomer(), address);
			address.getCustomer().getAddresses().add(address);
			logger.debug("Added address " + address.getAddress() + " to customer " + address.getCustomer().getCustomerId());
		}catch(InvalidParameterException e) {
			//already linked! ignore
		}
		
		//should we flush the cache? right now search results will not immediately update
		Cache.remove(address.getCustomer().getApiKey(), Cache.namespace.CUSTOMER_BY_API_KEY);
		Cache.remove(address.getCustomer().getCustomerId()+"", Cache.namespace.CUSTOMER_BY_ID);
		Cache.remove(address.getCustomer().getApiKey(), Cache.namespace.CUSTOMER_ADDRESSES);
	}

	public static void save(Address address) throws InvalidParameterException, FatalException {
		address.save();
		address.getAddressMetaData().save();
		//should we flush the cache? right now search results will not immediately update
		Cache.remove(address.getCustomer().getApiKey(), Cache.namespace.CUSTOMER_BY_API_KEY);
		Cache.remove(address.getCustomer().getCustomerId()+"", Cache.namespace.CUSTOMER_BY_ID);
		Cache.remove(address.getCustomer().getApiKey(), Cache.namespace.CUSTOMER_ADDRESSES);		
		Cache.remove(address.getAddressId()+"|"+true, Cache.namespace.ADDRESS);			
		Cache.remove(address.getAddressId()+"|"+false, Cache.namespace.ADDRESS);			
		Cache.remove(address.getAddressId()+"", Cache.namespace.ADDRESS_META_DATA);			
	}
	
	public static void removeAddressFromCustomer(Customer customer, Address address) throws InvalidParameterException, FatalException {
		AddressDAO.removeAddressFromCustomer(customer, address);
		Cache.remove(customer.getApiKey(), Cache.namespace.CUSTOMER_BY_API_KEY);
		Cache.remove(customer.getCustomerId()+"", Cache.namespace.CUSTOMER_BY_ID);
		Cache.remove(customer.getApiKey(), Cache.namespace.CUSTOMER_ADDRESSES);
		Cache.remove(address.getAddressId()+"|"+true, Cache.namespace.ADDRESS);			
		Cache.remove(address.getAddressId()+"|"+false, Cache.namespace.ADDRESS);			
		Cache.remove(address.getAddressId()+"", Cache.namespace.ADDRESS_META_DATA);			
		customer.getAddresses().remove(address);
	}

}
