package com.viralogy.rewardme.manager;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.AdminDAO;
import com.viralogy.rewardme.model.SecretKey;
import com.viralogy.rewardme.model.SecretKey.Type;
import com.viralogy.rewardme.util.Cache;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.SecurityUtil;

public abstract class AdminManager {
	
	private static Logger logger = Logger.getLogger(AdminManager.class);

	public static SecretKey getSecretKey(long secretKeyId) throws InvalidParameterException, FatalException {	
		SecretKey secretKey = Cache.get(secretKeyId+"", Cache.namespace.SECRET_KEY_BY_ID);
		if(secretKey == null) {
			secretKey = AdminDAO.getSecretKey(secretKeyId);
			Cache.put(secretKey, secretKeyId+"", Cache.namespace.SECRET_KEY_BY_ID);
		}
		return secretKey;
	}		
	
	public static SecretKey getSecretKey(String secretKeyValue, Type type) throws InvalidParameterException, FatalException {	
		SecretKey secretKey = Cache.get(secretKeyValue, Cache.namespace.SECRET_KEY_BY_TYPE_AND_KEY);
		if(secretKey == null) {
			secretKey = AdminDAO.getSecretKey(secretKeyValue, type);
			Cache.put(secretKey, secretKeyValue, Cache.namespace.SECRET_KEY_BY_TYPE_AND_KEY);
		}
		return secretKey;
	}			
		
	public static List<SecretKey> getSecretKeys(Type type) throws InvalidParameterException, FatalException {
		List<SecretKey> secretKeys = Cache.get(type.toString()+"", Cache.namespace.SECRET_KEYS_BY_TYPE);
		if(secretKeys == null) {
			secretKeys = AdminDAO.getSecretKeys(type);
			Cache.put(secretKeys, type.toString()+"", Cache.namespace.SECRET_KEYS_BY_TYPE);
		}
		return secretKeys;		
	}
	
	public static void updateAdminSecretKeys() throws InvalidParameterException, FatalException {
		Constants.Request.ADMIN_SECRET_KEYS = 		getSecretKeys(SecretKey.Type.EVERYTHING);
		Constants.Request.ADMIN_SECRET_KEYS.addAll(	getSecretKeys(SecretKey.Type.API));
	}
		
}
