package com.viralogy.rewardme.manager;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.ApplicationDAO;
import com.viralogy.rewardme.model.Application;
import com.viralogy.rewardme.model.ApplicationObservation;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.DeviceApplication;
import com.viralogy.rewardme.util.Cache;

public abstract class ApplicationManager {

	private static Logger logger = Logger.getLogger(ApplicationManager.class);
	
	public static Application getApplication(long applicationId) throws InvalidParameterException, FatalException {	
		Application application = Cache.get(applicationId+"", Cache.namespace.APPLICATION_BY_APPLICATION_ID);
		if(application == null) {
			application = ApplicationDAO.getApplication(applicationId);
			Cache.put(application, applicationId+"", Cache.namespace.APPLICATION_BY_APPLICATION_ID);
		}
		return application;
	}
	
	public static List<Application> getApplications(Customer customer) throws InvalidParameterException, FatalException {	
		return ApplicationDAO.getApplications(customer);
	}
	
	public static void save(Application application) throws InvalidParameterException, FatalException {
		application.save();
		Cache.remove(application.getApplicationId()+"", Cache.namespace.DEVICE_APPLICATION_BY_DEVICE_ID);
	}
	
	public static void remove(Application application) throws InvalidParameterException, FatalException {
		application.setArchived(true);
		save(application);
		
		//remove the device applications using this application
		try {
			List<DeviceApplication> deviceApplications = DeviceManager.getDeviceApplications(application);
			for(DeviceApplication deviceApplication : deviceApplications) {
				DeviceManager.remove(deviceApplication);
			}
		}catch(InvalidParameterException e) {
			//no device application - this is okay
		}
	}
	
	public static void save(ApplicationObservation applicationObservation) throws InvalidParameterException, FatalException {
		applicationObservation.save();
	}
}
