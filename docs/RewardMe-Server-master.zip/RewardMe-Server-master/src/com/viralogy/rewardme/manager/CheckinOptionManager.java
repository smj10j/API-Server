package com.viralogy.rewardme.manager;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.CheckinOptionDAO;
import com.viralogy.rewardme.model.CheckinOption;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.PointCategory;
import com.viralogy.rewardme.model.Schedule;
import com.viralogy.rewardme.util.Cache;

public abstract class CheckinOptionManager {
	
	private static Logger logger = Logger.getLogger(CheckinOptionManager.class);

	public static CheckinOption getCheckinOption(long checkinOptionId) throws FatalException, InvalidParameterException {
		CheckinOption checkinOption = Cache.get(checkinOptionId+"", Cache.namespace.CHECKIN_OPTION);
		if(checkinOption == null) {
			checkinOption = CheckinOptionDAO.getCheckinOption(checkinOptionId);
			Cache.put(checkinOption, checkinOptionId+"", Cache.namespace.CHECKIN_OPTION);
		}
		//logger.debug("Got checkinOptionId: " + checkinOption.getCheckinOptionId() + OutputUtil.getElapsedString());
		return checkinOption;
	}
	
	public static List<CheckinOption> getAllCheckinOptions(Customer customer, boolean ignoreSchedules) throws FatalException, InvalidParameterException {
		List<CheckinOption> checkinOptions = Cache.get(customer.getApiKey()+"|"+ignoreSchedules, Cache.namespace.CUSTOMER_CHECKIN_OPTIONS);
		if(checkinOptions == null) {
			checkinOptions = CheckinOptionDAO.getAllCheckinOptions(customer, ignoreSchedules);
			Cache.put(checkinOptions, customer.getApiKey()+"|"+ignoreSchedules, Cache.namespace.CUSTOMER_CHECKIN_OPTIONS);
		}
		//logger.debug("Got all checkin options for customerId: " + customer.getCustomerId() + OutputUtil.getElapsedString());
		return checkinOptions;
	}	
	
	public static void save(Customer customer, CheckinOption checkinOption) throws FatalException, InvalidParameterException {
		if(checkinOption.getPointCategory() == null) {
			PointCategory pointCategory = new PointCategory();
			pointCategory.setPointCategoryId(0);
			checkinOption.setPointCategory(pointCategory);
		}
		checkinOption.save();
		Cache.remove(customer.getApiKey(), Cache.namespace.CUSTOMER_BY_API_KEY);
		Cache.remove(customer.getCustomerId()+"", Cache.namespace.CUSTOMER_BY_ID);
		Cache.remove(customer.getApiKey()+"|"+true, Cache.namespace.CUSTOMER_CHECKIN_OPTIONS);
		Cache.remove(customer.getApiKey()+"|"+false, Cache.namespace.CUSTOMER_CHECKIN_OPTIONS);
	}
	
	public static void addCheckinOptionToCustomer(Customer customer, CheckinOption checkinOption) throws InvalidParameterException, FatalException {
		save(customer, checkinOption);
		CheckinOptionDAO.addCheckinOptionToCustomer(customer, checkinOption);
		customer.getCheckinOptions().add(checkinOption);
	}
	
	public static void removeCheckinOptionFromCustomer(Customer customer, CheckinOption checkinOption) throws InvalidParameterException, FatalException {
		CheckinOptionDAO.removeCheckinOptionFromCustomer(customer, checkinOption);
		Cache.remove(customer.getApiKey(), Cache.namespace.CUSTOMER_BY_API_KEY);
		Cache.remove(customer.getCustomerId()+"", Cache.namespace.CUSTOMER_BY_ID);
		Cache.remove(customer.getApiKey()+"|"+true, Cache.namespace.CUSTOMER_CHECKIN_OPTIONS);
		Cache.remove(customer.getApiKey()+"|"+false, Cache.namespace.CUSTOMER_CHECKIN_OPTIONS);
		Cache.remove(checkinOption.getCheckinOptionId()+"", Cache.namespace.CHECKIN_OPTION);
		customer.getCheckinOptions().remove(checkinOption);
	}
	
	public static void addScheduleToCheckinOption(Customer customer, CheckinOption checkinOption, Schedule schedule) throws FatalException, InvalidParameterException {
		try {
			schedule = ScheduleManager.getSchedule(schedule.getDayOfWeek(), schedule.getStartTime(), schedule.getEndTime(), schedule.getMultiplier());
		}catch(InvalidParameterException e) {
			//schedule has not yet been created
			ScheduleManager.addSchedule(schedule);
		}
		CheckinOptionDAO.addScheduleToCheckinOption(checkinOption, schedule);
		Cache.remove(customer.getApiKey(), Cache.namespace.CUSTOMER_BY_API_KEY);
		Cache.remove(customer.getCustomerId()+"", Cache.namespace.CUSTOMER_BY_ID);
		Cache.remove(customer.getApiKey()+"|"+true, Cache.namespace.CUSTOMER_CHECKIN_OPTIONS);
		Cache.remove(customer.getApiKey()+"|"+false, Cache.namespace.CUSTOMER_CHECKIN_OPTIONS);
		Cache.remove(checkinOption.getCheckinOptionId()+"", Cache.namespace.CHECKIN_OPTION);
		checkinOption.getSchedules().add(schedule);
		Cache.clear();
	}	
	
	public static void removeScheduleFromCheckinOption(Customer customer, CheckinOption checkinOption, Schedule schedule) throws FatalException, InvalidParameterException {
		CheckinOptionDAO.removeScheduleFromCheckinOption(checkinOption, schedule);
		Cache.remove(customer.getApiKey(), Cache.namespace.CUSTOMER_BY_API_KEY);
		Cache.remove(customer.getCustomerId()+"", Cache.namespace.CUSTOMER_BY_ID);
		Cache.remove(customer.getApiKey()+"|"+true, Cache.namespace.CUSTOMER_CHECKIN_OPTIONS);
		Cache.remove(customer.getApiKey()+"|"+false, Cache.namespace.CUSTOMER_CHECKIN_OPTIONS);
		Cache.remove(checkinOption.getCheckinOptionId()+"", Cache.namespace.CHECKIN_OPTION);
		checkinOption.getSchedules().remove(schedule);
	}	
}
