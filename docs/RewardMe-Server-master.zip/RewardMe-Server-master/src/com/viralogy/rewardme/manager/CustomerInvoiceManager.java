package com.viralogy.rewardme.manager;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.CustomerInvoiceDAO;
import com.viralogy.rewardme.model.CustomerBilling;
import com.viralogy.rewardme.model.CustomerInvoice;
import com.viralogy.rewardme.model.CustomerInvoiceItem;
import com.viralogy.rewardme.model.CustomerInvoiceRecurring;
import com.viralogy.rewardme.util.ListUtil;

public abstract class CustomerInvoiceManager
{

    private static Logger logger = Logger.getLogger(CustomerInvoiceManager.class);
    
    public static void save(CustomerBilling customerBilling) throws FatalException, InvalidParameterException{
        customerBilling.save();
    }
    
    public static void save(CustomerInvoiceItem customerInvoiceItem) throws FatalException, InvalidParameterException{
        customerInvoiceItem.save();
    }
    
    public static void save(CustomerInvoiceRecurring customerInvoiceRecurring) throws FatalException, InvalidParameterException{
        customerInvoiceRecurring.save();
    }
    
    public static void save(CustomerInvoice customerInvoice) throws FatalException, InvalidParameterException {
        customerInvoice.save();
    }
    
    public static CustomerInvoiceRecurring getCustomerInvoiceRecurring(long customerBillingId) throws InvalidParameterException, FatalException {
        return CustomerInvoiceDAO.getCustomerInvoiceRecurring( customerBillingId );
    }
    
    public static CustomerInvoice getCustomerInvoice(long freshbooksInvoiceId) throws InvalidParameterException, FatalException {
        return CustomerInvoiceDAO.getCustomerInvoice( freshbooksInvoiceId );
    }
    
    public static CustomerInvoiceItem getCustomerInvoiceItem ( String name, String description, float unitCost, long quantity, boolean createNew ) throws FatalException, InvalidParameterException {
        
        try {
            return CustomerInvoiceDAO.getCustomerInvoiceItem( name, description, unitCost, quantity);
        } catch (InvalidParameterException e ) {
            // Item does not yet exist
        }
        
        if( createNew ) {
            logger.debug("Trying to create the invoice item since does not already exist");
            CustomerInvoiceItem customerInvoiceItem = new CustomerInvoiceItem(name, description, unitCost, quantity);
            save(customerInvoiceItem);
            
            return customerInvoiceItem;
        } else {
            throw new InvalidParameterException(Constants.Error.BILLING.FRESHBOOKS_NOT_SYNCED, ListUtil.from( name+""));
        }
    }
    
    public static long getCustomerInvoiceItemId( CustomerInvoiceItem customerInvoiceItem ) throws FatalException, InvalidParameterException{
        CustomerInvoiceItem item = getCustomerInvoiceItem( customerInvoiceItem.getName(), customerInvoiceItem.getDescription(), 
                                                           customerInvoiceItem.getUnitCost(), customerInvoiceItem.getQuantity(), false);
        return item.getCustomerInvoiceItemId();
    }
    
    public static CustomerBilling getBilling(long freshbooksClientId) throws FatalException, InvalidParameterException {
        return CustomerInvoiceDAO.getBilling(freshbooksClientId);
    }
    
    public static void addCustomerInvoiceItemsToCustomerInvoiceRecurring(List<CustomerInvoiceItem> customerInvoiceItems, CustomerInvoiceRecurring customerInvoiceRecurring) throws FatalException, InvalidParameterException {
		long customerInvoiceRecurringId = customerInvoiceRecurring.getCustomerInvoiceRecurringId();
    	for (CustomerInvoiceItem customerInvoiceItem : customerInvoiceItems) {
    		long customerInvoiceItemId = customerInvoiceItem.getCustomerInvoiceItemId();
			CustomerInvoiceDAO.addCustomerInvoiceItemToCustomerInvoiceRecurring( customerInvoiceItemId, customerInvoiceRecurringId);
		}
	}
    
    public static void addCustomerInvoiceItemsToCustomerInvoice(List<CustomerInvoiceItem> customerInvoiceItems, CustomerInvoice customerInvoice) throws FatalException, InvalidParameterException {
        long customerInvoiceId = customerInvoice.getCustomerInvoiceId();
        for (CustomerInvoiceItem customerInvoiceItem : customerInvoiceItems) {
            long customerInvoiceItemId = customerInvoiceItem.getCustomerInvoiceItemId();
            CustomerInvoiceDAO.addCustomerInvoiceItemToCustomerInvoice( customerInvoiceItemId, customerInvoiceId);
        }
    }
}