package com.viralogy.rewardme.manager;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.CustomerDAO;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerBilling;
import com.viralogy.rewardme.model.CustomerContact;
import com.viralogy.rewardme.model.Event;
import com.viralogy.rewardme.model.Permission;
import com.viralogy.rewardme.model.Reward;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserReward;
import com.viralogy.rewardme.util.Cache;

public abstract class CustomerManager {
	
	private static Logger logger = Logger.getLogger(CustomerManager.class);

	public static Customer getCustomer(String apiKey) throws InvalidParameterException, FatalException {
		//first see if we have an api_key=>customer cache value
		Customer customer = Cache.get(apiKey, Cache.namespace.CUSTOMER_BY_API_KEY);
		if(customer == null) {
			//find the customer id
			Long customerId = Cache.get(apiKey, Cache.namespace.CUSTOMER_API_KEY_TO_CUSTOMER_ID);
			if(customerId == null) {
				customerId = CustomerDAO.getCustomerId(apiKey);
				Cache.put(customerId, apiKey, Cache.namespace.CUSTOMER_API_KEY_TO_CUSTOMER_ID);
			}
			customer = getCustomer(customerId);
			Cache.put(customer, apiKey, Cache.namespace.CUSTOMER_BY_API_KEY);
		}
		//logger.debug("Got customer via apiKey. customerId: " + customer.getCustomerId() + OutputUtil.getElapsedString());
		return customer;
	}
	
	public static Customer getCustomer(Address address) throws InvalidParameterException, FatalException {
		Long customerId = Cache.get(address.getAddressId()+"", Cache.namespace.ADDRESS_ID_TO_CUSTOMER_ID);
		if(customerId == null) {
			customerId = CustomerDAO.getCustomerId(address);
			Cache.put(customerId, address.getAddressId()+"", Cache.namespace.ADDRESS_ID_TO_CUSTOMER_ID);
		}
		return getCustomer(customerId);
	}
	
	public static Customer getCustomerFromCardspring(String cardspringBusinessId) throws InvalidParameterException, FatalException {
		return CustomerDAO.getCustomerFromCardspring(cardspringBusinessId);
	}
	
	public static Customer getCustomer(Reward reward) throws InvalidParameterException, FatalException {
		Long customerId = Cache.get(reward.getRewardId()+"", Cache.namespace.REWARD_ID_TO_CUSTOMER_ID);
		if(customerId == null) {
			customerId = CustomerDAO.getCustomerId(reward);
			Cache.put(customerId, reward.getRewardId()+"", Cache.namespace.REWARD_ID_TO_CUSTOMER_ID);
		}
		return getCustomer(customerId);
	}
	
	public static Customer getCustomer(long customerId) throws InvalidParameterException, FatalException {
		//get the basic customer data
		Customer customer = Cache.get(customerId+"", Cache.namespace.CUSTOMER_BY_ID);
		if(customer == null) {
			customer = CustomerDAO.getCustomer(customerId);
			Cache.put(customer, customerId+"", Cache.namespace.CUSTOMER_BY_ID);
		}

		//logger.debug("Got customer via customerId. customerId: " + customer.getCustomerId() + OutputUtil.getElapsedString());
		return customer;
	}	
	
	public static Customer getCustomerByStripeCustomerId(String stripeCustomerId) throws InvalidParameterException, FatalException {
		return CustomerDAO.getCustomerByStripeCustomerId(stripeCustomerId);
	}	

	public static void save(CustomerContact customerContact) throws FatalException, InvalidParameterException {
		if(customerContact.getCustomer().getApiKey().equalsIgnoreCase("viralogy")) {
			customerContact.getCustomer().setCustomerId(0);
		}
		customerContact.save();
	}

	public static void save(Customer customer) throws FatalException, InvalidParameterException {
		customer.save();
		Cache.remove(customer.getApiKey(), Cache.namespace.CUSTOMER_BY_API_KEY);
		Cache.remove(customer.getCustomerId()+"", Cache.namespace.CUSTOMER_BY_ID);
	}	
		
	public static void removeCustomer(Customer customer) throws InvalidParameterException, FatalException {
		CustomerDAO.removeCustomer(customer);
		Cache.clear();
	}

	public static CustomerContact getContact(String email, String password, User user, String md5PinCode, Customer customer) throws InvalidParameterException, FatalException {
		return CustomerDAO.getContact(email, password, user, md5PinCode, customer);
	}
	
	public static List<CustomerContact> getContacts(Customer customer) throws InvalidParameterException, FatalException {
		return CustomerDAO.getContacts(customer);
	}

	public static CustomerContact getContact(long customerContactId) throws InvalidParameterException, FatalException {
		return CustomerDAO.getContact(customerContactId);
	}
	
	public static CustomerContact getContact(User user) throws InvalidParameterException, FatalException {
		return CustomerDAO.getContact(user);
	}
	
	public static void removeContact(CustomerContact customerContact) throws InvalidParameterException, FatalException {
		CustomerDAO.removeContact(customerContact);
		Cache.remove(customerContact.getCustomer().getApiKey(), Cache.namespace.CUSTOMER_BY_API_KEY);
		Cache.remove(customerContact.getCustomer().getCustomerId()+"", Cache.namespace.CUSTOMER_BY_ID);
	}	
	
	public static List<Customer> query(String query, int returnCount) throws FatalException, InvalidParameterException {
		return CustomerDAO.query(query, returnCount);
	}
	
	public static CustomerBilling getBilling(Customer customer) throws FatalException, InvalidParameterException {
		return CustomerDAO.getBilling(customer);
	}
	
	public static CustomerBilling getBilling(long customerBillingId) throws FatalException, InvalidParameterException {
	    return CustomerDAO.getBilling(customerBillingId);
	}
	
	public static void saveBilling(CustomerBilling customerBilling) throws InvalidParameterException, FatalException {
		customerBilling.save();
	}
	
	public static List<Event> getAdminEvents(Customer customer, int returnCount) throws FatalException, InvalidParameterException {
		return CustomerDAO.getAdminEvents(customer, returnCount);
	}
		
	public static List<UserReward> getRedeemedRewards(Customer customer, int returnCount) throws InvalidParameterException, FatalException{
	    return CustomerDAO.getRedeemedRewards(customer, returnCount);
	}
	
	public static Map<String, Permission> getPermissions(CustomerContact customerContact) throws FatalException, InvalidParameterException {
		return CustomerDAO.getPermissions(customerContact);
	}
	
	public static List<Customer> getModifiableCustomers(User user) throws FatalException, InvalidParameterException {
		CustomerContact customerContact = getContact(user);
		return CustomerDAO.getModifiableCustomers(customerContact);
	}
	
}
