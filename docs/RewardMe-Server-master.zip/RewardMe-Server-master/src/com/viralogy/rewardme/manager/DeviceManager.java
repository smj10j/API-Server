package com.viralogy.rewardme.manager;

import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.DeviceDAO;
import com.viralogy.rewardme.model.Application;
import com.viralogy.rewardme.model.Device;
import com.viralogy.rewardme.model.DeviceApplication;
import com.viralogy.rewardme.model.DeviceLink;
import com.viralogy.rewardme.model.UnlinkedDeviceApplication;
import com.viralogy.rewardme.model.UserCheckin;
import com.viralogy.rewardme.pos.Transaction;
import com.viralogy.rewardme.util.Cache;

public abstract class DeviceManager {

	private static Logger logger = Logger.getLogger(DeviceManager.class);

	public static Device getDevice(String deviceId) throws InvalidParameterException, FatalException {	
		return getDevice(deviceId, false);
	}
	
	public static Device getDevice(String deviceId, boolean createIfNoneExists) throws InvalidParameterException, FatalException {	
		Device device = Cache.get(deviceId, Cache.namespace.DEVICE_BY_ID);
		if(device == null) {
			try {
				device = DeviceDAO.getDevice(deviceId);
				Cache.put(device, deviceId, Cache.namespace.DEVICE_BY_ID);
			}catch(InvalidParameterException e) {
				if(!createIfNoneExists) {
					throw e;
				}else {
					//create the device
					logger.info("Creating new device with deviceId="+deviceId);
					device = new Device(deviceId);
					create(device);
				}
			}
		}
		return device;
	}
	
	/* We use this instead of a .save() because .save() doesn't handle String primary keys yet */
	private static void create(Device device) throws InvalidParameterException, FatalException {
		DeviceDAO.create(device);
	}		
	
	public static void save(Device device) throws InvalidParameterException, FatalException {
		device.save();
		Cache.remove(device.getDeviceId(), Cache.namespace.DEVICE_BY_ID);
		Cache.remove(device.getDeviceId(), Cache.namespace.USER_BY_DEVICE);
		Cache.remove(device.getDeviceId(), Cache.namespace.DEVICE_LINKS_BY_DEVICE_ID);
	}
	
	//TODO: Device Application: updating an address or a checkin option won't refresh the DeviceApplication cache 
	public static DeviceApplication getDeviceApplication(Device device) throws InvalidParameterException, FatalException {	
		DeviceApplication deviceApplication = Cache.get(device.getDeviceId(), Cache.namespace.DEVICE_APPLICATION_BY_DEVICE_ID);
		if(deviceApplication == null) {
			deviceApplication = DeviceDAO.getDeviceApplication(device);
			Cache.put(deviceApplication, device.getDeviceId(), Cache.namespace.DEVICE_APPLICATION_BY_DEVICE_ID);
		}
		return deviceApplication;
	}
	
	public static DeviceApplication getDeviceApplication(long deviceApplicationId) throws InvalidParameterException, FatalException {	
		DeviceApplication deviceApplication = Cache.get(deviceApplicationId+"", Cache.namespace.DEVICE_APPLICATION_BY_DEVICE_APPLICATION_ID);
		if(deviceApplication == null) {
			deviceApplication = DeviceDAO.getDeviceApplication(deviceApplicationId);
			Cache.put(deviceApplication, deviceApplicationId+"", Cache.namespace.DEVICE_APPLICATION_BY_DEVICE_APPLICATION_ID);
		}
		return deviceApplication;
	}
	
	public static List<DeviceApplication> getDeviceApplications(Application application) throws InvalidParameterException, FatalException {
		return DeviceDAO.getDeviceApplications(application);
	}

	public static UnlinkedDeviceApplication getUnlinkedDeviceApplication(long unlinkedDeviceApplicationId) throws InvalidParameterException, FatalException {	
		UnlinkedDeviceApplication unlinkedDeviceApplication = Cache.get(unlinkedDeviceApplicationId+"", Cache.namespace.UNLINKED_DEVICE_APPLICATION_BY_UNLINKED_DEVICE_APPLICATION_ID);
		if(unlinkedDeviceApplication == null) {
			unlinkedDeviceApplication = DeviceDAO.getUnlinkedDeviceApplication(unlinkedDeviceApplicationId);
			Cache.put(unlinkedDeviceApplication, unlinkedDeviceApplicationId+"", Cache.namespace.UNLINKED_DEVICE_APPLICATION_BY_UNLINKED_DEVICE_APPLICATION_ID);
		}
		return unlinkedDeviceApplication;
	}
	
	public static DeviceApplication createDeviceApplication(Device device, DeviceApplication previousDeviceApplication, UnlinkedDeviceApplication unlinkedDeviceApplication, boolean removeOnSuccess) throws InvalidParameterException, FatalException {
		DeviceApplication deviceApplication = new DeviceApplication(device, unlinkedDeviceApplication);
		if(previousDeviceApplication != null) {
			deviceApplication.setDeviceApplicationId(previousDeviceApplication.getDeviceApplicationId());
		}
		save(deviceApplication);
		if(removeOnSuccess) {
			unlinkedDeviceApplication.remove();
		}
		return deviceApplication;
	}
	
	public static void save(DeviceApplication deviceApplication) throws InvalidParameterException, FatalException {
		deviceApplication.save();
		Cache.remove(deviceApplication.getDevice().getDeviceId(), Cache.namespace.DEVICE_APPLICATION_BY_DEVICE_ID);
		Cache.remove(deviceApplication.getDeviceApplicationId()+"", Cache.namespace.DEVICE_APPLICATION_BY_DEVICE_APPLICATION_ID);
	}

	public static void save(UnlinkedDeviceApplication unlinkedDeviceApplication) throws InvalidParameterException, FatalException {
		unlinkedDeviceApplication.save();
		Cache.remove(unlinkedDeviceApplication.getUnlinkedDeviceApplicationId()+"", Cache.namespace.UNLINKED_DEVICE_APPLICATION_BY_UNLINKED_DEVICE_APPLICATION_ID);
	}
	
	public static void remove(DeviceApplication deviceApplication) throws InvalidParameterException, FatalException {
		deviceApplication.remove();
		Cache.remove(deviceApplication.getDevice().getDeviceId(), Cache.namespace.DEVICE_APPLICATION_BY_DEVICE_ID);
		Cache.remove(deviceApplication.getDeviceApplicationId()+"", Cache.namespace.DEVICE_APPLICATION_BY_DEVICE_APPLICATION_ID);
	}
	
	public static DeviceLink getDeviceLink(long deviceLinkId) throws InvalidParameterException, FatalException {	
		DeviceLink deviceLink = Cache.get(deviceLinkId+"", Cache.namespace.DEVICE_LINK_BY_ID);
		if(deviceLink == null) {
			deviceLink = DeviceDAO.getDeviceLink(deviceLinkId);
			Cache.put(deviceLink, deviceLinkId+"", Cache.namespace.DEVICE_LINK_BY_ID);
		}
		return deviceLink;
	}
	
	public static DeviceLink getDeviceLink(Device device1, Device device2) throws InvalidParameterException, FatalException {
		Device swap = device1;
		if(device1.getDeviceId().compareTo(device2.getDeviceId()) > 0) {
			device1 = device2;
			device2 = swap;
		}
		DeviceLink deviceLink = Cache.get(device1.getDeviceId()+"|"+device2.getDeviceId(), Cache.namespace.DEVICE_LINK_BY_DEVICE_IDS);
		if(deviceLink == null) {
			deviceLink = DeviceDAO.getDeviceLink(device1, device2);
			Cache.put(deviceLink, device1.getDeviceId()+"|"+device2.getDeviceId(), Cache.namespace.DEVICE_LINK_BY_DEVICE_IDS);
		}
		return deviceLink;
	}
	
	public static Set<DeviceLink> getDeviceLinks(Device device) throws InvalidParameterException, FatalException {	
		Set<DeviceLink> deviceLinks = Cache.get(device.getDeviceId(), Cache.namespace.DEVICE_LINKS_BY_DEVICE_ID);
		if(deviceLinks == null) {
			deviceLinks = DeviceDAO.getDeviceLinks(device);
			Cache.put(deviceLinks, device.getDeviceId(), Cache.namespace.DEVICE_LINKS_BY_DEVICE_ID);
		}
		return deviceLinks;
	}
	
	public static void save(DeviceLink deviceLink) throws InvalidParameterException, FatalException {
		deviceLink.save();
		Cache.remove(deviceLink.getDeviceLinkId()+"", Cache.namespace.DEVICE_LINK_BY_ID);
		Cache.remove(deviceLink.getDevice1().getDeviceId()+"", Cache.namespace.DEVICE_LINKS_BY_DEVICE_ID);
		Cache.remove(deviceLink.getDevice2().getDeviceId()+"", Cache.namespace.DEVICE_LINKS_BY_DEVICE_ID);
	}
	
	public static void remove(DeviceLink deviceLink) throws InvalidParameterException, FatalException {
		deviceLink.remove();
		Cache.remove(deviceLink.getDeviceLinkId()+"", Cache.namespace.DEVICE_LINK_BY_ID);
		Cache.remove(deviceLink.getDevice1().getDeviceId()+"", Cache.namespace.DEVICE_LINKS_BY_DEVICE_ID);
		Cache.remove(deviceLink.getDevice2().getDeviceId()+"", Cache.namespace.DEVICE_LINKS_BY_DEVICE_ID);
	}
	
	public static UserCheckin getLastCheckin(DeviceApplication deviceApplication) throws InvalidParameterException, FatalException {	
		return DeviceDAO.getLastCheckin(deviceApplication);
	}
	
	public static Transaction getLastTransaction(DeviceApplication deviceApplication) throws InvalidParameterException, FatalException {	
		return DeviceDAO.getLastTransaction(deviceApplication);

	}
}
