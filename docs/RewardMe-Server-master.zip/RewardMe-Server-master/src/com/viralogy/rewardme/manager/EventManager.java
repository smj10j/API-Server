package com.viralogy.rewardme.manager;


import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Event;
import com.viralogy.rewardme.model.EventTrigger;

public abstract class EventManager {

	private static Logger logger = Logger.getLogger(EventManager.class);

	public static void save(Event event) throws InvalidParameterException, FatalException {
		
		event.save();
		
		//handle any triggers based on this log event
		Set<EventTrigger> eventTriggers = TriggerManager.getEventTriggers(event);
		for(EventTrigger eventTrigger : eventTriggers) {
			TriggerManager.execute(eventTrigger);
		}
	}
}
