package com.viralogy.rewardme.manager;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.FeatureDAO;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerFeature;
import com.viralogy.rewardme.model.CustomerFeatureUsage;
import com.viralogy.rewardme.model.CustomerFeature.Feature;

public abstract class FeatureManager {
	
	private static Logger logger = Logger.getLogger(FeatureManager.class);

	public static CustomerFeature getCustomerFeature(long customerFeatureId) throws FatalException, InvalidParameterException {
		return FeatureDAO.getCustomerFeature(customerFeatureId);
	}

	public static CustomerFeature getCustomerFeature(Customer customer, Feature feature) throws FatalException, InvalidParameterException {
		return FeatureDAO.getCustomerFeature(customer, feature);
	}
	
	
	public static void useFeature(Customer customer, Feature feature) throws FatalException, InvalidParameterException {
		CustomerFeature customerFeature = getCustomerFeature(customer, feature);
		if(canUseFeature(customerFeature)) {
			CustomerFeatureUsage customerFeatureUsage = new CustomerFeatureUsage(customerFeature);
			customerFeatureUsage.save();
		}else {
			throw new InvalidParameterException(Constants.Error.GENERAL.FEATURE_CANNOT_USE_FEATURE);
		}
	}

	public static void unuseFeature(Customer customer, Feature feature) throws FatalException, InvalidParameterException {
		CustomerFeature customerFeature = getCustomerFeature(customer, feature);
		CustomerFeatureUsage customerFeatureUsage = getLastCustomerFeatureUsage(customerFeature);
		customerFeatureUsage.remove();
	}
	
	public static CustomerFeatureUsage getLastCustomerFeatureUsage(CustomerFeature customerFeature) throws FatalException, InvalidParameterException {
		return FeatureDAO.getLastCustomerFeatureUsage(customerFeature);
	}
	
	public static boolean canUseFeature(CustomerFeature customerFeature) throws FatalException, InvalidParameterException {
		return getFeatureUsage(customerFeature) < customerFeature.getAmount();
	}
	
	public static boolean canUseFeature(Customer customer, Feature feature) throws FatalException, InvalidParameterException {
		CustomerFeature customerFeature = getCustomerFeature(customer, feature);
		return canUseFeature(customerFeature);
	}

	public static long getFeatureUsage(Customer customer, Feature feature) throws FatalException, InvalidParameterException {
		CustomerFeature customerFeature = getCustomerFeature(customer, feature);
		return getFeatureUsage(customerFeature);
	}

	public static long getFeatureUsage(CustomerFeature customerFeature) throws FatalException, InvalidParameterException {
		return FeatureDAO.getFeatureUsage(customerFeature);
	}
	
	public static void saveCustomerFeature(CustomerFeature customerFeature) throws FatalException, InvalidParameterException {
		customerFeature.save();
	}
	
	public static List<CustomerFeature> getFeatures(Customer customer) throws FatalException, InvalidParameterException {
		return FeatureDAO.getFeatures(customer);
	}
}
