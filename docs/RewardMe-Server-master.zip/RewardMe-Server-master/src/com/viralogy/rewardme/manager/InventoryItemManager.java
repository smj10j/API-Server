package com.viralogy.rewardme.manager;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.DeviceDAO;
import com.viralogy.rewardme.dao.InventoryItemDAO;
import com.viralogy.rewardme.model.Device;
import com.viralogy.rewardme.model.InventoryItem;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.util.Cache;

public abstract class InventoryItemManager {

	private static Logger logger = Logger.getLogger(InventoryItemManager.class);
	
	public static InventoryItem getInventoryItem(String serial) throws FatalException, InvalidParameterException {
		return InventoryItemDAO.getInventoryItem(serial);
	}

	public static List<InventoryItem> getInventoryItems(User user, String type) throws FatalException, InvalidParameterException {
		return InventoryItemDAO.getInventoryItems(user, type);
	}
	
	public static void save(InventoryItem inventoryItem) throws FatalException, InvalidParameterException {
		inventoryItem.save();
	}
	
	public static void removeInventoryItem(String serial) throws InvalidParameterException, FatalException {
		InventoryItemDAO.removeInventoryItem(serial);
	}


}