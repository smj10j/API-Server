package com.viralogy.rewardme.manager;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.LotteryDAO;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Lottery;
import com.viralogy.rewardme.model.Reward;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.util.Cache;

public abstract class LotteryManager {
	
	private static Logger logger = Logger.getLogger(LotteryManager.class);
	
	public static Lottery getLottery(long lotteryId) throws FatalException, InvalidParameterException {
		Lottery lottery = LotteryDAO.getLottery(lotteryId);
		
		return lottery;
	}

	public static List<Lottery> getAllLotteries(Customer customer) throws FatalException, InvalidParameterException {
		List<Lottery> lotteries = Cache.get(customer.getApiKey(), Cache.namespace.CUSTOMER_LOTTERIES);
		if(lotteries == null) {
			lotteries = LotteryDAO.getAllLotteries(customer);
			Cache.put(lotteries, customer.getApiKey(), Cache.namespace.CUSTOMER_LOTTERIES);
		}
		
		return lotteries;
	}
	
	public static Reward getLotteryReward(User user, Customer customer, List<Lottery> lotteries) throws FatalException, InvalidParameterException {
		
		Reward reward = null;
		
		for (Lottery l : lotteries) {
			if (l.getPercentChance() > 100*Math.random()){
				
				reward = l.getReward();
				
				if (reward==null){
					return reward;
				} else if (l.getNumberOfPrizes() > LotteryDAO.getNumberOfWinners(l)) {
					LotteryDAO.recordWin(user, l);
					return reward;
				}
			}
		}
		return reward;
	}
}
