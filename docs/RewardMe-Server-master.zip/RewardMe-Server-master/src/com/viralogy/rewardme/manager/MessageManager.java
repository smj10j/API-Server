package com.viralogy.rewardme.manager;

import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.Constants.NotificationType;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.customer.CustomerConstants;
import com.viralogy.rewardme.customer.Mooyah;
import com.viralogy.rewardme.dao.CustomerDAO;
import com.viralogy.rewardme.dao.UserDAO;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerBroadcastMessage;
import com.viralogy.rewardme.model.Device;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserMessage;
import com.viralogy.rewardme.model.UserPreference;
import com.viralogy.rewardme.model.UserToCustomerBroadcastMessage;
import com.viralogy.rewardme.scheduler.ScheduledTask;
import com.viralogy.rewardme.scheduler.ScheduledTask.Type;
import com.viralogy.rewardme.servlet.GatewayServlet;
import com.viralogy.rewardme.util.StringUtil;

public abstract class MessageManager {

	private static Logger logger = Logger.getLogger(MessageManager.class);
	
	public static void save(UserMessage userMessage) throws FatalException, InvalidParameterException {
		userMessage.save();
	}
	
	public static List<UserMessage> getUserMessages(Customer customer, User user, int returnCount) throws FatalException, InvalidParameterException {
		return UserDAO.getUserMessages(customer, user, returnCount);
	}

	public static UserMessage getUserMessage(long userMessageId) throws FatalException, InvalidParameterException {
		return UserDAO.getUserMessage(userMessageId);
	}
	
	public static UserMessage getLastUserMessage(User user) throws FatalException, InvalidParameterException {
		return UserDAO.getLastUserMessage(user);
	}
	
	public static void save(UserToCustomerBroadcastMessage userToCustomerBroadcastMessage) throws FatalException, InvalidParameterException {
		userToCustomerBroadcastMessage.save();
	}
	
	public static CustomerBroadcastMessage getCustomerBroadcastMessage(long customerBroadcastMessageId) throws FatalException, InvalidParameterException {
		return CustomerDAO.getCustomerBroadcastMessage(customerBroadcastMessageId);
	}
	
	public static CustomerBroadcastMessage getLastCustomerBroadcastMessage(User user) throws FatalException, InvalidParameterException {
		return CustomerDAO.getLastCustomerBroadcastMessage(user);
	}
	
	public static void save(CustomerBroadcastMessage customerBroadcastMessage) throws InvalidParameterException, FatalException {
		customerBroadcastMessage.save();
	}
	
	private static boolean sendViaPush(User user) throws FatalException, InvalidParameterException {
		
		boolean sendViaPush = false;
		for(Device device : user.getDevices()) {
			//try and send a push notification
			if(!StringUtil.isNullOrEmpty(device.getRemoteDeviceUUID())) {
				sendViaPush = true;
			}
		}
		
		return sendViaPush;
	}
	
	public static void send(UserMessage userMessage, NotificationType notificationType, boolean ignoreNotificationPreferences) throws InvalidParameterException, FatalException {
		
		userMessage.setSent(false);
		MessageManager.save(userMessage);

		if(notificationType.equals(NotificationType.TEXT_SYSTEM)) {
			
			if(!sendViaPush(userMessage.getUser())) {
				PhoneManager.sendSMS(userMessage.getUser().getPhoneNumber(), userMessage.getMessage());
			}else {
				PhoneManager.sendPushNotification(userMessage.getUser(), userMessage.getMessage());
			}

			userMessage.setSent(true);
			MessageManager.save(userMessage);
			
		}else if(!ignoreNotificationPreferences && !preferencesAllow(notificationType, userMessage)) {
			//filter out users who have preferences that don't allow the send
			logger.info("Attempted to send userMessageId="+userMessage.getUserMessageId() + " but user preferences don't allow it");
		
		}else {
			if(userMessage.getCustomer().is(CustomerConstants.MOOYAH)) {
				Mooyah.sendSMS(userMessage.getUser(), userMessage.getMessage());
			}else {
				
				if(!sendViaPush(userMessage.getUser())) {
					PhoneManager.sendSMS(userMessage.getUser().getPhoneNumber(), userMessage.getMessage());
				}else {
					PhoneManager.sendPushNotification(userMessage.getUser(), userMessage.getMessage());
				}				
			}
			userMessage.setSent(true);
			MessageManager.save(userMessage);
			
		}
		
	}
	
	public static void schedule(UserMessage userMessage, NotificationType notificationType) throws FatalException, InvalidParameterException {
		MessageManager.save(userMessage);
		
		String baseUrl = GatewayServlet.getLocalServerBaseUrl() + "schedule";
		String queryString = "customerId="+userMessage.getCustomer().getCustomerId()+"&"+
							"userMessageId="+userMessage.getUserMessageId()+"&"+
							"notificationType="+notificationType;
		
		//schedule it
		String url = baseUrl + "?" + queryString;
		(new ScheduledTask(Type.URL, url, userMessage.getTimestamp())).save();
	}
	
	public static void send(CustomerBroadcastMessage customerBroadcastMessage, NotificationType notificationType, boolean ignoreNotificationPreferences) throws InvalidParameterException, FatalException {
		
		Set<User> users = UserManager.getUsersWithCheckin(customerBroadcastMessage.getCustomer(), customerBroadcastMessage.getAddress());
		for (User user : users) {
			if(StringUtil.isNullOrEmpty(user.getPhoneNumber())) {
				continue;
			}
			
			try {
				//filter out users who have preferences that don't allow the send
				if(!ignoreNotificationPreferences && !preferencesAllow(notificationType, user, customerBroadcastMessage)) {
					//filter out users who have preferences that don't allow the send
					logger.info("Attempted to send customerBroadcastMessageId="+customerBroadcastMessage.getCustomerBroadcastMessageId() + " but user preferences don't allow it");
					continue;
				}
				
				boolean sendViaPush = sendViaPush(user);
				
				if(!sendViaPush) {
					PhoneManager.sendSMS(user.getPhoneNumber(), customerBroadcastMessage.getMessage());
				}else {
					PhoneManager.sendPushNotification(user, customerBroadcastMessage.getMessage());
				}
				
				//log the send
				MessageManager.save(new UserToCustomerBroadcastMessage(user, customerBroadcastMessage, !sendViaPush));
				
			}catch(InvalidParameterException e) {
				//don't fail the whole batch
				logger.error(e);
			}
		}
		
		customerBroadcastMessage.setSent(true);
		MessageManager.save(customerBroadcastMessage);
	}
	
	public static boolean preferencesAllow(NotificationType notificationType, UserMessage userMessage) throws FatalException, InvalidParameterException {
		User user = userMessage.getUser();
		if(!notificationType.equals(NotificationType.TEXT_SYSTEM)) {
			UserPreference textAllPreference = user.getUserPreference(Constants.UserPreference.NOTIFICATION_TEXT_ALL, userMessage.getCustomer());
			if(textAllPreference != null) {
				if(textAllPreference.getValue().equals(Constants.NO)) {
					logger.debug("Notification preferences disallow ALL texts to userId="+user.getUserId()+" from customerId="+userMessage.getCustomer().getCustomerId());
					return false;
				}
			}else if(notificationType.equals(NotificationType.TEXT_APP)) {
				UserPreference textAppPreference = user.getUserPreference(Constants.UserPreference.NOTIFICATION_TEXT_APP, userMessage.getCustomer());
				if(textAppPreference != null && textAppPreference.getValue().equals(Constants.NO)) {
					logger.debug("Notification preferences disallow APP texts to userId="+user.getUserId()+" from customerId="+userMessage.getCustomer().getCustomerId());
					return false;
				}
			}else if(notificationType.equals(NotificationType.TEXT_PROMO)) {
				UserPreference textPromoPreference = user.getUserPreference(Constants.UserPreference.NOTIFICATION_TEXT_PROMO, userMessage.getCustomer());
				if(textPromoPreference != null && textPromoPreference.getValue().equals(Constants.NO)) {
					logger.debug("Notification preferences disallow PROMO texts to userId="+user.getUserId()+" from customerId="+userMessage.getCustomer().getCustomerId());
					return false;
				}
			}
		}
		return true;
	}
	
	
	public static boolean preferencesAllow(NotificationType notificationType, User user, CustomerBroadcastMessage customerBroadcastMessage) throws FatalException, InvalidParameterException {
		if(!notificationType.equals(NotificationType.TEXT_SYSTEM)) {
			UserPreference textAllPreference = user.getUserPreference(Constants.UserPreference.NOTIFICATION_TEXT_ALL, customerBroadcastMessage.getCustomer());
			if(textAllPreference != null) {
				if(textAllPreference.getValue().equals(Constants.NO)) {
					return false;
				}
			}else if(notificationType.equals(NotificationType.TEXT_APP)) {
				UserPreference textAppPreference = user.getUserPreference(Constants.UserPreference.NOTIFICATION_TEXT_APP, customerBroadcastMessage.getCustomer());
				if(textAppPreference != null && textAppPreference.getValue().equals(Constants.NO)) {
					return false;
				}
			}else if(notificationType.equals(NotificationType.TEXT_PROMO)) {
				UserPreference textPromoPreference = user.getUserPreference(Constants.UserPreference.NOTIFICATION_TEXT_PROMO, customerBroadcastMessage.getCustomer());
				if(textPromoPreference != null && textPromoPreference.getValue().equals(Constants.NO)) {
					return false;
				}
			}
		}
		return true;
	}
}
