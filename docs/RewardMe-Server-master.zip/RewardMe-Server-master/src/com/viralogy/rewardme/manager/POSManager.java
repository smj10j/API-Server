package com.viralogy.rewardme.manager;

import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.POSDAO;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Receipt;
import com.viralogy.rewardme.model.Session;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.pos.Discount;
import com.viralogy.rewardme.pos.Employee;
import com.viralogy.rewardme.pos.InventoryCategory;
import com.viralogy.rewardme.pos.InventoryItem;
import com.viralogy.rewardme.pos.InventoryItemHistory;
import com.viralogy.rewardme.pos.InventoryItemMod;
import com.viralogy.rewardme.pos.InventoryItemModHistory;
import com.viralogy.rewardme.pos.Transaction;
import com.viralogy.rewardme.util.Cache;
public abstract class POSManager {

	private static Logger logger = Logger.getLogger(POSManager.class);

	public static Transaction getTransaction(long transactionId) throws InvalidParameterException, FatalException {	
		Transaction transaction = Cache.get(transactionId+"", Cache.namespace.POS.TX_BY_ID);
		if(transaction == null) {
			transaction = POSDAO.getTransaction(transactionId);
			Cache.put(transaction, transactionId+"", Cache.namespace.POS.TX_BY_ID);
		}
		return transaction;
	}	

	public static Employee getEmployee(long employeeId) throws InvalidParameterException, FatalException {	
		Employee employee = Cache.get(employeeId+"", Cache.namespace.EMPLOYEE_BY_ID);
		if(employee == null) {
			employee = POSDAO.getEmployee(employeeId);
			Cache.put(employee, employeeId+"", Cache.namespace.EMPLOYEE_BY_ID);
		}
		return employee;
	}	
	
	public static Transaction getTransaction(Customer customer, Address address, String externalTxId) throws InvalidParameterException, FatalException {
		Transaction transaction = Cache.get(customer.getCustomerId()+"",address.getAddressId()+"",externalTxId+"", Cache.namespace.POS.TX_BY_EXTERNAL_TX_ID);
		if(transaction == null) {
			transaction = POSDAO.getTransaction(customer, address, externalTxId);
			Cache.put(transaction, customer.getCustomerId()+"",address.getAddressId()+"",externalTxId+"", Cache.namespace.POS.TX_BY_EXTERNAL_TX_ID);
		}
		return transaction;
	}	
	
	public static Employee getEmployee(Customer customer, Address address, String externalEmployeeId) throws InvalidParameterException, FatalException {	
		Employee employee = Cache.get(customer.getCustomerId()+"",address.getAddressId()+"",externalEmployeeId+"", Cache.namespace.EMPLOYEE_BY_EXTERNAL_ID);
		if(employee == null) {
			employee = POSDAO.getEmployee(customer, address, externalEmployeeId);
			Cache.put(employee, customer.getCustomerId()+"",address.getAddressId()+"",externalEmployeeId+"", Cache.namespace.EMPLOYEE_BY_EXTERNAL_ID);
		}
		return employee;
	}	
	
	public static InventoryItem getInventoryItem(long inventoryItemId) throws InvalidParameterException, FatalException {	
		InventoryItem inventoryItem = Cache.get(inventoryItemId+"", Cache.namespace.POS.INVENTORY_ITEM_BY_ID);
		if(inventoryItem == null) {
			inventoryItem = POSDAO.getInventoryItem(inventoryItemId);
			Cache.put(inventoryItem, inventoryItemId+"", Cache.namespace.POS.INVENTORY_ITEM_BY_ID);
		}
		return inventoryItem;
	}		
	
	public static InventoryItem getInventoryItem(Customer customer, String externalInventoryItemId) throws InvalidParameterException, FatalException {	
		InventoryItem inventoryItem = Cache.get(customer.getCustomerId()+"",externalInventoryItemId+"", Cache.namespace.POS.INVENTORY_ITEM_BY_EXTERNAL_ID);
		if(inventoryItem == null) {
			inventoryItem = POSDAO.getInventoryItem(customer, externalInventoryItemId);
			Cache.put(inventoryItem, customer.getCustomerId()+"",externalInventoryItemId+"", Cache.namespace.POS.INVENTORY_ITEM_BY_EXTERNAL_ID);
		}
		return inventoryItem;
	}		
	
	public static InventoryItem getInventoryItemFromKitchenItemName(Customer customer, String kitchenItemName) throws InvalidParameterException, FatalException {	
		InventoryItem inventoryItem = Cache.get(customer.getCustomerId()+"",kitchenItemName+"", Cache.namespace.POS.INVENTORY_ITEM_BY_KITCHEN_ITEM_NAME);
		if(inventoryItem == null) {
			inventoryItem = POSDAO.getInventoryItemFromKitchenItemName(customer, kitchenItemName);
			Cache.put(inventoryItem, customer.getCustomerId()+"",kitchenItemName+"", Cache.namespace.POS.INVENTORY_ITEM_BY_KITCHEN_ITEM_NAME);
		}
		return inventoryItem;
	}
	
	public static InventoryItemMod getInventoryItemMod(long inventoryItemModId) throws InvalidParameterException, FatalException {	
		InventoryItemMod inventoryItemMod = Cache.get(inventoryItemModId+"", Cache.namespace.POS.INVENTORY_ITEM_MOD_BY_ID);
		if(inventoryItemMod == null) {
			inventoryItemMod = POSDAO.getInventoryItemMod(inventoryItemModId);
			Cache.put(inventoryItemMod, inventoryItemModId+"", Cache.namespace.POS.INVENTORY_ITEM_MOD_BY_ID);
		}
		return inventoryItemMod;
	}	
	
	public static InventoryItemMod getInventoryItemMod(Customer customer, String externalInventoryItemModId) throws InvalidParameterException, FatalException {	
		InventoryItemMod inventoryItemMod = Cache.get(customer.getCustomerId()+"",externalInventoryItemModId+"", Cache.namespace.POS.INVENTORY_ITEM_MOD_BY_EXTERNAL_ID);
		if(inventoryItemMod == null) {
			inventoryItemMod = POSDAO.getInventoryItemMod(customer, externalInventoryItemModId);
			Cache.put(inventoryItemMod, customer.getCustomerId()+"",externalInventoryItemModId+"", Cache.namespace.POS.INVENTORY_ITEM_MOD_BY_EXTERNAL_ID);
		}
		return inventoryItemMod;
	}	
	
	public static InventoryItemMod getInventoryItemModFromKitchenItemName(Customer customer, String kitchenItemName) throws InvalidParameterException, FatalException {	
		InventoryItemMod inventoryItemMod = Cache.get(customer.getCustomerId()+"",kitchenItemName+"", Cache.namespace.POS.INVENTORY_ITEM_MOD_BY_KITCHEN_ITEM_NAME);
		if(inventoryItemMod == null) {
			inventoryItemMod = POSDAO.getInventoryItemModFromKitchenItemName(customer, kitchenItemName);
			Cache.put(inventoryItemMod, customer.getCustomerId()+"",kitchenItemName+"", Cache.namespace.POS.INVENTORY_ITEM_MOD_BY_KITCHEN_ITEM_NAME);
		}
		return inventoryItemMod;
	}
	
	public static InventoryCategory getInventoryCategory(long inventoryCategoryId) throws InvalidParameterException, FatalException {	
		InventoryCategory inventoryCategory = Cache.get(inventoryCategoryId+"", Cache.namespace.POS.INVENTORY_CATEGORY_BY_ID);
		if(inventoryCategory == null) {
			inventoryCategory = POSDAO.getInventoryCategory(inventoryCategoryId);
			Cache.put(inventoryCategory, inventoryCategoryId+"", Cache.namespace.POS.INVENTORY_CATEGORY_BY_ID);
		}
		return inventoryCategory;
	}		
	
	public static Discount getDiscount(long discountId) throws InvalidParameterException, FatalException {	
		Discount discount = Cache.get(discountId+"", Cache.namespace.POS.DISCOUNT_BY_ID);
		if(discount == null) {
			discount = POSDAO.getDiscount(discountId);
			Cache.put(discount, discountId+"", Cache.namespace.POS.DISCOUNT_BY_ID);
		}
		return discount;
	}	
	
	public static Set<InventoryCategory> getInventoryCategories(InventoryItem inventoryItem) throws InvalidParameterException, FatalException {	
		Set<InventoryCategory> inventoryCategories = Cache.get(inventoryItem.getPosInventoryItemId()+"", Cache.namespace.POS.INVENTORY_CATEGORIES_BY_INVENTORY_ITEM_ID);
		if(inventoryCategories == null) {
			inventoryCategories = POSDAO.getInventoryCategories(inventoryItem);
			Cache.put(inventoryCategories, inventoryItem.getPosInventoryItemId()+"", Cache.namespace.POS.INVENTORY_CATEGORIES_BY_INVENTORY_ITEM_ID);
		}
		return inventoryCategories;
	}		

	public static Set<InventoryItem> getInventoryItems(Transaction transaction) throws InvalidParameterException, FatalException {	
		Set<InventoryItem> inventoryItems = Cache.get(transaction.getPosTxId()+"", Cache.namespace.POS.INVENTORY_ITEMS_BY_TX_ID);
		if(inventoryItems == null) {
			inventoryItems = POSDAO.getInventoryItems(transaction);
			Cache.put(inventoryItems, transaction.getPosTxId()+"", Cache.namespace.POS.INVENTORY_ITEMS_BY_TX_ID);
		}
		return inventoryItems;
	}
	
	public static Set<InventoryItemMod> getInventoryItemMods(Transaction transaction, InventoryItem inventoryItem) throws InvalidParameterException, FatalException {	
		Set<InventoryItemMod> inventoryItemMods = Cache.get(transaction.getPosTxId()+"|"+inventoryItem.getPosInventoryItemId(), Cache.namespace.POS.INVENTORY_ITEMS_MODS_BY_ITEM_ID_AND_TX_ID);
		if(inventoryItemMods == null) {
			inventoryItemMods = POSDAO.getInventoryItemMods(transaction, inventoryItem);
			Cache.put(inventoryItemMods, transaction.getPosTxId()+"|"+inventoryItem.getPosInventoryItemId(), Cache.namespace.POS.INVENTORY_ITEMS_MODS_BY_ITEM_ID_AND_TX_ID);
		}
		return inventoryItemMods;
	}
	
	public static Set<Discount> getInventoryItemDiscounts(Transaction transaction, InventoryItem inventoryItem) throws InvalidParameterException, FatalException {	
		Set<Discount> inventoryItemDiscounts = Cache.get(transaction.getPosTxId()+"|"+inventoryItem.getPosInventoryItemId(), Cache.namespace.POS.INVENTORY_ITEMS_DISCOUNTS_BY_ITEM_ID_AND_TX_ID);
		if(inventoryItemDiscounts == null) {
			inventoryItemDiscounts = POSDAO.getInventoryItemDiscounts(transaction, inventoryItem);
			Cache.put(inventoryItemDiscounts, transaction.getPosTxId()+"|"+inventoryItem.getPosInventoryItemId(), Cache.namespace.POS.INVENTORY_ITEMS_DISCOUNTS_BY_ITEM_ID_AND_TX_ID);
		}
		return inventoryItemDiscounts;
	}
	
	public static Set<Discount> getDiscounts(Transaction transaction) throws InvalidParameterException, FatalException {	
		Set<Discount> discounts = Cache.get(transaction.getPosTxId()+"", Cache.namespace.POS.DISCOUNTS_BY_TX_ID);
		if(discounts == null) {
			discounts = POSDAO.getDiscounts(transaction);
			Cache.put(discounts, transaction.getPosTxId()+"", Cache.namespace.POS.DISCOUNTS_BY_TX_ID);
		}
		return discounts;
	}	
	
	public static void save(Session session, Transaction transaction, Receipt receipt) throws InvalidParameterException, FatalException {
		User user = transaction.getUser();
		Customer customer = transaction.getCustomer();
		Address address = transaction.getAddress();
		if (user != null && customer != null && address != null) {
			long userId = user.getUserId();
			long customerId = customer.getCustomerId();
			long addressId = address.getAddressId();
			String paymentMethod = transaction.getPaymentMethod().toString();
			Cache.remove("" + userId + "|" + customerId + "|" + addressId + "|" + paymentMethod, Cache.namespace.POS.SEGMENT_SUM_AMOUNT_LESS_TAX_AND_DISCOUNT);
			Cache.remove("" + userId + "|" + customerId + "|" + addressId + "|" + paymentMethod, Cache.namespace.POS.SEGMENT_SUM_AMOUNT_LESS_TAX);	
			Cache.remove("" + userId + "|" + customerId + "|" + addressId + "|" + paymentMethod, Cache.namespace.POS.SEGMENT_SUM_AMOUNT_LESS_DISCOUNT);
			Cache.remove("" + userId + "|" + customerId + "|" + addressId + "|" + paymentMethod, Cache.namespace.POS.SEGMENT_SUM_AMOUNT);
		}
		transaction.save();
		POSDAO.saveInventoryItemsAndMods(transaction);
				
		if(receipt != null) {
			//save the receipt data and link it to the transactional data
			POSDAO.save(transaction, receipt);
		}	
	}
	
	public static void save(Employee employee) throws InvalidParameterException, FatalException {
		employee.save();
		
		Cache.remove(employee.getEmployeeId()+"", Cache.namespace.EMPLOYEE_BY_ID);
		Cache.remove(employee.getCustomer().getCustomerId()+"",employee.getExternalEmployeeId(), Cache.namespace.EMPLOYEE_BY_EXTERNAL_ID);
	}
		
	public static void save(InventoryItem inventoryItem) throws InvalidParameterException, FatalException {
		
		//save the item
		inventoryItem.save();

		//create a history entry
		InventoryItemHistory inventoryItemHistory = new InventoryItemHistory(inventoryItem);
		inventoryItemHistory.save();
		
		Cache.remove(inventoryItem.getPosInventoryItemId()+"", Cache.namespace.POS.INVENTORY_ITEM_BY_ID);
		Cache.remove(inventoryItem.getCustomer().getCustomerId()+"",inventoryItem.getExternalPosInventoryItemId(), Cache.namespace.POS.INVENTORY_ITEM_BY_EXTERNAL_ID);
	}
	
	public static void save(InventoryItemMod inventoryItemMod) throws InvalidParameterException, FatalException {
		
		//save the mod
		inventoryItemMod.save();

		//create a history entry
		InventoryItemModHistory inventoryItemModHistory = new InventoryItemModHistory(inventoryItemMod);
		inventoryItemModHistory.save();
		
		Cache.remove(inventoryItemMod.getPosInventoryItemModId()+"", Cache.namespace.POS.INVENTORY_ITEM_MOD_BY_ID);
		Cache.remove(inventoryItemMod.getCustomer().getCustomerId()+"",inventoryItemMod.getExternalPosInventoryItemModId(), Cache.namespace.POS.INVENTORY_ITEM_MOD_BY_EXTERNAL_ID);
	}
	
	public static List<Transaction> getTransactions(Customer customer, Address address, User user) throws FatalException, InvalidParameterException {
		return POSDAO.getTransactions(customer, address, user);
	}
	
	//user, customer, address cannot be null. It will throw FatalError otherwise. 
	public static float getAmountSumOfUser(User user, Customer customer, Address address,
	            					boolean doNotIncludeTax, boolean doNotIncludeDiscount, String paymentMethod) throws FatalException {
		if (user == null || customer == null || address == null) {
			throw new FatalException("Attempted to gather the sum of a user with no user, customer, address");
		}
		Float sum = Cache.get("" + user.getUserId() + "|" + customer.getCustomerId() + 
					  "|" + address.getAddressId() + "|" + (paymentMethod == null ? "UNKNOWN" : paymentMethod),
					  (doNotIncludeTax ? (doNotIncludeDiscount ? Cache.namespace.POS.SEGMENT_SUM_AMOUNT_LESS_TAX_AND_DISCOUNT : Cache.namespace.POS.SEGMENT_SUM_AMOUNT_LESS_TAX) 
							  		   : (doNotIncludeDiscount ? Cache.namespace.POS.SEGMENT_SUM_AMOUNT_LESS_DISCOUNT : Cache.namespace.POS.SEGMENT_SUM_AMOUNT)));
		if (sum == null) {
			sum = POSDAO.getAmountSumOfUser(customer, address, user, doNotIncludeTax, doNotIncludeDiscount, paymentMethod);
			Cache.put(sum, "" + user.getUserId() + "|" + customer.getCustomerId() + 
					  "|" + address.getAddressId() + "|" + (paymentMethod == null ? "UNKNOWN" : paymentMethod), 
					  (doNotIncludeTax ? (doNotIncludeDiscount ? Cache.namespace.POS.SEGMENT_SUM_AMOUNT_LESS_TAX_AND_DISCOUNT : Cache.namespace.POS.SEGMENT_SUM_AMOUNT_LESS_TAX) 
							  		   : (doNotIncludeDiscount ? Cache.namespace.POS.SEGMENT_SUM_AMOUNT_LESS_DISCOUNT : Cache.namespace.POS.SEGMENT_SUM_AMOUNT)));
		}
		return sum;
	}
}
