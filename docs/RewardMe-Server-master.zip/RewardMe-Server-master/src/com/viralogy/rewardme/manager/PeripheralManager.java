package com.viralogy.rewardme.manager;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.PeripheralDAO;
import com.viralogy.rewardme.model.Peripheral;
import com.viralogy.rewardme.util.Cache;
public abstract class PeripheralManager {

	private static Logger logger = Logger.getLogger(PeripheralManager.class);

	public static Peripheral getPeripheral(long peripheralId) throws InvalidParameterException, FatalException {	
		Peripheral peripheral = Cache.get(peripheralId+"", Cache.namespace.PERIPHERAL_BY_ID);
		if(peripheral == null) {
			peripheral = PeripheralDAO.getPeripheral(peripheralId);
			Cache.put(peripheral, peripheralId+"", Cache.namespace.PERIPHERAL_BY_ID);
		}
		return peripheral;
	}	

	public static Peripheral getPeripheral(String externalPeripheralId) throws InvalidParameterException, FatalException {	
		Peripheral peripheral = Cache.get(externalPeripheralId, Cache.namespace.PERIPHERAL_BY_EXTERNAL_ID);
		if(peripheral == null) {
			peripheral = PeripheralDAO.getPeripheral(externalPeripheralId);
			Cache.put(peripheral, externalPeripheralId, Cache.namespace.PERIPHERAL_BY_EXTERNAL_ID);
		}
		return peripheral;
	}	
	
	public static void save(Peripheral peripheral) throws FatalException, InvalidParameterException {

		peripheral.save();
		
		Cache.remove(peripheral.getExternalPeripheralId(), Cache.namespace.PERIPHERAL_BY_EXTERNAL_ID);
		Cache.remove(peripheral.getPeripheralId()+"", Cache.namespace.PERIPHERAL_BY_ID);
	}

}
