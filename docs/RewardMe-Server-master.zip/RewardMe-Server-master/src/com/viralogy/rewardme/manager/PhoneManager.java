package com.viralogy.rewardme.manager;

import java.util.Date;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.Constants.NotificationType;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.customer.CustomerConstants;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserMessage;
import com.viralogy.rewardme.model.UserPreference;
import com.viralogy.rewardme.util.APNSUtil;
import com.viralogy.rewardme.util.Cache;
import com.viralogy.rewardme.util.RemoteRequestUtil;
import com.viralogy.rewardme.util.TwilioUtil;

public abstract class PhoneManager {
	
	private static Logger logger = Logger.getLogger(PhoneManager.class);
	
	public static boolean sendSMS(String toPhoneNumber, String message) throws InvalidParameterException, FatalException {
		toPhoneNumber = TwilioUtil.cleanNumber(toPhoneNumber);
		TwilioUtil.sendSMS(toPhoneNumber, message);
		return true;
	}
	
	public static boolean sendPushNotification(User user, String message) throws InvalidParameterException, FatalException {
		String payload = APNSUtil.createPayload(message, null, null, 1, "alarmsound.caf", "View");
		try {
			APNSUtil.send(user, payload);
			return true;
		}catch(InvalidParameterException e) {
			//failed to send
			logger.error("Failed to send push notification to userId="+user.getUserId(), e);
			return false;
		}
	}
	
	public static boolean isMobile(String phoneNumber) throws FatalException {		

		String response = getPhoneNumberDetails(phoneNumber);
		if(response != null) {
			boolean isMobile = response.contains("Cellular");
			logger.debug("Phone number " + phoneNumber + " is " + (isMobile ? "" : "NOT ") + "a mobile number");
			return isMobile;
		}
		return true;	//default to mobile
	}
	
	public static boolean isValid(String phoneNumber) throws FatalException {		
		String response = getPhoneNumberDetails(phoneNumber);
		//logger.debug("Phone number verification response: " + response);
		if(response != null) {
			boolean exists = response.contains("Phone Type:");
			logger.debug("Phone number " + phoneNumber + " " + (exists ? "does" : "DOES NOT") + " exist");
			return exists;
		}
		return true;	//default to exists
	}
	
	private static String getPhoneNumberDetails(String phoneNumber) {
		try {
			//paid service: http://www.searchbug.com/tools/landline-or-cellphone.aspx
			//another free service: http://www.intelius.com/results.php?ReportType=33&formname=phone&qnpa=714&qnxx=334&qstation=5791&focusfirst=1
			//another free service: http://www.phonevalidator.com/results.aspx?p=7143345791
			String USOnlyNumber = phoneNumber.substring(2);
			String areaCode = USOnlyNumber.substring(0,3);
			String first3 = USOnlyNumber.substring(3,6);
			String second4 = USOnlyNumber.substring(6,10);
			String url = "http://www.intelius.com/results.php";
			String params = "ReportType=33&formname=phone&qnpa="+areaCode+"&qnxx="+first3+"&qstation="+second4+"&focusfirst=1";
			logger.debug("Phone number verification request: " + url + "?" + params);
			
			String response = Cache.get(url, params, Cache.namespace.PHONE_NUMBER_LOOKUP_REQUEST);
			if(response == null) { 
				response = RemoteRequestUtil.get(url, params, null, null, false);
				Cache.put(response, url, params, Cache.namespace.PHONE_NUMBER_LOOKUP_REQUEST);
			}			
			//logger.debug("Phone number verification response: " + response);
			
			return response;		
			
		}catch(Exception e) {
			//problem?
			logger.error("FAILED TO VALIDATE MOBILE NUMBER " + phoneNumber + " - CONTINUING WITH ASSUMPTION THAT IT'S VALID");
			return null;
		}		
	}
	
	
	public static void sendMenu(User user, Customer customer, boolean notifyAboutUnexpectedText) throws FatalException, InvalidParameterException {
		
		boolean partOfTextClub = false;
		UserPreference userPreference = user.getUserPreference(Constants.UserPreference.NOTIFICATION_TEXT_ALL, customer);
		if(userPreference != null && userPreference.getValue().equals(Constants.YES)) {
			partOfTextClub = true;
		}
		
		String menu = "" + 
			(notifyAboutUnexpectedText ? "Sorry, we didn't understand that last message.\n" : "") + 
			(partOfTextClub ? "Reply STOP to stop messages from " + customer.getName() + "\n" : "") +
			(customer.is(CustomerConstants.LE_BOULANGER) ? "" : "Manage notifications on "+Constants.URL.MY_REWARDME+" or call 1-888-255-2512")
		;
		UserMessage userMessage = new UserMessage(customer, user, new Date(), menu);
		MessageManager.send(userMessage, NotificationType.TEXT_SYSTEM, true);
	}

}
