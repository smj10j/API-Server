package com.viralogy.rewardme.manager;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.PointsDAO;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.PointCategory;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserPoints;
import com.viralogy.rewardme.model.UserPoints.Type;

public abstract class PointsManager {

	private static Logger logger = Logger.getLogger(PointsManager.class);

	public static void credit(User user, Customer customer, Address address, Type type, PointCategory pointCategory, long points) throws FatalException, InvalidParameterException {
		UserPoints userPoints = getUserPoints(user, customer, type, pointCategory, null);
		PointsDAO.credit(userPoints, address, points);
}
	
	public static void debit(User user, Customer customer, Address address, Type type, PointCategory pointCategory, long points) throws FatalException, InvalidParameterException {
		UserPoints userPoints = getUserPoints(user, customer, type, pointCategory, null);
		PointsDAO.debit(userPoints, address, points);
	}
	
	public static UserPoints getUserPoints(User user, Customer customer, Type type, PointCategory pointCategory, Long secondsAgo) throws FatalException, InvalidParameterException {
		return PointsDAO.getUserPoints(user, customer, type, pointCategory, secondsAgo);
	}
	
	public static UserPoints getUserPoints(User user, Type type, PointCategory pointCategory, Long secondsAgo) throws FatalException, InvalidParameterException {
		return PointsDAO.getUserPoints(user, type, pointCategory, secondsAgo);
	}
	
	public static PointCategory getPointCategory(long pointCategoryId) throws FatalException, InvalidParameterException {
		return PointsDAO.getPointCategory(pointCategoryId);
	}
	
	public static PointCategory getPointCategory(Customer customer, String name) throws InvalidParameterException, FatalException {
		return PointsDAO.getPointCategory(customer, name);
	}
	
	public static void save(PointCategory pointCategory) throws InvalidParameterException, FatalException {
		pointCategory.save();
	}
	
	public static List<PointCategory> getAllPointCategories(Customer customer) throws FatalException, InvalidParameterException {
		return PointsDAO.getAllPointCategories(customer);
	}
	
	public static PointCategory getDefaultPointCategory(Customer customer) throws FatalException, InvalidParameterException {
		List<PointCategory> pointCategories = getAllPointCategories(customer);
		if(pointCategories.size() == 0) {
			return null;
		}else {
			//lowest weight
			return pointCategories.get(0);
		}
	}
}
