package com.viralogy.rewardme.manager;

import java.util.Map;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.PreferencesDAO;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerPreference;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserPreference;
import com.viralogy.rewardme.util.Cache;

public abstract class PreferencesManager {

	private static Logger logger = Logger.getLogger(PreferencesManager.class);

	public static Map<String, UserPreference> getUserPreferences(User user, Customer customer) throws FatalException, InvalidParameterException {
		Map<String, UserPreference> userPreferences = Cache.get(user.getUserId()+"", customer == null ? null : (customer.getCustomerId() + ""), Cache.namespace.USER_PREFERENCES);
		if(userPreferences == null) {
			userPreferences = PreferencesDAO.getUserPreferences(user, customer);
			Cache.put(userPreferences, Cache.lifetime.FIVE_MINUTE, user.getUserId()+"", customer == null ? null : (customer.getCustomerId() +""), Cache.namespace.USER_PREFERENCES);
		}
		return userPreferences;
	}
	
	public static void remove(UserPreference userPreference) throws FatalException, InvalidParameterException {
		userPreference.remove();

		Cache.remove(userPreference.getUser().getUserId()+"", Cache.namespace.USER_BY_ID);
		Cache.remove(userPreference.getUser().getPhoneNumber(), Cache.namespace.USER_BY_PHONE_NUMBER);
		Cache.remove(userPreference.getUser().getUserId()+"", userPreference.getCustomer() == null ? null : userPreference.getCustomer().getCustomerId() + "", Cache.namespace.USER_PREFERENCES);
		userPreference.getUser().clearTransients();
	}
	
	public static void removeUserPreferences(User user, Customer customer) throws FatalException, InvalidParameterException {
		Map<String, UserPreference> userPreferences = user.getUserPreferences(customer);
		for(String preferenceName : userPreferences.keySet()) {
			UserPreference userPreference = userPreferences.get(preferenceName);
			remove(userPreference);
		}
		user.clearTransients();
	}
	
	public static void save(UserPreference userPreference) throws FatalException, InvalidParameterException {
		
		//HACK for faster queries while still using the GeneralDAO for saving
		//MySQL can't index NULL values - so we substitute 0
		if(userPreference.getCustomer() == null) {
			Customer nullCustomer = new Customer();
			nullCustomer.setCustomerId(0);
			userPreference.setCustomer(nullCustomer);
			userPreference.save();
			userPreference.setCustomer(null);
		}else {
			userPreference.save();
		}

		Cache.remove(userPreference.getUser().getUserId()+"", Cache.namespace.USER_BY_ID);
		Cache.remove(userPreference.getUser().getPhoneNumber(), Cache.namespace.USER_BY_PHONE_NUMBER);
		Cache.remove(userPreference.getUser().getUserId()+"", userPreference.getCustomer() == null ? null : userPreference.getCustomer().getCustomerId() + "", Cache.namespace.USER_PREFERENCES);
		userPreference.getUser().clearTransients();
	}
	
	public static Map<String, CustomerPreference> getCustomerPreferences(Customer customer, Address address) throws FatalException, InvalidParameterException {
		Map<String, CustomerPreference> customerPreferences = Cache.get(customer.getCustomerId() + "", address == null ? null : address.getAddressId() + "", Cache.namespace.CUSTOMER_PREFERENCES);
		if(customerPreferences == null ) {
			customerPreferences = PreferencesDAO.getCustomerPreferences(customer, address);
			Cache.put(customerPreferences, Cache.lifetime.FIVE_MINUTE, customer.getCustomerId() + "", address == null ? null : address.getAddressId() + "", Cache.namespace.CUSTOMER_PREFERENCES);
		}
		
		return customerPreferences;
	}
	
	public static void remove(CustomerPreference customerPreference) throws FatalException, InvalidParameterException {
		customerPreference.remove();
		Cache.remove( customerPreference.getCustomer().getCustomerId() + "", customerPreference.getAddress() == null ? null : customerPreference.getAddress().getAddressId() + "", Cache.namespace.CUSTOMER_PREFERENCES);
		Cache.remove( customerPreference.getCustomer().getCustomerId() + "", null + "", Cache.namespace.CUSTOMER_PREFERENCES);
		Cache.remove( customerPreference.getCustomer().getApiKey(), Cache.namespace.CUSTOMER_BY_API_KEY);
		Cache.remove( customerPreference.getCustomer().getApiKey(), Cache.namespace.CUSTOMER_BY_ID);
		if(customerPreference.getAddress() != null) {
			Cache.remove( customerPreference.getAddress().getAddressId()+"|"+true, Cache.namespace.ADDRESS);
			Cache.remove( customerPreference.getAddress().getAddressId()+"|"+false, Cache.namespace.ADDRESS);
		}
	}
	
	public static void removeCustomerPreferences(Customer customer, Address address) throws FatalException, InvalidParameterException {
		Map<String, CustomerPreference> customerPreferences = customer.getCustomerPreferences(address);
		for(String preferenceName : customerPreferences.keySet()) {
			CustomerPreference customerPreference = customerPreferences.get(preferenceName);
			remove(customerPreference);
		}
	}
	
	public static void save(CustomerPreference customerPreference) throws FatalException, InvalidParameterException {
		//HACK for faster queries while still using the GeneralDAO for saving
		//MySQL can't index NULL values - so we substitute 0
		if(customerPreference.getAddress() == null) {
			Address nullAddress = new Address(null);
			nullAddress.setAddressId(0);
			customerPreference.setAddress(nullAddress);
			customerPreference.save();
			customerPreference.setAddress(null);
		}else {
			customerPreference.save();
		}		
		
		Cache.remove( customerPreference.getCustomer().getCustomerId() + "", customerPreference.getAddress() == null ? null : customerPreference.getAddress().getAddressId() + "", Cache.namespace.CUSTOMER_PREFERENCES);
		Cache.remove( customerPreference.getCustomer().getCustomerId() + "", null + "", Cache.namespace.CUSTOMER_PREFERENCES);
		Cache.remove( customerPreference.getCustomer().getApiKey(), Cache.namespace.CUSTOMER_BY_API_KEY);
		Cache.remove( customerPreference.getCustomer().getApiKey(), Cache.namespace.CUSTOMER_BY_ID);
		if(customerPreference.getAddress() != null) {
			Cache.remove( customerPreference.getAddress().getAddressId()+"|"+true, Cache.namespace.ADDRESS);
			Cache.remove( customerPreference.getAddress().getAddressId()+"|"+false, Cache.namespace.ADDRESS);
		}
		Cache.remove( customerPreference.getCustomer().getApiKey(), Cache.namespace.CUSTOMER_ADDRESSES);

	}
	
}
