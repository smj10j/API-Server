package com.viralogy.rewardme.manager;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Rating;

public abstract class RatingManager {

	public static void save(Rating rating) throws FatalException, InvalidParameterException{
		rating.save();
	}
}
