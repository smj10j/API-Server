package com.viralogy.rewardme.manager;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.dao.ReferralDAO;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserCheckin;
import com.viralogy.rewardme.model.UserReferral;
import com.viralogy.rewardme.model.UserReferralRequest;
import com.viralogy.rewardme.util.Cache;

public abstract class ReferralManager {

	private static Logger logger = Logger.getLogger(ReferralManager.class);
	
	public static void archiveUserReferralRequest(User referrer, User referred, Customer customer) throws FatalException, InvalidParameterException {
		archiveUserReferralRequest(
			new UserReferralRequest(
					referrer, 
					referred, 
					null, 
					customer
			)
		);
	}
	
	public static void archiveUserReferralRequest(UserReferralRequest userReferralRequest) throws FatalException, InvalidParameterException {
		ReferralDAO.archiveUserReferralRequest(userReferralRequest);
		Cache.remove(userReferralRequest.getUserReferralRequestId()+"", Cache.namespace.USER_REFERRAL_REQUEST_BY_ID);
		Cache.remove(userReferralRequest.getReferred().getUserId()+"", userReferralRequest.getCustomer().getCustomerId()+"", Cache.namespace.USER_REFERRAL_REQUEST_BY_USER);
		Cache.remove(userReferralRequest.getReferred().getUserId()+"",  Cache.namespace.USER_REFERRAL_REQUESTS_BY_USER);
		Cache.remove(userReferralRequest.getReferred().getPhoneNumber(), Cache.namespace.USER_REFERRAL_REQUEST_BY_PHONE_NUMBER);
	}
	
	public static UserReferralRequest createUserReferralRequest(User referrer, User referred, Customer customer) throws FatalException, InvalidParameterException {
		
		//check if it's... the same user
		if(referred.getUserId() == referrer.getUserId()) {
			throw new InvalidParameterException(Constants.Error.REFERRAL.REFERRAL_SELF);
		}		
		
		//check if the referred person has already visited this location
		List<UserCheckin> userCheckinsAtLocation = UserManager.getCheckins(referred, customer, false, 1);
		if(userCheckinsAtLocation.size() != 0) {
			//the referred user has been here before
			throw new InvalidParameterException(Constants.Error.REFERRAL.ALREADY_VISITED);
		}
		
		UserReferral userReferral = getUserReferral(referred, customer);
		if(userReferral != null) {
			//should we enforce this in the schema?
			throw new InvalidParameterException(Constants.Error.REFERRAL.ALREADY_REFERRED);				
		}
		
		UserReferralRequest userReferralRequest = getUserReferralRequest(referred, customer);
		if(userReferralRequest != null) {
			//should we enforce this in the schema?
			throw new InvalidParameterException(Constants.Error.REFERRAL.ALREADY_REFERRED);				
		}		
		
		userReferralRequest = ReferralDAO.createUserReferralRequest(referrer, referred, null, customer);
		Cache.remove(referred.getUserId()+"", customer.getCustomerId()+"", Cache.namespace.USER_REFERRAL_REQUEST_BY_USER);
		Cache.remove(referred.getUserId()+"",  Cache.namespace.USER_REFERRAL_REQUESTS_BY_USER);
		if(referred.getPhoneNumber() != null) {
			Cache.remove(referred.getPhoneNumber(), Cache.namespace.USER_REFERRAL_REQUEST_BY_PHONE_NUMBER);
		}
		return userReferralRequest;
	}	
	
	public static UserReferralRequest createUserReferralRequest(User referrer, String referredPhoneNumber, Customer customer) throws FatalException, InvalidParameterException {
		//don't worry about people referring themselves - we'll catch it later
		
		User referred = null;
		try {
			referred = UserManager.getUserByPhoneNumber(referredPhoneNumber);
			//we can then use the userId
					
		}catch(InvalidParameterException e) {
			//not created - we need to use the phone number 
						
			UserReferralRequest userReferralRequest = getUserReferralRequest(referredPhoneNumber, customer);
			if(userReferralRequest != null) {
				//should we enforce this in the schema?
				throw new InvalidParameterException(Constants.Error.REFERRAL.ALREADY_REFERRED);				
			}
			
			return ReferralDAO.createUserReferralRequest(referrer, null, referredPhoneNumber, customer);
			
		}
		//we only get here if referred is set
		return createUserReferralRequest(referrer, referred, customer);
		
	}	
	
	public static List<UserReferralRequest> getUserReferralRequests(User referred, int returnCount) throws FatalException, InvalidParameterException {
		return ReferralDAO.getUserReferralRequests(referred, returnCount);
	}
	
	public static UserReferralRequest getUserReferralRequest(User referred, Customer customer) throws FatalException, InvalidParameterException {
		UserReferralRequest userReferralRequest = Cache.get(referred.getUserId()+"", customer.getCustomerId()+"", Cache.namespace.USER_REFERRAL_REQUEST_BY_USER);
		if(userReferralRequest == null) {
			userReferralRequest = ReferralDAO.getUserReferralRequest(referred, customer);
			Cache.put(userReferralRequest, referred.getUserId()+"", customer.getCustomerId()+"", Cache.namespace.USER_REFERRAL_REQUEST_BY_USER);
		}
		return userReferralRequest;
	}
	
	public static UserReferralRequest getUserReferralRequest(long userReferralRequestId) throws FatalException, InvalidParameterException {
		UserReferralRequest userReferralRequest = Cache.get(userReferralRequestId+"", Cache.namespace.USER_REFERRAL_REQUEST_BY_ID);
		if(userReferralRequest == null) {
			userReferralRequest = ReferralDAO.getUserReferralRequest(userReferralRequestId);
			Cache.put(userReferralRequest, userReferralRequestId+"", Cache.namespace.USER_REFERRAL_REQUEST_BY_ID);
		}
		return userReferralRequest;
	}	
	
	public static UserReferralRequest getUserReferralRequest(String referredPhoneNumber, Customer customer) throws FatalException, InvalidParameterException {
		UserReferralRequest userReferralRequest = Cache.get(referredPhoneNumber, customer.getCustomerId()+"", Cache.namespace.USER_REFERRAL_REQUEST_BY_PHONE_NUMBER);
		if(userReferralRequest == null) {
			userReferralRequest = ReferralDAO.getUserReferralRequest(referredPhoneNumber, customer);
			Cache.put(userReferralRequest, referredPhoneNumber, customer.getCustomerId()+"", Cache.namespace.USER_REFERRAL_REQUEST_BY_PHONE_NUMBER);
		}
		return userReferralRequest;
	}	
	
	public static UserReferral createUserReferral(User referrer, User referred, Customer customer) throws FatalException, InvalidParameterException {
		
		//check if it's... the same user
		if(referred.getUserId() == referrer.getUserId()) {
			
			//let's remove any outstanding requests matching this info
			archiveUserReferralRequest(referrer, referred, customer);
			MySQL.commit();

			throw new InvalidParameterException(Constants.Error.REFERRAL.REFERRAL_SELF);
		}
		
		//make sure the referrer has already visited this location
		UserCheckin lastCheckin = UserManager.getLastCheckin(referrer, customer, false);
		if(lastCheckin == null) {
			//let's remove any outstanding requests matching this info
			archiveUserReferralRequest(referrer, referred, customer);
			MySQL.commit();
			
			throw new InvalidParameterException(Constants.Error.REFERRAL.LOCATION_NOT_VISITED_BY_REFERRER);			
		}
		
		//check if the referred person has already visited this location
		List<UserCheckin> userCheckinsAtLocation = UserManager.getCheckins(referred, customer, false, 1);
		if(userCheckinsAtLocation.size() != 0) {
			//the referred user has been here before
			
			//let's remove any outstanding requests matching this info
			archiveUserReferralRequest(referrer, referred, customer);
			MySQL.commit();
			
			throw new InvalidParameterException(Constants.Error.REFERRAL.ALREADY_VISITED);
		}
		//let's remove any outstanding requests matching this info
		archiveUserReferralRequest(referrer, referred, customer);
		
		UserReferral userReferral = ReferralDAO.createUserReferral(referrer, referred, customer);
		Cache.remove(referred.getUserId()+"", customer.getCustomerId()+"", Cache.namespace.USER_REFERRAL_BY_USER_CUSTOMER);
		return userReferral;
	}
	
	public static UserReferral getUserReferral(User referred, Customer customer) throws FatalException, InvalidParameterException {
		UserReferral UserReferral = Cache.get(referred.getUserId()+"", customer.getCustomerId()+"", Cache.namespace.USER_REFERRAL_BY_USER_CUSTOMER);
		if(UserReferral == null) {
			UserReferral = ReferralDAO.getUserReferral(referred, customer);
			Cache.put(UserReferral, referred.getUserId()+"", customer.getCustomerId()+"", Cache.namespace.USER_REFERRAL_BY_USER_CUSTOMER);
		}
		return UserReferral;
	}
	
}
