package com.viralogy.rewardme.manager;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.ReportingDAO;
import com.viralogy.rewardme.model.Report;

public abstract class ReportingManager {

	private static Logger logger = Logger.getLogger(ReportingManager.class);

	public static Report getReport(long reportId) throws InvalidParameterException, FatalException {
		return ReportingDAO.getReport(reportId);
	}
	
	public static List<Report> getReports() throws InvalidParameterException, FatalException {
		return ReportingDAO.getReports();
	}
	
	public static void save(Report report) throws InvalidParameterException, FatalException {
		report.save();
	}
	
	public static void run(Report report) throws InvalidParameterException, FatalException {
		/* TODO: enable once `definition` field is serializable
		String cacheKey = report.getCustomer().getCustomerId()+"|"+report.getReportId()+"|";
		cacheKey+= report.getStartDate().getTime()+"|"+report.getEndDate().getTime()+"|"+report.getPeriodType().toString()+"|";
		
		Report completedReport = Cache.get(cacheKey, Cache.namespace.COMPLETED_REPORT);
		if(completedReport == null) {
			ReportingDAO.run(report);
			Cache.put(report, cacheKey, Cache.namespace.COMPLETED_REPORT);
		}else {
			report = completedReport;
		}
		*/
	
		ReportingDAO.run(report);

	}
}
