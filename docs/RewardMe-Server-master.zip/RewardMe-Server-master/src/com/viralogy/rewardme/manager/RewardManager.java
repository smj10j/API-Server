package com.viralogy.rewardme.manager;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.RewardDAO;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Device;
import com.viralogy.rewardme.model.PointCategory;
import com.viralogy.rewardme.model.Reward;
import com.viralogy.rewardme.model.Session;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserCheckin;
import com.viralogy.rewardme.model.UserPoints;
import com.viralogy.rewardme.model.UserReward;
import com.viralogy.rewardme.util.Cache;
import com.viralogy.rewardme.util.ListUtil;

public abstract class RewardManager {
	
	private static Logger logger = Logger.getLogger(RewardManager.class);

	public static Reward getReward(long rewardId) throws FatalException, InvalidParameterException {
		Reward reward = Cache.get(rewardId+"", Cache.namespace.REWARD);
		if(reward == null) {
			reward = RewardDAO.getReward(rewardId);
			Cache.put(reward, rewardId+"", Cache.namespace.REWARD);
		}
		//logger.debug("Got rewardId: "+ reward.getRewardId() + OutputUtil.getElapsedString());
		return reward;
	}
	
	public static List<Reward> getAllCustomerRewards(Customer customer) throws FatalException, InvalidParameterException {
		List<Reward> rewards = Cache.get(customer.getApiKey(), Cache.namespace.CUSTOMER_REWARDS);
		if(rewards == null) {
			rewards = RewardDAO.getAllCustomerRewards(customer);
			Cache.put(rewards, customer.getApiKey(), Cache.namespace.CUSTOMER_REWARDS);
		}		
		//logger.debug("Got all rewards for customerId: " + customer.getCustomerId() + OutputUtil.getElapsedString());
		return rewards;
	}
	
	/*
	 * Returns a list of rewards that the user can, at some point, achieve the reward
	 * The reward may not be available at this moment - for example, if there is a post redeem cooldown period set
	 */
	public static List<Reward> getAllCustomerRewardsAvailableToUser(Customer customer, User user, PointCategory pointCategory) throws FatalException, InvalidParameterException {
		List<Reward> allAvailableRewards = getAllCustomerRewards(customer);
		List<Reward> availableRewards = new ArrayList<Reward>(); 
		for(Reward reward : allAvailableRewards) {
			if(reward.isEnabled() && isRewardAvailableToUser(user, reward, pointCategory)) {
				availableRewards.add(reward);
			}
		}
		return availableRewards;
	}
	
	public static List<UserReward> getActiveRewards( Customer customer, User user ) throws FatalException, InvalidParameterException {
		return RewardDAO.getActiveRewards(customer, user);
	}
	
	public static void addRewardToCustomer(Customer customer, Reward reward) throws InvalidParameterException, FatalException {
		RewardDAO.addRewardToCustomer(customer, reward);
		Cache.remove(customer.getApiKey(), Cache.namespace.CUSTOMER_BY_API_KEY);
		Cache.remove(customer.getCustomerId()+"", Cache.namespace.CUSTOMER_BY_ID);
		Cache.remove(customer.getApiKey(), Cache.namespace.CUSTOMER_REWARDS);
		customer.getRewards().add(reward);
	}
	
	public static void removeRewardFromCustomer(Customer customer, Reward reward) throws InvalidParameterException, FatalException {
		RewardDAO.removeRewardFromCustomer(customer, reward);
		Cache.remove(customer.getApiKey(), Cache.namespace.CUSTOMER_BY_API_KEY);
		Cache.remove(customer.getCustomerId()+"", Cache.namespace.CUSTOMER_BY_ID);
		Cache.remove(customer.getApiKey(), Cache.namespace.CUSTOMER_REWARDS);
		Cache.remove(reward.getRewardId()+"", Cache.namespace.REWARD);		
		customer.getRewards().remove(reward);
	}
	
	public static boolean isRewardAvailableToUser(User user, Reward reward, PointCategory pointCategory) throws FatalException, InvalidParameterException {
		
		//check redemption limits
		if(reward.getRedemptionLimit() != 0) {
			Boolean redemptionLimitHit = Cache.get(user.getUserId()+"|"+reward.getRewardId(), Cache.namespace.REWARD_REDEMPTION_LIMIT_HIT);
			if(redemptionLimitHit == null) {
				redemptionLimitHit = RewardDAO.isRedemptionLimitHit(user, reward);
				Cache.put(redemptionLimitHit, user.getUserId()+"|"+reward.getRewardId(), Cache.namespace.REWARD_REDEMPTION_LIMIT_HIT);
			}
			if(redemptionLimitHit) {
				return false;
			}
		}
		
		PointCategory defaultPointCategory = PointsManager.getDefaultPointCategory(reward.getCustomer());
		PointCategory rewardPointCategory = reward.getPointCategory() == null ? defaultPointCategory : reward.getPointCategory();
		pointCategory = pointCategory == null ? defaultPointCategory : pointCategory;
		
		if(pointCategory == null && rewardPointCategory != null) {
			//we want the default but the reward is not the default
			//this shouldn't ever happen because pointCategory=null should be set to the default
			return false;
		}else if(pointCategory != null && rewardPointCategory == null) {
			//we want a non-default but the reward is the default
			//this shouldn't ever happen because pointCategory=null should be set to the default
			return false;
		}else if(pointCategory != null && pointCategory.getPointCategoryId() != rewardPointCategory.getPointCategoryId()) {
			//we want a different point category than the reward
			return false;
		}
		
		/*
		//now let's check if the reward is being redeemed after the cooldown period has passed
		if(reward.getPostRedeemCooldown() != 0) {
			//get the last time this reward was redeemed
			Long seconds = RewardDAO.getTimeSinceLastRedeem(user, reward);
			if(seconds != null && seconds < reward.getPostRedeemCooldown()) {
				return false;
			}
		}
		*/
		
		return true;
	}
	
	public static void completeRedeem(User user, Reward reward, Address address) throws FatalException, InvalidParameterException {
		Customer customer = CustomerManager.getCustomer(reward);

		RewardDAO.completeRedeem(user, reward, address);
		
		Cache.remove(user.getUserId()+"|"+null, Cache.namespace.USER_ADDRESSES);
		Cache.remove(user.getUserId()+"|"+customer.getCustomerId(), Cache.namespace.USER_ADDRESSES);
		Cache.remove(user.getUserId()+"", Cache.namespace.USER_BY_ID);
		Cache.remove(user.getPhoneNumber(), Cache.namespace.USER_BY_PHONE_NUMBER);
		Cache.remove(user.getUserId()+"", customer.getApiKey(), Cache.namespace.USER_REWARDS);
	}
	
	public static void credit(User user, Reward reward, Session session) throws FatalException, InvalidParameterException {
		redeem(user, reward, AddressManager.getNearest(user.getGeoCoord(), reward.getCustomer()), session, true);
	}
	
	public static boolean rewardIsActive(User user, Reward reward) throws FatalException, InvalidParameterException {
		//let's get our currently active rewards
		List<UserReward> activeUserRewards = RewardManager.getActiveRewards(reward.getCustomer(), user);
		for(UserReward activeUserReward : activeUserRewards) {
			if(activeUserReward.getReward().getRewardId() == reward.getRewardId()) {
				return true;
			}
		}
		return false;
	}
	
	//force allows redemption of an non-standard reward and also doesn't consider point values
	//it will not allow redeeming of rewards a user already has 
	//force is called from user.checkin
	public static UserReward redeem(User user, Reward reward, Address redeemAddress, Session session, boolean force) throws FatalException, InvalidParameterException {
				
		//set the customer
		Customer customer = CustomerManager.getCustomer(reward);
		
		// gets address of redemption by nearest location
		Address nearestAddress = redeemAddress != null ? redeemAddress : AddressManager.getNearest(user.getGeoCoord(), customer);
		
		if(!customer.isEnabled() && !user.isAuthorized()) {
			throw new InvalidParameterException(Constants.Error.GENERAL.DISABLED_CUSTOMER);
		}
		reward.setCustomer(customer);
		
		//check if the reward is active already
		if(rewardIsActive(user, reward)) {
			//we don't want to redeem a reward we already have active
			throw new InvalidParameterException(Constants.Error.REDEEM.REWARD_IS_ALREADY_ACTIVE, ListUtil.from(reward.getRewardId()+""));
		}
		
		//don't allow redemptions before a user has checked in
		/*if(!force) {
			if(UserManager.getLastCheckin(user, customer, false) == null) {
				throw new InvalidParameterException(Constants.Error.REDEEM.USER_HAS_NOT_CHECKED_IN_BUT_TRIED_TO_REDEEM);						
			}
		}*/
		
		//now let's get all the rewards that are available for this customer - honors schedules
		boolean available = false;
		List<Reward> availableRewards = RewardManager.getAllCustomerRewardsAvailableToUser(reward.getCustomer(), user, reward.getPointCategory());
		for(Reward availableReward : availableRewards) {
			if(availableReward.getRewardId() == reward.getRewardId()) {
				available = true;
				break;
			}
		}
		if(!available) {
			//we don't want to allow redemption of inactive rewards
			throw new InvalidParameterException(Constants.Error.REDEEM.REWARD_IS_NOT_AVAILABLE, ListUtil.from(reward.getRewardId()+""));
		}		
		
		//don't allow the user to redeem a reward with escrow check-in points
		if(!force) {
			for(Address address : reward.getCustomer().getAddresses()) {
				UserCheckin userCheckin = UserManager.getLastCheckin(user, reward.getCustomer(), true);
				if(userCheckin != null) {
					UserPoints allPoints = PointsManager.getUserPoints(user, reward.getCustomer(), null, reward.getPointCategory(), null);
					UserPoints recentPoints = PointsManager.getUserPoints(user, reward.getCustomer(), UserPoints.Type.CHECKIN, reward.getPointCategory(), userCheckin.getCheckinOption().getCooldownLength());
					long availableBalance = allPoints.getCurrentBalance() - recentPoints.getCurrentBalance();
					if(availableBalance < reward.getPointsRequired()) {
						logger.warn("Attempted a reward redemption before the refactory period was over. userId="+user.getUserId()+", addressId="+address.getAddressId()+", rewardId="+reward.getRewardId());
						throw new InvalidParameterException(Constants.Error.POINTS.INSUFFICIENT_POINTS,ListUtil.from(reward.getPointsRequired()+"", availableBalance+"", recentPoints.getCurrentBalance()+""));
					}
				}
			}
		}
		
		if(!force) {
			//subtract the points
			PointsManager.debit(user, reward.getCustomer(), nearestAddress, UserPoints.Type.REDEEM, reward.getPointCategory(), reward.getPointsRequired());
		}
		
		//redeem
		UserReward userReward = RewardDAO.redeem(user, reward, nearestAddress);
		
		Cache.remove(user.getUserId()+"|"+null, Cache.namespace.USER_ADDRESSES);
		Cache.remove(user.getUserId()+"|"+reward.getCustomer().getCustomerId(), Cache.namespace.USER_ADDRESSES);
		Cache.remove(user.getUserId()+"", Cache.namespace.USER_BY_ID);
		Cache.remove(user.getUserId()+"", reward.getCustomer().getApiKey(), Cache.namespace.USER_REWARDS);
		
		return userReward;
	}
	
	public static void save(Reward reward) throws FatalException, InvalidParameterException {
		if(reward.getPointCategory() == null) {
			PointCategory pointCategory = new PointCategory();
			pointCategory.setPointCategoryId(0);
			reward.setPointCategory(pointCategory);
		}
		reward.save();
		Cache.remove(reward.getCustomer().getApiKey(), Cache.namespace.CUSTOMER_BY_API_KEY);
		Cache.remove(reward.getCustomer().getCustomerId()+"", Cache.namespace.CUSTOMER_BY_ID);
		Cache.remove(reward.getCustomer().getApiKey(), Cache.namespace.CUSTOMER_REWARDS);
		Cache.remove(reward.getRewardId()+"", Cache.namespace.REWARD);		
	}
}
