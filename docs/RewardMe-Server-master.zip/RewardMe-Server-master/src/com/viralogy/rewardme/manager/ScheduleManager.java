package com.viralogy.rewardme.manager;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.ScheduleDAO;
import com.viralogy.rewardme.model.Schedule;
import com.viralogy.rewardme.model.ScheduleTime;
import com.viralogy.rewardme.model.Schedule.DayOfWeekType;
import com.viralogy.rewardme.util.Cache;

public abstract class ScheduleManager {
	
	private static Logger logger = Logger.getLogger(ScheduleManager.class);

	public static Schedule getSchedule(long scheduleId) throws FatalException, InvalidParameterException {
		Schedule schedule = Cache.get(scheduleId+"", Cache.namespace.SCHEDULE);
		if(schedule == null) {
			schedule = ScheduleDAO.getSchedule(scheduleId);
			Cache.put(schedule, scheduleId+"", Cache.namespace.SCHEDULE);
		}
		return schedule;
	}
	
	public static Schedule getSchedule(DayOfWeekType dayOfWeekType, ScheduleTime startTime, ScheduleTime endTime, double multiplier) throws FatalException, InvalidParameterException {
		Schedule schedule = Cache.get(dayOfWeekType.toString()+"|"+startTime.toHourMinute()+"|"+endTime.toHourMinute()+"|"+multiplier, Cache.namespace.SCHEDULE);
		if(schedule == null) {
			schedule = ScheduleDAO.getSchedule(dayOfWeekType, startTime, endTime, multiplier);
			Cache.put(schedule, dayOfWeekType.toString()+"|"+startTime.toHourMinute()+"|"+endTime.toHourMinute()+"|"+multiplier, Cache.namespace.SCHEDULE);
		}
		return schedule;
	}

	public static void addSchedule(Schedule schedule) throws InvalidParameterException, FatalException {
		ScheduleDAO.addSchedule(schedule);
	}

}
