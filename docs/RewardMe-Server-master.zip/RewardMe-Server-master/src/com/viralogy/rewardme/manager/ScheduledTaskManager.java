package com.viralogy.rewardme.manager;


import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.dao.ScheduledTaskDAO;
import com.viralogy.rewardme.scheduler.ScheduledTask;
import com.viralogy.rewardme.scheduler.ScheduledTask.Type;
import com.viralogy.rewardme.util.RemoteRequestUtil;

public abstract class ScheduledTaskManager {

	private static Logger logger = Logger.getLogger(ScheduledTaskManager.class);

	public static void executeTasks(Set<ScheduledTask> scheduledTasks) throws InvalidParameterException, FatalException {
		for(ScheduledTask scheduledTask : scheduledTasks) {
			executeTask(scheduledTask);
		}
	}
	
	public static void executeTask(ScheduledTask scheduledTask) throws InvalidParameterException, FatalException {
		logger.info("Processing scheduledTask " + scheduledTask.toString());
		
		//indicate it was processed
		scheduledTask.setArchived(true);
		scheduledTask.save();
		MySQL.commit();
		
		//run the task!
		if(scheduledTask.getType().equals(Type.URL)) {
			String[] urlParts = scheduledTask.getData().split("\\?");
			RemoteRequestUtil.get(urlParts[0], urlParts.length>1 ? urlParts[1] : null, true);
		}
	}	
	
	public static Set<ScheduledTask> getScheduledTasksToExecute() throws InvalidParameterException, FatalException {
		return ScheduledTaskDAO.getScheduledTasksToExecute();
	}
	
	public static void save(ScheduledTask scheduledTask) throws InvalidParameterException, FatalException {
		scheduledTask.save();
	}
}