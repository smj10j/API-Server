package com.viralogy.rewardme.manager;

import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.SegmentDAO;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Event;
import com.viralogy.rewardme.model.PointCategory;
import com.viralogy.rewardme.model.Segment;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserSegment;
import com.viralogy.rewardme.util.Cache;

public abstract class SegmentManager {
	private static Logger logger = Logger.getLogger(SegmentManager.class);
	
	public static Segment getSegment(long segmentId, boolean onlyUnArchived ) throws FatalException, InvalidParameterException {
		Segment segment;
		segment = Cache.get(segmentId+"", onlyUnArchived  ? Cache.namespace.SEGMENT : Cache.namespace.SEGMENT_ARCHIVED);
		if(segment == null) {
			segment = SegmentDAO.getSegment(segmentId, onlyUnArchived );
			Cache.put(segment, segmentId+"", onlyUnArchived  ? Cache.namespace.SEGMENT : Cache.namespace.SEGMENT_ARCHIVED);
		}
		return segment;
	}
	
	//returns only nonArchived segments
	public static Segment getSegment(long segmentId) throws FatalException, InvalidParameterException {
		return getSegment(segmentId, true);
	}

	public static void remove(Segment segment) throws InvalidParameterException, FatalException {
		segment.setArchived(true);
		save(segment);
		Cache.remove(segment.getSegmentId()+"", Cache.namespace.SEGMENT);
		Cache.remove(segment.getCustomer().getApiKey() + "|" + (segment.getAddress() == null ? "null" : segment.getAddress().getAddressId()), Cache.namespace.CUSTOMER_SEGMENTS);
	}
	
	public static void save(Segment segment) throws InvalidParameterException, FatalException {
		segment.save();
		Cache.remove(segment.getSegmentId()+"", Cache.namespace.SEGMENT);
		Cache.remove(segment.getSegmentId()+"", Cache.namespace.SEGMENT_ARCHIVED);
		Cache.remove(segment.getCustomer().getApiKey() + "|" + (segment.getAddress() == null ? "null" : segment.getAddress().getAddressId()), Cache.namespace.CUSTOMER_SEGMENTS);
		if (segment.wasDefinitionUpdated() && !segment.isArchived()) {//This is needed in the case that the user should be removed from the segment due to the change of definition. Even though this will be expensive, I believe updating the definition will be rare. Since users often stay in the same bucket for a while, the caching will make it worthwhile.
			long StartTime1 = System.currentTimeMillis();
			segment.initIterator();
			long Elapsed =  (System.currentTimeMillis() - StartTime1);
			logger.info("TIME TAKEN FOR INITILIZING segment: " + Elapsed);
			while (segment.hasNextUser()) {
				long StartTime = System.currentTimeMillis();
				User user = segment.nextUser();
				Elapsed =  (System.currentTimeMillis() - StartTime);
				logger.info("TIME TAKEN FOR segment.nextUser: " + Elapsed);
				Cache.remove(user.getUserId()+"|"+segment.getSegmentId(), Cache.namespace.USER_SEGMENT);
			}
			Elapsed =  (System.currentTimeMillis() - StartTime1);
			logger.info("TIME TAKEN FOR WHOLE SEGMENT ITERATOR: " + Elapsed);
		}
	}
	
	//customer cannot be null
	public static List<Segment> getAllSegments(Customer customer, Address address, boolean onlyUnArchived) throws FatalException, InvalidParameterException {
		List<Segment> segments;
		if (onlyUnArchived) {
			segments = Cache.get(customer.getApiKey() + "|" + (address == null ? "null" : address.getAddressId()), Cache.namespace.CUSTOMER_SEGMENTS);
			if(segments == null) {
				segments = SegmentDAO.getAllSegments(customer, address);
				Cache.put(segments, customer.getApiKey() + "|" + (address == null ? "null" : address.getAddressId()), Cache.namespace.CUSTOMER_SEGMENTS);
			}
		} else {//no caching for archived segments. 
			segments = SegmentDAO.getAllSegments(customer, address, false);
		}
		return segments;
	}
	
	public static List<Segment> getAllSegments(Customer customer, Address address) throws FatalException, InvalidParameterException {
		return getAllSegments(customer, address, true);
	}
	
	public static List<UserSegment> getAllSegmentsAvailableToUser(Customer customer, Address address, User user) throws FatalException, InvalidParameterException {
		List<UserSegment> userSegments;
	//	if (address == null) {
	//		userSegments = Cache.get(customer.getApiKey() + "|" + user.getUserId(), Cache.namespace.GLOBAL_USER_SEGMENTS);
	//	} else {
	//		userSegments = Cache.get(customer.getApiKey() + "|" + user.getUserId(), Cache.namespace.ADDRESS_USER_SEGMENTS);
	//	}
	//	if(userSegments == null) {
			userSegments = SegmentDAO.getUserSegments(customer, address, user);
	//	if (address == null) {
	//			Cache.put(userSegments, customer.getApiKey() + "|" + user.getUserId(), Cache.namespace.GLOBAL_USER_SEGMENTS);
		//	} else {
		//		Cache.put(userSegments, customer.getApiKey() + "|" + user.getUserId(), Cache.namespace.ADDRESS_USER_SEGMENTS);
		//	}
	//	}
		return userSegments;
	} 
	
	//returns users from Only nonArchived segments
	public static Segment userSegmentIterator(long segmentId) throws FatalException, InvalidParameterException {
		Segment segment = getSegment(segmentId);
		segment.initIterator();
		return segment;
	}
	
	private static void removeUserFromSegment(User user, Segment segment) throws FatalException {
		SegmentDAO.removeUserFromSegment(user, segment);
		Cache.remove(user.getUserId()+"|"+segment.getSegmentId(), Cache.namespace.USER_SEGMENT);
	}

	private static void addUserToSegment(User user, Segment segment) throws FatalException, InvalidParameterException {
		SegmentDAO.addUserToSegment(user, segment);
	}

	//returns nonArchivedOnly UserSegments
	public static UserSegment getUserSegment(User user, Segment segment) throws FatalException, InvalidParameterException {
		if (segment.isArchived()) {
			throw new FatalException("Attempted to get UserSegment of an archived Segment");
		}
		UserSegment userSegment = Cache.get(user.getUserId()+"|"+segment.getSegmentId(), Cache.namespace.USER_SEGMENT);
		if (userSegment == null) {
			userSegment = SegmentDAO.getUserSegment(user, segment);
			Cache.put(userSegment, user.getUserId()+"|"+segment.getSegmentId(), Cache.namespace.USER_SEGMENT);
			segment.setDefinitionUpdated(false); //current definition in cache is most updated.
		}
		return userSegment;
	}

	public static void processSegment(Segment segment, Event event) throws FatalException, InvalidParameterException {
		User user = event.getUser();
		if (user != null && !event.getName().equals("user.remove")) {//these require to have user data
			JSONObject definition = segment.getDefinition();
			int numberOfTruesRequired = definition.length();
			int numberOfTrues = 0;
			try {
				JSONObject checkin = definition.getJSONObject("checkin");
				if (processCheckin(segment, event, checkin)) {
					numberOfTrues++;
				}
			} catch (JSONException e) {
				//okay
			}
			try {
				JSONArray transactions = definition.getJSONArray("transactions");
				int transactionsLength = transactions.length();
				numberOfTruesRequired += transactionsLength - 1;
				for (int i = 0; i < transactionsLength; i++) {
					if (processTransactions(segment, event, transactions.getJSONObject(i))) {
						numberOfTrues++;
					}
				}
			} catch (JSONException e) {
				//okay
			}
			try {
				getUserSegment(user, segment);
				if (numberOfTrues != numberOfTruesRequired) {
					removeUserFromSegment(user,segment);
				}
			} catch (InvalidParameterException e) {
				if (numberOfTrues == numberOfTruesRequired) {
					addUserToSegment(user,segment);
				}
			}
		}
	}
	
	private static boolean processCheckin(Segment segment, Event event,
			JSONObject checkin) throws FatalException, InvalidParameterException {
		int numberOfTruesRequired = checkin.length();
		int numberOfTrues = 0;
		try {
			JSONArray pointObject = checkin.getJSONArray("points");
			int pointObjectLength = pointObject.length();
			numberOfTruesRequired += pointObjectLength - 1;
			for (int i = 0; i < pointObjectLength; i++) {
				if (processPoints(segment, event, pointObject.getJSONObject(i))) {
					numberOfTrues++;
				}
			}
		} catch (JSONException e) {
			//okay
		}
		try {
			JSONArray visitObject = checkin.getJSONArray("visits");
			int visitObjectLength = visitObject.length();
			numberOfTruesRequired += visitObjectLength - 1;
			for (int i = 0; i < visitObject.length(); i++) {
				if (processVisits(segment, event, visitObject.getJSONObject(i))) {
					numberOfTrues++;
				}
			}
		} catch (JSONException e) {
			//okay
		}
		if (numberOfTrues == numberOfTruesRequired) {
			return true;
		}
		return false;
	}

	private static boolean processTransactions(Segment segment, Event event,
			                                JSONObject transactions) throws FatalException, InvalidParameterException {
		Address eventAddress = event.getAddress();
		Address segmentAddress = segment.getAddress();
		Customer customer = event.getCustomer();
		User user = event.getUser();
		if (eventAddress != null || event.getName().equals("address.remove")) {//these require to have address data
			try {
				String USDAmountSpent = transactions.getString("amountSpent");
				boolean doNotIncludeTax = false;
				boolean doNotIncludeDiscount = false;
				
				if (transactions.has("exclude")) {
					String doNotInclude = transactions.getString("exclude");
					String[] doNotIncludeElements = doNotInclude.split(",");
					for (String element : doNotIncludeElements) {
						String elementTrimmed = element.trim();
						if (elementTrimmed.equals("tax")) {
							doNotIncludeTax = true;
						} else if (elementTrimmed.equals("discount")) {
							doNotIncludeDiscount = true;
						}
					}
				}
				
				float USDsum = 0f;
				if (transactions.has("paymentMethod")) {
					String paymentMethod = transactions.getString("paymentMethod");
					if (segmentAddress != null) {//nonglobal segment
						USDsum = POSManager.getAmountSumOfUser(user, customer, segmentAddress, doNotIncludeTax, doNotIncludeDiscount, paymentMethod);
					} else {//global segment
						for (Address address : customer.getAddresses()) {
							USDsum += POSManager.getAmountSumOfUser(user, customer, address, doNotIncludeTax, doNotIncludeDiscount, paymentMethod);
						}
					}
				} else {
					if (segmentAddress != null) {//nonglobal segment
						USDsum = POSManager.getAmountSumOfUser(user, customer, segmentAddress, doNotIncludeTax, doNotIncludeDiscount, null);
					} else {//global segment
						for (Address address : customer.getAddresses()) {
							USDsum += POSManager.getAmountSumOfUser(user, customer, address, doNotIncludeTax, doNotIncludeDiscount, null);
						}
					}
				}
				
				if (USDAmountSpent.contains("<=")) {
					float USDAmount = Float.parseFloat(USDAmountSpent.substring(2));
					if (USDsum <= USDAmount) {
						return true;
					}
				} else if (USDAmountSpent.contains(">=")) {
					float USDAmount = Float.parseFloat(USDAmountSpent.substring(2));
					if (USDsum >= USDAmount) {
						return true;
					}
				} else if (USDAmountSpent.contains("<")) {
					float USDAmount = Float.parseFloat(USDAmountSpent.substring(1));
					if (USDsum < USDAmount) {
						return true;
					}

				} else if (USDAmountSpent.contains(">")) {
					float USDAmount = Float.parseFloat(USDAmountSpent.substring(1));
					if (USDsum > USDAmount) {
						return true;
					}
				} else {
					float USDAmount = Float.parseFloat(USDAmountSpent);
					if (USDsum == USDAmount) {
						return true;
					}
				}
			} catch (JSONException e) {
				//okay. Currently does nothing unless it has "amountSpent"
			}
		}
		return false;
	}

	private static boolean processVisits(Segment segment, Event event,
			  JSONObject visitObject) throws FatalException, InvalidParameterException {
		Customer customer = event.getCustomer();
		User user = event.getUser();
		Address eventAddress = event.getAddress();
		Address segmentAddress = segment.getAddress();
		if (segmentAddress == null || eventAddress != null || event.getName().equals("address.remove")) {//requires address data. If it's address.remove it can possible effect global segments (a check before processSegment enforces this to be only global segments).
			try {
				String amountOfVisits = visitObject.getString("numberOfVisits");
				
				Long visits = UserManager.countUserCheckins(user, customer, segmentAddress);//if segmentAddress == null, grabs a total count for global segments
				
				if (amountOfVisits.contains("<=")) {
					long visitAmount = Long.parseLong(amountOfVisits.substring(2));
					if (visits <= visitAmount) {
						return true;
					}
				} else if (amountOfVisits.contains(">=")) {
					long visitAmount = Long.parseLong(amountOfVisits.substring(2));
					if (visits >= visitAmount) {
						return true;
					}
				} else if (amountOfVisits.contains("<")) {
					long visitAmount = Long.parseLong(amountOfVisits.substring(1));
					if (visits < visitAmount) {
						return true;
					}
				} else if (amountOfVisits.contains(">")) {
					long visitAmount = Long.parseLong(amountOfVisits.substring(1));
					if (visits > visitAmount) {
						return true;
					}
				} else {//equal
					long visitAmount = Long.parseLong(amountOfVisits);
					if (visits == visitAmount) {
						return true;						}
				}
			} catch (JSONException e) {
				//okay. Currently does nothing unless it has "numberOfVisits"
			}
		}
		return false;
	}
	
	private static boolean processPoints(Segment segment, Event event,
									  JSONObject pointObject) throws FatalException, InvalidParameterException {
		Customer customer = event.getCustomer();
		User user = event.getUser();
		try {
			String pointAmount = pointObject.getString("pointAmount");
			
			if (pointAmount.contains("<=")) {
				long pointValue = Long.parseLong(pointAmount.substring(2));
				if (pointObject.has("pointCategory")) {//the right amount in a specific point category
					PointCategory pointCategory = PointsManager.getPointCategory(customer, pointObject.getString("pointCategory"));
					long userPoints = user.getPoints(customer, pointCategory).getCurrentBalance();
					if (userPoints <= pointValue) {
						return true;
					}
				} else {//the right amount in any point category.
					if (event.getUser().getPoints(customer, null).getCurrentBalance() <= pointValue) {
						return true;
					}
					List<PointCategory> pointCategories = PointsManager.getAllPointCategories(event.getCustomer());
					for(PointCategory pointCategory : pointCategories) {
						long userPoints = event.getUser().getPoints(customer, pointCategory).getCurrentBalance();
						if (userPoints <= pointValue) {
							return true;
						} 
					}
				}
			} else if (pointAmount.contains(">=")) {
				long pointValue = Long.parseLong(pointAmount.substring(2));
				if (pointObject.has("pointCategory")) {//the right amount in a specific point category
					PointCategory pointCategory = PointsManager.getPointCategory(customer, pointObject.getString("pointCategory"));
					long userPoints = user.getPoints(customer, pointCategory).getCurrentBalance();
					if (userPoints >= pointValue) {
						return true;
					}
				} else {//the right amount in any point category.
					if (event.getUser().getPoints(customer, null).getCurrentBalance() >= pointValue) {
						return true;
					}
					List<PointCategory> pointCategories = PointsManager.getAllPointCategories(event.getCustomer());
					for(PointCategory pointCategory : pointCategories) {
						long userPoints = event.getUser().getPoints(customer, pointCategory).getCurrentBalance();
						if (userPoints >= pointValue) {
							return true;
						} 
					}
				}
			} else if (pointAmount.contains("<")) {
				long pointValue = Long.parseLong(pointAmount.substring(1));
				if (pointObject.has("pointCategory")) {//the right amount in a specific point category
					PointCategory pointCategory = PointsManager.getPointCategory(customer, pointObject.getString("pointCategory"));
					long userPoints = user.getPoints(customer, pointCategory).getCurrentBalance();
					if (userPoints < pointValue) {
						return true;
					}
				} else {//the right amount in any point category.
					if (event.getUser().getPoints(customer, null).getCurrentBalance() < pointValue) {
						return true;
					}
					List<PointCategory> pointCategories = PointsManager.getAllPointCategories(event.getCustomer());
					for(PointCategory pointCategory : pointCategories) {
						long userPoints = event.getUser().getPoints(customer, pointCategory).getCurrentBalance();
						if (userPoints < pointValue) {
							return true;
						} 
					}
				}
			} else if (pointAmount.contains(">")) {
				long pointValue = Long.parseLong(pointAmount.substring(1));
				if (pointObject.has("pointCategory")) {//the right amount in a specific point category
					PointCategory pointCategory = PointsManager.getPointCategory(customer, pointObject.getString("pointCategory"));
					long userPoints = user.getPoints(customer, pointCategory).getCurrentBalance();
					if (userPoints > pointValue) {
						return true;
					}
				} else {//the right amount in any point category.
					if (event.getUser().getPoints(customer, null).getCurrentBalance() > pointValue) {
						return true;
					}
					List<PointCategory> pointCategories = PointsManager.getAllPointCategories(event.getCustomer());
					for(PointCategory pointCategory : pointCategories) {
						long userPoints = event.getUser().getPoints(customer, pointCategory).getCurrentBalance();
						if (userPoints > pointValue) {
							return true;
						} 
					}
				}
			}  else {//equal to
				long pointValue = Long.parseLong(pointAmount);
				if (pointObject.has("pointCategory")) {//the right amount in a specific point category
					PointCategory pointCategory = PointsManager.getPointCategory(customer, pointObject.getString("pointCategory"));
					long userPoints = user.getPoints(customer, pointCategory).getCurrentBalance();
					if (userPoints == pointValue) {
						return true;
					}
				} else {//the right amount in any point category.
					if (event.getUser().getPoints(customer, null).getCurrentBalance() == pointValue) {
						return true;
					}
					List<PointCategory> pointCategories = PointsManager.getAllPointCategories(event.getCustomer());
					for(PointCategory pointCategory : pointCategories) {
						long userPoints = event.getUser().getPoints(customer, pointCategory).getCurrentBalance();
						if (userPoints == pointValue) {
							return true;
						} 
					}
				}
			}
		}catch (JSONException e) {
			//okay
		}
		try {//add user to segment if user has 1 or more points in a specific pointcategory.
			if (!pointObject.has("pointAmount")) {//already taken care of up there.
				PointCategory pointCategory = PointsManager.getPointCategory(customer, pointObject.getString("pointCategory"));
				long userPoints = user.getPoints(customer, pointCategory).getCurrentBalance();
				if (userPoints > 0) {
					return true;
				} 
			}
		} catch (JSONException e) {
			//okay
		}
		return false;
	}
	
}
