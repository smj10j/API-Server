package com.viralogy.rewardme.manager;

import java.io.IOException;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletException;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.ServerDAO;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.Server;
import com.viralogy.rewardme.servlet.GatewayServlet;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.RemoteRequestUtil;
import com.viralogy.rewardme.util.SecurityUtil;

public abstract class ServerManager {

	private static Logger logger = Logger.getLogger(ServerManager.class);

	public static Server getServer(Long serverId) throws InvalidParameterException, FatalException {	
		return ServerDAO.getServer(serverId);
	}		

	public static List<Server> getServers(Server.Type type, int returnCount) throws InvalidParameterException, FatalException {	
		return ServerDAO.getServers(type, returnCount);
	}	
	
	public static void save(Server server) throws InvalidParameterException, FatalException {
		server.save();
	}
	
	public static String executeAPIRequest(String requestParameters, boolean async) throws FatalException, InvalidParameterException {
		
		logger.debug("Preparing executeAPIRequest api call: " + requestParameters);
		String apiKey = null;
		String newRequestParameters = "";
		List<String> keyValuePairs = ListUtil.explode(requestParameters, "&");
		for(String keyValuePair : keyValuePairs) {
			String[] kv = keyValuePair.split("=");
			if(kv.length == 2) {
				//currently ignoring bad parameter strings
				String key = kv[0];
				String value = kv[1];
				
				if(key.equals("apiKey")) {
					apiKey = value;
				}
				if(newRequestParameters.length() > 0) {
					newRequestParameters+= "&";
				}
				newRequestParameters+= key+"="+value;
			}
		}
		
		//add the signature and timestmap
		//TODO: change this to not use steve's secret key
		String secretKey = "paf09820n79adgnn23nag923m0agdsf]p]23aw3y-steve";
		long timestamp = (Calendar.getInstance().getTimeInMillis()/1000);
		newRequestParameters+= "&timestamp="+timestamp;
		String dataForSignature = apiKey+"|"+timestamp+"|"+newRequestParameters;
		logger.debug("dataForSignature: " + dataForSignature);
		String signature = SecurityUtil.calculateSignature(dataForSignature, secretKey);
		newRequestParameters+= "&signature="+signature;
		
		logger.debug("About to run executeAPIRequest api call with query: " + newRequestParameters);
		
		return RemoteRequestUtil.get(GatewayServlet.getLocalServerBaseUrl() + "api", newRequestParameters, async);
	}
	
	public static void executeAPIRequest(String requestParameters, RewardMeRequest request, RewardMeResponse response) throws FatalException, InvalidParameterException {
		//clone the original request, and use the same http response
		RewardMeRequest childRequest = new RewardMeRequest(request.getHttpServletRequest());
		childRequest.setNewRequest(false);
		
		//remove certain parameters
		String[] sharedRequestKeysToRemove = {
			Constants.Request.REQUEST,
			Constants.Request.API_KEY,
			Constants.Request.SIGNATURE,
			Constants.Request.TIMESTAMP,
			Constants.Request.RESPONSE_FORMAT
		};
		for(String sharedRequestKeyToRemove : sharedRequestKeysToRemove) {
			childRequest.overrideParameter(sharedRequestKeyToRemove, null);	
		}
				
		try {
			logger.debug("Preparing executeAPIRequest api call: " + requestParameters);
			String apiKey = null;
			List<String> keyValuePairs = ListUtil.explode(requestParameters, "&");
			for(String keyValuePair : keyValuePairs) {
				String[] kv = keyValuePair.split("=");
				if(kv.length == 2) {
					//currently ignoring bad parameter strings
					String key = kv[0];
					String value = kv[1];
					
					childRequest.overrideParameter(key, value);
					
					if(key.equals("apiKey")) {
						apiKey = value;
					}
				}
			}
			
			//now remove any junk params still on the requestToReplay string
			for(String sharedRequestKeyToRemove : sharedRequestKeysToRemove) {
				childRequest.overrideParameter(sharedRequestKeyToRemove, null);	
			}			
			
			//add the signature and timestmap
			//TODO: change this to not use steve's secret key
			String secretKey = "paf09820n79adgnn23nag923m0agdsf]p]23aw3y-steve";
			long timestamp = (Calendar.getInstance().getTimeInMillis()/1000);
			childRequest.overrideParameter("timestamp", timestamp+"");
			String dataForSignature = apiKey+"|"+timestamp+"|"+RemoteRequestUtil.getQueryString(childRequest);
			logger.debug("dataForSignature: " + dataForSignature);
			String signature = SecurityUtil.calculateSignature(dataForSignature, secretKey);
			childRequest.overrideParameter("signature", signature);
			
			logger.debug("About to run executeAPIRequest api call with query: " + RemoteRequestUtil.getQueryString(childRequest));
			
			//false here indicates that the GatewayServlet cannot marshal or close the output stream
			(new GatewayServlet()).processRequest(childRequest, response, false);
			
		}  catch (ServletException e) {
			throw new FatalException(e);
		} catch (IOException e) {
			throw new FatalException(e);
		}
	}
}
