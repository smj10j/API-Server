package com.viralogy.rewardme.manager;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.SessionDAO;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.Session;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.util.Cache;

public abstract class SessionManager {

	private static Logger logger = Logger.getLogger(SessionManager.class);

	public static Session getSession(RewardMeRequest request) throws FatalException, InvalidParameterException{
		User user = request.getUser();
		Customer customer = request.getCustomer();
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, false);
		Address address = addressId == null ? null : AddressManager.getAddress( addressId, false);

		if( user == null || customer == null ) {
			return null;
		}
		Session session = Cache.get(user.getUserId() + "|" + customer.getCustomerId() + "|" + (address != null ? address.getAddressId() : "") , Cache.namespace.SESSION_BY_USER_ID_AND_CUSTOMER_AND_ID_ADDRESS_ID);
		if(session == null ) {
			try {
				session = SessionDAO.getSession( user, customer, address);
				save(session);
			} catch (InvalidParameterException e ) {
				session = new Session(user, customer, address);
				save(session);
			}
			
			// sessions have two hours of life at creation
			Cache.put(session, Cache.lifetime.TWO_HOUR, session.getSessionId() + "", Cache.namespace.SESSION_BY_ID);
			Cache.put(session, Cache.lifetime.TWO_HOUR, user.getUserId() + "|" + customer.getCustomerId() + "|" + (address != null ? address.getAddressId() : ""), Cache.namespace.SESSION_BY_USER_ID_AND_CUSTOMER_AND_ID_ADDRESS_ID);
		}
		return session;
	}
	
	public static Session getSession(long sessionId) throws FatalException, InvalidParameterException {
		Session session = Cache.get(sessionId + "", Cache.namespace.SESSION_BY_ID);
		
		if(session == null) {
			session = SessionDAO.getSession(sessionId);
			
			// if session is minutes before the two hour lifetime, then it will have several minutes of buffer time
			Cache.put(session, sessionId + "", Cache.namespace.SESSION_BY_ID);
		}
		
		return session;
	}
	
	public static void save(Session session) throws FatalException, InvalidParameterException {
		session.save();
	}
}
