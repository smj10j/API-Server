package com.viralogy.rewardme.manager;

import java.util.*;

import org.apache.log4j.Logger;

import com.stripe.*;
import com.stripe.exception.*;
import com.stripe.model.*;
import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerContact;
import com.viralogy.rewardme.servlet.StripeServlet;
import com.viralogy.rewardme.util.EmailUtil;

public class StripeManager {
	

	private static Logger logger = Logger.getLogger(StripeManager.class);
	
	
	//CUSTOMERS
	
	public static void updateCustomer(com.viralogy.rewardme.model.Customer customer, String cardToken, String description, String plan) throws InvalidParameterException, FatalException {
		Stripe.apiKey = Constants.Request.STRIPE_API_KEY;  //change to live secret key in production!
		
		if(customer.getStripeCustomerId().equals("")) { //stripeCustomerId doesn't exist in db.  create it.
			createCustomer(customer, cardToken, description, plan);
		}
		else {	//stripeCustomerId exists in db.
			try {
				com.stripe.model.Customer stripeCustomer = com.stripe.model.Customer.retrieve(customer.getStripeCustomerId());
				//at this point, we know the customer exists, so we update it with the values given.
				Map<String, Object> updateParams = new HashMap<String, Object>();
				if(cardToken != null) {
					updateParams.put("card", cardToken);
				}
				if(description != null) {
					updateParams.put("description", description);
				}
				if(plan != null) {
					Map<String, Object> subscriptionParams = new HashMap<String, Object>(); 
					subscriptionParams.put("plan", plan); 
					stripeCustomer.updateSubscription(subscriptionParams);
				}
				
				try {
					stripeCustomer = stripeCustomer.update(updateParams);
				}
				catch(StripeException e) {
					throw new InvalidParameterException(Constants.Error.INVALID_ID.STRIPE_CUSTOMER_ID);
				}

				customer.setStripeCustomerId(stripeCustomer.getId());
				customer.save();
			}
			catch(StripeException e) {  //customer doesn't exist on stripe side, but exists on server side, which is weird and shouldn't happen, but we create it anyway
				createCustomer(customer, cardToken, description, plan);
			}
		}
	}
	
	public static void createCustomer(com.viralogy.rewardme.model.Customer customer, String cardToken, String description, String plan) throws InvalidParameterException, FatalException {
		Stripe.apiKey = Constants.Request.STRIPE_API_KEY;  //change to live secret key in production!
		
		Map<String, Object> customerParams = new HashMap<String, Object>(); 
		customerParams.put("card", cardToken); // obtained with Stripe.js 
		customerParams.put("description", description); 
		
		try {
			com.stripe.model.Customer stripeCustomer = com.stripe.model.Customer.create(customerParams);
			
			Map<String, Object> subscriptionParams = new HashMap<String, Object>(); 
			subscriptionParams.put("plan", plan); 
			stripeCustomer.updateSubscription(subscriptionParams); 
			
			customer.setStripeCustomerId(stripeCustomer.getId());
			customer.save();
		}
		catch(StripeException e) {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.STRIPE_CUSTOMER_ID);
		}
		
	}
	
	
	
	
	
	
	
	
	
	//INVOICES
	
	public static void addInvoiceItem(com.viralogy.rewardme.model.Customer customer, int amount, String description, String currency) throws InvalidParameterException {
		//PRICE IS IN CENTS
		Stripe.apiKey = Constants.Request.STRIPE_API_KEY;
		
		Map<String, Object> invoiceItemParams = new HashMap<String, Object>();
		
		invoiceItemParams.put("description", description);
		invoiceItemParams.put("amount", amount);
		invoiceItemParams.put("currency", currency);
		invoiceItemParams.put("customer", customer.getStripeCustomerId());
		
		try {
			InvoiceItem.create(invoiceItemParams);
		}
		catch(StripeException e) {
			logger.error(e);
			throw new InvalidParameterException(Constants.Error.INVALID_ID.STRIPE_CUSTOMER_ID);
		}
		
	}

	public static Invoice getNextInvoice(Customer customer) throws InvalidParameterException {
		Stripe.apiKey = Constants.Request.STRIPE_API_KEY;
		
		Map<String, Object> invoiceParams = new HashMap<String, Object>();
		invoiceParams.put("customer", customer.getStripeCustomerId());
		try {
			return Invoice.upcoming(invoiceParams);
		}
		catch(StripeException e) {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.STRIPE_CUSTOMER_ID);
		}
	}
	
	public static List<Invoice> getInvoices(com.viralogy.rewardme.model.Customer customer, int count, int offset) throws InvalidParameterException {
		Stripe.apiKey = Constants.Request.STRIPE_API_KEY;
		
		Map<String, Object> invoiceParams = new HashMap<String, Object>();
		invoiceParams.put("customer", customer.getStripeCustomerId());
		invoiceParams.put("count", count);
		invoiceParams.put("offset", offset);
		
		try {
			return Invoice.all(invoiceParams).getData();
		}
		catch(StripeException e) {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.STRIPE_CUSTOMER_ID);
		}
		
	}
	
	
	
	
	
	
	
	
	
	//CHARGES
	
	public static Charge createCharge(com.viralogy.rewardme.model.Customer customer, double amount, String currency) throws InvalidParameterException {
		Stripe.apiKey = Constants.Request.STRIPE_API_KEY;
		
		Map<String, Object> chargeParams = new HashMap<String, Object>();
		chargeParams.put("amount", amount);
		chargeParams.put("currency", currency);
		chargeParams.put("customer", customer.getStripeCustomerId());
		
		try {
			return Charge.create(chargeParams);
		} catch (StripeException e) {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.STRIPE_CUSTOMER_ID);
		}
	}
	
	public static Charge getCharge(String chargeId) throws InvalidParameterException {
		Stripe.apiKey = Constants.Request.STRIPE_API_KEY;
		
		try {
			return Charge.retrieve(chargeId);
		}
		catch(StripeException e) {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.CHARGE_ID);
		}
	}
	
	public static List<Charge> getCharges(com.viralogy.rewardme.model.Customer customer, int count, int offset) throws InvalidParameterException {
		Stripe.apiKey = Constants.Request.STRIPE_API_KEY;
		
		Map<String, Object> chargeParams = new HashMap<String, Object>();
		chargeParams.put("customer", customer.getStripeCustomerId());
		chargeParams.put("count", count);
		chargeParams.put("offset", offset);
		
		try {
			return Charge.all(chargeParams).getData();
		}
		catch(StripeException e) {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.STRIPE_CUSTOMER_ID);
		}
		
	}
	
	public static Charge refundCharges(String chargeId) throws InvalidParameterException {
		Stripe.apiKey = Constants.Request.STRIPE_API_KEY;
		
		try {
			Charge charge = Charge.retrieve(chargeId);
			return charge.refund();
		}
		catch(StripeException e) {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.CHARGE_ID);
		}
	}

	
	
	
	
	
	public static void webhookNotify(String eventId) throws InvalidParameterException, FatalException {
		Stripe.apiKey = Constants.Request.STRIPE_API_KEY;
		try {
			Event event = Event.retrieve(eventId);
			if(event == null) {
				logger.debug("Event is null");
				throw new InvalidParameterException(Constants.Error.INVALID_ID.EVENT_ID);
			}
			
			logger.debug(event);
			
			String[] temp = event.getType().split("\\.");
			String dataType = "";
			
			if(temp.length > 1) {
				dataType = temp[0];
			}
			else {
				dataType = event.getType();
			}
			
			Customer customer;
			if(dataType.equals("invoice")) {
				customer = CustomerManager.getCustomerByStripeCustomerId(((Invoice)event.getData().getObject()).getCustomer());
			}
			else if(dataType.equals("invoiceitem")) {
				customer = CustomerManager.getCustomerByStripeCustomerId(((InvoiceItem)event.getData().getObject()).getCustomer());
			}
			else if(dataType.equals("customer")) {
				customer = CustomerManager.getCustomerByStripeCustomerId(((com.stripe.model.Customer)event.getData().getObject()).getId());
			}
			/*else if(dataType.equals("token")) {
				customer = CustomerManager.getCustomerByStripeCustomerId(((Token)event.getData().getObject()).getId());
			}*/
			else if(dataType.equals("charge")) {
				customer = CustomerManager.getCustomerByStripeCustomerId(((Charge)event.getData().getObject()).getCustomer());
			}
			/*else if(dataType.equals("coupon")) {
				customer = CustomerManager.getCustomerByStripeCustomerId(((Coupon)event.getData().getObject()).getId());
			}*/
			else if(dataType.equals("subscription")) {
				customer = CustomerManager.getCustomerByStripeCustomerId(((Subscription)event.getData().getObject()).getCustomer());
			}
			/*else if(dataType.equals("plan")) {
				customer = CustomerManager.getCustomerByStripeCustomerId(((Plan)event.getData().getObject()).getId());
			}*/
			else {
				throw new FatalException("strange data type from webhook");
			}
			
			List<CustomerContact> contacts = CustomerManager.getContacts(customer);
			List<String> emails = new ArrayList<String>();
			
			for(int i = 0; i < contacts.size(); i++) {
				emails.add(contacts.get(i).getEmail());
			}
			
			EmailUtil.email(customer, "no-reply", emails, "REWARDME NOTIFICATION EMAIL", ("<p>Notification: " + event.getType() + "</p>").getBytes(), "html", 0);
		}
		catch(StripeException e) {
			logger.error(e);
			throw new InvalidParameterException(Constants.Error.INVALID_ID.EVENT_ID);
		}
	}

}
