package com.viralogy.rewardme.manager;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.conf.Constants.NotificationType;
import com.viralogy.rewardme.dao.SurveyDAO;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Survey;
import com.viralogy.rewardme.model.SurveyResult;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserMessage;
import com.viralogy.rewardme.model.UserSurvey;

public abstract class SurveyManager {

	private static Logger logger = Logger.getLogger(SurveyManager.class);
	
	public static void save(Survey survey) throws FatalException, InvalidParameterException {
		survey.save();
	}

	public static void save(UserSurvey userSurvey) throws FatalException, InvalidParameterException {
		userSurvey.save();
	}
	
	public static Survey getSurvey(long surveyId) throws FatalException, InvalidParameterException {
		return SurveyDAO.getSurvey(surveyId);
	}
	
	public static UserSurvey getUserSurvey(long userSurveyId) throws FatalException, InvalidParameterException {
		return SurveyDAO.getUserSurvey(userSurveyId);
	}

	public static UserSurvey getLatestUserSurvey(User user) throws FatalException, InvalidParameterException {
		return SurveyDAO.getLatestUserSurvey(user);
	}
	
	public static UserSurvey getUserSurvey(User user, Survey survey) throws FatalException, InvalidParameterException {
		return SurveyDAO.getUserSurvey(user, survey);
	}

	public static Set<UserSurvey> getUserSurveys(Survey survey) throws FatalException, InvalidParameterException {
		return SurveyDAO.getUserSurveys(survey);
	}
	
	public static List<SurveyResult> getSurveyResults(Survey survey) throws FatalException, InvalidParameterException {
		return SurveyDAO.getSurveyResults(survey);
	}
	
	public static List<Survey> getSurveys(Customer customer, int returnCount, boolean enabledOnly) throws FatalException, InvalidParameterException {
		return SurveyDAO.getSurveys(customer, returnCount, enabledOnly);
	}
	
	public static void send(UserSurvey userSurvey) throws FatalException, InvalidParameterException {
	
		//send the survey
		if(userSurvey.getSurvey().isAvailableOnMobile()) {
			
			//create a text message and send the survey
			UserMessage userMessage = new UserMessage(userSurvey.getSurvey().getCustomer(), userSurvey.getUser(), new Date(), userSurvey.getSurvey().getContent());
			MessageManager.send(userMessage, NotificationType.TEXT_APP, false);
			
			//mark the survey as sent
			userSurvey.setSent(true);
			save(userSurvey);
			
		}else {
			//TODO: SURVEY: implement - currently impossible to reach here with survey.create blocking creation
		}
	}
	
	public static void respond(UserSurvey userSurvey, String response) throws FatalException, InvalidParameterException {
		
		userSurvey.setResponse(response);
		SurveyManager.save(userSurvey);
		
		if(userSurvey.getSurvey().isAbleToShowResults()) {
			if(userSurvey.getSurvey().isAvailableOnMobile()) {
				//text back results
				List<SurveyResult> surveyResults = getSurveyResults(userSurvey.getSurvey());
				String surveyResultsStr =  "Survey Results\n" + SurveyResult.toString(surveyResults);
				UserMessage userMessage = new UserMessage(userSurvey.getSurvey().getCustomer(), userSurvey.getUser(), new Date(), surveyResultsStr);
				MessageManager.send(userMessage, NotificationType.TEXT_APP, false);
				
			}else {
				//TODO: SURVEY: implement case when survey is not on mobile
			}
		}
	}
	
}
