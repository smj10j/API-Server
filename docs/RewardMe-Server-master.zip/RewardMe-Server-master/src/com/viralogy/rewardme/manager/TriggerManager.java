package com.viralogy.rewardme.manager;


import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.EventDAO;
import com.viralogy.rewardme.model.Event;
import com.viralogy.rewardme.model.EventTrigger;
import com.viralogy.rewardme.model.ScheduledTrigger;
import com.viralogy.rewardme.model.Trigger;
import com.viralogy.rewardme.model.UserMessage;
import com.viralogy.rewardme.scheduler.ScheduledTask;
import com.viralogy.rewardme.scheduler.ScheduledTask.Type;
import com.viralogy.rewardme.servlet.GatewayServlet;
import com.viralogy.rewardme.util.RemoteRequestUtil;

public abstract class TriggerManager {

	private static Logger logger = Logger.getLogger(TriggerManager.class);

	public static void execute(Trigger trigger) throws InvalidParameterException, FatalException {
		
		
		if(trigger.getClass().equals(EventTrigger.class)) {
			logger.debug("Processing eventTriggerId="+((EventTrigger)trigger).getEventTriggerId());
		}else if(trigger.getClass().equals(ScheduledTrigger.class)){
			logger.debug("Processing scheduledTriggerId="+((ScheduledTrigger)trigger).getScheduledTriggerId());
		}
		
		switch(trigger.getType()) {
		
		case DELETE_EVENT_TRIGGER: 
			
			//flag the event trigger as handled
			trigger.setTriggered(true);
			TriggerManager.save(trigger);
			
			try {
				EventTrigger eventTrigger = TriggerManager.getEventTrigger(trigger.getTypeId());
				eventTrigger.setArchived(true);
				eventTrigger.save();
			}catch(InvalidParameterException e) {
				//ignore - trigger doesn't exist
				logger.error(e);
			}
			
			break;
		case DELETE_SCHEDULED_TRIGGER: 
			
			//flag the event trigger as handled
			trigger.setTriggered(true);
			TriggerManager.save(trigger);
			
			try {
				ScheduledTrigger scheduledTrigger = TriggerManager.getScheduledTrigger(trigger.getTypeId());
				scheduledTrigger.setArchived(true);
				scheduledTrigger.save();
			}catch(InvalidParameterException e) {
				//ignore - trigger doesn't exist
				logger.error(e);
			}
			
			break;
							
		case DELETE_USER_MESSAGE: 
			
			//flag the event trigger as handled
			trigger.setTriggered(true);
			TriggerManager.save(trigger);
			
			try {
				UserMessage userMessage = MessageManager.getUserMessage(trigger.getTypeId());
				if(!userMessage.isSent()) {
					userMessage.remove();
				}
			}catch(InvalidParameterException e) {
				//ignore - userMessage doesn't exist
				logger.error(e);
			}
			
			break;				
		case URL_CALLBACK: 
			
			//flag the event trigger as handled
			trigger.setTriggered(true);
			TriggerManager.save(trigger);
			
			String[] requests = trigger.getData().split(",");
			for(String request : requests) {
				String[] dataParts = request.split("\\?");
				String endpoint = dataParts[0];
				String parameters = dataParts[1];
				
				//apend useful parameters
				if(!parameters.endsWith("&")) {
					parameters+= "&";	
				}
				parameters+= "phoneNumber="+trigger.getUser().getPhoneNumber()+"&";
				parameters+= "apiKey="+trigger.getCustomer().getApiKey()+"&";
				
				if(trigger.getClass().equals(EventTrigger.class)) {
					parameters+= "eventName="+((EventTrigger)trigger).getEventName()+"&";
					parameters+= "eventValue="+((EventTrigger)trigger).getEventValue();
				}else if(trigger.getClass().equals(ScheduledTrigger.class)){
					parameters+= "eventTimestamp="+((ScheduledTrigger)trigger).getTimestamp().getTime();
				}
				
				String response = RemoteRequestUtil.get(endpoint, parameters, false);
				logger.info("Response from URL_CALLBACK request " + endpoint + "?" + parameters +": " + response);
			}
								
			break;
		case API_REQUEST: 
			
			//flag the event trigger as handled
			trigger.setTriggered(true);
			TriggerManager.save(trigger);
			
			String[] apiRequests = trigger.getData().split(",");
			for(String apiRequest : apiRequests) {
				
				//apend useful parameters
				if(!apiRequest.endsWith("&")) {
					apiRequest+= "&";	
				}				
				apiRequest+= "phoneNumber="+trigger.getUser().getPhoneNumber()+"&";
				apiRequest+= "apiKey="+trigger.getCustomer().getApiKey()+"&";
				
				String response = ServerManager.executeAPIRequest(apiRequest, false);
				logger.info("Response from API_REQUEST request " + apiRequest +": " + response);
			}
								
			break;
		default:
			throw new InvalidParameterException(Constants.Error.GENERAL.INVALID_EVENT_TRIGGER_TYPE);
		}
	}
	
	public static void save(Trigger trigger) throws FatalException, InvalidParameterException {
		if(trigger.getClass().equals(EventTrigger.class)) {
			TriggerManager.save((EventTrigger)trigger);
		}else if(trigger.getClass().equals(ScheduledTrigger.class)){
			TriggerManager.save((ScheduledTrigger)trigger);			
		}else {
			throw new FatalException("Tried to save an object (" + trigger.getClass().getDeclaringClass() + ") that was not an Event or Scheduled trigger");
		}
	}
	
	public static void save(EventTrigger eventTrigger) throws InvalidParameterException, FatalException {
		eventTrigger.save();
	}

	public static void save(ScheduledTrigger scheduledTrigger) throws InvalidParameterException, FatalException {
		scheduledTrigger.save();
		
		if(!scheduledTrigger.isTriggered()) {
			//if the triggered flag has not been set, we should schedule the trigger!
			
			String baseUrl = GatewayServlet.getLocalServerBaseUrl() + "schedule";
			String queryString = "scheduledTriggerId="+scheduledTrigger.getScheduledTriggerId();
			
			//schedule it
			String url = baseUrl + "?" + queryString;
			(new ScheduledTask(Type.URL, url, scheduledTrigger.getTimestamp())).save();
		}
	}
	
	public static Set<EventTrigger> getEventTriggers(Event event) throws InvalidParameterException, FatalException {
		return EventDAO.getEventTriggers(event);
	}
	
	public static EventTrigger getEventTrigger(long eventTriggerId) throws FatalException, InvalidParameterException {
		return EventDAO.getEventTrigger(eventTriggerId);
	}
	
	public static ScheduledTrigger getScheduledTrigger(long scheduledTriggerId) throws FatalException, InvalidParameterException {
		return EventDAO.getScheduledTrigger(scheduledTriggerId);
	}	
}
