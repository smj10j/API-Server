package com.viralogy.rewardme.manager;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.Constants.NotificationType;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.customer.CustomerConstants;
import com.viralogy.rewardme.customer.Mooyah;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.dao.ReferralDAO;
import com.viralogy.rewardme.dao.UserDAO;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.CheckinOption;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerPreference;
import com.viralogy.rewardme.model.Device;
import com.viralogy.rewardme.model.DeviceApplication;
import com.viralogy.rewardme.model.Schedule;
import com.viralogy.rewardme.model.ScheduleTime;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserCheckin;
import com.viralogy.rewardme.model.UserMessage;
import com.viralogy.rewardme.model.UserPoints;
import com.viralogy.rewardme.model.UserPreference;
import com.viralogy.rewardme.model.UserReferral;
import com.viralogy.rewardme.model.UserReward;
import com.viralogy.rewardme.model.UserSocialCheckin;
import com.viralogy.rewardme.util.Cache;
import com.viralogy.rewardme.util.DateUtil;
import com.viralogy.rewardme.util.EmailUtil;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.SecurityUtil;
import com.viralogy.rewardme.util.StringUtil;
import com.viralogy.rewardme.util.TwilioUtil;

public abstract class UserManager {

	private static Logger logger = Logger.getLogger(UserManager.class);

	public static User getUser(Long userId) throws InvalidParameterException, FatalException {	
		User user = Cache.get(userId+"", Cache.namespace.USER_BY_ID);
		if(user == null) {
			user = UserDAO.getUser(userId);
			Cache.put(user, userId+"", Cache.namespace.USER_BY_ID);
		}
				
		//logger.debug("Got userId: " + user.getUserId() + OutputUtil.getElapsedString());
		return user;
	}		
		
	public static User getUserByPhoneNumber(String phoneNumber) throws InvalidParameterException, FatalException {
		phoneNumber = TwilioUtil.cleanNumber(phoneNumber);
		User user = Cache.get(phoneNumber, Cache.namespace.USER_BY_PHONE_NUMBER);
		if(user == null) { 
			user = UserDAO.getUserByPhoneNumber(phoneNumber);
			Cache.put(user, phoneNumber, Cache.namespace.USER_BY_PHONE_NUMBER);
		}

		return user;
	}	
	
	public static void save(User user) throws InvalidParameterException, FatalException {
		UserManager.saveDevices(user);
		try {
			user.save();
		}catch(FatalException e) {
    		if(e.getMessage().contains("for key 'phone_number'")) {
				throw new InvalidParameterException(Constants.Error.GENERAL.PHONE_NUMBER_ALREADY_IN_USE, ListUtil.from(user.getPhoneNumber()));
			}else {
				throw e;
			}
		}
		Cache.remove(user.getPhoneNumber(), Cache.namespace.USER_BY_PHONE_NUMBER);
		Cache.remove(user.getUserId()+"", Cache.namespace.USER_BY_ID);
	}
	
	//assuming this is depreciated, if not caching for countUserCheckins() will break
	public static void reset(User user) throws FatalException, InvalidParameterException {
		logger.warn("RESETTING USER: userId="+user.getUserId());
		
		for(Device device : user.getDevices()) {
			device.remove();
		}
		
		UserDAO.reset(user);
		
		Cache.remove(user.getUserId()+"|"+null, Cache.namespace.USER_ADDRESSES);
		Cache.remove(user.getUserId()+"", Cache.namespace.USER_BY_ID);
		Cache.remove(user.getPhoneNumber(), Cache.namespace.USER_BY_PHONE_NUMBER);
		for(Device device : user.getDevices()) {
			Cache.remove(device.getDeviceId(), Cache.namespace.USER_BY_DEVICE);
		}
		//Cache.flush();
	}
	
	//assuming this is depreciated. if not caching for countUserCheckins() will break
	public static void remove(User user) throws InvalidParameterException, FatalException {
		
		reset(user);
		
		logger.warn("REMOVING USER: userId="+user.getUserId());
		
		user.remove();
	}
	
	public static void resetPIN(User user, Customer customer) throws FatalException, InvalidParameterException {
		String pinCode = StringUtil.getRandomNumber(4);
		String md5PinCode = SecurityUtil.md5(pinCode);

		//update the pincode
		user.setPinCode(md5PinCode);
		UserManager.save(user);
		
		//set a preference to indicate the user changed the PIN (used by My.RewardMe to prompt the user to update it)
		UserPreference updatedPinCodePreference = user.getUserPreference(Constants.UserPreference.CHANGED_PIN, null);
		if(updatedPinCodePreference == null) {
			updatedPinCodePreference = new UserPreference(user, null, Constants.UserPreference.CHANGED_PIN, "true");
		}else {
			updatedPinCodePreference.setValue("true");
		}
		PreferencesManager.save(updatedPinCodePreference);
		
		//text message the user the new pincode
		String updatePincodeMessage = "" + 
			"RewardMe PIN Changed to "+pinCode+"\n" +
			"Manage your PIN on "+Constants.URL.MY_REWARDME;
		UserMessage userMessage = new UserMessage(customer, user, new Date(), updatePincodeMessage);
		MessageManager.send(userMessage, NotificationType.TEXT_SYSTEM, true);
		
		//if the user set an email, send them an email about it
		try {
			UserPreference emailPreference = user.getUserPreference(Constants.UserPreference.EMAIL, null);
			if(emailPreference != null && !StringUtil.isNullOrEmpty(emailPreference.getValue())) {
				
				String subject = "RewardMe PIN Changed";
				
				String body = "Your RewardMe PIN was changed due to a user request.\n" +
							"Your new PIN is " + pinCode + "\n" +
							"\n" +
							"Visit "+Constants.URL.MY_REWARDME+" now to change your PIN.\n" + 
							"\n" + 
							"Thanks for using RewardMe!";
				
				EmailUtil.email(null, "no-reply", ListUtil.from(emailPreference.getValue()), subject, body.getBytes(), "txt", null);
			}
			
		}catch(InvalidParameterException e) {
			//ignore - we don't want to send the user a text then undo the pincode change because of an email error
			MySQL.commit();
			throw e;
		}catch(FatalException e) {
			//ignore - we don't want to send the user a text then undo the pincode change because of an email error
			MySQL.commit();
			throw e;
		}
	}
		
	public static UserCheckin getLastCheckin(User user, Customer customer, boolean onlyThoseThatAreNotCooledDown) throws FatalException, InvalidParameterException {
		return UserDAO.getLastCheckin(user, customer, onlyThoseThatAreNotCooledDown);
	}	
	
	public static UserReward getLastRedeem(User user, Customer customer, boolean onlyThoseThatAreNotCooledDown) throws FatalException, InvalidParameterException {
		return UserDAO.getLastRedeem(user, customer, onlyThoseThatAreNotCooledDown);
	}	
	
	public static UserCheckin checkin(Customer customer, User user, Address address, CheckinOption checkinOption, DeviceApplication deviceApplication, int pointAward) throws FatalException, InvalidParameterException {
			
		if(!customer.isEnabled() && !user.isAuthorized()) {
			throw new InvalidParameterException(Constants.Error.GENERAL.DISABLED_CUSTOMER);
		}

		// prevent checkins outside the available schedules
		boolean available = false;
		double multiplier = 1;
		List<CheckinOption> availableCheckingOptions = CheckinOptionManager.getAllCheckinOptions(customer, false);
		for(CheckinOption availableCheckinOption : availableCheckingOptions) {
			if(availableCheckinOption.getCheckinOptionId() == checkinOption.getCheckinOptionId()) {
				available = true;
				for(Schedule schedule : availableCheckinOption.getSchedules()) {
					//TODO: Schedule: not honoring day of week
					ScheduleTime nowScheduleTime = new ScheduleTime(DateUtil.getCurrentHour(), DateUtil.getCurrentMinute());
					if(schedule.getStartTime().before(nowScheduleTime) && schedule.getEndTime().after(nowScheduleTime)) {
						multiplier = schedule.getMultiplier();
					}
				}
				break;
			}
		}
		
		if(!available) {
			throw new InvalidParameterException(Constants.Error.CHECKIN.NOT_AVAILABLE_AT_THIS_TIME);
		}
		
		//check rate limiting
		//get the last time we checked in here (if ever)
		
		UserCheckin userCheckin = UserManager.getLastCheckin(user, customer, true);
		
		if(userCheckin != null) {
			long readyAt = userCheckin.getCreated().getTime() + (userCheckin.getCheckinOption().getCooldownLength()*1000);
			String readyAtString = "";
			if(userCheckin.getTimeRemainingInCooldown() < Constants.Time.HOUR*12) {
				SimpleDateFormat format = new SimpleDateFormat("h:mm a z");
				readyAtString = format.format(new Date(readyAt));
			}else {
				SimpleDateFormat format = new SimpleDateFormat("EEE, MMM d");
				readyAtString = format.format(new Date(readyAt));
			}
			logger.warn("Attempted a checkin before the refactory period was over. userId="+user.getUserId()+", addressId="+address.getAddressId()+", now="+System.currentTimeMillis()+", readyAt="+readyAt);
			throw new InvalidParameterException(Constants.Error.CHECKIN.TOO_FREQUENT,ListUtil.from(readyAtString));
		}
		
		//log the checkin
		userCheckin = UserDAO.checkin(user, address, customer, checkinOption, deviceApplication, null);
				
		//add the points
		PointsManager.credit(user, customer, address, UserPoints.Type.CHECKIN, checkinOption.getPointCategory(), (long)(pointAward * multiplier));
		
		if(checkinOption.getReferralPointAward() != 0 || checkinOption.getRecurringReferralPointAward() != 0) {
			//there is a referral value... was this user referred?
			//logger.debug("Checkin has a referral value - checking if anyone referred this user here");
			UserReferral userReferral = ReferralManager.getUserReferral(user, customer);
			if(userReferral != null) {
				//this user was referred here!
				logger.debug("Referral - referrerId: " + userReferral.getReferrer().getUserId() + ", referredId: " + userReferral.getReferred().getUserId()+", customerId: "+userReferral.getCustomer().getCustomerId()+", referralPointAward: "+checkinOption.getReferralPointAward()+", recurringReferralPointAward: "+checkinOption.getRecurringReferralPointAward());
				if(userReferral.getFirstUsed() == null && checkinOption.getReferralPointAward() > 0) {
					//first time!
					
					List<UserCheckin> userCheckinsAtLocation = UserManager.getCheckins(userReferral.getReferrer(), customer, false, 1);
					if(userCheckinsAtLocation.size() == 0) {
						//post date a checkin if the referrer has not yet visited the location
						UserDAO.checkin(userReferral.getReferrer(), address, customer, checkinOption, deviceApplication, checkinOption.getCooldownLength());
					}
					
					
					PointsManager.credit(userReferral.getReferrer(), customer, address, UserPoints.Type.REFERRAL, checkinOption.getPointCategory(), checkinOption.getReferralPointAward());
					ReferralDAO.setFirstTimeReferralUse(userReferral);
					Cache.remove(userReferral.getReferred().getUserId()+"", userReferral.getCustomer().getCustomerId()+"", Cache.namespace.USER_REFERRAL_BY_USER_CUSTOMER);
					
					//send a notification to the referring user
					UserPreference namePreference = userReferral.getReferred().getUserPreference(UserPreference.KEYS.NAME, null);
					String name = namePreference == null ? "Your friend" : namePreference.getValue();
					MessageManager.save(
						new UserMessage(
							userReferral.getCustomer(), 
							userReferral.getReferrer(), 
							new Date(),
							name + "'s first visit to " + userReferral.getCustomer().getName() + " just earned you " + checkinOption.getReferralPointAward() + " points!"
						)
					);
					
				}else if(checkinOption.getRecurringReferralPointAward() > 0){
					//repeat visit
					PointsManager.credit(userReferral.getReferrer(), customer, address, UserPoints.Type.REFERRAL, checkinOption.getPointCategory(), checkinOption.getRecurringReferralPointAward());
					
					//send a notification to the referring user
					UserPreference namePreference = userReferral.getReferred().getUserPreference(UserPreference.KEYS.NAME, null);
					String name = namePreference == null ? "Your friend" : namePreference.getValue();
					/*UserMessage userMessage = new UserMessage(
						userReferral.getCustomer(), 
						userReferral.getReferrer(), 
						new Date(),
						name + "'s repeat visit to " + userReferral.getCustomer().getName() + " just earned you " + checkinOption.getRecurringReferralPointAward() + " points!"
					);
					MessageManager.schedule(userMessage, NotificationType.TEXT_APP);
					*/

				}
			}
		}

		//send a notification to the user about the checkin
		if(pointAward != 0) {
			String timeString = DateUtil.getTimeString(checkinOption.getCooldownLength());
			String pointsString = pointAward + " points";
			if(multiplier > 1) {
				pointsString+= " and " + ((long)(pointAward * (multiplier-1))) + " bonus points";
			}
			/*UserMessage userMessage = new UserMessage(
				customer, 
				user, 
				new Date(), 
				"You just earned " + pointsString + " at " + customer.getName() + "!\nYour new points will be available in " + timeString+"."
			);
			MessageManager.schedule(userMessage, NotificationType.TEXT_APP);
			*/
		}
		
		//clear the caches
		Cache.remove(user.getUserId()+"|"+null, Cache.namespace.USER_ADDRESSES);
		Cache.remove(user.getUserId()+"|"+customer.getCustomerId(), Cache.namespace.USER_ADDRESSES);
		Cache.remove(user.getUserId()+"", address.getAddressId() + "", Cache.namespace.USER_CHECKIN);
		Cache.remove(user.getUserId()+"", Cache.namespace.USER_BY_ID);
		Cache.remove("" + user.getUserId() + 
				("|"+address.getAddressId()) +
				("|"+ customer.getCustomerId()),
				 Cache.namespace.COUNT_USER_CHECKINS);
		Cache.remove("" + user.getUserId() + 
				("|"+ customer.getCustomerId()),
				Cache.namespace.COUNT_USER_CHECKINS);//remove global checkins
		for(Device device : user.getDevices()) {
			Cache.remove(device.getDeviceId(), Cache.namespace.USER_BY_DEVICE);
		}
		Cache.remove(user.getUserId()+"", customer.getApiKey(), Cache.namespace.USER_REWARDS);
	
		return userCheckin;
	}
	
	public static List<Device> getDevices(User user) throws FatalException, InvalidParameterException {
		List<Device> devices = Cache.get(user.getUserId()+"", Cache.namespace.USER_DEVICES);
		if(devices == null) {
			devices = UserDAO.getDevices(user);
			Cache.put(devices, Cache.lifetime.FIVE_MINUTE, user.getUserId()+"", Cache.namespace.USER_DEVICES);
		}		
		return devices;
	}
	
	public static void addDeviceToUser(User user, Device device) throws FatalException, InvalidParameterException {
		user.getDevices().add(device);
		UserManager.save(user);
		user.clearTransients();
	}
	
	public static void saveDevices(User user) throws InvalidParameterException, FatalException {
		for(Device device : user.getDevices()) {
			DeviceManager.save(device);
			UserDAO.saveDeviceToUser(user, device);
		}
		Cache.remove(user.getPhoneNumber(), Cache.namespace.USER_BY_PHONE_NUMBER);
		Cache.remove(user.getUserId()+"", Cache.namespace.USER_BY_ID);
		Cache.remove(user.getUserId()+"", Cache.namespace.USER_DEVICES);
	}
			
	public static Set<User> getUsersWithCheckin(Customer customer, Address address) throws FatalException, InvalidParameterException {
		String key = (customer==null ? null : customer.getCustomerId()) + "|" + (address==null ? null : address.getAddressId());
		Set<User> users = Cache.get(key, Cache.namespace.USERS_WITH_CHECKIN_AT_CUSTOMER_ADDRESS);
		if(users == null) {
			users = UserDAO.getUsersWithCheckin(customer, address);
			Cache.put(users, key, Cache.namespace.USERS_WITH_CHECKIN_AT_CUSTOMER_ADDRESS);
		}		
		return users;
	}
	
	public static List<UserCheckin> getCheckins(User user, Customer customer, boolean uniqueCustomersOnly, int returnCount) throws FatalException, InvalidParameterException {
		return UserDAO.getCheckins(user, customer, uniqueCustomersOnly, returnCount);
	}

	public static List<UserCheckin.ShortFormat> getShortCheckins(User user, Customer customer, boolean uniqueCustomersOnly, int returnCount) throws FatalException, InvalidParameterException {
		return UserDAO.getShortCheckins(user, customer, uniqueCustomersOnly, returnCount);
	}
	
	//customer cannot be null here
	public static Long countUserCheckins(User user, Customer customer, Address address) throws FatalException, InvalidParameterException {
		if (customer == null) {
			throw new FatalException("Attempted to count user checkins with null customer");
		}
		Long count;
		count = Cache.get("" + user.getUserId() +
						 (address == null ? "" : "|"+address.getAddressId()) +
						 ("|"+ customer.getCustomerId()),
						 Cache.namespace.COUNT_USER_CHECKINS);
		if (count == null) {
			count = UserDAO.countUserCheckins(user, customer, address);
			Cache.put(count, "" + user.getUserId() + 
					(address == null ? "" : "|"+address.getAddressId()) +
					 ("|"+ customer.getCustomerId()),
					 Cache.namespace.COUNT_USER_CHECKINS);
		}
		return count;
	}
	
	public static void save(UserSocialCheckin userSocialCheckin) throws FatalException, InvalidParameterException{
		userSocialCheckin.save();
	}
	
	public static void startTextMessageOptIn(User user, Customer customer) throws InvalidParameterException, FatalException {		
		UserPreference userPreference = user.getUserPreference(Constants.UserPreference.NOTIFICATION_TEXT_OPT_IN_INITIATED, customer);
		if(userPreference == null) {
			userPreference = new UserPreference(user, customer, Constants.UserPreference.NOTIFICATION_TEXT_OPT_IN_INITIATED, Constants.YES);
		}
		userPreference.setValue(Constants.YES);
		PreferencesManager.save(userPreference);
		
		userPreference = user.getUserPreference(Constants.UserPreference.NOTIFICATION_TEXT_ALL, customer);
		if(userPreference == null || userPreference.getValue().equals(Constants.NO)) {
			//text_all is OFF
			String welcomeText = customer.getName() + " Rewards\n" +  
				"Reply YES to confirm signup\n" + 
				(customer.is(CustomerConstants.LE_BOULANGER) ? "" : "Manage your account at "+customer.getWebsiteUrl());
			UserMessage userMessage = new UserMessage(customer, user, new Date(), welcomeText);
			MessageManager.send(userMessage, NotificationType.TEXT_SYSTEM, true);			
		}else {
			//text_all is already ON
			String welcomeText = customer.getName() + " Rewards\n" +  
					"You're already part of the text club!\n" + 
					(customer.is(CustomerConstants.LE_BOULANGER) ? "" : "Manage your account at "+customer.getWebsiteUrl());
				UserMessage userMessage = new UserMessage(customer, user, new Date(), welcomeText);
				MessageManager.send(userMessage, NotificationType.TEXT_SYSTEM, true);				
		}
	}	
	
	public static boolean welcomeNewUser(Customer customer, Address address, User user, boolean isNewUser, boolean delayed) throws FatalException, InvalidParameterException {
		boolean sendWelcomeText = isNewUser;
		
		if(customer.is(CustomerConstants.REWARDME)) {
			return false;
		}
		
		if(!sendWelcomeText) {
			UserPreference userPreference = user.getUserPreference(Constants.UserPreference.NOTIFICATION_TEXT_OPT_IN_INITIATED, customer);
			if(userPreference == null) {
				sendWelcomeText = true;
			}
		}
		
		if(sendWelcomeText) {

			//start the opt-in process
			UserPreference userPreference = user.getUserPreference(Constants.UserPreference.NOTIFICATION_TEXT_OPT_IN_INITIATED, customer);
			if(userPreference == null) {
				userPreference = new UserPreference(user, customer, Constants.UserPreference.NOTIFICATION_TEXT_OPT_IN_INITIATED, Constants.YES);
			}
			userPreference.setValue(Constants.YES);
			PreferencesManager.save(userPreference);
			
			
			
			if(customer.is(CustomerConstants.MOOYAH)) {
				//Customer-specific
				Mooyah.subscribe(user, customer, address);
			}else {
				//everyone else
							
				//get the customer welcome message
				CustomerPreference signupMessagePreference = customer.getCustomerPreference(Constants.CustomerPreference.Keys.NEW_USER_SIGNUP_MESSAGE, null);
				String welcomeMessage = signupMessagePreference != null ? signupMessagePreference.getValue() : Constants.CustomerPreference.Default.NEW_USER_SIGNUP_MESSAGE;
				welcomeMessage = welcomeMessage.replace("%NAME%", customer.getName()).replace("%SUBDOMAIN%", customer.getSubdomain());
								
				//send a welcome message 1 minute from now
				Date sendDate = DateUtil.addToDate(new Date(), Calendar.MINUTE, 1);
				UserMessage userMessage = new UserMessage(customer, user, sendDate, welcomeMessage);
				MessageManager.schedule(userMessage, NotificationType.TEXT_SYSTEM);
			
				//disable text messages for new users
				if(isNewUser) {
					userPreference = new UserPreference(user, customer, Constants.UserPreference.NOTIFICATION_TEXT_ALL, Constants.NO);
					PreferencesManager.save(userPreference);
				}
			}
		}
		
		return sendWelcomeText;
	}
}
