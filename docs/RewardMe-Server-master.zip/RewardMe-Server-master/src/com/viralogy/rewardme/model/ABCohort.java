package com.viralogy.rewardme.model;

import java.io.Serializable;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.CohortType;
import com.viralogy.rewardme.manager.ABTestManager;

@MySQLTable(name=MySQL.TABLES.AB_COHORT,
		primaryKey="abCohortId",
		transients={
		
		}
)

public class ABCohort extends DatabaseBackedObject implements Serializable {

	private static Logger logger = Logger.getLogger(ABCohort.class);

	private static final long serialVersionUID = 8473658629581733296L;

	
	private long abCohortId;
	ABTest abTest;


	private long displayCohortId;
	private long successes;
	private long views;
	private String description;
	
	public ABCohort(ABTest test) {
		setAbTest(test);
	}
	
	public String toString() {
		return "Test ID: " + abTest.getAbTestId() + " and Cohort ID: " + displayCohortId;
	}
	
	public long getAbCohortId() {
		return abCohortId;
	}

	public void setAbCohortId(long newCohortId) {
		this.abCohortId = newCohortId;
	}
	
	public ABTest getAbTest() {
		return abTest;
	}

	public void setAbTest(ABTest test) {
		this.abTest = test;
	}
	
	public void setDisplayCohortId(long newDisplayCohortId) {
		this.displayCohortId = newDisplayCohortId;
	}

	public long getDisplayCohortId() {
		return displayCohortId;
	}
	
	public long getSuccesses() {
		return successes;
	}
	
	public void setSuccesses(long newSuccesses) {
		this.successes = newSuccesses;
	}
	
	public long getViews() {
		return views;
	}

	public void setViews(long views) {
		this.views = views;
	}

	public String getDescription() {
		return description;
	}
	
	public void setDescription(String newDescription) {
		this.description = newDescription;
	}
	
	public static ABCohort from(MySQL mysql) throws FatalException, InvalidParameterException {
		ABCohort cohort = new ABCohort(ABTestManager.getAbTest((Long)mysql.getColumn("ab_test_id"), null));
		cohort.setDisplayCohortId((Long)mysql.getColumn("display_cohort_id"));
		cohort.setAbCohortId((Long)mysql.getColumn("ab_cohort_id"));
		cohort.setSuccesses((Long)mysql.getColumn("successes"));
		cohort.setViews((Long)mysql.getColumn("views"));
		cohort.setDescription((String)mysql.getColumn("description"));
		return cohort;
	}

	public CohortType toCohortType() throws InvalidParameterException, FatalException {
		CohortType cohortType = new CohortType();
		cohortType.setTest(getAbTest().toTestType());
		cohortType.setDisplayCohortId(getDisplayCohortId());
		cohortType.setSuccesses(getSuccesses());
		cohortType.setViews(getViews());
		cohortType.setDescription(getDescription());
		cohortType.setAbCohortId(getAbCohortId());
		return cohortType;
	}
}
