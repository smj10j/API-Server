package com.viralogy.rewardme.model;								

import java.io.Serializable;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.TestType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CustomerManager;

@MySQLTable(name=MySQL.TABLES.AB_TEST, 
		primaryKey="abTestId",
		transients={
		
		}
)

public class ABTest extends DatabaseBackedObject implements Serializable {

	private static Logger logger = Logger.getLogger(ABTest.class);
	
	private long abTestId;
	private String name;
	private String description;
	private Customer customer;
	private Address address;
	
	private static final long serialVersionUID = 1671618122453278954L;
	
	public ABTest(String newName, Customer customer, Address address) {
		name = newName;
		this.address = address;
		this.customer = customer;
	}
	
	public String toString() {
		return "ID: " + abTestId;
	}

	public void setAbTestId(long newTestId) {
		this.abTestId = newTestId;
	}

	public long getAbTestId() {
		return abTestId;
	}
	
	public static ABTest from(MySQL mysql) throws FatalException, InvalidParameterException {
		ABTest test = new ABTest((String)mysql.getColumn("name"), CustomerManager.getCustomer((Long)mysql.getColumn("customer_id")), AddressManager.getAddress((Long)mysql.getColumn("address_id"), true));
		test.setAbTestId((Long)mysql.getColumn("ab_test_id"));
		test.setDescription((String)mysql.getColumn("description"));
		return test;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String newName) {
		this.name = newName;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String newDescription) {
		this.description = newDescription;
	}

	public Customer getCustomer() {
		return customer;
	}
	
	public void setCustomer(Customer newCustomer) {
		this.customer = newCustomer;
	}
	
	public Address getAddress() {
		return address;
	}
	
	public void setAddress(Address newAddress) {
		address = newAddress;
	}
	
	public TestType toTestType() throws InvalidParameterException, FatalException {
		TestType testType = new TestType();
		testType.setAbTestId(getAbTestId());
		testType.setName(getName());
		testType.setDescription(getDescription());
		testType.setCustomer(getCustomer().toCustomerType(null, false, false));
		testType.setAddress(getAddress().toAddressType(null, false));
		return testType;
	}
}
