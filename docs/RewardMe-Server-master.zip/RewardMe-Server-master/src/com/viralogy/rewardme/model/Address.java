package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.AddressType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.PreferencesManager;
import com.viralogy.rewardme.model.AddressMetaData.Provider;
import com.viralogy.rewardme.util.Cache;
import com.viralogy.rewardme.util.OutputUtil;
import com.viralogy.rewardme.util.RemoteRequestUtil;
import com.viralogy.rewardme.util.YelpUtil;

@MySQLTable(name=MySQL.TABLES.ADDRESS, 
		primaryKey="addressId",
		transients={
			"customer",
			"addressMetaData",
			"customerPreferences"
		}
)

public class Address extends DatabaseBackedObject implements Serializable {
	
	private static Logger logger = Logger.getLogger(Address.class);

	private static final long serialVersionUID = 3596806529212251820L;

	private long addressId;
	private String address;
	private GeoCoord geoCoord;
	private long checkinRadius;
	private AddressMetaData addressMetaData;	//not saved with address.save() as it has no primary key
	private Customer customer;					//transient
	private String cardspringStoreId;
	private Map<String, CustomerPreference> customerPreferences; // transient
	
	//right now the database supports multiple customers per address (and multiple addresses per customers
	//in the future we may want to reflect that here (as to allow customers to group certain addresses into multiple api keys)

	public Address(GeoCoord geoCoord) {
		this.geoCoord = geoCoord;
	}
	
	public Address(Customer customer, String address, long checkinRadius, String imageUrl, String imageUrlSmall) {
		this.customer = customer;
		this.address = address;
		this.checkinRadius = checkinRadius;
	}
	
	public String toString() {
		return "addressId: " + addressId + ", address: " + address;
	}
	
	public AddressType toAddressType() throws InvalidParameterException, FatalException {
		return toAddressType(null, false);
	}
	public AddressType toAddressType(User user, boolean includeLightSequences) throws InvalidParameterException, FatalException {
		AddressType addressType = new AddressType();
		addressType.setAddressId(getAddressId());
		addressType.setAddress(getAddress());
		addressType.setCheckinRadius(getCheckinRadius());
		addressType.setEnabled(true);//TODO: Address: implement enabled for address
		if(geoCoord != null) {
			addressType.setGeoCoord(getGeoCoord().toGeoCoordType());			
		}
		if(addressMetaData != null) {
			addressType.setMetaData(getAddressMetaData().toAddressMetaDataType());
		}
		if(customer != null) {
			addressType.setCustomer(getCustomer().toCustomerType(user, false, includeLightSequences));
		}
		if(user != null) {
			if(user.getGeoCoord() != null) {
				addressType.setDistance(OutputUtil.round(user.getGeoCoord().distanceTo(getGeoCoord())/Constants.Distance.METERS_PER_MILE, 1));
			}
		}
		return addressType;
	}
	
	public void geocode() throws FatalException, InvalidParameterException {
		String formattedAddress = Cache.get(address, Cache.namespace.GEOCODE_FORMATTED_ADDRESS);
		GeoCoord geoCoord = Cache.get(address, Cache.namespace.GEOCODE_GEOCOORD);
		if(formattedAddress == null) {
			String response = null;
			try {
				response = RemoteRequestUtil.get(
					"http://maps.google.com/maps/api/geocode/json", 
					"address="+URLEncoder.encode(address,"UTF-8")+"&sensor=false", false
				);
			}catch(UnsupportedEncodingException e) {
				throw new FatalException(e);
			}
			try {
				JSONObject responseObject = new JSONObject(response);
				if(responseObject.getJSONArray("results").length() == 0) {
					throw new InvalidParameterException("No location information for that street address - addressId: " + addressId);
				}
				JSONObject result = responseObject.getJSONArray("results").getJSONObject(0);
				JSONObject location = result.getJSONObject("geometry").getJSONObject("location");
				
				formattedAddress = result.getString("formatted_address");
				geoCoord = new GeoCoord(location.getDouble("lng"), location.getDouble("lat"));

				Cache.put(formattedAddress, address, Cache.namespace.GEOCODE_FORMATTED_ADDRESS);
				Cache.put(geoCoord, address, Cache.namespace.GEOCODE_GEOCOORD);

			}catch(JSONException e) {
				throw new FatalException(e);
			}
		}
		//no longer using the formatted address because it removes SUITE info
		//this.address = formattedAddress;
		this.geoCoord = geoCoord;
	}
	
	public void refresh() throws InvalidParameterException, FatalException {
		if(customer == null) {
			customer = CustomerManager.getCustomer(this);
		}
		geocode();
		if(geoCoord == null) {
			throw new FatalException("Tried to refresh address data when geocoord is null! - addressId: " + addressId);
		}
		
		if(addressMetaData == null) {
			addressMetaData = new AddressMetaData(Provider.YELP);
			addressMetaData.setName(getCustomer().getName());
			addressMetaData.setAddressId(this.getAddressId());
		}
		
	}

	/*
	 * Gets all the needed address "YelpData" from the Yelp API
	 * The given customer parameter is used for looking up the name of the location
	 * Assumes that an "address" variable has already been set
	 * Calls geocode on itself automatically
	 */
	public void refreshMetaData() throws FatalException, InvalidParameterException {
		if(customer == null) {
			customer = CustomerManager.getCustomer(this);
		}
		geocode();
		if(geoCoord == null) {
			throw new FatalException("Tried to refresh yelp data when geocoord is null! - addressId: " + addressId);
		}
		setAddressMetaData(YelpUtil.getBusinessInformation(customer, this));
	}

	public void setGeoCoord(GeoCoord geoCoord) {
		this.geoCoord = geoCoord;
	}

	public GeoCoord getGeoCoord() {
		return geoCoord;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddress() {
		return address;
	}
	
	public void setAddressId(long addressId) {
		this.addressId = addressId;
	}

	public long getAddressId() {
		return addressId;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() throws InvalidParameterException, FatalException {
		if(customer == null) {
			customer = CustomerManager.getCustomer(this);
		}
		return customer;
	}

	public static Address from(MySQL mysql, Customer customer) throws FatalException, InvalidParameterException {
		Address address = new Address(
			 GeoCoord.fromRadians(
				((BigDecimal)mysql.getColumn("longitude_radians")).doubleValue(), 
				((BigDecimal)mysql.getColumn("latitude_radians")).doubleValue()
			)
		);
		address.setAddressId((Long)mysql.getColumn("address_id"));
		address.setCheckinRadius((Long)mysql.getColumn("checkin_radius"));
		address.setAddress((String)mysql.getColumn("address"));
		address.setCardspringStoreId((String)mysql.getColumn("cardspring_store_id"));
		try {
			address.setCustomer(customer == null ? CustomerManager.getCustomer(address) : customer);
		}catch(InvalidParameterException e) {
			//ignore - it's possible for an address to not have a customer and this general method should allow that
		}
		
		address.setAddressMetaData(AddressManager.getAddressMetaData(address));
		
		return address;
	}

	public void setCheckinRadius(long checkinRadius) {
		this.checkinRadius = checkinRadius;
	}

	public long getCheckinRadius() {
		return checkinRadius;
	}
	

	public static List<Address> sortByDistance(List<Address> originalList, GeoCoord geoCoord, int returnCount, int startPageIndex) {
		//logger.debug("Starting distance sort." + OutputUtil.getElapsedString());
		List<Address> addresses = new ArrayList<Address>();
		Map<Address, Double> distancesMap = new HashMap<Address, Double>();
		List<Double> distances = new ArrayList<Double>();
		
		//create a map of address to distance so we don't have to compute these again
		for(Address address : originalList) {
			double distance = geoCoord.distanceTo(address.getGeoCoord());
			//logger.debug("Distance to " + address.getGeoCoord() + " is " + distance);
			distances.add(distance);
			distancesMap.put(address, distance);
		}
		Collections.sort(distances);
		
		//Most people do not make it past three pages.  Thus, we are sending three pages worth of 
		//information and the same time to the phone.  The phone will not ask for more results 
		//until it has proceeded through all of the pages.
		int minIndex = returnCount * startPageIndex;
		int i = 0;
		
		//match up the distances with an address - duplicate distances are fine
		for(double distanceToMatch : distances) {
			if(i < minIndex) {
				i++;
				continue;
			}
			
			if(addresses.size() >= returnCount) {
				break;
			}
			for(Address address : distancesMap.keySet()) {
				double addressDistance = distancesMap.get(address);
				if(addressDistance == distanceToMatch) {
					addresses.add(address);
					distancesMap.remove(address);
					break;
				}
			}
		}

		//logger.debug("Finished distance sort." + OutputUtil.getElapsedString());
		return addresses;
	}

	public void setAddressMetaData(AddressMetaData addressMetaData) {
		this.addressMetaData = addressMetaData;
	}

	public AddressMetaData getAddressMetaData() {
		return addressMetaData;
	}
	
	public Map<String, CustomerPreference> getCustomerPreferences() throws FatalException, InvalidParameterException {
		if( customerPreferences == null ) {
			customerPreferences = PreferencesManager.getCustomerPreferences(this.customer, this);
		}
		return customerPreferences;
	}

	public String getCardspringStoreId() {
		return cardspringStoreId;
	}

	public void setCardspringStoreId(String cardspringStoreId) {
		this.cardspringStoreId = cardspringStoreId;
	}
}
