package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.AddressMetaDataType;

@MySQLTable(name=MySQL.TABLES.ADDRESS_METADATA, 
		primaryKey="addressId",
		transients={})
public class AddressMetaData extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = -1302298453971186010L;

	private static Logger logger = Logger.getLogger(AddressMetaData.class);

	public static enum Provider {
		YELP
	};
	
	private long addressId;
	private Provider provider;
	private String providerId;
	private String providerLink;
	private String name;
	private String category;
	private String imageUrl;
	private String imageUrlSmall;
	private String ratingUrl;
	private String phoneNumber;
	private long totalReviews;

	public AddressMetaData(Provider provider) {
		this.setProvider(Provider.YELP);
	}
	
	public AddressMetaDataType toAddressMetaDataType() throws FatalException {
		AddressMetaDataType addressMetaDataType = new AddressMetaDataType();
		try {
			addressMetaDataType.setProvider(getProvider().toString());
			addressMetaDataType.setProviderId(getProviderId());
			addressMetaDataType.setProviderLink(getProviderLink());
			addressMetaDataType.setName(getName() == null ? null : URLEncoder.encode(getName(),"UTF-8"));
			addressMetaDataType.setCategory(getCategory() == null ? null : URLEncoder.encode(getCategory(), "UTF-8"));
			addressMetaDataType.setImageUrl(getImageUrl());
			addressMetaDataType.setImageUrlSmall(getImageUrlSmall());
			addressMetaDataType.setPhoneNumber(getPhoneNumber());
			addressMetaDataType.setRatingUrl(getRatingUrl());
			addressMetaDataType.setTotalReviews(getTotalReviews());
			
		} catch (UnsupportedEncodingException e) {
			throw new FatalException(e);
		}
		return addressMetaDataType;
	}
	
	public String getImageUrlSmall() {
		return imageUrlSmall;
	}

	public void setImageUrlSmall(String imageUrlSmall) {
		this.imageUrlSmall = imageUrlSmall;
	}
	
	public void setAddressId(long addressId) {
		this.addressId = addressId;
	}

	public long getAddressId() {
		return addressId;
	}

	public static AddressMetaData from(MySQL mysql) throws FatalException {
		AddressMetaData addressMetaData = new AddressMetaData(Provider.valueOf((String)mysql.getColumn("provider")));
		addressMetaData.setAddressId((Long)mysql.getColumn("address_id"));
		addressMetaData.setProviderId((String)mysql.getColumn("provider_id"));
		addressMetaData.setProviderLink((String)mysql.getColumn("provider_link"));
		addressMetaData.setName((String)mysql.getColumn("name"));
		addressMetaData.setCategory((String)mysql.getColumn("category"));
		addressMetaData.setImageUrl((String)mysql.getColumn("image_url"));
		addressMetaData.setImageUrlSmall((String)mysql.getColumn("image_url_small"));
		addressMetaData.setRatingUrl((String)mysql.getColumn("rating_url"));
		addressMetaData.setPhoneNumber((String)mysql.getColumn("phone_number"));
		addressMetaData.setTotalReviews((Long)mysql.getColumn("total_reviews"));
		return addressMetaData;
	}
	
	public String getRatingUrl() {
		return ratingUrl;
	}

	public void setRatingUrl(String ratingUrl) {
		this.ratingUrl = ratingUrl;
	}

	public void setProvider(Provider provider) {
		this.provider = provider;
	}

	public Provider getProvider() {
		return provider;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderLink(String providerLink) {
		this.providerLink = providerLink;
	}

	public String getProviderLink() {
		return providerLink;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCategory() {
		return category;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setTotalReviews(long totalReviews) {
		this.totalReviews = totalReviews;
	}

	public long getTotalReviews() {
		return totalReviews;
	}
}
