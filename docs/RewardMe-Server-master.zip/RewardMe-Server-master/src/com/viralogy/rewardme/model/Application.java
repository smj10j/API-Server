package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.ApplicationType;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.servlet.GatewayServlet;
import com.viralogy.rewardme.util.StringUtil;

@MySQLTable(name=MySQL.TABLES.APPLICATION, 
		primaryKey="applicationId",
		transients={}
)

public class Application extends DatabaseBackedObject implements Serializable {
			
	private static final long serialVersionUID = -661370856783162040L;
	
	private static String APPLICATION_BASE_URL = null;
	public static final Object HOSTED_STRING = "HOSTED";
	
	public static enum Type {
		KIOSK,
		COUNTER_SERVICE_LOYALTY,
		COUNTER_SERVICE_LOYALTY_EMPLOYEE_FACING,
		AD_NETWORK,
		TABLE_SERVICE_WAITING_LIST
	}
	
	private static Map<Type, String> typeDescriptions = new HashMap<Type, String>(); 
	static {
		typeDescriptions.put(Type.KIOSK, "Collects phone numbers from users without points or rewards");
		typeDescriptions.put(Type.COUNTER_SERVICE_LOYALTY, "Awards users points for each purchase and allows them to redeem rewards");
		typeDescriptions.put(Type.COUNTER_SERVICE_LOYALTY_EMPLOYEE_FACING, "Awards users points for each purchase and allows the cashier to redeem rewards on behalf of the user");
		typeDescriptions.put(Type.AD_NETWORK, "Displays relevant ads from the RewardMe network");
		typeDescriptions.put(Type.TABLE_SERVICE_WAITING_LIST, "Collects phone numbers from users and allows text messages to be sent to them when their table is ready");		
	}
	
	private long applicationId;
	private String name;
	private String description;
	private boolean archived;
	private Type type;
	private Customer customer;
	private String url;
	private Date updated;
	private Date created;
	
	public Application() {
		
	}
	
	public Application(String name, String description, Customer customer, Type type, String url) {
		setName(name);
		setDescription(description);
		setCustomer(customer);
		setType(type);
		setUrl(url);
	}

	public ApplicationType toApplicationType(boolean typeOnly) throws FatalException, InvalidParameterException {
		ApplicationType applicationType = new ApplicationType();
		applicationType.setType(getType().toString());
		applicationType.setDescription(getDescription());
		if(!typeOnly) {
			applicationType.setApplicationId(getApplicationId());
			applicationType.setCustomer(getCustomer().toCustomerType(null, false, false));
			applicationType.setName(getName());
			applicationType.setUrl(getUrl());
			applicationType.setUpdated(getUpdated() == null ? null : getUpdated().getTime());
			applicationType.setCreated(getCreated() == null ? null : getCreated().getTime());
		}
		return applicationType;
	}
	
	public static Application from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		Application application = new Application(
			(String)mysql.getColumn("name"),
			(String)mysql.getColumn("description"),
			CustomerManager.getCustomer((Long)mysql.getColumn("customer_id")),
			Type.valueOf((String)mysql.getColumn("type")),
			(String)mysql.getColumn("url")
		);
		application.setApplicationId((Long)mysql.getColumn("application_id"));
		application.setUpdated((Date)mysql.getColumn("updated"));		
		application.setCreated((Date)mysql.getColumn("created"));		
		application.setArchived((Boolean)mysql.getColumn("archived"));		
				
		application.takeFieldValuesSnapshot();
		
		return application;
	}
	
	public void setType(Type type) {
		this.type = type;
	}

	public Type getType() {
		return type;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}
	
	public void setUpdated(Date updated) {
		this.updated = updated;
	}

	public Date getUpdated() {
		return updated;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUrl() {
		
		//Remotely hosted
		if(!StringUtil.isNullOrEmpty(url)) {
			return url;
		}
		
		//RewardMe hosted
		String appName = "";
		if(type == Type.KIOSK) {
			appName = "kiosk";
		}else if(type == Type.COUNTER_SERVICE_LOYALTY) {
			appName = "csc";
		}else if(type == Type.COUNTER_SERVICE_LOYALTY_EMPLOYEE_FACING) {
			appName = "cse";
		}else if(type == Type.AD_NETWORK) {
			appName = "ad";
		}else if(type == Type.TABLE_SERVICE_WAITING_LIST) {
			appName = "tswl";
		}
		
		if(StringUtil.isNullOrEmpty(APPLICATION_BASE_URL)) {
			if(GatewayServlet.isSandbox()) {
				APPLICATION_BASE_URL = "http://sandbox.tablet.rewardme.com/";				
			}else if(GatewayServlet.isBeta()) {
				APPLICATION_BASE_URL = "http://beta.tablet.rewardme.com/";				
			}else {
				APPLICATION_BASE_URL = "https://tablet.rewardme.com/";
			}
		}
		
		return APPLICATION_BASE_URL+appName+"/"+customer.getApiKey().toLowerCase();
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}

	public long getApplicationId() {
		return applicationId;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDescription() {
		if(description == null) {
			return typeDescriptions.get(getType());
		}
		return description;
	}

	public void setArchived(boolean archived) {
		this.archived = archived;
	}

	public boolean isArchived() {
		return archived;
	}
	
	
}