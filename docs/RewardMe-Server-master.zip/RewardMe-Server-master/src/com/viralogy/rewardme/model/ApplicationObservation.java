package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.manager.ApplicationManager;
import com.viralogy.rewardme.manager.DeviceManager;
import com.viralogy.rewardme.manager.UserManager;

@MySQLTable(name=MySQL.TABLES.APPLICATION_OBSERVATION, 
		primaryKey="applicationObservationId",
		transients={}
)

public class ApplicationObservation extends DatabaseBackedObject implements Serializable {
				
	private static final long serialVersionUID = 1530889427228264942L;
	
	private long applicationObservationId;
	private Application application;
	private DeviceApplication deviceApplication;
	private long observationsInstanceId;
	private User user;
	private String module;
	private String element;
	private String action;
	private String data;
	private Date timestamp;
	private Date created;
	
	public ApplicationObservation(
			Application application, 
			DeviceApplication deviceApplication, long observationsInstanceId,
			Date timestamp, String module, String element, String action, String data, User user) {
		
		setApplication(application);
		setDeviceApplication(deviceApplication);
		setObservationsInstanceId(observationsInstanceId);
		setTimestamp(timestamp);
		setModule(module);
		setElement(element);
		setAction(action);
		setData(data);
		setUser(user);
	}
	
	public static ApplicationObservation from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		Long deviceApplicationId = (Long)mysql.getColumn("device_application_id");
		Long userId = (Long)mysql.getColumn("user_id");
		ApplicationObservation applicationObservation = new ApplicationObservation(
			ApplicationManager.getApplication((Long)mysql.getColumn("application_id")),
			deviceApplicationId == 0 ? null : DeviceManager.getDeviceApplication(deviceApplicationId),
			(Long)mysql.getColumn("observations_instance_id"),
			(Date)mysql.getColumn("timestamp"),
			(String)mysql.getColumn("module"),
			(String)mysql.getColumn("element"),
			(String)mysql.getColumn("action"),
			(String)mysql.getColumn("data"), userId == null ? null : UserManager.getUser(userId)
		);
		applicationObservation.setApplicationObservationId((Long)mysql.getColumn("application_observation_id"));
		applicationObservation.setCreated((Date)mysql.getColumn("created"));
				
		return applicationObservation;
	}
	

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setApplicationObservationId(long applicationObservationId) {
		this.applicationObservationId = applicationObservationId;
	}

	public long getApplicationObservationId() {
		return applicationObservationId;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public Application getApplication() {
		return application;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public User getUser() {
		return user;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getModule() {
		return module;
	}

	public void setElement(String element) {
		this.element = element;
	}

	public String getElement() {
		return element;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getAction() {
		return action;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getData() {
		return data;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setObservationsInstanceId(long observationsInstanceId) {
		this.observationsInstanceId = observationsInstanceId;
	}

	public long getObservationsInstanceId() {
		return observationsInstanceId;
	}

	public DeviceApplication getDeviceApplication() {
		return deviceApplication;
	}

	public void setDeviceApplication(DeviceApplication deviceApplication) {
		this.deviceApplication = deviceApplication;
	}
	
	
}