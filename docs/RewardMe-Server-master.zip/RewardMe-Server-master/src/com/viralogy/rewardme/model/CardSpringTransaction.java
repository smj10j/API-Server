package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.UserManager;

@MySQLTable(name = MySQL.TABLES.CARDSPRING_TRANSACTION, 
			primaryKey = "cardspringTransactionId", 
			transients = {
			}
)
public class CardSpringTransaction extends DatabaseBackedObject implements
		Serializable {

	private static final long serialVersionUID = 9049509350055007954L;

	private long cardspringTransactionId;
	private User user;
	private Customer customer;

	public static enum Type {
		AUTHORIZATION("authorization"), SETTLEMENT("settlement");
		public String value;

		Type(String value) {
			this.value = value;
		}
	}

	private Type eventType;
	private double amount;
	private String currency;
	private Date purchaseTime;
	private Date created;

	public static CardSpringTransaction from(MySQL mysql)
			throws FatalException, InvalidParameterException {

		CardSpringTransaction cst = new CardSpringTransaction();
		cst.setCustomer(CustomerManager.getCustomer((Long) mysql
				.getColumn("customer_id")));
		cst.setUser(UserManager.getUser((Long) mysql.getColumn("user_id")));
		if (mysql.getColumn("event_type").equals(Type.AUTHORIZATION.value))
			cst.setEventType(Type.AUTHORIZATION);
		else
			cst.setEventType(Type.SETTLEMENT);
		cst.setAmount((Long) mysql.getColumn("amount"));
		cst.setCurrency((String) mysql.getColumn("currency"));
		cst.setPurchaseTime((Date) mysql.getColumn("purchase_time"));

		return cst;
	}

	public CardSpringTransaction() {

	}

	public CardSpringTransaction(User user, Customer customer, Type eventType,
			double amount, String currency, Date purchaseTime) {
		this.user = user;
		this.customer = customer;
		this.eventType = eventType;
		this.amount = amount;
		this.currency = currency;
		this.purchaseTime = purchaseTime;
	}

	public long getCardspringTransactionId() {
		return cardspringTransactionId;
	}

	public void setCardspringTransactionId(long cardspringTransactionId) {
		this.cardspringTransactionId = cardspringTransactionId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Type getEventType() {
		return eventType;
	}

	public void setEventType(Type eventType) {
		this.eventType = eventType;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Date getPurchaseTime() {
		return purchaseTime;
	}

	public void setPurchaseTime(Date purchaseTime) {
		this.purchaseTime = purchaseTime;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

}