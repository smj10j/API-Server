package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.CheckinOptionType;
import com.viralogy.rewardme.jaxb.SchedulesType;
import com.viralogy.rewardme.manager.PointsManager;

@MySQLTable(name=MySQL.TABLES.CHECKIN_OPTION, 
		primaryKey="checkinOptionId",
		transients={
			"schedules"
		}
)
public class CheckinOption extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = 8121709665598071695L;
	
	public static enum Type {
		VISIT_BASED,
		VALUE_BASED
	};
	
	private long checkinOptionId;
	private PointCategory pointCategory;
	private long pointAward;
	private long referralPointAward;
	private long recurringReferralPointAward;
	private String name;
	private Type type;
	private String imageUrl;
	private long cooldownLength;
	private List<Schedule> schedules = new ArrayList<Schedule>();

	
	public CheckinOption() {

	}
		
	public CheckinOption(String name, Type type, String imageUrl, PointCategory pointCategory, int pointAward, int referralPointAward, int recurringReferralPointAward, int cooldownLength) {
		this.setName(name);
		this.setPointCategory(pointCategory);
		this.setType(type);
		this.setImageUrl(imageUrl);
		this.setPointAward(pointAward);
		this.setReferralPointAward(referralPointAward);
		this.setRecurringReferralPointAward(recurringReferralPointAward);
		this.setCooldownLength(cooldownLength);
	}
	
	public CheckinOptionType toCheckinOptionType() throws FatalException, InvalidParameterException {
		CheckinOptionType checkinOptionType = new CheckinOptionType();
		checkinOptionType.setCheckinOptionId(getCheckinOptionId());
		checkinOptionType.setName(getName());
		checkinOptionType.setType(getType().toString());
		checkinOptionType.setImageUrl(getImageUrl());
		checkinOptionType.setPointAward(getPointAward());
		checkinOptionType.setReferralPointAward(getReferralPointAward());
		checkinOptionType.setRecurringReferralPointAward(getRecurringReferralPointAward());
		checkinOptionType.setCooldownLength(getCooldownLength());
		checkinOptionType.setSchedules(new SchedulesType());
		for(Schedule schedule : getSchedules()) {
			checkinOptionType.getSchedules().getSchedule().add(schedule.toScheduleType());
		}
		if(pointCategory != null) {
			checkinOptionType.setPointCategory(pointCategory.toPointCategoryType());
		}
		return checkinOptionType;
	}

	public void setCheckinOptionId(long checkinOptionId) {
		this.checkinOptionId = checkinOptionId;
	}

	public long getCheckinOptionId() {
		return checkinOptionId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setPointAward(long pointAward) {
		this.pointAward = pointAward;
	}

	public long getPointAward() {
		return pointAward;
	}

	public void setCooldownLength(long cooldownLength) {
		this.cooldownLength = cooldownLength;
	}

	public long getCooldownLength() {
		return cooldownLength;
	}

	public void setSchedules(List<Schedule> schedules) {
		this.schedules = schedules;
	}

	public List<Schedule> getSchedules() {
		return schedules;
	}

	public static CheckinOption from(MySQL mysql) throws FatalException, InvalidParameterException {
		CheckinOption checkinOption = new CheckinOption();
		checkinOption.setCheckinOptionId((Long)mysql.getColumn("checkin_option_id"));
		checkinOption.setName((String)mysql.getColumn("name"));
		checkinOption.setType(Type.valueOf((String)mysql.getColumn("type")));
		checkinOption.setImageUrl((String)mysql.getColumn("image_url"));
		checkinOption.setPointAward((Integer)mysql.getColumn("point_award"));
		checkinOption.setReferralPointAward((Integer)mysql.getColumn("referral_point_award"));
		checkinOption.setRecurringReferralPointAward((Integer)mysql.getColumn("recurring_referral_point_award"));
		checkinOption.setCooldownLength((Long)mysql.getColumn("cooldown_length"));
		
		Long pointCategoryId = (Long)mysql.getColumn("point_category_id");
		checkinOption.setPointCategory(pointCategoryId == null || pointCategoryId == 0 ? null : PointsManager.getPointCategory(pointCategoryId));
		
		checkinOption.setSchedules(new ArrayList<Schedule>());
		
		//fetch all the schedules
		mysql.query("" +
				"SELECT * FROM " + MySQL.TABLES.CHECKIN_OPTION_TO_SCHEDULE + " cs, " + MySQL.TABLES.SCHEDULE + " s " +  
				"WHERE cs.checkin_option_id=? AND cs.schedule_id=s.schedule_id",
				checkinOption.getCheckinOptionId());
		while(mysql.nextRow()) {
			checkinOption.getSchedules().add(Schedule.from(mysql));
		}
		Collections.sort(checkinOption.getSchedules(), new Schedule.sort());
		
		return checkinOption;
	}

	public void setReferralPointAward(long referralPointAward) {
		this.referralPointAward = referralPointAward;
	}

	public long getReferralPointAward() {
		return referralPointAward;
	}

	public void setRecurringReferralPointAward(long recurringReferralPointAward) {
		this.recurringReferralPointAward = recurringReferralPointAward;
	}

	public long getRecurringReferralPointAward() {
		return recurringReferralPointAward;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Type getType() {
		return type;
	}

	public PointCategory getPointCategory() {
		return pointCategory;
	}

	public void setPointCategory(PointCategory pointCategory) {
		this.pointCategory = pointCategory;
	}	

}
