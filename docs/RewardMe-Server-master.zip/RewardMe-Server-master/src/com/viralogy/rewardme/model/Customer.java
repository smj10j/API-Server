package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.AddressesType;
import com.viralogy.rewardme.jaxb.CheckinOptionsType;
import com.viralogy.rewardme.jaxb.CustomerContactsType;
import com.viralogy.rewardme.jaxb.CustomerFeaturesType;
import com.viralogy.rewardme.jaxb.CustomerType;
import com.viralogy.rewardme.jaxb.RewardsType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CheckinOptionManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.FeatureManager;
import com.viralogy.rewardme.manager.PreferencesManager;
import com.viralogy.rewardme.manager.RewardManager;
import com.viralogy.rewardme.manager.SurveyManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.util.StringUtil;

@MySQLTable(name=MySQL.TABLES.CUSTOMER, 
		primaryKey="customerId",
		transients={
			"customerContacts",
			"addresses",
			"rewards",
			"checkinOptions",
			"features",
			"billing",
			"customerPreference",
			"customerPreferences",
			"surveys",
			"websiteUrl"
		}
)

public class Customer extends DatabaseBackedObject implements Serializable {

	private static Logger logger = Logger.getLogger(Customer.class);

	private static final long serialVersionUID = 8413764518270892930L;
	
	private String apiKey;
	private String name;
	private String subdomain;
	private String secretKey;
	private String authCode;
	private User user;
	private long customerId;
	private String cardspringBusinessId;
	private boolean enabled;
	private long created;
	private String stripeCustomerId;


	private List<CustomerContact> customerContacts = null;// transient
	private List<Address> addresses = null;// transient
	private List<Reward> rewards = null;// transient
	private List<CheckinOption> checkinOptions = null;// transient
	private List<CustomerFeature> features = null;// transient
	private List<Survey> surveys = null;// transient
	private CustomerBilling billing;	//transient
	private Map<String, CustomerPreference> customerPreferences = null; // transient

	public Customer() {

	}	
	
	public CustomerType toCustomerType(User user, boolean includeHeavySequences, boolean includeLightSequences) throws InvalidParameterException, FatalException {
		CustomerType customerType = new CustomerType();
		customerType.setCustomerId(getCustomerId());
		customerType.setApiKey(getApiKey());
		customerType.setEnabled(isEnabled());
		customerType.setName(getName());
		customerType.setSubdomain(getSubdomain());
		customerType.setTotalRewards(getRewards().size());
		customerType.setStripeCustomerId(getStripeCustomerId());
		if(includeHeavySequences) {
			
			if(getUser() != null) {
				customerType.setUser(getUser().toUserType(this));			
			}
			
			customerType.setAddresses(new AddressesType());
			for(Address address : getAddresses()) {
				customerType.getAddresses().getAddress().add(address.toAddressType(user, false));
			}
			customerType.setRewards(new RewardsType());
			for(Reward reward : getRewards()) {
				customerType.getRewards().getReward().add(reward.toRewardType());
			}
			customerType.setCheckinOptions(new CheckinOptionsType());
			for(CheckinOption checkinOption : getCheckinOptions()) {
				customerType.getCheckinOptions().getCheckinOption().add(checkinOption.toCheckinOptionType());
			}
			customerType.setCustomerContacts(new CustomerContactsType());
			for(CustomerContact customerContact : getCustomerContacts()) {
				customerType.getCustomerContacts().getCustomerContact().add(customerContact.toCustomerContactType(false));
			}			
			customerType.setFeatures(new CustomerFeaturesType());
			for(CustomerFeature customerFeature : getFeatures()) {
				customerType.getFeatures().getFeature().add(customerFeature.toCustomerFeatureType(false));
			}
			
			if(user != null && user.isAuthorized()) {
				customerType.setBilling(getBilling().toCustomerBillingType(false));
			}
			
			setPromotedRewardsType(customerType);
		
		}else if(includeLightSequences) {
			setPromotedRewardsType(customerType);
		}
		return customerType;
	}
	
	private void setPromotedRewardsType(CustomerType customerType) throws InvalidParameterException, FatalException {
		customerType.setPromotedRewards(new RewardsType());
		boolean foundPromotedReward = false;
		for(Reward reward : getRewards()) {
			if(reward.isPromoted()) {
				customerType.getPromotedRewards().getReward().add(reward.toRewardType());
				foundPromotedReward = true;
			}
		}
		if(!foundPromotedReward) {
			//used to throw the exception
			//throw new InvalidParameterException(Constants.Error.CUSTOMERS_MUST_HAVE_AT_LEAST_ONE_PROMOTED_REWARD, ListUtil.from(getCustomerId()+""));
			logger.warn("Customer does not have a promoted reward! customerId=" + getCustomerId());
		}		
	}
	
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
	public String getApiKey() {
		return apiKey;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	
	public void setCreated(long created) {
		this.created = created;
	}

	public long getCreated() {
		return created;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public long getCustomerId() {
		return customerId;
	}

	public List<Address> getAddresses() throws FatalException, InvalidParameterException {
		if(addresses == null) {
			addresses = AddressManager.getAllAddresses(this);
		}
		return addresses;		
	}

	public List<Reward> getRewards() throws FatalException, InvalidParameterException {
		if(rewards == null) {
			rewards = RewardManager.getAllCustomerRewards(this);
		}
		return rewards;
	}

	public List<CheckinOption> getCheckinOptions() throws FatalException, InvalidParameterException {
		if(checkinOptions == null) {
			checkinOptions = CheckinOptionManager.getAllCheckinOptions(this, true);
		}
		return checkinOptions;
	}
	
	public List<Survey> getSurveys() throws FatalException, InvalidParameterException {
		if(surveys == null) {
			surveys = SurveyManager.getSurveys(this, 10000, true);
		}
		return surveys;
	}
	
	public String getStripeCustomerId() {
		return stripeCustomerId;
	}

	public void setStripeCustomerId(String stripeCustomerId) {
		this.stripeCustomerId = stripeCustomerId;
	}
	
	public static Customer from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		
		Customer customer = new Customer();
		customer.setCustomerId((Long)mysql.getColumn("customer_id"));
		customer.setApiKey((String)mysql.getColumn("api_key"));
		customer.setName((String)mysql.getColumn("name"));
		customer.setSecretKey((String)mysql.getColumn("secret_key"));
		customer.setAuthCode((String)mysql.getColumn("auth_code"));
		customer.setSubdomain((String)mysql.getColumn("subdomain"));
		customer.setEnabled((Boolean)mysql.getColumn("enabled"));
		customer.setCardspringBusinessId((String)mysql.getColumn("cardspring_business_id"));

		customer.setStripeCustomerId((String)mysql.getColumn("stripe_customer_id"));
		
		Long userId = (Long)mysql.getColumn("user_id");
		customer.setUser(userId == null ? null : UserManager.getUser(userId));
		
		customer.takeFieldValuesSnapshot();
		
		return customer;
	}

	public List<CustomerContact> getCustomerContacts() throws InvalidParameterException, FatalException {
		if(customerContacts == null) {
			customerContacts = CustomerManager.getContacts(this);
		}
		return customerContacts;
	}

	public List<CustomerFeature> getFeatures() throws FatalException, InvalidParameterException {
		if(features == null) {
			features = FeatureManager.getFeatures(this);
		}
		return features;
	}

	public CustomerBilling getBilling() throws FatalException, InvalidParameterException {
		if(billing == null) {
			try {
				billing = CustomerManager.getBilling(this);
			}catch(InvalidParameterException e) {
				//no billing info
				billing = new CustomerBilling(this, null, 0L);
			}
		}
		return billing;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}

	public String getSecretKey() {
		return secretKey;
	}

	public static class NameComparator implements Comparator<Customer> {
	    public int compare(Customer left, Customer right) {
	    	if(left == null) {
	    		if(right == null) {
	    			return 0;
	    		}else {
	    			return -1;
	    		}
	    	}else if(right == null) {
	    		return 1;
	    	}else {
	    		return left.getName().compareTo(right.getName());
	    	}
	    }
	}
	
	public Map<String, CustomerPreference> getCustomerPreferences(Address address) throws FatalException, InvalidParameterException {
		
		if( address == null ) {
			if( customerPreferences == null ) {
				customerPreferences = PreferencesManager.getCustomerPreferences(this, null );
			}
			return customerPreferences;
		} else {
			return address.getCustomerPreferences();
		}
	}
	
	public CustomerPreference getCustomerPreference(String name, Address address) throws FatalException, InvalidParameterException {
		if(!StringUtil.isNullOrEmpty(name)) {
			name = name.toLowerCase();
		}
		return getCustomerPreferences(address).get(name);
	}

	public void setSubdomain(String subdomain) {
		this.subdomain = subdomain;
	}

	public String getSubdomain() {
		return subdomain;
	}
	
	public String getWebsiteUrl() {
		if(subdomain == null) {
			return Constants.URL.MY_REWARDME;
		}else {
			return subdomain + "." + Constants.URL.MY_REWARDME;
		}
	}
	
	public boolean is(String apiKey) {
		return getApiKey().equalsIgnoreCase(apiKey);
	}

	public String getAuthCode() {
		return authCode;
	}

	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getCardspringBusinessId() {
		return cardspringBusinessId;
	}

	public void setCardspringBusinessId(String cardspringBusinessId) {
		this.cardspringBusinessId = cardspringBusinessId;
	}
}
