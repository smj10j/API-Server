package com.viralogy.rewardme.model;

import java.io.Serializable;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.CustomerBillingType;
import com.viralogy.rewardme.manager.CustomerManager;

@MySQLTable(name=MySQL.TABLES.CUSTOMER_BILLING,
		primaryKey="customerBillingId",
		transients={
		}
)
		
public class CustomerBilling extends DatabaseBackedObject implements Serializable {
			
	private static final long serialVersionUID = -1479133996749779623L;
	
	private long customerBillingId;
	private Customer customer;
	private CustomerContact customerContact;
	private long freshbooksClientId;
	
	public CustomerBilling(Customer customer, CustomerContact customerContact, long freshbooksClientId) {
		setCustomer(customer);
		setCustomerContact(customerContact);
		setFreshbooksClientId(freshbooksClientId);
	}
	public CustomerBilling() {
	    
	}
	

	public CustomerBillingType toCustomerBillingType(boolean includeLightSequences) throws InvalidParameterException, FatalException {
		CustomerBillingType customerBillingType = new CustomerBillingType();
		customerBillingType.setCustomerBillingId(getCustomerBillingId());
		customerBillingType.setCustomerContact( getCustomerContact() == null ? null : getCustomerContact().toCustomerContactType( false ) );
		customerBillingType.setFreshbooksClientId( getFreshbooksClientId() );
		if(includeLightSequences) {
			customerBillingType.setCustomer(getCustomer().toCustomerType(null,false,false));
		}
		return customerBillingType;
	}
	
	
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}
	
	public void setCustomerBillingId(long customerBillingId) {
		this.customerBillingId = customerBillingId;
	}
	
	public long getCustomerBillingId() {
		return customerBillingId;
	}
	
	public void setCustomerContact(CustomerContact customerContact) {
        this.customerContact = customerContact;
    }

    public CustomerContact getCustomerContact() {
        return customerContact;
    }
    
    public void setFreshbooksClientId(long freshbooksClientId) {
        this.freshbooksClientId = freshbooksClientId;
    }

    public long getFreshbooksClientId() {
        return freshbooksClientId;
    }


    public static CustomerBilling from(MySQL mysql) throws FatalException, InvalidParameterException {
        Customer customer = CustomerManager.getCustomer((Long)mysql.getColumn("customer_id"));
        
        CustomerBilling customerBilling = new CustomerBilling();
        customerBilling.setCustomerBillingId((Long)mysql.getColumn( "customer_billing_id" ));
        customerBilling.setCustomer(customer);
        customerBilling.setCustomerContact(CustomerManager.getContact((Long)mysql.getColumn("customer_contact_id")));
        customerBilling.setFreshbooksClientId((Long)mysql.getColumn("freshbooks_client_id"));
        

        return customerBilling;
    }

}
