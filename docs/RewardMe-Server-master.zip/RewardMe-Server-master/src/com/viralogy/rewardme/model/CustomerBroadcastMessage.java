package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.CustomerBroadcastMessageType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CustomerManager;

@MySQLTable(name=MySQL.TABLES.CUSTOMER_BROADCAST_MESSAGE, 
		primaryKey="customerBroadcastMessageId",
		transients={
		}
)

public class CustomerBroadcastMessage extends DatabaseBackedObject implements Serializable {
		
	private static final long serialVersionUID = 1674390388790878375L;
	
	private long customerBroadcastMessageId;
	private Customer customer;
	private String message;
	private Date timestamp;
	private Address address;
	private boolean sent;
	private Date created;
	
	public CustomerBroadcastMessage(Customer customer, Address address, String message, Date timestamp) throws FatalException {
		setCustomer(customer);
		setMessage(message);
		setTimestamp(timestamp);
		setAddress(address);
	}
	
	public CustomerBroadcastMessageType toCustomerBroadcastMessageType(boolean includeSequences) throws InvalidParameterException, FatalException {
		CustomerBroadcastMessageType customerBroadcastMessageType = new CustomerBroadcastMessageType();
		customerBroadcastMessageType.setCustomerBroadcastMessageId(customerBroadcastMessageId);
		customerBroadcastMessageType.setCustomer(customer.toCustomerType(null, false, false));
		customerBroadcastMessageType.setAddress(address.toAddressType());
		customerBroadcastMessageType.setTimestamp(timestamp.getTime());
		customerBroadcastMessageType.setMessage(message);
		return customerBroadcastMessageType;
	}

	public String toString() {
		return "customerBroadcastMessageId: " + customerBroadcastMessageId;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public static CustomerBroadcastMessage from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		Customer customer = CustomerManager.getCustomer((Long)mysql.getColumn("customer_id"));
		Long addressId = (Long)mysql.getColumn("address_id");
		Address address = addressId == null ? null : AddressManager.getAddress(addressId, false);
		String message = (String)mysql.getColumn("message");
		Date timestamp = (Date)mysql.getColumn("timestamp");
		
		CustomerBroadcastMessage customerBroadcastMessage = new CustomerBroadcastMessage(
				customer,
				address,
				message,
				timestamp
		);
		
		customerBroadcastMessage.setCustomerBroadcastMessageId((Long)mysql.getColumn("customer_broadcast_message_id"));
		customerBroadcastMessage.setSent((Boolean)mysql.getColumn("sent"));
		customerBroadcastMessage.setCreated((Date)mysql.getColumn("created"));
		
		return customerBroadcastMessage;
	}
	
	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomerBroadcastMessageId(long customerBroadcastMessageId) {
		this.customerBroadcastMessageId = customerBroadcastMessageId;
	}

	public long getCustomerBroadcastMessageId() {
		return customerBroadcastMessageId;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}

	public void setSent(boolean sent) {
		this.sent = sent;
	}

	public boolean isSent() {
		return sent;
	}

}
