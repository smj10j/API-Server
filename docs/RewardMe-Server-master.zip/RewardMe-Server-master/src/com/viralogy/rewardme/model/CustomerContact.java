package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Map;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.CustomerContactType;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.util.ListUtil;

@MySQLTable(name=MySQL.TABLES.CUSTOMER_CONTACT, 
		primaryKey="customerContactId",
		transients={
			"permissions"
		}
)

public class CustomerContact extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = 945925157665964693L;

	private long customerContactId;
	private String name;
	private String email;
	private String password;
	private User user;
	private Customer customer;
	private Map<String, Permission> permissions;
	
	public CustomerContact() {

	}
	
	public CustomerContact(Customer customer, String name, String email, String password, User user) {
		setCustomer(customer);
		setName(name);
		setEmail(email);
		setPassword(password);
		setUser(user);
	}

	public CustomerContactType toCustomerContactType(boolean showPasswords) throws InvalidParameterException, FatalException {
		CustomerContactType customerContactType = new CustomerContactType();
		customerContactType.setCustomerContactId(getCustomerContactId());
		if(customer != null) {
			customerContactType.setApiKey(customer.getApiKey());
		}
		if(user != null) {
			customerContactType.setUser(getUser().toUserType(customer));
		}
		customerContactType.setEmail(getEmail());
		customerContactType.setName(getName());
		if(showPasswords) {
			customerContactType.setPassword(getPassword());
		}
		return customerContactType;
	}
	
	
	public void setCustomerContactId(long customerContactId) {
		this.customerContactId = customerContactId;
	}

	public long getCustomerContactId() {
		return customerContactId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmail() {
		return email;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPassword() {
		return password;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public User getUser() {
		return user;
	}

	public static CustomerContact from(MySQL mysql, Customer customer, User user) throws InvalidParameterException, FatalException {
		CustomerContact customerContact = new CustomerContact();
		customerContact.setCustomerContactId((Long)mysql.getColumn("customer_contact_id"));
		long customerId = (Long)mysql.getColumn("customer_id");
		customerContact.setCustomer(customerId == 0 ? null : (customer == null ? CustomerManager.getCustomer(customerId): customer));
		customerContact.setUser(user == null ? UserManager.getUser((Long)mysql.getColumn("user_id")) : user);
		customerContact.setName((String)mysql.getColumn("name"));
		customerContact.setEmail((String)mysql.getColumn("email"));
		customerContact.setPassword((String)mysql.getColumn("password"));
		return customerContact;
	}

	public void setPermissions(Map<String, Permission> permissions) {
		this.permissions = permissions;
	}

	public Map<String, Permission> getPermissions() throws FatalException, InvalidParameterException {
		if(permissions == null) {
			permissions = CustomerManager.getPermissions(this);
		}
		return permissions;
	}
	
	public void verifyPermission(Permission permission) throws FatalException, InvalidParameterException {
		if(getPermissions().get(permission.getName()) == null) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_GENERAL, ListUtil.from(getName(), permission.getName()));
		}
	}
}
