package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.CustomerFeatureType;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.FeatureManager;

@MySQLTable(name=MySQL.TABLES.CUSTOMER_FEATURE, 
		primaryKey="customerFeatureId",
		transients={
		}
)
		
public class CustomerFeature extends DatabaseBackedObject implements Serializable {
		
	private static final long serialVersionUID = -391906550530614252L;

	public static enum Feature {
		TEXT_MESSAGE,
		ACTIVITY_NOTIFICATION
	}
	
	private long customerFeatureId;
	private Feature feature;
	private Customer customer;
	private long amount;
	private Date created;
	
	public CustomerFeature(Customer customer, Feature feature, long amount) {
		setCustomer(customer);
		setFeature(feature);
		setAmount(amount);
	}
	

	public CustomerFeatureType toCustomerFeatureType(boolean includeLightSequences) throws InvalidParameterException, FatalException {
		CustomerFeatureType customerFeatureType = new CustomerFeatureType();
		customerFeatureType.setCustomerFeatureId(customerFeatureId);
		customerFeatureType.setFeature(feature.toString());
		customerFeatureType.setAmount(amount);
		if(includeLightSequences) {
			customerFeatureType.setCustomer(customer.toCustomerType(null,false,false));
			customerFeatureType.setRemaining(getRemaining());
		}
		return customerFeatureType;
	}
	
	
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public static CustomerFeature from(MySQL mysql) throws FatalException, InvalidParameterException {
		Customer customer = CustomerManager.getCustomer((Long)mysql.getColumn("customer_id"));
		
		CustomerFeature customerFeature = new CustomerFeature(
				customer,
				Feature.valueOf((String)mysql.getColumn("feature")),
				(Long)mysql.getColumn("amount")
		);
		customerFeature.setCustomerFeatureId((Long)mysql.getColumn("customer_feature_id"));
		customerFeature.setCreated((Date)mysql.getColumn("created"));
		
		return customerFeature;
	}

	public void setFeature(Feature feature) {
		this.feature = feature;
	}

	public Feature getFeature() {
		return feature;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setCustomerFeatureId(long customerFeatureId) {
		this.customerFeatureId = customerFeatureId;
	}

	public long getCustomerFeatureId() {
		return customerFeatureId;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}

	public long getAmount() {
		return amount;
	}
	
	private long getRemaining() throws FatalException, InvalidParameterException {
		return getAmount() - FeatureManager.getFeatureUsage(this);
	}

}
