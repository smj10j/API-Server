package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.manager.FeatureManager;

@MySQLTable(name=MySQL.TABLES.CUSTOMER_FEATURE_USAGE, 
		primaryKey="customerFeatureUsageId",
		transients={
		}
)
		
public class CustomerFeatureUsage extends DatabaseBackedObject implements Serializable {
		
	private static final long serialVersionUID = 6050645644064500753L;
	
	private long customerFeatureUsageId;
	private CustomerFeature customerFeature;
	private Date created;
	
	public CustomerFeatureUsage(CustomerFeature customerFeature) {
		setCustomerFeature(customerFeature);
	}

	public static CustomerFeatureUsage from(MySQL mysql) throws FatalException, InvalidParameterException {
		CustomerFeature customerFeature = FeatureManager.getCustomerFeature((Long)mysql.getColumn("customer_feature_id"));
		
		CustomerFeatureUsage customerFeatureUsage = new CustomerFeatureUsage(
				customerFeature
		);
		customerFeatureUsage.setCustomerFeatureUsageId((Long)mysql.getColumn("customer_feature_usage_id"));
		customerFeatureUsage.setCreated((Date)mysql.getColumn("created"));
		
		return customerFeatureUsage;
	}

	public void setCustomerFeatureUsageId(long customerFeatureUsageId) {
		this.customerFeatureUsageId = customerFeatureUsageId;
	}

	public long getCustomerFeatureUsageId() {
		return customerFeatureUsageId;
	}
	
	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setCustomerFeature(CustomerFeature customerFeature) {
		this.customerFeature = customerFeature;
	}

	public CustomerFeature getCustomerFeature() {
		return customerFeature;
	}

}
