package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.CustomerInvoiceType;
import com.viralogy.rewardme.manager.CustomerManager;

@MySQLTable(name=MySQL.TABLES.CUSTOMER_INVOICE, 
		primaryKey="customerInvoiceId",
		transients={} )

public class CustomerInvoice extends DatabaseBackedObject implements Serializable {

	private static final long serialVersionUID = 2816738982728157942L;
	private long customerInvoiceId;
	private CustomerBilling customerBilling;
	private long freshbooksInvoiceId;
	private Date dueDate;
	private Date paidDate;
	
	public CustomerInvoice( CustomerBilling customerBilling, long freshbooksInvoiceId,
	    Date dueDate, Date paidDate) {
		setCustomerInvoiceId(customerInvoiceId);
		setCustomerBilling(customerBilling);
		setFreshbooksInvoiceId(freshbooksInvoiceId);
		setDueDate(dueDate);
		setPaidDate(paidDate);
	}
	
	public CustomerInvoice() {
		
	}
	
	public CustomerInvoiceType toCustomerInvoiceType() throws FatalException, InvalidParameterException{
	    CustomerInvoiceType CustomerInvoiceType = new CustomerInvoiceType();
	    CustomerInvoiceType.setCustomerInvoiceId(getCustomerInvoiceId());
	    CustomerInvoiceType.setCustomerBilling(getCustomerBilling().toCustomerBillingType(false));
	    CustomerInvoiceType.setFreshbooksInvoiceId(getFreshbooksInvoiceId());
	    CustomerInvoiceType.setDueDate(getDueDate().getTime());
	    CustomerInvoiceType.setPaidDate(getPaidDate().getTime());
	    return CustomerInvoiceType;
	}
	
	public void setCustomerInvoiceId( long customerInvoiceId) {
		this.customerInvoiceId = customerInvoiceId;
	}
	
	public long getCustomerInvoiceId() {
		return customerInvoiceId;
	}
	
	public void setCustomerBilling(CustomerBilling customerBilling) {
		this.customerBilling = customerBilling;
	}
	
	public CustomerBilling getCustomerBilling() {
		return customerBilling;
	}
	
	public void setFreshbooksInvoiceId( long freshbooksInvoiceId) {
		this.freshbooksInvoiceId = freshbooksInvoiceId;
	}
	
	public long getFreshbooksInvoiceId() {
		return freshbooksInvoiceId;
	}
    
    public void setDueDate( Date dueDate) {
        this.dueDate = dueDate;
    }
    
    public Date getDueDate() {
        return dueDate;
    }
	
	public void setPaidDate(Date paidDate) {
		this.paidDate = paidDate;
	}
	
	public Date getPaidDate() {
		return paidDate;
	}
	
	public static CustomerInvoice from(MySQL mysql) throws FatalException, InvalidParameterException{
	    CustomerInvoice customerInvoice = new CustomerInvoice();
	    
	    customerInvoice.setCustomerInvoiceId((Long)mysql.getColumn("customer_invoice_id"));
	    customerInvoice.setCustomerBilling(CustomerManager.getBilling( (Long)mysql.getColumn("customer_billing_id")));
	    customerInvoice.setFreshbooksInvoiceId((Long)mysql.getColumn("freshbooks_invoice_id"));
	    
	    customerInvoice.setDueDate((Date)mysql.getColumn("due_date"));
	    customerInvoice.setPaidDate((Date)mysql.getColumn( "paid_date" ));
	    
	    return customerInvoice;
	}
	
}

