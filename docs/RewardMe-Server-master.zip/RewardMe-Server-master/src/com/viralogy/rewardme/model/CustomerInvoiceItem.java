package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.math.BigDecimal;

import org.apache.commons.httpclient.NameValuePair;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.CustomerInvoiceItemType;

@MySQLTable(name=MySQL.TABLES.CUSTOMER_INVOICE_ITEM, 
		primaryKey="customerInvoiceItemId",
		transients={} )

public class CustomerInvoiceItem extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = -2040881237907231190L;
	private long customerInvoiceItemId;
	private String name;
	private String description;
	private float unitCost;
	private long quantity;
	private float totalCost;
	
    
	public CustomerInvoiceItem( String name, String description, float unitCost, 
			long quantity, long totalCost) {
		setName(name);
		setDescription(description);
		setUnitCost(unitCost);
		setQuantity(quantity);
		setTotalCost(totalCost);
	}
	
	public CustomerInvoiceItem( String name, String description, float unitCost, 
        long quantity) {
        setName(name);
        setDescription(description);
        setUnitCost(unitCost);
        setQuantity(quantity);
        updateTotalCost();
	}
	
	public CustomerInvoiceItem() {
		
	}
	
	public CustomerInvoiceItemType toCustomerInvoiceItemType() throws InvalidParameterException, FatalException {
	    CustomerInvoiceItemType customerInvoiceItem = new CustomerInvoiceItemType();
	    
	    customerInvoiceItem.setName( getName() );
	    customerInvoiceItem.setDescription( getDescription() );
	    customerInvoiceItem.setUnitCost( getUnitCost() );
	    customerInvoiceItem.setQuantity( getQuantity() );
	    customerInvoiceItem.setTotalCost( getTotalCost() );
	    
	    return customerInvoiceItem;
	}
	
	public NameValuePair[] getNameValuePairs() {
	    
	    NameValuePair[] pairs = {
            new NameValuePair(Constants.Freshbooks.NAME, getName()),
            new NameValuePair(Constants.Freshbooks.DESCRIPTION, getDescription() ),
            new NameValuePair(Constants.Freshbooks.UNIT_COST, getUnitCost()+""),
            new NameValuePair(Constants.Freshbooks.QUANTITY, getQuantity()+""),
        };
	    
	    return pairs;
	}
	
	public void setCustomerInvoiceItemId(long itemId) {
		this.customerInvoiceItemId = itemId;
	}
	
	public long getCustomerInvoiceItemId() {
	    return customerInvoiceItemId;
	}
	
	public void setName(String name) {
	    this.name = name;
	}
	
	public String getName() {
	    return name;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setUnitCost(float unitCost) {
		this.unitCost = unitCost;
	}
	
	public float getUnitCost() {
	    return unitCost;
	}
	
	public void setQuantity( long quantity) {
		this.quantity = quantity;
	}
	
	public long getQuantity() {
	    return quantity;
	}
	
	public void setTotalCost( float totalCost) {
		this.totalCost = totalCost;
	}
	
	public float getTotalCost() {
	    return totalCost;
	}
	
	public void updateTotalCost() {
	    totalCost = unitCost * quantity;
	}

    
    public static CustomerInvoiceItem from(MySQL mysql) throws FatalException, InvalidParameterException {
        CustomerInvoiceItem customerInvoiceItem = new CustomerInvoiceItem();
        
        customerInvoiceItem.setCustomerInvoiceItemId((Long)mysql.getColumn("customer_invoice_item_id"));
        customerInvoiceItem.setName((String)mysql.getColumn( "name" ));
        customerInvoiceItem.setDescription((String)mysql.getColumn( "description" ));
        customerInvoiceItem.setUnitCost( ((BigDecimal)(mysql.getColumn("unit_cost"))).floatValue());
        customerInvoiceItem.setQuantity((Long)mysql.getColumn("quantity") );
        customerInvoiceItem.setTotalCost(((BigDecimal)(mysql.getColumn("total_cost"))).floatValue());
        
        return customerInvoiceItem;
    }
	
	
}
