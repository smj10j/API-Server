package com.viralogy.rewardme.model;

import java.util.Date;

public class CustomerInvoicePayment {

    private long freshbooksClientId;
    private long freshbooksInvoiceId;
    private Date datePaid;
    private Double amount;
    
    public CustomerInvoicePayment( long freshbooksClientId,  long freshbooksInvoiceId, 
    		Date datePaid, double amount) {
    	setFreshbooksClientId( freshbooksClientId );
    	setFreshbooksInvoiceId( freshbooksInvoiceId);
    	setDatePaid( datePaid);
    	setAmount( amount);
    }
    
    public void setFreshbooksClientId( long freshbooksClientId) {
    	this.freshbooksClientId = freshbooksClientId;
    }
    
    public long getFreshbooksClientId() {
    	return freshbooksClientId;
    }
    
    public void setFreshbooksInvoiceId( long freshbooksInvoiceId) {
    	this.freshbooksInvoiceId = freshbooksInvoiceId;
    }
    
    public long getFreshbooksInvoiceId() {
    	return freshbooksInvoiceId;
    }
    
    public void setDatePaid( Date datePaid) {
    	this.datePaid = datePaid;
    }
    
    public Date getDatePaid() {
    	return datePaid;
    }
    
    public void setAmount( double amount) {
    	this.amount = amount;
    }
    
    public double getAmount() {
    	return amount;
    }
}
