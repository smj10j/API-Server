package com.viralogy.rewardme.model;

import java.io.Serializable;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.CustomerInvoiceRecurringType;
import com.viralogy.rewardme.manager.CustomerManager;


@MySQLTable(name=MySQL.TABLES.CUSTOMER_INVOICE_RECURRING, 
		primaryKey="customerInvoiceRecurringId",
		transients={} )

public class CustomerInvoiceRecurring extends DatabaseBackedObject implements Serializable {
	
	
	private static final long serialVersionUID = 8152312833350496234L;
	private long customerInvoiceRecurringId;
	private CustomerBilling customerBilling;
	private long freshbooksRecurringId;
	private boolean stopped;
	private boolean autoBill;

	public CustomerInvoiceRecurring( CustomerBilling customerBilling, long freshbooksRecurringId, boolean stopped, 
	    boolean autoBill) {
	   setCustomerBilling(customerBilling);
	   setFreshbooksRecurringId(freshbooksRecurringId);
	   setStopped(stopped);
	   setAutoBill(autoBill);
	}
	
	public CustomerInvoiceRecurring() {
	    
	}
	
	public CustomerInvoiceRecurringType toCustomerInvoiceRecurringType() throws InvalidParameterException, FatalException {
	    CustomerInvoiceRecurringType customerInvoiceRecurringType = new CustomerInvoiceRecurringType();
	    customerInvoiceRecurringType.setCustomerInvoiceRecurringId(getCustomerInvoiceRecurringId());
	    customerInvoiceRecurringType.setCustomerBilling( getCustomerBilling().toCustomerBillingType( false ) );
	    customerInvoiceRecurringType.setFreshbooksRecurringId( getFreshbooksRecurringId() );
	    customerInvoiceRecurringType.setStopped( isStopped() );
	    customerInvoiceRecurringType.setAutoBill( isAutoBill() );
	    
	    return customerInvoiceRecurringType;
	}
	
	public void setCustomerInvoiceRecurringId( long recurringId) {
	    this.customerInvoiceRecurringId = recurringId;
	}
	
	public long getCustomerInvoiceRecurringId() {
	    return customerInvoiceRecurringId;
	}
	
	public void setCustomerBilling(CustomerBilling customerBilling) {
	    this.customerBilling = customerBilling;
	}
	
	public CustomerBilling getCustomerBilling() {
	    return customerBilling;
	}
	
	public void setFreshbooksRecurringId(long freshbooksRecurringId) {
	    this.freshbooksRecurringId = freshbooksRecurringId;
	}
	
	public long getFreshbooksRecurringId() {
	    return freshbooksRecurringId;
	}
	
	public void setStopped(boolean stopped) {
	    this.stopped = stopped;
	}
	
	public boolean isStopped() {
	    return stopped;
	}
	
	public void setAutoBill(boolean autoBill) {
	    this.autoBill = autoBill;
	}
	
	public boolean isAutoBill() {
	    return autoBill;
	}

    public static CustomerInvoiceRecurring from(MySQL mysql) throws FatalException, InvalidParameterException{
        CustomerInvoiceRecurring customerInvoiceRecurring = new CustomerInvoiceRecurring();
        
        customerInvoiceRecurring.setCustomerInvoiceRecurringId((Long)mysql.getColumn( "customer_invoice_recurring_id" ));
        customerInvoiceRecurring.setCustomerBilling(CustomerManager.getBilling((Long)mysql.getColumn("customer_billing_id" )) );
        customerInvoiceRecurring.setFreshbooksRecurringId((Long)mysql.getColumn("freshbooks_recurring_id") );
        customerInvoiceRecurring.setStopped((Boolean)mysql.getColumn("stopped") );
        customerInvoiceRecurring.setAutoBill((Boolean)mysql.getColumn("auto_bill"));
        
        return customerInvoiceRecurring;
    }
}
