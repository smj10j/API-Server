package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.CustomerPreferenceType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CustomerManager;

@MySQLTable(name=MySQL.TABLES.CUSTOMER_PREFERENCE, 
		primaryKey="customerPreferenceId",
		transients={}
)

public class CustomerPreference extends DatabaseBackedObject implements Serializable{

	private static final long serialVersionUID = -4143459257621585749L;
	
	public static final class KEYS {
		public static final String NAME = "name";
	}
	
	private long customerPreferenceId;
	private Customer customer;
	private Address address;
	private String name;
	private String value;
	private Date updated;
	private Date created;
	
	public CustomerPreference() {
		
	}
	
	public CustomerPreference(Customer customer, Address address, String name, String value ) {
		setCustomer(customer);
		setAddress(address);
		setName(name);
		setValue(value);
	}
	
	public String toString() {
		return "Id: " + customerPreferenceId;
	}
	
	public CustomerPreferenceType toCustomerPreferenceType() throws InvalidParameterException, FatalException {
		CustomerPreferenceType customerPreferenceType = new CustomerPreferenceType();
		customerPreferenceType.setCustomerPreferenceId(getCustomerPreferenceId());
		customerPreferenceType.setName(getName());
		customerPreferenceType.setValue(getValue());
		customerPreferenceType.setCreated(getCreated().getTime());
		customerPreferenceType.setUpdated(getUpdated().getTime());
		customerPreferenceType.setPrivate(getCustomer() == null ? false : true );
		
		return customerPreferenceType;
	}
	
	public static CustomerPreference from(MySQL mysql ) throws FatalException, InvalidParameterException {
		CustomerPreference customerPreference = new CustomerPreference();
		customerPreference.setCustomerPreferenceId((Long) mysql.getColumn("customer_preference_id"));
		customerPreference.setCustomer(CustomerManager.getCustomer((Long) mysql.getColumn("customer_id")));
		Long addressId = (Long) mysql.getColumn("address_id");
		if(addressId != null && addressId != 0) {
			customerPreference.setAddress(AddressManager.getAddress(addressId, true ));
		}
		customerPreference.setName((String)mysql.getColumn("name"));
		customerPreference.setValue((String)mysql.getColumn("value"));
		customerPreference.setCreated((Date)mysql.getColumn("created"));
		customerPreference.setUpdated((Date)mysql.getColumn("updated"));
		
		return customerPreference;
	}
	
	public void setCustomerPreferenceId(long customerPreferenceId) {
		this.customerPreferenceId = customerPreferenceId;
	}
	
	public long getCustomerPreferenceId() {
		return customerPreferenceId;
	}
	
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	public Customer getCustomer() {
		return customer;
	}
	
	public void setName(String name ) {
		this.name = name == null ? null : name.toLowerCase();
	}
	
	public String getName() {
		return name;
	}
	
	public void setValue(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}
	
	public Date getUpdated() {
		return updated;
	}
	
	public void setUpdated(Date updated) {
		this.updated = updated;
	}
	
	public void setCreated(Date created) { 
		this.created = created;
	}
	
	public Date getCreated() { 
		return created;
	}
	
	public void setAddress(Address address) {
		this.address = address;
	}
	
	public Address getAddress() {
		return address;
	}
}
