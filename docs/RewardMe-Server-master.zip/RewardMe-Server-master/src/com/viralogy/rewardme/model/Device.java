package com.viralogy.rewardme.model;

import java.io.Serializable;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.DeviceType;
import com.viralogy.rewardme.manager.DeviceManager;


@MySQLTable(name=MySQL.TABLES.DEVICE, 
		primaryKey="deviceId",
		transients={
			"deviceApplication"
		}
)

public class Device extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = -4159026185944895014L;
	
	private String deviceId;
	private String remoteDeviceUUID;
	private String osName;
	private String osVersion;
	private String model;
	private DeviceApplication deviceApplication;//transient
	
	public Device(String deviceId) {
		setDeviceId(deviceId);
	}
	
	public String toString() {
		return "Id: " + deviceId + ", os: " + osName + " " + osVersion + ", model: " + model;
	}
	
	public DeviceType toDeviceType() throws InvalidParameterException, FatalException {
		DeviceType deviceType = new DeviceType();
		deviceType.setDeviceId(getDeviceId());
		deviceType.setRemoteDeviceUUID(getRemoteDeviceUUID());
		deviceType.setOsName(getOsName());
		deviceType.setModel(getModel());
		deviceType.setOsVersion(getOsVersion());
		return deviceType;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getModel() {
		return model;
	}

	public void setOsVersion(String osVersion) {
		this.osVersion = osVersion;
	}

	public String getOsVersion() {
		return osVersion;
	}

	public void setOsName(String osName) {
		this.osName = osName;
	}

	public String getOsName() {
		return osName;
	}
	
	public static Device from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		Device device = new Device((String)mysql.getColumn("device_id"));
		device.setRemoteDeviceUUID((String)mysql.getColumn("remote_device_uuid"));
		device.setOsName((String)mysql.getColumn("os_name"));
		device.setOsVersion((String)mysql.getColumn("os_version"));
		device.setModel((String)mysql.getColumn("model"));
		
		return device;
	}

	public void setRemoteDeviceUUID(String remoteDeviceUUID) {
		this.remoteDeviceUUID = remoteDeviceUUID;
	}

	public String getRemoteDeviceUUID() {
		return remoteDeviceUUID;
	}

	public DeviceApplication getDeviceApplication() throws InvalidParameterException, FatalException {
		if(deviceApplication == null) {
			deviceApplication = DeviceManager.getDeviceApplication(this);
		}
		return deviceApplication;
	}	
}
