package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.DeviceApplicationType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.ApplicationManager;
import com.viralogy.rewardme.manager.CheckinOptionManager;
import com.viralogy.rewardme.manager.DeviceManager;

@MySQLTable(name=MySQL.TABLES.DEVICE_APPLICATION, 
		primaryKey="deviceApplicationId",
		transients={}
)

public class DeviceApplication extends DatabaseBackedObject implements Serializable {
		
	private static final long serialVersionUID = -4326078996684821519L;
		
	private long deviceApplicationId;
	private Application application;
	private Device device;
	private Address address;
	private CheckinOption checkinOption;
	private Date updated;
	private Date created;
	
	public DeviceApplication() {
		
	}
	
	public DeviceApplication(Device device, UnlinkedDeviceApplication unlinkedDeviceApplication) {
		setDevice(device);
		setApplication(unlinkedDeviceApplication.getApplication());
		setAddress(unlinkedDeviceApplication.getAddress());
		setCheckinOption(unlinkedDeviceApplication.getCheckinOption());
	}

	public DeviceApplicationType toDeviceApplicationType() throws FatalException, InvalidParameterException {
		DeviceApplicationType deviceApplicationType = new DeviceApplicationType();
		deviceApplicationType.setDeviceApplicationId(getDeviceApplicationId());
		deviceApplicationType.setApplication(getApplication().toApplicationType(false));
		deviceApplicationType.setDevice(getDevice().toDeviceType());
		deviceApplicationType.setAddress(getAddress().toAddressType());
		deviceApplicationType.setCheckinOption(getCheckinOption() == null ? null : getCheckinOption().toCheckinOptionType());
		deviceApplicationType.setUpdated(getUpdated() == null ? null : getUpdated().getTime());
		deviceApplicationType.setCreated(getCreated() == null ? null : getCreated().getTime());
		return deviceApplicationType;
	}
	
	public static DeviceApplication from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		DeviceApplication deviceApplication = new DeviceApplication();
		deviceApplication.setDeviceApplicationId((Long)mysql.getColumn("device_application_id"));
		deviceApplication.setApplication(ApplicationManager.getApplication((Long)mysql.getColumn("application_id")));
		deviceApplication.setDevice(DeviceManager.getDevice((String)mysql.getColumn("device_id")));
		deviceApplication.setAddress(AddressManager.getAddress((Long)mysql.getColumn("address_id"), false));
		Long checkinOptionId = (Long)mysql.getColumn("checkin_option_id");
		if(checkinOptionId != null) {
			deviceApplication.setCheckinOption(CheckinOptionManager.getCheckinOption(checkinOptionId));
		}
		deviceApplication.setUpdated((Date)mysql.getColumn("updated"));		
		deviceApplication.setCreated((Date)mysql.getColumn("created"));		
				
		deviceApplication.takeFieldValuesSnapshot();
		
		return deviceApplication;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}

	public void setUpdated(Date updated) {
		this.updated = updated;
	}

	public Date getUpdated() {
		return updated;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}


	public void setCheckinOption(CheckinOption checkinOption) {
		this.checkinOption = checkinOption;
	}


	public CheckinOption getCheckinOption() {
		return checkinOption;
	}


	public void setDevice(Device device) {
		this.device = device;
	}


	public Device getDevice() {
		return device;
	}

	public void setDeviceApplicationId(long deviceApplicationId) {
		this.deviceApplicationId = deviceApplicationId;
	}

	public long getDeviceApplicationId() {
		return deviceApplicationId;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public Application getApplication() {
		return application;
	}
	
	
}