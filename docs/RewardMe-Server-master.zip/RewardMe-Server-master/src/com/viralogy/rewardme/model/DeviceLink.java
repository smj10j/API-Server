package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.DeviceLinkType;
import com.viralogy.rewardme.manager.DeviceManager;
import com.viralogy.rewardme.manager.ServerManager;

@MySQLTable(name=MySQL.TABLES.DEVICE_LINK, 
		primaryKey="deviceLinkId",
		transients={}
)
		
public class DeviceLink extends DatabaseBackedObject implements Serializable {
			
	/*
	 * Device1's id should always be alphabetically lower than Device2's id
	 */
	
	private static final long serialVersionUID = -5453115984026832875L;
	
	private long deviceLinkId;
	private Device device1;
	private Device device2;
	private Server server;
	private Date updated;
	private Date created;
			
	public DeviceLink(Device device1, Device device2, Server server) throws FatalException {
		
		Device swap = device1;
		if(device1.getDeviceId().compareTo(device2.getDeviceId()) > 0) {
			device1 = device2;
			device2 = swap;
		}
		
		setDevice1(device1);
		setDevice2(device2);
		setServer(server);
	}
	

	public DeviceLinkType toDeviceLinkType() throws FatalException, InvalidParameterException {
		DeviceLinkType deviceLinkType = new DeviceLinkType();
		deviceLinkType.setDeviceLinkId(getDeviceLinkId());
		deviceLinkType.setDevice1(getDevice1().toDeviceType());
		deviceLinkType.setDevice2(getDevice2().toDeviceType());
		deviceLinkType.setServer(getServer().toServerType());
		deviceLinkType.setCreated(getCreated() == null ? null : getCreated().getTime());
		deviceLinkType.setUpdated(getUpdated() == null ? null : getUpdated().getTime());
		return deviceLinkType;
	}


	public void setDeviceLinkId(long deviceLinkId) {
		this.deviceLinkId = deviceLinkId;
	}

	public long getDeviceLinkId() {
		return deviceLinkId;
	}

	private void setDevice1(Device device1) {
		this.device1 = device1;
	}

	public Device getDevice1() {
		return device1;
	}

	private void setDevice2(Device device2) {
		this.device2 = device2;
	}

	public Device getDevice2() {
		return device2;
	}

	public void setServer(Server server) {
		this.server = server;
	}

	public Server getServer() {
		return server;
	}

	public void setUpdated(Date updated) {
		this.updated = updated;
	}

	public Date getUpdated() {
		return updated;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public static DeviceLink from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		DeviceLink deviceLink = new DeviceLink(
			DeviceManager.getDevice((String)mysql.getColumn("device1_id")),
			DeviceManager.getDevice((String)mysql.getColumn("device2_id")),
			ServerManager.getServer((Long)mysql.getColumn("server_id"))	
		);
		deviceLink.setDeviceLinkId((Long)mysql.getColumn("device_link_id"));
		deviceLink.setCreated((Date)mysql.getColumn("created"));
		deviceLink.setUpdated((Date)mysql.getColumn("updated"));
				
		return deviceLink;
	}
}
