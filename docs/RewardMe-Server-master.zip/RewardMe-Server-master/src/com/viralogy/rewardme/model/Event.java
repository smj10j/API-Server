package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.httpclient.NameValuePair;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.EventType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.AdminManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.DeviceManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.servlet.GatewayServlet;
import com.viralogy.rewardme.util.RemoteRequestUtil;
import com.viralogy.rewardme.util.SecurityUtil;
import com.viralogy.rewardme.util.StringUtil;

@MySQLTable(name=MySQL.TABLES.EVENT, 
		primaryKey="eventId",
		transients={
		}
)
		
public class Event extends DatabaseBackedObject implements Serializable {

	private static final long serialVersionUID = -2502834304074972905L;
	
	private static Set<String> IGNORE_EVENTS = new HashSet<String>();
	static {
		IGNORE_EVENTS.add("server.status");
		IGNORE_EVENTS.add("device.authenticate");
		IGNORE_EVENTS.add("application.saveObservations");
	}
	
	private long eventId;
	private String name;
	private String value;
	private Customer customer;
	private Address address;
	private User user;
	private Device device;
	private Date created;
	private SecretKey secretKey;
	private boolean admin;
	
	public Event(Customer customer, User user, Device device, Address address, String name, String value, boolean admin, SecretKey secretKey) {
		setName(name);
		setValue(value);
		setCustomer(customer);
		setDevice(device);
		setAddress(address);
		setUser(user);
		setAdmin(admin);
		setSecretKey(secretKey);
	}	
	
	//convenience method
	public void saveAsync() throws InvalidParameterException, FatalException {
		
		if(StringUtil.isNullOrEmpty(getName()) || IGNORE_EVENTS.contains(getName().toLowerCase())) {
			return;
		}
		
		NameValuePair[] parameters = {
			new NameValuePair(Constants.Request.NAME, getName()),
			new NameValuePair(Constants.Request.VALUE, getValue()),
			new NameValuePair(Constants.Request.USER_ID, getUser() == null ? null : getUser().getUserId()+""),
			new NameValuePair(Constants.Request.DEVICE_ID, getDevice() == null ? null : getDevice().getDeviceId()),
			new NameValuePair(Constants.Request.CUSTOMER_ID, getCustomer() == null ? null : getCustomer().getCustomerId()+""),
			new NameValuePair(Constants.Request.ADDRESS_ID, getAddress() == null ? null : getAddress().getAddressId()+""),
			new NameValuePair(Constants.Request.SECRET_KEY_ID, getSecretKey() == null ? null : getSecretKey().getSecretKeyId()+""),
			new NameValuePair(Constants.Request.ADMIN, isAdmin()+"")
		};

		RemoteRequestUtil.post(GatewayServlet.getLocalServerBaseUrl()+"log", parameters, null, null, true);
	}

	public EventType toEventType() throws InvalidParameterException, FatalException {
		EventType eventType = new EventType();
		eventType.setCustomer(customer == null ? null : customer.toCustomerType(user, false, false));
		eventType.setAddress(address == null ? null : address.toAddressType());
		eventType.setUser(user == null ? null : user.toUserType(null));
		eventType.setDevice(getDevice() == null ? null : device.toDeviceType());
		eventType.setAdmin(admin);
		eventType.setName(name);
		eventType.setValue(value);
		eventType.setCreated(getCreated() == null ? null : created.getTime());
		return eventType;
	}
	
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public User getUser() {
		return user;
	}
	

	public static Event from(MySQL mysql) throws FatalException, InvalidParameterException {
		Customer customer = null;
		User user = null;
		Device device = null;
		Address address = null;
		SecretKey secretKey = null;
		
		Long userId = (Long)mysql.getColumn("user_id");
		Long addressId = (Long)mysql.getColumn("address_id");
		Long customerId = (Long)mysql.getColumn("customer_id");
		Long secretKeyId = (Long)mysql.getColumn("secret_key_id");
		String deviceId = (String)mysql.getColumn("device_id");
		
		if(addressId != null) {
			try {
				address = AddressManager.getAddress(addressId, false);
			}catch(InvalidParameterException e) {
				//ignore
			}
		}
		if(customerId != null) {
			try {
				customer = CustomerManager.getCustomer(customerId);
			}catch(InvalidParameterException e) {
				//ignore
			}
		}
		if(userId != null) {
			try {
				user = UserManager.getUser(userId);
			}catch(InvalidParameterException e) {
				//ignore
			}
		}
		if(deviceId != null) {
			try {
				device = DeviceManager.getDevice(deviceId);
			}catch(InvalidParameterException e) {
				//ignore
			}
		}
		
		if(secretKeyId != null) {
			try {
				secretKey = AdminManager.getSecretKey(secretKeyId);
			}catch(InvalidParameterException e) {
				//ignore - secret keys can be removed
			}
		}

		Event event = new Event(
			customer,
			user,
			device,
			address, 
			(String)mysql.getColumn("name"),
			(String)mysql.getColumn("value"), 
			(Boolean)mysql.getColumn("admin"), secretKey
		);
		
		event.setEventId((Long)mysql.getColumn("event_id"));
		event.setCreated((Date)mysql.getColumn("created"));
		
		return event;
	}

	public void setEventId(long logEventId) {
		this.eventId = logEventId;
	}

	public long getEventId() {
		return eventId;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setAdmin(Boolean admin) {
		this.admin = (admin == null ? false : admin);
	}

	public boolean isAdmin() {
		return admin;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}
	
	/**
	 * @return a 64-byte string
	 * @throws FatalException
	 */
	public String hash() throws FatalException {
		String data1 = "" + 
			(getUser()==null ? "" : getUser().getUserId()+"|")+
			(getCustomer()==null ? "" : getCustomer().getCustomerId()+"|")+
			(getAddress()==null ? "" : getAddress().getAddressId());
		String data2 = ""+
			getName()+"|"+
			getValue();		
		
		return SecurityUtil.md5(data1).substring(0,31) + "|" +  SecurityUtil.md5(data2);
	}

	public SecretKey getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(SecretKey secretKey) {
		this.secretKey = secretKey;
	}

	public Device getDevice() {
		return device;
	}

	public void setDevice(Device device) {
		this.device = device;
	}
}
