package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.EventTriggerType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.DeviceManager;
import com.viralogy.rewardme.manager.UserManager;

@MySQLTable(name=MySQL.TABLES.EVENT_TRIGGER, 
		primaryKey="eventTriggerId",
		transients={
		}
)
		
public class EventTrigger extends Trigger implements Serializable {

	private static final long serialVersionUID = -2502834304074972905L;
	
	private long eventTriggerId;
	private String eventName;
	private String eventValue;
	private String eventHash;
	
	public EventTrigger(Event event, Type type, Long typeId, String data) throws FatalException {
		super(event, type, typeId, data);
		setEventName(event.getName());
		setEventValue(event.getValue());
		setEventHash(event.hash());
	}	
	
	public EventTriggerType toEventTriggerType() throws InvalidParameterException, FatalException {
		EventTriggerType eventTriggerType = new EventTriggerType();
		eventTriggerType.setEventTriggerId(getEventTriggerId());
		eventTriggerType.setCustomer(getCustomer() == null ? null : getCustomer().toCustomerType(getUser(), false, false));
		eventTriggerType.setAddress(getAddress() == null ? null : getAddress().toAddressType());
		eventTriggerType.setUser(getUser() == null ? null : getUser().toUserType(null));
		eventTriggerType.setName(getEventName());
		eventTriggerType.setValue(getEventValue());
		eventTriggerType.setEventHash(getEventHash());
		eventTriggerType.setType(getType().toString());
		eventTriggerType.setTypeId(getTypeId());
		eventTriggerType.setData(getData());
		eventTriggerType.setCreated(getCreated() == null ? null : getCreated().getTime());
		return eventTriggerType;
	}
	
	public static EventTrigger from(MySQL mysql) throws FatalException, InvalidParameterException {
		Long addressId = (Long)mysql.getColumn("address_id");
		//TODO: add deviceId?
		String deviceId = null;

		EventTrigger eventTrigger = new EventTrigger(
			new Event(
				CustomerManager.getCustomer((Long)mysql.getColumn("customer_id")), 
				UserManager.getUser((Long)mysql.getColumn("user_id")), 
				deviceId == null ? null : DeviceManager.getDevice(deviceId), 
				addressId == null ? null : AddressManager.getAddress(addressId, false), 
				(String)mysql.getColumn("event_name"),
				(String)mysql.getColumn("event_value"), 
				false, 
				null
			),
			Type.valueOf((String)mysql.getColumn("type")),
			(Long)mysql.getColumn("type_id"), 
			(String)mysql.getColumn("data")
		);
		
		eventTrigger.setEventHash((String)mysql.getColumn("event_hash"));
		eventTrigger.setTriggered((Boolean)mysql.getColumn("triggered"));
		eventTrigger.setArchived((Boolean)mysql.getColumn("archived"));
		eventTrigger.setEventTriggerId((Long)mysql.getColumn("event_trigger_id"));
		eventTrigger.setCreated((Date)mysql.getColumn("created"));
		
		eventTrigger.takeFieldValuesSnapshot();
		
		return eventTrigger;
	}

	public void setEventValue(String eventValue) {
		this.eventValue = eventValue;
	}

	public String getEventValue() {
		return eventValue;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEventName() {
		return eventName;
	}


	public void setEventTriggerId(long eventTriggerId) {
		this.eventTriggerId = eventTriggerId;
	}

	public long getEventTriggerId() {
		return eventTriggerId;
	}

	public void setEventHash(String eventHash) {
		this.eventHash = eventHash;
	}

	public String getEventHash() {
		return eventHash;
	}
	
	
	
	
	
	
	
	
	
	
	/*
	 * 
	 *This is all for DatabaseBackedObject
	 */
	
	public Customer getCustomer() {
		return super.getCustomer();
	}

	public User getUser() {
		return super.getUser();
	}

	public Date getCreated() {
		return super.getCreated();
	}

	public Address getAddress() {
		return super.getAddress();
	}

	public Long getTypeId() {
		return super.getTypeId();
	}

	public Type getType() {
		return super.getType();
	}

	public boolean isTriggered() {
		return super.isTriggered();
	}

	public boolean isArchived() {
		return super.isArchived();
	}
	
	public String getData() {
		return super.getData();
	}

}
