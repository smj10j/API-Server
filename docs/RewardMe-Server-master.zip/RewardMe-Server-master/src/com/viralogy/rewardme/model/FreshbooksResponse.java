package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.List;

public class FreshbooksResponse implements Serializable {

    
    private static final long serialVersionUID = -5366093749227397821L;
    
    private long freshbooksId;
    
    private CustomerInvoice customerInvoice;
    private CustomerInvoicePayment customerInvoicePayment;
    private List<CustomerInvoiceItem> customerInvoiceItems;
    
    public void setFreshbooksId( long freshbooksId ) {
        this.freshbooksId = freshbooksId;
    }
    
    public long getFreshbooksId( ) {
        return freshbooksId;
    }
    
    public void setCustomerInvoice (CustomerInvoice customerInvoice ) {
        this.customerInvoice = customerInvoice;
    }
    
    public CustomerInvoice getCustomerInvoice() {
        return customerInvoice;
    }
    
    public void setCustomerInvoicePayment( CustomerInvoicePayment customerInvoicePayment) {
    	this.customerInvoicePayment = customerInvoicePayment;
    }
    
    public CustomerInvoicePayment getCustomerInvoicePayment() {
    	return customerInvoicePayment;
    }
    
    public void setCustomerInvoiceItems( List<CustomerInvoiceItem> customerInvoiceItems) {
        this.customerInvoiceItems = customerInvoiceItems;
    }
    
    public List<CustomerInvoiceItem> getCustomerInvoiceItems() {
        return customerInvoiceItems;
    }
    
    
    
    
}
