package com.viralogy.rewardme.model;

import java.io.Serializable;

import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.GeoCoordType;
import com.viralogy.rewardme.util.Cache;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.RemoteRequestUtil;

public class GeoCoord implements Serializable {
		
	private static final long serialVersionUID = -6585691011747045757L;

	private double latitude;
	private double longitude;
	
	public GeoCoord(long longitudeE6, long latitudeE6) {
		setLongitudeE6(longitudeE6);
		setLatitudeE6(latitudeE6);
	}
	
	public GeoCoord(double longitude, double latitude) {
		setLongitude(longitude);
		setLatitude(latitude);
	}
	
	public static GeoCoord fromRadians(double longitudeRadians, double latitudeRadians) {
		return new GeoCoord((longitudeRadians * 180.0f) / Constants.PI, (latitudeRadians * 180.0f) / Constants.PI);
	}
	
	public String toString() {
		return getLatitude() + ", " + getLongitude();
	}
	
	public GeoCoordType toGeoCoordType() {
		GeoCoordType geoCoordType = new GeoCoordType();
		geoCoordType.setLatitudeE6(getLatitudeE6());
		geoCoordType.setLongitudeE6(getLongitudeE6());
		return geoCoordType;
	}

	public double distanceTo(GeoCoord geoCoord) {
		return Math.acos(Math.sin(getLatitudeRadians()) * Math.sin(geoCoord.getLatitudeRadians()) +
				Math.cos(getLatitudeRadians()) * Math.cos(geoCoord.getLatitudeRadians()) *
				Math.cos(getLongitudeRadians() - geoCoord.getLongitudeRadians())) * Constants.Distance.RADIUS_OF_EARTH;
	}

	public double degreesTo(GeoCoord geoCoord) {
		double dLng = geoCoord.getLongitudeRadians() - getLongitudeRadians();
		double y = Math.sin(dLng) * Math.cos(geoCoord.getLatitudeRadians());
		double x = (Math.cos(getLatitudeRadians()) * Math.sin(geoCoord.getLatitudeRadians())) - 
				   (Math.sin(getLatitudeRadians()) * Math.cos(geoCoord.getLatitudeRadians())*Math.cos(dLng));
		double degrees = (Math.atan2(y,x) * 180.0f) / Constants.PI;
		if(degrees < 0) {
			degrees+= 360;
		}
		
		return degrees;
	}
	
	public String reverseGeocode() throws FatalException, InvalidParameterException {
		String address = Cache.get(this.toString(), Cache.namespace.REVERSE_GEOCODE);
		if(address == null) {		
			String response = RemoteRequestUtil.get(
				"http://maps.google.com/maps/api/geocode/json", 
				"latlng="+getLatitude()+","+getLongitude()+"&sensor=false", false
			);
			try {
				JSONObject responseObject = new JSONObject(response);
				JSONObject result = null;
				try {
					result = responseObject.getJSONArray("results").getJSONObject(0);
				}catch(JSONException e) {
					//this means we failed to reverse geo these coords
					throw new InvalidParameterException(Constants.Error.GENERAL.INVALID_COORDS_FOR_REVERSE_GEOCODING, ListUtil.from(this.toString()));
				}
				address = result.getString("formatted_address");
				Cache.put(address, this.toString(), Cache.namespace.REVERSE_GEOCODE);
			}catch(JSONException e) {
				throw new FatalException(e);
			}
		}
		return address;
	}
	
	/*
	 * Increasing the multipliers will increase the granularity of regions
	 */
	public long getRegionId() {
		double m = (getLatitude()*1000) + getLongitude()*100;
		long r = Math.round(m / 100);
		return r;
	}
	
	public void setLatitudeE6(long latitudeE6) {
		this.latitude = latitudeE6 / 1E6;
	}

	public long getLatitudeE6() {
		return (long)(latitude * 1E6);
	}
	
	public double getLatitudeRadians() {
		return (latitude / 180.0f) * Constants.PI;
	}

	public void setLongitudeE6(long longitudeE6) {
		this.longitude = longitudeE6 / 1E6;
	}

	public long getLongitudeE6() {
		return (long)(longitude * 1E6);
	}

	public double getLongitudeRadians() {
		return (longitude / 180.0f) * Constants.PI;
	}
	
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getLongitude() {
		return longitude;
	}
	
}
