package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.InventoryItemType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.UserManager;


@MySQLTable(name=MySQL.TABLES.INVENTORY_ITEM, 
		primaryKey="inventoryItemId",
		transients={
		}
)

public class InventoryItem extends DatabaseBackedObject implements Serializable {

	private static final long serialVersionUID = -4159026185944895014L;
	
	private String serial;
	private Address address;
	private Customer customer;
	private User user;	//phone number
	private String type;
	private String description;
	private long inventoryItemId;
	private Date created;
	
	public InventoryItemType toInventoryItemType() throws FatalException, InvalidParameterException {
		InventoryItemType inventoryItemType = new InventoryItemType();
		inventoryItemType.setAddress(address == null ? null : address.toAddressType());
		inventoryItemType.setCustomer(customer == null ? null : customer.toCustomerType(user, false, false));
		inventoryItemType.setUser(user == null ? null : user.toUserType(null));
		inventoryItemType.setInventoryItemId(getInventoryItemId());
		inventoryItemType.setSerial(getSerial());
		inventoryItemType.setDescription(getDescription());
		inventoryItemType.setType(getType());
		inventoryItemType.setCreated(getCreated() == null ? null: getCreated().getTime());
		
		return inventoryItemType;
	}
	
	public InventoryItem(String serial, Address address, Customer customer, String type) {
		setSerial(serial);
		setAddress(address);
		setCustomer(customer);
		setType(type);
	}
	
	public InventoryItem(String serial, Address address, Customer customer, User user, String type, String description) {
		setUser(user);
		setSerial(serial);
		setAddress(address);
		setCustomer(customer);
		setType(type);
		setDescription(description); 
	}
	
	public static InventoryItem from(MySQL mysql) throws InvalidParameterException, FatalException {
		User user = null;
		Address address = null;
		Customer customer = null;
		
		Long userId = (Long)mysql.getColumn("user_id");
		Long addressId = (Long)mysql.getColumn("address_id");
		Long customerId = (Long)mysql.getColumn("customer_id");
		String serial = (String)mysql.getColumn("serial");
		String type = (String)mysql.getColumn("type");
		String description = (String)mysql.getColumn("description");
				
		if(userId != null)
			user = UserManager.getUser(userId);
		
		if(addressId != null)
			address = AddressManager.getAddress(addressId,false);
		
		if(customerId != null)
			customer = CustomerManager.getCustomer(customerId);
						
		InventoryItem inventoryItem = new InventoryItem(serial, address, customer, user, type, description);
	
		inventoryItem.setCreated((Date)mysql.getColumn("created"));
		inventoryItem.setInventoryItemId((Long)mysql.getColumn("inventory_item_id"));

		
		return inventoryItem;
	}

	public String getSerial() {
		return serial;
	}

	public void setSerial(String serial) {
		this.serial = serial;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public long getInventoryItemId() {
		return inventoryItemId;
	}

	public void setInventoryItemId(long inventoryItemId) {
		this.inventoryItemId = inventoryItemId;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
}