package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;
import java.math.BigDecimal;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.RewardManager;

@MySQLTable(name=MySQL.TABLES.LOTTERY, 
		primaryKey="lotteryId",
		transients={
			"customer"
		}
)
		
public class Lottery extends DatabaseBackedObject implements Serializable {

	private static final long serialVersionUID = 3691037169160443972L;

	private long lotteryId;
	private double percentChance;
	private long numberOfPrizes;

	private Date created;
	private Customer customer;
	private Reward reward;
	
	public Lottery(Customer customer, Reward reward, double percentChance, long numberOfPrizes) {
		setPercentChance(percentChance);
		setNumberOfPrizes(numberOfPrizes);
		setCustomer(customer);
		setReward(reward);
	}

	public void setLotteryId(long lotteryId) {
		this.lotteryId = lotteryId;
	}

	public long getLotteryId() {
		return lotteryId;
	}
	
	public void setPercentChance(double percentChance) {
		this.percentChance = percentChance;
	}
	
	public double getPercentChance() {
		return percentChance;
	}
	
	public void setNumberOfPrizes(long numberOfPrizes) {
		this.numberOfPrizes = numberOfPrizes;
	}
	
	public long getNumberOfPrizes() {
		return numberOfPrizes;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}
	
	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}
	
	public Reward getReward() {
		return reward;
	}

	public void setReward(Reward reward) {
		this.reward = reward;
	}
	
	public static Lottery from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		Customer customer = CustomerManager.getCustomer((Long)mysql.getColumn("customer_id"));
		Reward reward = RewardManager.getReward((Long)mysql.getColumn("reward_id"));
		
		Lottery lottery = new Lottery(
				customer, 
				reward, 
				((BigDecimal)mysql.getColumn("percent_chance")).doubleValue(),
				(Long)mysql.getColumn("number_of_prizes")
		);
		
		lottery.setLotteryId((Long)mysql.getColumn("lottery_id"));
		
		return lottery;
	}	
}
