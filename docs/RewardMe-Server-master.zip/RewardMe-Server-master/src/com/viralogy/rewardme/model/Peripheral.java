package com.viralogy.rewardme.model;

import java.io.Serializable;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.manager.DeviceManager;


@MySQLTable(name=MySQL.TABLES.PERIPHERAL, 
		primaryKey="peripheralId",
		transients={

		}
)

public class Peripheral extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = 8861658186335580392L;
	
	public static enum Type {
		SAVERMINT
	}
	
	private String peripheralId;
	private String externalPeripheralId;
	private DeviceApplication deviceApplication;
	private Type type;

	public Peripheral(String externalPeripheralId, Type type, DeviceApplication deviceApplication) {
		setExternalPeripheralId(externalPeripheralId);
		setType(type);
		setDeviceApplication(deviceApplication);
	}
	
	public static Peripheral from(MySQL mysql) throws FatalException, InvalidParameterException {
		Peripheral peripheral = new Peripheral(
			(String)mysql.getColumn("external_peripheral_id"),
			Type.valueOf((String)mysql.getColumn("type")),
			DeviceManager.getDeviceApplication((Long)mysql.getColumn("device_application_id"))
		);
		
		return peripheral;
	}

	public void setPeripheralId(String peripheralId) {
		this.peripheralId = peripheralId;
	}

	public String getPeripheralId() {
		return peripheralId;
	}

	public void setExternalPeripheralId(String externalPeripheralId) {
		this.externalPeripheralId = externalPeripheralId;
	}

	public String getExternalPeripheralId() {
		return externalPeripheralId;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Type getType() {
		return type;
	}

	public void setDeviceApplication(DeviceApplication deviceApplication) {
		this.deviceApplication = deviceApplication;
	}

	public DeviceApplication getDeviceApplication() {
		return deviceApplication;
	}	
}
