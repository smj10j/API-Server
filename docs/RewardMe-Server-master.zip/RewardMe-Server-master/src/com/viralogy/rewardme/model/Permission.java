package com.viralogy.rewardme.model;

import java.io.Serializable;


import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;

@MySQLTable(name=MySQL.TABLES.PERMISSION, 
		primaryKey="permissionId",
		transients={}
)
public class Permission extends DatabaseBackedObject implements Serializable {
		
	private static final long serialVersionUID = 6094010661530093295L;
	
	private long permissionId;
	private String name;
		
	public Permission(String name) {
		setName(name);
	}
	
	public Permission(long permissionId, String name) {
		setPermissionId(permissionId);
		setName(name);
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public static Permission from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		Permission permission = new Permission(
				(Long)mysql.getColumn("permission_id"),
				(String)mysql.getColumn("address")
		);

		return permission;
	}

	public void setPermissionId(long permissionId) {
		this.permissionId = permissionId;
	}

	public long getPermissionId() {
		return permissionId;
	}
}
