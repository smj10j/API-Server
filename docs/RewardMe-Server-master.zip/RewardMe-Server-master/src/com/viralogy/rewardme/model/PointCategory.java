package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.PointCategoryType;
import com.viralogy.rewardme.manager.CustomerManager;

@MySQLTable(name=MySQL.TABLES.POINT_CATEGORY, 
		primaryKey="pointCategoryId",
		transients={}
)

public class PointCategory extends DatabaseBackedObject implements Serializable {
				
	private static final long serialVersionUID = 466501890623468769L;
	
	private long pointCategoryId;
	private String name;
	private Customer customer;
	private long weight;
	private Date updated;
	private Date created;
	
	public PointCategory() {
		
	}
	
	public PointCategory(Customer customer, String name, long weight) {
		setName(name);
		setCustomer(customer);
		setWeight(weight);
	}

	public PointCategoryType toPointCategoryType() throws FatalException, InvalidParameterException {
		PointCategoryType pointCategoryType = new PointCategoryType();
		//pointCategoryType.setCustomer(getCustomer().toCustomerType(null, false, false));
		pointCategoryType.setName(getName());
		pointCategoryType.setWeight(getWeight());
		pointCategoryType.setUpdated(getUpdated() == null ? null : getUpdated().getTime());
		pointCategoryType.setCreated(getCreated() == null ? null : getCreated().getTime());
		return pointCategoryType;
	}
	
	public static PointCategory from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		PointCategory pointCategory = new PointCategory(
			CustomerManager.getCustomer((Long)mysql.getColumn("customer_id")),
			(String)mysql.getColumn("name"),
			(Long)mysql.getColumn("weight")
		);
		pointCategory.setPointCategoryId((Long)mysql.getColumn("point_category_id"));
		pointCategory.setUpdated((Date)mysql.getColumn("updated"));		
		pointCategory.setCreated((Date)mysql.getColumn("created"));		
				
		return pointCategory;
	}
	
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}
	
	public void setUpdated(Date updated) {
		this.updated = updated;
	}

	public Date getUpdated() {
		return updated;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
	
	public long getWeight() {
		return weight;
	}

	public void setWeight(long weight) {
		this.weight = weight;
	}

	public long getPointCategoryId() {
		return pointCategoryId;
	}

	public void setPointCategoryId(long pointCategoryId) {
		this.pointCategoryId = pointCategoryId;
	}
	
	
}