package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.RatingType;
import com.viralogy.rewardme.pos.Transaction;

@MySQLTable( name=MySQL.TABLES.RATING,
	primaryKey = "ratingId",
	transients = {}
)

public class Rating extends DatabaseBackedObject implements Serializable {

	private static final long serialVersionUID = -4512207056863476725L;
	
	private long ratingId;
	private Transaction posTx;
	private long score;
	private String data;
	private Date created;
	
	public Rating() {
	
	}
	
	public Rating( Transaction transaction, long score, String data ) {
		setPosTx(transaction);
		setScore(score);
		setData(data);
	}
	
	public RatingType toRatingType() throws FatalException, InvalidParameterException {
		RatingType ratingType = new RatingType();
		
		ratingType.setRatingId(getRatingId());
		ratingType.setPosTxId(getPosTx().getPosTxId());
		ratingType.setData(getData());
		ratingType.setScore((int)getScore());
		ratingType.setCreated(getCreated() == null ? null : getCreated().getTime());
		
		return ratingType;
	}
	
	public long getRatingId() {
		return ratingId;
	}
	public void setRatingId(long ratingId) {
		this.ratingId = ratingId;
	}
	public Transaction getPosTx() {
		return posTx;
	}
	public void setPosTx(Transaction posTx) {
		this.posTx = posTx;
	}
	public long getScore() {
		return score;
	}
	public void setScore(long score) {
		this.score = score;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	
	
}
