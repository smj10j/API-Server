package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.customer.CustomerConstants;
import com.viralogy.rewardme.jaxb.POSInventoryItemsType;
import com.viralogy.rewardme.jaxb.ReceiptType;
import com.viralogy.rewardme.manager.POSManager;
import com.viralogy.rewardme.pos.Employee;
import com.viralogy.rewardme.pos.InventoryItem;
import com.viralogy.rewardme.pos.InventoryItemMod;
import com.viralogy.rewardme.pos.Transaction;
import com.viralogy.rewardme.pos.Transaction.PaymentMethod;
import com.viralogy.rewardme.util.DateUtil;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.StringUtil;

public class Receipt implements Serializable {

	private static final long serialVersionUID = -3446751020920738049L;
	private static Logger logger = Logger.getLogger(Receipt.class);
	
	private static final Set<String> TOTAL_WORDS = new HashSet<String>();
	private static final Set<String> SUBTOTAL_WORDS = new HashSet<String>();
	private static final Set<String> TAX_WORDS = new HashSet<String>();
	private static final Set<String> ORDER_ID_WORDS = new HashSet<String>();
	private static final Set<String> ORDER_TYPE_WORDS = new HashSet<String>();
	private static final Set<String> EMPLOYEE_ID_WORDS = new HashSet<String>();
	private static final Set<String> REWARDME_CREDIT_WORDS = new HashSet<String>();
	private static final Set<String> PAYMENT_METHOD_WORDS = new HashSet<String>();
	private static final Set<String> IGNORE_LINE_ITEM_WORDS = new HashSet<String>();
	
	private static final Set<String> CREDIT_CARD_WORDS = new HashSet<String>();

	private static final Pattern MONEY_REG_EX = Pattern.compile("\\$?-?(((\\d{1,3},)+\\d{3})|\\d+)\\.\\d{2}");
	private static final Pattern NUMBER_REG_EX = Pattern.compile("-?\\d+");
	private static final Pattern STRING_REG_EX = Pattern.compile("[a-zA-Z ]+");
	private static final Pattern WORD_REG_EX = Pattern.compile("[a-zA-Z0-9]+");

	/*
	 * words are added and reset in the order listed
	 * words that have higher % chance of being correct should be
	 * placed at the end of the list
	 */
	static {
		TOTAL_WORDS.add("bal");
		TOTAL_WORDS.add("amount");
		TOTAL_WORDS.add("balance");
		TOTAL_WORDS.add("total");

		SUBTOTAL_WORDS.add("net");
		SUBTOTAL_WORDS.add("sub");
		SUBTOTAL_WORDS.add("subtotal");

		TAX_WORDS.add("tax");
		
		ORDER_ID_WORDS.add("ticket");
		ORDER_ID_WORDS.add("order");
		ORDER_ID_WORDS.add("chk");
		ORDER_ID_WORDS.add("check");
		ORDER_ID_WORDS.add("invoice");
		ORDER_ID_WORDS.add("trn");
		ORDER_ID_WORDS.add("trans");
		ORDER_ID_WORDS.add("trans#");
		ORDER_ID_WORDS.add("transaction");

		EMPLOYEE_ID_WORDS.add("clerk");
		EMPLOYEE_ID_WORDS.add("station");
		EMPLOYEE_ID_WORDS.add("host");
		EMPLOYEE_ID_WORDS.add("emp");
		EMPLOYEE_ID_WORDS.add("employee");
		EMPLOYEE_ID_WORDS.add("cashier");
		
		REWARDME_CREDIT_WORDS.add("rewardme-credit");
		
		PAYMENT_METHOD_WORDS.add("discover");
		PAYMENT_METHOD_WORDS.add("cash");
		PAYMENT_METHOD_WORDS.add("visa");
		PAYMENT_METHOD_WORDS.add("gift");
		PAYMENT_METHOD_WORDS.add("mastercard");
		PAYMENT_METHOD_WORDS.add("amex");
		PAYMENT_METHOD_WORDS.add("debit");
		
		ORDER_TYPE_WORDS.add("here");
		ORDER_TYPE_WORDS.add("togo");
		ORDER_TYPE_WORDS.add("takeout");

		CREDIT_CARD_WORDS.add("discover");
		CREDIT_CARD_WORDS.add("visa");
		CREDIT_CARD_WORDS.add("mastercard");
		CREDIT_CARD_WORDS.add("amex");
		CREDIT_CARD_WORDS.add("diner");
		CREDIT_CARD_WORDS.add("charge");
		
		IGNORE_LINE_ITEM_WORDS.addAll(PAYMENT_METHOD_WORDS);
		IGNORE_LINE_ITEM_WORDS.addAll(CREDIT_CARD_WORDS);
		IGNORE_LINE_ITEM_WORDS.addAll(REWARDME_CREDIT_WORDS);
	}
	
	private long posReceiptId;
	
	//preset
	private User user;
	private Customer customer;
	private Address address;
	private Device device;
	
	//raw
	private String rawData;
	private String asciiData;
	
	//intermediate processing
	private List<String> linesWithKitchenItems = new ArrayList<String>();
	private List<String> linesWithPrices = new ArrayList<String>();
	private List<String> linesWithTotals = new ArrayList<String>();
	private List<String> linesWithSubtotals = new ArrayList<String>();
	private List<String> linesWithTax = new ArrayList<String>();
	private List<String> linesWithOrderIds = new ArrayList<String>();
	private List<String> linesWithEmployeeIds = new ArrayList<String>();
	private List<String> linesWithPaymentMethods = new ArrayList<String>();
	private List<String> linesWithRewardMeCredits = new ArrayList<String>();
	private List<String> linesWithUserNames = new ArrayList<String>();
	
	//processing flags
	private boolean isFromKitchen;	//kitchen receipts have no price data - we must use data from other locations

	//post-processing, ready to be consumed
	private double subtotal;
	private double total;
	private double tax;
	private List<InventoryItem> lineItems = new ArrayList<InventoryItem>();
	private Map<InventoryItem, Set<InventoryItemMod>> lineItemMods = new HashMap<InventoryItem, Set<InventoryItemMod>>();
	private Employee employee;
	private String externalTxId;
	private long pointsCredit;
	private String userName;
	private PaymentMethod paymentMethod;
	private Transaction transaction;
	
	
	public Receipt(User user, Customer customer, Device device, Address address, String rawData) throws InvalidParameterException, FatalException {
		this.user = user;
		this.customer = customer;
		this.device = device;
		this.address = address;
		this.rawData = rawData;		
		if(!StringUtil.isNullOrEmpty(this.rawData)) {
			this.rawData = this.rawData.trim();
		}
		this.asciiData = StringUtil.toAsciiFromUTF8(this.rawData);
		if(!StringUtil.isNullOrEmpty(this.asciiData)) {
			this.asciiData = this.asciiData.trim();
		}
		if(StringUtil.isNullOrEmpty(this.asciiData)) {
			throw new InvalidParameterException(Constants.Error.POS.NO_RECEIPT_DATA);
		}
		
		
		logger.debug("Reading receipt with rawData: " + this.rawData);
		logger.debug("Reading receipt with asciiData: " + this.asciiData);
		
		this.subtotal = 0;
		this.tax = 0;
		this.total = 0;
		
		this.employee = null;
		this.externalTxId = null;
		
		this.pointsCredit = 0;
		
		this.isFromKitchen = !asciiData.contains("$");
		if(this.isFromKitchen) {
			//see if payment info is in the receipt, which indicates it's not actually from the kitchen
			String lowercaseAsciiData = asciiData.toLowerCase();
			for(String paymentWord : PAYMENT_METHOD_WORDS) {
				if(lowercaseAsciiData.contains(paymentWord)) {
					this.isFromKitchen = false;
					break;
				}
			}
		}
		
		parse();
	}
	
	
	public ReceiptType toReceiptType() throws InvalidParameterException, FatalException {
		ReceiptType receiptType = new ReceiptType();
		
		receiptType.setRawData(getRawData());
		receiptType.setAsciiData(getAsciiData());
		
		receiptType.setCustomer(getCustomer().toCustomerType(getUser(), false, false));
		receiptType.setUser(getUser() == null ? null : getUser().toUserType(getCustomer()));
		receiptType.setAddress(getAddress().toAddressType());
		receiptType.setDevice(getDevice().toDeviceType());
		
		receiptType.setEmployee(getEmployee() == null ? null : getEmployee().toEmployeeType());
		receiptType.setExternalTxId(getExternalTxId());
		if(transaction != null && transaction.getPosTxId() != 0) {
			receiptType.setPosTxId(transaction.getPosTxId());
		}
		
		receiptType.setTotal(getTotal().floatValue());
		receiptType.setSubtotal(getSubtotal().floatValue());
		receiptType.setTax(getTax().floatValue());
		receiptType.setPaymentMethod(getPaymentMethod().toString());
		
		receiptType.setPointsCredit((int)getPointsCredit());
		
		receiptType.setLineItems(new POSInventoryItemsType());
		for(InventoryItem inventoryItem : getLineItems()) {
			receiptType.getLineItems().getPOSInventoryItem().add(inventoryItem.toPOSInventoryItemType(getLineItemMods(inventoryItem), null, false));
		}

		return receiptType;
	}
	
	public String toString() {
		StringBuilder str = new StringBuilder();
		
		str.append("-- Line Items --").append("\n");
		for(InventoryItem inventoryItem : lineItems) {
			str .append(inventoryItem.getName())
				.append("\t")
				.append(inventoryItem.getCount())
				.append(" @ $")
				.append(inventoryItem.getPrice())
				.append("\n");
		}
		str.append("\n");
		
		str.append("Subtotal: $").append(subtotal).append("\n");
		str.append("Tax: $").append(tax).append("\n");
		str.append("Total: $").append(total).append("\n");
		str.append("Payment Method: ").append(paymentMethod).append("\n");
		str.append("\n");
		str.append("External Employee Id: ").append(employee == null ? null : employee.getExternalEmployeeId()).append("\n");
		str.append("External Tx Id: ").append(externalTxId).append("\n");
		str.append("\n");
		str.append("User Id: ").append(user == null ? null : user.getUserId()).append("\n");
		str.append("User Name: ").append(userName).append("\n");
		str.append("Customer Id: ").append(customer.getCustomerId()).append("\n");
		str.append("Address Id: ").append(address.getAddressId()).append("\n");
		str.append("Device Id: ").append(device.getDeviceId()).append("\n");
		
		return str.toString();
	}
	
	private void parse() throws InvalidParameterException, FatalException {
				
		//make a first pass over the receipt to:
		//	clean all whitespace
		//	preview the lines and put them into the relevant buckets
		Scanner scanner = new Scanner(asciiData);
		int lineNumber = 1;
		while(scanner.hasNextLine()) {
			String line = scanner.nextLine().trim();
			addLineToProcessingQueues(line, lineNumber++);			
		}
		
		//let's first get the information that is more loosely coupled with line item data
		setEmployee();
		setOrderId();
		
		//next let's get the aggregates
		setTotal();
		setSubtotal();
		setTax();
		
		//set the way the payment was made
		setPaymentMethod();
		
		//now, let's get the line item data
		setLineItems();
		
		//and set the customer's name if present (usually on the bottom of a receipt for takeout)
		setUserName();
		
		//and finally, let's handle any rewardme codes
		setRewardMeCredits();
		
		
		
		
		
		//do customer-specific handling
		if(!StringUtil.isNullOrEmpty(externalTxId)) {
			if(customer.is(CustomerConstants.FRAICHE)) {
				externalTxId = DateUtil.getTodaysStartDateAsString() + "-" + externalTxId;
	
			}
		}
		
		
	}
	
	private void setEmployee() throws InvalidParameterException, FatalException {
		if(linesWithEmployeeIds.size() > 0) {
			//pull the employee id out of the line
			String externalEmployeeId = null;
			for(String line : linesWithEmployeeIds) {
				Scanner scanner = new Scanner(line);
				String match = null;
				boolean foundEmployeeIdStart = false;
				if(customer.is(CustomerConstants.FRAICHE)) {
					foundEmployeeIdStart = true;
				}
				while((match = scanner.findInLine(WORD_REG_EX)) != null) {
					//use the last 'word' in the line
					if(!foundEmployeeIdStart) {
						if(EMPLOYEE_ID_WORDS.contains(match)) {
							logger.debug("Looking for externalEmployeeId on line " + line + " after " + match);					
							foundEmployeeIdStart = true;
						}
						continue;
					}
					if(externalEmployeeId == null || match.length() > externalEmployeeId.length()) {
						externalEmployeeId = match;
						logger.debug("Set externalEmployeeId to " + externalEmployeeId);					
					}else {
						logger.debug("Saw potential externalEmployeeId " + match + " but stuck with " + externalEmployeeId);											
					}
				}
			}
			
			if(externalEmployeeId != null) {
				try {
					employee = POSManager.getEmployee(customer, address, externalEmployeeId);
				}catch(InvalidParameterException e) {
					//create the employee
					String employeeName = externalEmployeeId;
					employee = new Employee(customer, address, employeeName, externalEmployeeId);
					POSManager.save(employee);
				}
			}
		}
	}
	
	private void setOrderId() {
		if(linesWithOrderIds.size() > 0) {
			//pull the order id out of the line
			for(String line : linesWithOrderIds) {
				if(line.contains("time")) {	//ignore "Order Time: ..."
					continue;
				}
				Scanner scanner = new Scanner(line);
				String match = scanner.findInLine(NUMBER_REG_EX);
				if(!StringUtil.isNullOrEmpty(match) && (externalTxId == null || match.length() > externalTxId.length())) {
					externalTxId = match;
					logger.debug("Set externalTxId to " + externalTxId);
				}else {
					logger.debug("Found externalTxId of " + match + " but stuck with existing externalTxId of " + externalTxId);
				}
			}
		}
	}
	
	private void setTotal() {
		if(linesWithTotals.size() > 0) {
			//pull the total info out of the line
			for(String line : linesWithTotals) {
				Scanner scanner = new Scanner(line);
				String valueStr = null;
				while((valueStr = scanner.findInLine(MONEY_REG_EX)) != null) {
					valueStr = valueStr.replaceAll("[\\$,]", "");
					try {
						double value = Double.valueOf(valueStr);
						if(value > total) {
							total = value;
						}
					}catch(NumberFormatException e) {
						logger.warn("Tried to set " + valueStr + " as total but failed due to NumberFormatException");
					}
				}
			}
		}
	}

	private void setSubtotal() {
		if(linesWithSubtotals.size() > 0) {
			//pull the subtotal info out of the line
			for(String line : linesWithSubtotals) {
				Scanner scanner = new Scanner(line);
				String valueStr = null;
				while((valueStr = scanner.findInLine(MONEY_REG_EX)) != null) {
					valueStr = valueStr.replaceAll("[\\$,]", "");
					try {
						double value = Double.valueOf(valueStr);
						if(value > subtotal) {
							subtotal = value;
						}
					}catch(NumberFormatException e) {
						logger.warn("Tried to set " + valueStr + " as subtotal but failed due to NumberFormatException");
					}
				}
			}
		}else {
			if(total != 0) {
				subtotal = total;
			}
		}
	}

	private void setTax() {
		if(linesWithTax.size() > 0) {
			//pull the tax info out of the line
			for(String line : linesWithTax) {
				Scanner scanner = new Scanner(line);
				String valueStr = null;
				while((valueStr = scanner.findInLine(MONEY_REG_EX)) != null) {
					valueStr = valueStr.replaceAll("[\\$,]", "");
					try {
						double value = Double.valueOf(valueStr);
						if(value > tax) {
							tax = value;
						}
					}catch(NumberFormatException e) {
						logger.warn("Tried to set " + valueStr + " as tax but failed due to NumberFormatException");
					}
				}
			}
			
			double diff = total - subtotal;
			if(diff - tax > .01) {	//rounding errors
				logger.warn("Read tax value of " + tax + ", but total="+total+" and subtotal="+subtotal+" (diff="+diff+"). Setting tax to 0");
				tax = 0;
			}
			
		}else {
			//try and guess
			if(total != 0 && subtotal != 0) {
				tax = total - subtotal;
			}
		}
	}
	
	private void setLineItems() throws InvalidParameterException, FatalException {
		
		InventoryItem lastLineItem = null;
		double calculatedTotal = 0;

		if(isFromKitchen) {
			if(linesWithKitchenItems.size() > 0) {
				for(String line : linesWithKitchenItems) {
					
					if(line.length() < 3) {
						logger.debug("Skipping line because it's too short: " + line);
						continue;
					}

					String kitchenItemName = line;
					boolean isItem = line.startsWith("[");
					if(isItem) {
						kitchenItemName = line.substring("[   ]".length()-1);
					}
					kitchenItemName = kitchenItemName.trim();
					logger.debug("Trying to find an item with kitchenItemName: " + kitchenItemName);
					
					int quantity = 1;
					try {
						if(kitchenItemName.contains(" ")) {
							String quantityStr = kitchenItemName.substring(0, kitchenItemName.indexOf(" ")).replaceAll("[\\(\\),a-zA-Z]", "");
							quantity = Integer.valueOf(quantityStr);	
							kitchenItemName = kitchenItemName.substring(kitchenItemName.indexOf(" "));
							logger.debug("Set quantity=" + quantity + ", kitchenItemName=" + kitchenItemName);
						}
					}catch(NumberFormatException e) {
						//failed to get quantity - it's cool
					}
					
					//item
					try {
						InventoryItem inventoryItem = POSManager.getInventoryItemFromKitchenItemName(customer, kitchenItemName);
						inventoryItem.setCount(quantity);
						calculatedTotal+= (inventoryItem.getPrice() * inventoryItem.getCount());
						lineItems.add(inventoryItem);
						lastLineItem = inventoryItem;
						
					}catch(InvalidParameterException e) {
						//item doesn't exists in our database
						logger.warn("Tried to get inventory item from kitchenItemName: " + kitchenItemName + " but none exists - trying as a mod now");

						//try it as a mod now
						try {
							InventoryItemMod inventoryItemMod = POSManager.getInventoryItemModFromKitchenItemName(customer, kitchenItemName);
							inventoryItemMod.setCount(quantity);
							calculatedTotal+= (inventoryItemMod.getPrice() * inventoryItemMod.getCount());
							if(lastLineItem != null) {
								Set<InventoryItemMod> lineItemModsForLineItem = lineItemMods.get(lastLineItem);
								if(lineItemModsForLineItem == null) {
									lineItemModsForLineItem = new HashSet<InventoryItemMod>();
									lineItemMods.put(lastLineItem, lineItemModsForLineItem);
								}
								lineItemModsForLineItem.add(inventoryItemMod);
							}else {
								logger.warn("Skipping lineItemMod with kitchenItemName " + kitchenItemName + " because lastLineItem is null");							
							}	
						}catch(InvalidParameterException e2) {
							//item doesn't exists in our database
							logger.warn("Tried to get inventory item modifier from kitchenItemName: " + kitchenItemName + " but none exists");
						}
					}
				}
			}
			
			//kitchen receipts don't have price data - so use what we found
			subtotal = calculatedTotal;
			total = calculatedTotal;
			tax = 0;
			
		}else {
			if(linesWithPrices.size() > 0) {
				//pull the parts of the line item out of the line

				for(String line : linesWithPrices) {
					
					if(calculatedTotal >= total) {
						//trust the found "total" vs our calculated total and
						//prefer items at the top of the list over ones at the bottom
						//when our totals don't match up
						break;
					}
					
					Scanner scanner = new Scanner(line);
					String name = "";
					String firstWord = null;
					String previousWord = null;
					int quantity = 1;
					
					while(scanner.hasNext()) {
						if(previousWord != null) {
							name+= previousWord + " ";
						}
						
						String word = scanner.next();
						if(firstWord == null) {
							firstWord = word;
							try {
								firstWord = firstWord.replaceAll("[\\(\\)\\[\\],a-zA-Z]", "");
								quantity = Integer.valueOf(firstWord);						
								previousWord = null;
							}catch(NumberFormatException e) {
								//not a quantity
								previousWord = word;
							}
						}else {
							previousWord = word;
						}
					}
					name = name.trim();
					if(IGNORE_LINE_ITEM_WORDS.contains(name)) {
						logger.warn("Skipping over line item \"" + name + "\" because it's in the ignore list");
						continue;
					}
					try {
						previousWord = previousWord.replaceAll("[\\$,a-zA-Z\\(\\)]", "");
						Double price = Double.valueOf(previousWord);
						calculatedTotal+= price;
						price/= quantity;
						
						if(price < 0) {
							//TODO: add as a discount
							logger.warn("Skipping over a negative price of " + price + " for item with name " + name);
							continue;
						}
						
						if(name.startsWith(">")) {
							//modifier
							InventoryItemMod inventoryItemMod = new InventoryItemMod(customer, name, name, price.floatValue(), 0f);
							inventoryItemMod.setCount(quantity);
							if(lastLineItem != null) {
								Set<InventoryItemMod> lineItemModsForLineItem = lineItemMods.get(lastLineItem);
								if(lineItemModsForLineItem == null) {
									lineItemModsForLineItem = new HashSet<InventoryItemMod>();
									lineItemMods.put(lastLineItem, lineItemModsForLineItem);
								}
								lineItemModsForLineItem.add(inventoryItemMod);
							}else {
								logger.warn("Skipping lineItemMod with name " + name + " because lastLineItem is null");							
							}
						}else {
							InventoryItem inventoryItem = new InventoryItem(customer, name, name, price.floatValue(), 0f);
							inventoryItem.setCount(quantity);
							lineItems.add(inventoryItem);
							lastLineItem = inventoryItem;
						}
						
					}catch(NumberFormatException e) {
						logger.warn("Tried to set " + previousWord + " as price of line item " + name + " but failed due to NumberFormatException");
					}
				}
			}
		}
		
		/*
		 * The below code groups line items 
		 * It is commented out because grouping of line items loses the line item => line item mod relationship
		 * For now, we will use the POS systems own grouping if present
		 */
		/*
		List<InventoryItem> finalLineItems = new ArrayList<InventoryItem>();
		Map<InventoryItem, Set<InventoryItemMod>> finalLineItemMods = new HashMap<InventoryItem, Set<InventoryItemMod>>();

		for(InventoryItem inventoryItem : lineItems) {
			int index = finalLineItems.indexOf(inventoryItem);
			InventoryItem finalLineItem = null;
			logger.debug("got index: " + index + " for line item: " + inventoryItem.getName());
			if(index == -1) {
				finalLineItem = inventoryItem;
				finalLineItems.add(finalLineItem);
			}else {
				finalLineItem = finalLineItems.get(index);
				int newCount = finalLineItem.getCount() + inventoryItem.getCount();
				finalLineItem.setCount(newCount);
			}
		}
		lineItems = finalLineItems;
		*/
		
	}
	
	private void setPaymentMethod() {
		if(linesWithPaymentMethods.size() > 0) {
			//pull the payment method info out of the line
			for(String line : linesWithPaymentMethods) {
				Scanner scanner = new Scanner(line);
				while(scanner.hasNext()) {
					//use the last word in the line
					String word = scanner.next().toLowerCase();
					try {
						paymentMethod = PaymentMethod.valueOf(word.toUpperCase());
						logger.debug("Set payment method to " + paymentMethod);
					}catch(IllegalArgumentException e) {
						//see if it's a type we know
						if(CREDIT_CARD_WORDS.contains(word)) {
							paymentMethod = PaymentMethod.CREDIT;
						}else if(word.equals("cash")) {
							paymentMethod = PaymentMethod.CASH;
						}else if(word.equals("debit")) {
							paymentMethod = PaymentMethod.DEBIT;
						}else if(word.equals("gift")) {
							paymentMethod = PaymentMethod.GIFT_CARD;
						}
					}
				}
			}
		}
		if(paymentMethod == null) {
			paymentMethod = PaymentMethod.UNKNOWN;
		}
	}
	
	private void setRewardMeCredits() {
		if(linesWithRewardMeCredits.size() > 0) {
			//pull the point amount out of the line
			for(String line : linesWithRewardMeCredits) {
				Scanner scanner = new Scanner(line);
				String valueStr = scanner.findInLine(NUMBER_REG_EX);
				try {
					valueStr = valueStr.replaceAll("[\\$,]", "");
					pointsCredit+= Long.valueOf(valueStr);
					
				}catch(NumberFormatException e) {
					logger.warn("Tried to add " + valueStr + " to pointsCredit but failed due to NumberFormatException");
				}				
				logger.debug("Set pointsCredit to " + pointsCredit);				
			}
		}
	}
	
	private void setUserName() {
		
		//prefer lines on the bottom of the receipt
		Collections.reverse(linesWithUserNames);
		
		if(linesWithUserNames.size() > 0) {
			//pull the user name out of the line - for now we're just using the last line on the receipt
			for(int i = 0; i < linesWithUserNames.size(); i++) {
				String line = linesWithUserNames.get(i);
				Scanner scanner = new Scanner(line);
				int wordCount = 0;
				while(scanner.hasNext()) {
					if(wordCount++ > 0) {
						//more than one word on the line - skip
						logger.debug("Unset userName because there was more than one word on the line");
						userName = null;
						break;
					}
					//use the last word in the line
					userName = scanner.next().toLowerCase();
					
					if(ORDER_TYPE_WORDS.contains(userName)) {
						logger.debug("Unset userName because it appears to be an order type word");
						userName = null;
						break;
					}
					
					if(userName.length() > 1) {
						//capitalize
						userName = userName.substring(0,1).toUpperCase() + userName.substring(1);
					}
					logger.debug("Set userName to " + userName);
				}
				//just use the last line of the receipt that looks like a name
				break;
			}
		}
	}

	private void addLineToProcessingQueues(String line, int lineNumber) {
		
		if(StringUtil.isNullOrEmpty(line)) {
			return;
		}
		
		//clean up the data
		List<String> trimmedWords = new ArrayList<String>();
		Scanner scanner = new Scanner(line);
		while(scanner.hasNext()) {
			String word = scanner.next();
			word = word.trim();
			word = word.replace(":"," ");
			word = word.replace("!"," ");
			word = word.replace("\\$", " ");
			word = word.toLowerCase();
			trimmedWords.add(word);
		}
		
		//now reconstruct the line and split it appropriately 
		line = ListUtil.implode(trimmedWords, " ");
		trimmedWords.clear();
		scanner = new Scanner(line);
		while(scanner.hasNext()) {
			String word = scanner.next();
			word = word.trim();
			trimmedWords.add(word);
		}		
		line = ListUtil.implode(trimmedWords, " ");
		if(StringUtil.isNullOrEmpty(line)) {
			return;
		}		
		//logger.debug("Scanning processed line: " + line);
		
		boolean isPossibleLineItemLine = true;
		
		for(String word : trimmedWords) {
			
			/* Check for "total" in the word */
			for(String aWord : TOTAL_WORDS) {
				if(word.equals(aWord)) {
					//line = line.replace(aWord, " ");	//removing the word helps with printouts like total$38.45
					linesWithTotals.add(line);
					logger.debug("Looks like there is total information on line: " + line);
					isPossibleLineItemLine = false;
					break;
				}
			}
			
			/* Check for "subtotal" in the word */
			for(String aWord : SUBTOTAL_WORDS) {
				if(word.equals(aWord)) {
					//line = line.replace(aWord, " ");	//removing the word helps with printouts like total$38.45
					linesWithSubtotals.add(line);
					logger.debug("Looks like there is subtotal information on line: " + line);
					isPossibleLineItemLine = false;
					break;
				}
			}	
			
			/* Check for "tax" in the word */
			for(String aWord : TAX_WORDS) {
				if(word.equals(aWord)) {
					//line = line.replace(aWord, " ");	//removing the word helps with printouts like total$38.45
					linesWithTax.add(line);
					logger.debug("Looks like there is tax information on line: " + line);
					isPossibleLineItemLine = false;
					break;
				}
			}
			
			//order and employee info do not have $ on the line
			if(!line.contains("$")) {
				
				//lines with nothing on them except a number are usually lines
				//with the order id on them
				if(line.matches(NUMBER_REG_EX.pattern())) {
					logger.info("Line " + line + " looks like it may contain an order# - adding it to the list even though it doesn't have an order word in it");
					linesWithOrderIds.add(line);
				}
				
				/* Check for "order#" in the word */
				for(String aWord : ORDER_ID_WORDS) {
					if(word.equals(aWord)) {
						//line = line.replace(aWord, " ");	//removing the word helps with printouts like total$38.45
						linesWithOrderIds.add(line);
						logger.debug("Looks like there is order# information on line: " + line);
						isPossibleLineItemLine = false;
						break;
					}
				}
				
				/* Check for "employee" in the word */
				for(String aWord : EMPLOYEE_ID_WORDS) {
					if(word.equals(aWord)) {
						//line = line.replace(aWord, " ");	//removing the word helps with printouts like total$38.45
						linesWithEmployeeIds.add(line);
						logger.debug("Looks like there is employee information on line: " + line);
						isPossibleLineItemLine = false;
						break;
					}
				}

			}
			
			/* Check for "rewardme-transfer" in the word */
			for(String aWord : REWARDME_CREDIT_WORDS) {
				if(word.equals(aWord)) {
					//line = line.replace(aWord, " ");	//removing the word helps with printouts like total$38.45
					linesWithRewardMeCredits.add(line);
					logger.debug("Looks like there is RewardMe credit information on line: " + line);
					isPossibleLineItemLine = false;
					break;
				}
			}
			
			/* Check for payment method words */
			for(String aWord : PAYMENT_METHOD_WORDS) {
				if(word.equals(aWord)) {
					//line = line.replace(aWord, " ");	//removing the word helps with printouts like total$38.45
					linesWithPaymentMethods.add(line);
					logger.debug("Looks like there is payment method information on line: " + line);
					isPossibleLineItemLine = false;
					break;
				}
			}					
		}
		
		
		if(isPossibleLineItemLine) {
			if(isFromKitchen) {
				//assume everything is a line item and validate against our database of items
				linesWithKitchenItems.add(line);
				logger.debug("Line may contain an inventory item: " + line);
			}else {
				/* Check for $$$ on the line */
				Matcher moneyRegExMatcher = MONEY_REG_EX.matcher(line);
				if(moneyRegExMatcher.find()) {
					//we got bling
					linesWithPrices.add(line);
					logger.debug("Looks like there is price data on line: " + line);
				}else if(line.length() >= 3 && line.matches(STRING_REG_EX.pattern())) {
					//possibly the name of the person making the order
					logger.debug("Looks like there is userName information on line: " + line);
					linesWithUserNames.add(line);
				}					
			}		
		}
		
		
		
		if(customer.is(CustomerConstants.FRAICHE)) {
			if(lineNumber == 6) {
				linesWithEmployeeIds.add(line);						
				logger.debug("Looks like there is employee information on line: " + line);
			}
		}
	}
	
	public String getRawData() {
		return rawData;
	}

	public String getAsciiData() {
		return asciiData;
	}
	
	public Double getSubtotal() {
		return subtotal;
	}
	
	public Double getTotal() {
		return total;
	}

	public Double getTax() {
		return tax;
	}

	public List<InventoryItem> getLineItems() {
		return lineItems;
	}

	public Customer getCustomer() {
		return customer;
	}

	public Address getAddress() {
		return address;
	}

	public Device getDevice() {
		return device;
	}

	public String getExternalTxId() {
		return externalTxId;
	}

	public Employee getEmployee() {
		return employee;
	}

	public long getPointsCredit() {
		return pointsCredit;
	}

	public User getUser() {
		return user;
	}
	
	public long getPosReceiptId() {
		return posReceiptId;
	}

	public void setPosReceiptId(long posReceiptId) {
		this.posReceiptId = posReceiptId;
	}

	public String getUserName() {
		return userName;
	}

	public PaymentMethod getPaymentMethod() {
		return paymentMethod;
	}
	
	public Transaction getTransaction() {
		return transaction;
	}

	public Set<InventoryItemMod> getLineItemMods(InventoryItem inventoryItem) {
		return lineItemMods.get(inventoryItem);
	}
	
	public Transaction toTransaction() throws FatalException, InvalidParameterException {
		
		if(StringUtil.isNullOrEmpty(externalTxId)) {
			throw new InvalidParameterException(Constants.Error.POS.NO_EXTERNAL_TX_ID_ON_RECEIPT);
		}
		
		if(total == 0) {
			throw new InvalidParameterException(Constants.Error.POS.NO_TOTAL_FOUND_ON_RECEIPT);
		}
		
		if(employee == null) {
			//get a default employee
			String employeeName = "Unknown";
			try {
				employee = POSManager.getEmployee(customer, address, employeeName);
			}catch(InvalidParameterException e) {
				//create the default employee
				employee = new Employee(customer, address, employeeName, employeeName);
				POSManager.save(employee);
			}
		}
		
		transaction = new Transaction(
				user, 
				customer, 
				address, 
				device, 
				employee, 
				externalTxId, 
				(new Double(total)).floatValue(), 
				(new Double(subtotal)).floatValue(), 
				(new Double(subtotal)).floatValue(),
				paymentMethod
		);
		
		//add in the line items and mods
		for(InventoryItem inventoryItem : lineItems) {
			try {
				int quantity = inventoryItem.getCount();
				inventoryItem = POSManager.getInventoryItem(customer, inventoryItem.getExternalPosInventoryItemId());
				inventoryItem.setCount(quantity);
			}catch(InvalidParameterException e) {
				try {
					POSManager.save(inventoryItem);
				}catch(InvalidParameterException e2) {
					logger.warn("Failed to save inventory item: " + e2.getMessage(), e2);
					continue;
				}	
			}
			transaction.addInventoryItem(inventoryItem);
			
			Set<InventoryItemMod> inventoryItemMods = lineItemMods.get(inventoryItem);
			if(inventoryItemMods != null) {
				for(InventoryItemMod inventoryItemMod : inventoryItemMods) {
					try {
						int quantity = inventoryItemMod.getCount();
						inventoryItemMod = POSManager.getInventoryItemMod(customer, inventoryItemMod.getExternalPosInventoryItemModId());
						inventoryItemMod.setCount(quantity);
					}catch(InvalidParameterException e2) {
						try {
							POSManager.save(inventoryItemMod);
						}catch(InvalidParameterException e3) {
							logger.warn("Failed to save inventory item mod: " + e3.getMessage(), e3);							
							continue;
						}
					}
					transaction.addInventoryItemMod(inventoryItem, inventoryItemMod);
				}
			}

		}
		
		return transaction;
	}


}
