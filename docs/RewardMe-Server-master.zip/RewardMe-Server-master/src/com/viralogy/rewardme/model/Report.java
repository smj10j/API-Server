package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.ReportDataType;
import com.viralogy.rewardme.jaxb.ReportType;
import com.viralogy.rewardme.manager.ReportingManager;
import com.viralogy.rewardme.util.StringUtil;

@MySQLTable(name=MySQL.TABLES.REPORT, 
	primaryKey="reportId",
	transients={
		"customer",
		"address",
		"periodType",
		"startDate",
		"endDate",
		"rows",
		"periodGroupingString",
		"periodDisplayString",
		"orderByString"
	}
)

public class Report extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = 807700874856073878L;

	public static enum PeriodType {
		DAY,
		WEEK,
		MONTH,
		YEAR
	};
	
	private long reportId;
	private String name;
	private String groupName;
	private String description;
	private JSONObject definition;	//TODO: make serialized by writing readObject and writeObject methods
	private Date updated;
	private Date created;
	
	private Customer customer;
	private Address address;
	private PeriodType periodType;
	private Date startDate;
	private Date endDate;
	private Map<String, ReportDataRow> rows;
	
	public Report(String name, String groupName, String description, JSONObject definition) {
		setName(name);
		setGroupName(groupName);
		setDescription(description);
		setDefinition(definition);
	}
	
	
	public ReportType toReportType() throws InvalidParameterException, FatalException {
		ReportType reportType = new ReportType();
		reportType.setReportId(getReportId());
		reportType.setName(getName());
		reportType.setGroupName(getGroupName());
		reportType.setDescription(getDescription());
		reportType.setDefinition(getDefinition().toString());
		
		if(rows != null) {
			reportType.setCustomer(getCustomer() != null ? getCustomer().toCustomerType(null, false, false) : null);
			reportType.setAddress(getAddress() != null ? getAddress().toAddressType() : null);
			reportType.setPeriodType(getPeriodType().toString());
			reportType.setStartDateTs(getStartDate() != null ? getStartDate().getTime() : 0);
			reportType.setEndDateTs(getEndDate() != null ? getEndDate().getTime() : 0);
			
			ReportDataType reportDataType = new ReportDataType();
			for(String name : rows.keySet()) {
				ReportDataRow reportDataRow = rows.get(name);
				reportDataType.getRows().add(reportDataRow.toReportDataRowType());
			}
			reportType.setData(reportDataType);
		}
		
		return reportType;
	}
	
	public void run(Customer customer, Address address, Date startDate, Date endDate, PeriodType periodType) throws InvalidParameterException, FatalException {
		setCustomer(customer);
		setAddress(address);
		setStartDate(startDate);
		setEndDate(endDate);
		setPeriodType(periodType);
		
		this.rows = new LinkedHashMap<String, ReportDataRow>();
		
		ReportingManager.run(this);
	}

	public long getReportId() {
		return reportId;
	}


	public void setReportId(long reportId) {
		this.reportId = reportId;
	}
	
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setPeriodType(PeriodType periodType) {
		this.periodType = periodType;
	}


	public PeriodType getPeriodType() {
		return periodType;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}


	public Date getStartDate() {
		return startDate;
	}

	public Map<String, ReportDataRow> getRows() {
		return rows;
	}

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public JSONObject getDefinition() {
		return definition;
	}


	public void setDefinition(JSONObject definition) {
		this.definition = definition;
	}


	public Date getEndDate() {
		return endDate;
	}


	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}


	public Address getAddress() {
		return address;
	}


	public void setAddress(Address address) {
		this.address = address;
	}
	
	
	public static Report from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		Report report;
		try {
			report = new Report(
				(String)mysql.getColumn("name"),
				(String)mysql.getColumn("group_name"),
				(String)mysql.getColumn("description"),
				new JSONObject((String)mysql.getColumn("definition"))
			);
		} catch (JSONException e) {
			throw new FatalException(e);
		}
		
		report.setReportId((Long)mysql.getColumn("report_id"));
		report.setUpdated((Date)mysql.getColumn("updated"));
		report.setCreated((Date)mysql.getColumn("created"));
		
		return report;
	}

	public Date getUpdated() {
		return updated;
	}

	public void setUpdated(Date updated) {
		this.updated = updated;
	}


	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}
	
	public String getGroupName() {
		return groupName;
	}


	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
	public String getPeriodGroupingString(String primaryTable) {
		String periodString = null;
				
		String yearPeriodString = "year("+primaryTable+".created)";
		String monthPeriodString = "month("+primaryTable+".created)";
		String weekPeriodString = "week("+primaryTable+".created)";
		String dayPeriodString = "date("+primaryTable+".created)";

		switch(periodType) {
		case DAY:
			periodString = dayPeriodString;
			break;
		case WEEK:
			periodString = "concat("+weekPeriodString+",'/',"+yearPeriodString+")";
			break;
		case MONTH: 
			periodString = "concat("+monthPeriodString+",'/',"+yearPeriodString+")";
			break;
		case YEAR: 
			periodString = yearPeriodString;
			break;			
		}
		return periodString;
	}
	
	public String getPeriodDisplayString(String primaryTable) {
		String periodString = null;
		
		String yearPeriodString = "year("+primaryTable+".created)";
		String monthPeriodString = "month("+primaryTable+".created)";
		String dayPeriodString = "day("+primaryTable+".created)";
		
		switch(periodType) {
		case DAY:
			periodString = "concat("+monthPeriodString+",'/',"+dayPeriodString+",'/',"+yearPeriodString+")";
			break;
		case WEEK:
			periodString = "concat("+monthPeriodString+",'/',"+dayPeriodString+",'/',"+yearPeriodString+")";
			break;
		case MONTH: 
			periodString = "concat("+monthPeriodString+",'/1/',"+yearPeriodString+")";
			break;
		case YEAR: 
			periodString = "concat('1/1/',"+yearPeriodString+")";
			break;			
		}
		return periodString;
	}
	
	public String getOrderByString(String primaryTable) {
		return primaryTable+".created";
	}
	
}
