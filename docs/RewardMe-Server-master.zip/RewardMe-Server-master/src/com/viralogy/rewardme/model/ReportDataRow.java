package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.*;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.ReportDataRowType;
import com.viralogy.rewardme.util.ListUtil;

public class ReportDataRow implements Serializable {
	
	private static final long serialVersionUID = -7857684989606886424L;
	
	private String name;
	private boolean isTableView;
	private Map<Object, Object> columns = new LinkedHashMap<Object, Object>();
		
	public ReportDataRow(String name, boolean isTableView) {
		setName(name);
		setTableView(isTableView);
	}
	
	public ReportDataRowType toReportDataRowType() throws InvalidParameterException, FatalException {
		ReportDataRowType reportDataRowType = new ReportDataRowType();
					
		reportDataRowType.setName(getName());
		reportDataRowType.setIsTableView(isTableView());

		//TODO: handle nested ReportDataRow items as Y-values
		
		List<Object> xValues = Arrays.asList(columns.keySet().toArray());
		//Collections.reverse(xValues);
		List<Object> yValues = Arrays.asList(columns.values().toArray());
		//Collections.reverse(yValues);
		
		reportDataRowType.setX("\""+ListUtil.implode(xValues, "\",\"")+"\"");
		reportDataRowType.setY(ListUtil.implode(yValues, ","));
		
		return reportDataRowType;
	}
	
	public void addColumn(Object key, String value) {
		columns.put(key, value);
	}
	
	public void addColumn(Object key, JSONObject value) {
		JSONArray arrayOfValues = (JSONArray)columns.get(key);
		if(arrayOfValues == null) {
			arrayOfValues = new JSONArray();
		}
		//merge!
		arrayOfValues.put(value);

		columns.put(key, arrayOfValues);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<Object, Object> getColumns() {
		return columns;
	}

	public boolean isTableView() {
		return isTableView;
	}

	public void setTableView(boolean isTableView) {
		this.isTableView = isTableView;
	}
	
}
