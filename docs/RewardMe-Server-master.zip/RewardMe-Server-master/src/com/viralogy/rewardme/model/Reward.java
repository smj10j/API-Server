package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.RewardType;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.PointsManager;

@MySQLTable(name=MySQL.TABLES.REWARD, 
		primaryKey="rewardId",
		transients={
			"customer"
		}
)
		
public class Reward extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = 945925157665964693L;

	public static enum Type {
		FREE,
		DISCOUNT,
		SPECIAL_OFFER,
		VIP
	};
	
	private long rewardId;
	private boolean enabled;
	private PointCategory pointCategory;
	private Type type;
	private String headline;
	private String shortDescription;
	private String description;
	private String instructions;
	private String imageUrl;
	private String imageUrlSmall;
	private long pointsRequired;
	private long redemptionLimit;
	private Date startDate;
	private Date endDate;
	private boolean promoted;
	
	private Customer customer;	//transient
	
	public Reward( boolean enabled, Type type, 
			String headline, String shortDescription, String description, String instructions, 
			String imageUrl, String imageUrlSmall, 
			PointCategory pointCategory, long pointsRequired, long redemptionLimit, 
			Date startDate, Date endDate, boolean promoted) {
		setEnabled(enabled);
		setType(type);
		setHeadline(headline);
		setShortDescription(shortDescription);
		setDescription(description);
		setInstructions(instructions);
		setImageUrl(imageUrl);
		setImageUrlSmall(imageUrlSmall);
		setPointCategory(pointCategory);
		setPointsRequired(pointsRequired);
		setRedemptionLimit(redemptionLimit);
		setStartDate(startDate);
		setEndDate(endDate);
		setPromoted(promoted);
	}
	
	public Reward() {

	}
	
	public RewardType toRewardType() throws FatalException, InvalidParameterException {
		RewardType rewardType = new RewardType();
		try {
			rewardType.setRewardId(getRewardId());
			rewardType.setEnabled(isEnabled());
			rewardType.setType(getType().toString());
			rewardType.setHeadline(URLEncoder.encode(getHeadline(),"UTF-8"));
			rewardType.setShortDescription(URLEncoder.encode(getShortDescription(),"UTF-8"));
			rewardType.setDescription(URLEncoder.encode(getDescription(),"UTF-8"));
			rewardType.setInstructions(URLEncoder.encode(getInstructions(),"UTF-8"));
			rewardType.setImageUrl(getImageUrl());
			rewardType.setImageUrlSmall(getImageUrlSmall());
			rewardType.setPointsRequired(getPointsRequired());
			rewardType.setRedemptionLimit(getRedemptionLimit());
			rewardType.setStartDateTs(getStartDate() != null ? getStartDate().getTime() : 0);
			rewardType.setEndDateTs(getEndDate() != null ? getEndDate().getTime() : 0);
			rewardType.setIsPromoted(isPromoted());
			if(pointCategory != null) {
				rewardType.setPointCategory(pointCategory.toPointCategoryType());
			}

		}catch(UnsupportedEncodingException e) {
			throw new FatalException(e);
		}
		return rewardType;
	}

	public void setRewardId(long rewardId) {
		this.rewardId = rewardId;
	}

	public long getRewardId() {
		return rewardId;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Type getType() {
		return type;
	}

	public void setHeadline(String headline) {
		this.headline = headline;
	}

	public String getHeadline() {
		return headline;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}

	public String getInstructions() {
		return instructions;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setRedemptionLimit(long redemptionLimit) {
		this.redemptionLimit = redemptionLimit;
	}

	public long getRedemptionLimit() {
		return redemptionLimit;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() throws InvalidParameterException, FatalException {
		if(customer == null) {
			customer = CustomerManager.getCustomer(this);
		}
		return customer;
	}

	public void setPointsRequired(long pointsRequired) {
		this.pointsRequired = pointsRequired;
	}

	public long getPointsRequired() {
		return pointsRequired;
	}

	
	
	public static Reward from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		Reward reward = new Reward();
		reward.setRewardId((Long)mysql.getColumn("reward_id"));
		reward.setType(Type.valueOf((String)mysql.getColumn("type")));
		reward.setEnabled((Boolean)mysql.getColumn("enabled"));
		reward.setHeadline((String)mysql.getColumn("headline"));
		reward.setShortDescription((String)mysql.getColumn("short_description"));
		reward.setDescription((String)mysql.getColumn("description"));
		reward.setInstructions((String)mysql.getColumn("instructions"));
		reward.setImageUrl((String)mysql.getColumn("image_url"));
		reward.setImageUrlSmall((String)mysql.getColumn("image_url_small"));
		reward.setPointsRequired((Long)mysql.getColumn("points_required"));
		reward.setRedemptionLimit((Long)mysql.getColumn("redemption_limit"));
		reward.setPromoted((Boolean)mysql.getColumn("promoted"));
		reward.setStartDate((Date)mysql.getColumn("start_date"));
		reward.setEndDate((Date)mysql.getColumn("end_date"));
		
		Long pointCategoryId = (Long)mysql.getColumn("point_category_id");
		reward.setPointCategory(pointCategoryId == null || pointCategoryId == 0 ? null : PointsManager.getPointCategory(pointCategoryId));	
		
		reward.takeFieldValuesSnapshot();
		
		return reward;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public String getShortDescription() {
		return shortDescription;
	}


	public void setPromoted(boolean promoted) {
		this.promoted = promoted;
	}

	public boolean isPromoted() {
		return promoted;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrlSmall(String imageUrlSmall) {
		this.imageUrlSmall = imageUrlSmall;
	}

	public String getImageUrlSmall() {
		return imageUrlSmall;
	}

	public PointCategory getPointCategory() {
		return pointCategory;
	}

	public void setPointCategory(PointCategory pointCategory) {
		this.pointCategory = pointCategory;
	}	
}
