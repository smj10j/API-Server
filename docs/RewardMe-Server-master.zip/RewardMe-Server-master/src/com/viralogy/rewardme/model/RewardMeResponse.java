package com.viralogy.rewardme.model;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.jaxb.RewardMeType;
import com.viralogy.rewardme.jaxb.RewardMesType;
import com.viralogy.rewardme.util.JSONUtil;


public class RewardMeResponse implements Serializable {

	private static final long serialVersionUID = 3546783458653931353L;
    
	private static Logger logger = Logger.getLogger(RewardMeResponse.class);

    private RewardMeType rewardMeType;
	private RewardMesType rewardMesType;
	private boolean isBatchRequest;
	private HttpServletResponse httpServletResponse;
	private PrintWriter printWriter;
	private boolean canGenerateResponse;
		
	public RewardMeResponse(HttpServletResponse httpServletResponse) {
		setHttpServletResponse(httpServletResponse);
		rewardMeType = new RewardMeType();
		rewardMesType = new RewardMesType();
		this.canGenerateResponse = true;
	}
	
	public RewardMeResponse(RewardMeType rewardMeType) {
		this.rewardMeType = rewardMeType;
		this.canGenerateResponse = true;
	}
	
	public String toString() {
		StringWriter responseWriter = new StringWriter();
		try {
			JSONUtil.marshal(null, get(), responseWriter);
		} catch (FatalException e) {
			logger.error(e);
		} catch (IOException e) {
			logger.error(e);
		}
		return responseWriter.toString();
	}
	
	public RewardMeType get() {
		return rewardMeType;
	}
	
	public RewardMesType getMulti() {
		return rewardMesType;
	}
	
	public void setHttpServletResponse(HttpServletResponse httpServletResponse) {
		this.httpServletResponse = httpServletResponse;
	}

	public HttpServletResponse getHttpServletResponse() {
		return httpServletResponse;
	}
	
	public PrintWriter getWriter() throws IOException {
		if(printWriter == null) {
			printWriter = getHttpServletResponse().getWriter();
		}
		return getHttpServletResponse().getWriter();
	}

	public void setBatchRequest(boolean isBatchRequest) {
		this.isBatchRequest = isBatchRequest;
	}

	public boolean isBatchRequest() {
		return isBatchRequest;
	}
	
	public void moveSingleAttributesToMulti() {
		getMulti().setApiKey(get().getApiKey());
		getMulti().setAsyncToken(get().getAsyncToken());
		getMulti().setElapsed(get().getElapsed());
		getMulti().setError(get().getError());
		getMulti().setMethod(get().getMethod());
		getMulti().setServer(get().getServer());
		getMulti().setStatus(get().getStatus());
		getMulti().setTimestamp(get().getTimestamp());
	}

	public boolean canGenerateResponse() {
		return canGenerateResponse;
	}

	public void disableOutput() {
		this.canGenerateResponse = false;
	}
}
