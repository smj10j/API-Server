package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.math.BigDecimal;

import java.util.Comparator;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.ScheduleType;
import com.viralogy.rewardme.util.ListUtil;

public class Schedule implements Serializable {
	
	private static final long serialVersionUID = 945925157665964693L;

	public static enum DayOfWeekType {
		SUNDAY,
		MONDAY,
		TUESDAY,
		WEDNESDAY,
		THURSDAY,
		FRIDAY,
		SATURDAY
	};
	
	private long scheduleId;
	private ScheduleTime startTime;
	private ScheduleTime endTime;
	private DayOfWeekType dayOfWeek;
	private double multiplier;
	
	public Schedule(long scheduleId, DayOfWeekType dayOfWeek, ScheduleTime startTime, ScheduleTime endTime, double multiplier) throws InvalidParameterException {
		this.scheduleId = scheduleId;
		this.setDayOfWeek(dayOfWeek);
		this.setStartTime(startTime);
		this.setEndTime(endTime);
		this.setMultiplier(multiplier);
		
		//verify that the start time is before the end time
		if(startTime.after(endTime)) {
			throw new InvalidParameterException(Constants.Error.GENERAL.INVALID_SCHEDULE_TIMES, ListUtil.from(startTime.toString(), endTime.toString()));
		}		
	}
	
	public Schedule(DayOfWeekType dayOfWeek, ScheduleTime startTime, ScheduleTime endTime, double multiplier) throws InvalidParameterException {
		this.setDayOfWeek(dayOfWeek);	
		this.setStartTime(startTime);
		this.setEndTime(endTime);
		this.setMultiplier(multiplier);
		
		//verify that the start time is before the end time
		if(startTime.after(endTime)) {
			throw new InvalidParameterException(Constants.Error.GENERAL.INVALID_SCHEDULE_TIMES, ListUtil.from(startTime.toString(), endTime.toString()));
		}		
	}
	
	public ScheduleType toScheduleType() {
		ScheduleType scheduleType = new ScheduleType();
		scheduleType.setScheduleId(getScheduleId());
		scheduleType.setDayOfWeek(getDayOfWeek().toString());
		scheduleType.setStartHour(getStartTime().hour);
		scheduleType.setStartMinute(getStartTime().minute);
		scheduleType.setEndHour(getEndTime().hour);
		scheduleType.setEndMinute(getEndTime().minute);
		scheduleType.setMultiplier(getMultiplier());
		
		return scheduleType;
	}

	public void setStartTime(ScheduleTime startTime) {
		this.startTime = startTime;
	}

	public ScheduleTime getStartTime() {
		return startTime;
	}

	public void setEndTime(ScheduleTime endTime) {
		this.endTime = endTime;
	}

	public ScheduleTime getEndTime() {
		return endTime;
	}

	public void setDayOfWeek(DayOfWeekType dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}

	public DayOfWeekType getDayOfWeek() {
		return dayOfWeek;
	}

	public void setScheduleId(long scheduleId) {
		this.scheduleId = scheduleId;
	}

	public long getScheduleId() {
		return scheduleId;
	}
	
	public static class sort implements Comparator<Schedule>{

	    public int compare(Schedule schedule1, Schedule schedule2) {
	        if(schedule1.getDayOfWeek().ordinal() < schedule2.getDayOfWeek().ordinal()) {
	        	return -1;
	        }else if(schedule1.getDayOfWeek().ordinal() > schedule2.getDayOfWeek().ordinal()) {
	        	return 1;
	        }else {
	        	if(schedule1.getStartTime().before(schedule2.getStartTime())) {
	        		return -1;
	        	}else if(schedule1.getStartTime().after(schedule2.getStartTime())) {
	        		return 1;
	        	}else {
	        		if(schedule1.getEndTime().before(schedule2.getEndTime())) {
	        			return -1;
	        		}else if(schedule1.getEndTime().after(schedule2.getEndTime())) {
	        			return 1;
	        		}else {
	        			return 0;
	        		}
	        	}
	        }
	    }
	}
	
	public static Schedule from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		long scheduleId = (Long)mysql.getColumn("schedule_id");
		double multiplier = (Double)((BigDecimal)mysql.getColumn("multiplier")).doubleValue();
		DayOfWeekType dayOfWeek = DayOfWeekType.valueOf((String)mysql.getColumn("day_of_week"));
		long shm = (Long)mysql.getColumn("start_hour_minute");
		long ehm = (Long)mysql.getColumn("end_hour_minute");
		long startHour = shm / 1000;
		long endHour = ehm / 1000;
		long startMinute = shm - (startHour*1000);
		long endMinute = ehm - (endHour*1000);
		Schedule schedule = new Schedule(scheduleId, dayOfWeek, new ScheduleTime(startHour, startMinute), new ScheduleTime(endHour, endMinute), multiplier);
		
		return schedule;
	}

	public void setMultiplier(double multiplier) {
		this.multiplier = multiplier;
	}

	public double getMultiplier() {
		return multiplier;
	}	
}
