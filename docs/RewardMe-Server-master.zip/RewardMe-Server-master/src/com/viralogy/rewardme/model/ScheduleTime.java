package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

public class ScheduleTime implements Serializable {
		
	private static final long serialVersionUID = -6822786241617188515L;

	protected long hour;
	protected long minute;
	
	public ScheduleTime(long hour, long minute) {
		this.hour = hour;
		this.minute = minute;
	}
	
	public ScheduleTime(Date date) {
		Calendar cal = Calendar.getInstance();       // get calendar instance
		cal.setTime(date);                           // set cal to date
		this.hour = cal.get(Calendar.HOUR_OF_DAY);
		this.minute = cal.get(Calendar.MINUTE);
	}

	public String toString() {
		return this.hour + ":" + this.minute;
	}

	public long toHourMinute() {
		return this.hour*1000 + this.minute;
	}
	
	public boolean before(ScheduleTime other) {
		return this.hour < other.hour || this.hour == other.hour && this.minute < other.minute;
	}
	
	public boolean after(ScheduleTime other) {
		return !before(other);
	}
}
