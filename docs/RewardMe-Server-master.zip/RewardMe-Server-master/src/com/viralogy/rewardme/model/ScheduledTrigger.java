package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.ScheduledTriggerType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.DeviceManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.model.Trigger.Type;

@MySQLTable(name=MySQL.TABLES.SCHEDULED_TRIGGER, 
		primaryKey="scheduledTriggerId",
		transients={
		}
)
public class ScheduledTrigger extends Trigger implements Serializable {
	
	private static final long serialVersionUID = 8146736613514066425L;
	
	private long scheduledTriggerId;
	private Date timestamp;
	
	public ScheduledTrigger(Customer customer, User user, Device device, Address address, Type type, Long typeId, String data, Date timestamp) throws FatalException {
		super(customer, user, device, address, type, typeId, data);
		setTimestamp(timestamp);
	}	
	
	public ScheduledTriggerType toScheduledTriggerType() throws InvalidParameterException, FatalException {
		ScheduledTriggerType scheduledTriggerType = new ScheduledTriggerType();
		scheduledTriggerType.setScheduledTriggerId(getScheduledTriggerId());
		scheduledTriggerType.setCustomer(getCustomer() == null ? null : getCustomer().toCustomerType(getUser(), false, false));
		scheduledTriggerType.setAddress(getAddress() == null ? null : getAddress().toAddressType());
		scheduledTriggerType.setUser(getUser() == null ? null : getUser().toUserType(null));
		scheduledTriggerType.setType(getType().toString());
		scheduledTriggerType.setTypeId(getTypeId());
		scheduledTriggerType.setData(getData());
		scheduledTriggerType.setTimestamp(getTimestamp().getTime());
		scheduledTriggerType.setCreated(getCreated() == null ? null : getCreated().getTime());
		return scheduledTriggerType;
	}
	
	public static ScheduledTrigger from(MySQL mysql) throws FatalException, InvalidParameterException {
		Long addressId = (Long)mysql.getColumn("address_id");
		//TODO: add deviceId?
		String deviceId = null;

		ScheduledTrigger scheduledTrigger = new ScheduledTrigger(
			CustomerManager.getCustomer((Long)mysql.getColumn("customer_id")), 
			UserManager.getUser((Long)mysql.getColumn("user_id")), 
			deviceId == null ? null : DeviceManager.getDevice(deviceId), 
			addressId == null ? null : AddressManager.getAddress(addressId, false),
			Type.valueOf((String)mysql.getColumn("type")),
			(Long)mysql.getColumn("type_id"), 
			(String)mysql.getColumn("data"),
			(Date)mysql.getColumn("timestamp")
		);
		
		scheduledTrigger.setArchived((Boolean)mysql.getColumn("archived"));
		scheduledTrigger.setTriggered((Boolean)mysql.getColumn("triggered"));
		scheduledTrigger.setScheduledTriggerId((Long)mysql.getColumn("scheduled_trigger_id"));
		scheduledTrigger.setCreated((Date)mysql.getColumn("created"));
		
		scheduledTrigger.takeFieldValuesSnapshot();
		
		return scheduledTrigger;
	}

	public long getScheduledTriggerId() {
		return scheduledTriggerId;
	}

	public void setScheduledTriggerId(long scheduledTriggerId) {
		this.scheduledTriggerId = scheduledTriggerId;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	 * 
	 *This is all for DatabaseBackedObject
	 */
	
	public Customer getCustomer() {
		return super.getCustomer();
	}

	public User getUser() {
		return super.getUser();
	}

	public Date getCreated() {
		return super.getCreated();
	}

	public Address getAddress() {
		return super.getAddress();
	}

	public Long getTypeId() {
		return super.getTypeId();
	}

	public Type getType() {
		return super.getType();
	}

	public boolean isTriggered() {
		return super.isTriggered();
	}

	public boolean isArchived() {
		return super.isArchived();
	}
	
	public String getData() {
		return super.getData();
	}
}