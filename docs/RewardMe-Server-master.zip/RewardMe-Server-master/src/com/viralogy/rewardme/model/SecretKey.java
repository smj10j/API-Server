package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;

@MySQLTable(name=MySQL.TABLES.SECRET_KEY, 
		primaryKey="secretKeyId",
		transients={
		}
)
		
public class SecretKey extends DatabaseBackedObject implements Serializable {
			
	private static final long serialVersionUID = -7942696132783490965L;
	
	public static enum Type {
		EVERYTHING,
		API,
		PUSH
	}
	
	private long secretKeyId;
	private String secretKey;
	private Type type;
	private Date created;
	
	public SecretKey(String secretKey, Type type) {
		setSecretKey(secretKey);
		setType(type);
	}

	public static SecretKey from(MySQL mysql) throws FatalException, InvalidParameterException {	
		SecretKey secretKey = new SecretKey(
				(String)mysql.getColumn("secret_key"),
				Type.valueOf((String)mysql.getColumn("type"))
		);
		secretKey.setSecretKeyId((Long)mysql.getColumn("secret_key_id"));
		secretKey.setCreated((Date)mysql.getColumn("created"));
		
		return secretKey;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}

	public String getSecretKey() {
		return secretKey;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Type getType() {
		return type;
	}

	public void setSecretKeyId(long secretKeyId) {
		this.secretKeyId = secretKeyId;
	}

	public long getSecretKeyId() {
		return secretKeyId;
	}

}
