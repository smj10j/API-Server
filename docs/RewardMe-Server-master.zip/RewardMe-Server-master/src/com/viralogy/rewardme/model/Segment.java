package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.dao.SegmentDAO;
import com.viralogy.rewardme.jaxb.SegmentType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.SegmentManager;
import com.viralogy.rewardme.manager.UserManager;

@MySQLTable(name=MySQL.TABLES.SEGMENT, 
		primaryKey="segmentId",
		transients={
		"mysql",
		"hasNextUser",
		"definitionUpdated"
		}
)
public class Segment extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = -6895846082302342946L;
	private static Logger logger = Logger.getLogger(Segment.class);
	
	private long segmentId;
	private String definition; //String instead of JSONObject because String is serializable and JSONObject isn't
	private String name;
	private String description;
	private Customer customer;
	private Address address;
	private Date created;
	private Date updated;
	private boolean archived = false;
	
	private MySQL mysql = null; //transient - only exists when instantiated with initIterator()
	private boolean hasNextUser = false;
	private boolean definitionUpdated = false;//this only becomes true if this was a segment whose definition was updated through the SegmentService.save() method
	
	public Segment( Customer customer, Address address, JSONObject definition, 
					String name,  String description) {
		setDefinition(definition);
		setName(name);
		setDescription(description);
		setCustomer(customer);
		setAddress(address);
	}
	
	private Segment( Customer customer, Address address, String definition, 
			String name,  String description) {
		this.definition = definition;
		setName(name);
		setDescription(description);
		setCustomer(customer);
		setAddress(address);
	}
	
	public SegmentType toSegmentType() throws FatalException, InvalidParameterException {
		SegmentType segmentType = new SegmentType();
		segmentType.setSegmentId(getSegmentId());
		segmentType.setDefinition(this.definition);
		segmentType.setName(getName());
		segmentType.setDescription(getDescription());
		segmentType.setCustomer(getCustomer() != null ? getCustomer().toCustomerType(null, false, false) : null);
		segmentType.setAddress(getAddress() != null ? getAddress().toAddressType() : null);
		return segmentType;
	}
	
	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}

	public long getSegmentId() {
		return segmentId;
	}

	public void setDefinition(JSONObject definition) {
		this.definition = definition.toString();
	}

	public JSONObject getDefinition() throws FatalException {
		JSONObject jsonObject = null;
		try {
			jsonObject = new JSONObject(definition);
		} catch (JSONException e) {
			throw new FatalException("Segment has incorrect internal JSON definition: " + e);
		}
		return jsonObject;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}
	
	public void setAddress(Address address) {
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}
	
	public void setCreated(Date created) {
		this.created = created;
	}
	
	public Date getCreated() {
		return created;
	}
	
	public void setArchived(boolean archived) {
		this.archived = archived;
	}
	
	public boolean isArchived() {
		return archived;
	}
	
	public Date getUpdated() {
		return updated;
	}

	public void setUpdated(Date updated) {
		this.updated = updated;
	}
	
	public boolean wasDefinitionUpdated() {
		return definitionUpdated;
	}

	public void setDefinitionUpdated(boolean definitionUpdated) {
		this.definitionUpdated = definitionUpdated;
	}
	
	public static Segment from(MySQL mysql) throws FatalException, InvalidParameterException {
		Segment segment;
		Object addressColumn = mysql.getColumn("address_id");
		segment = new Segment(
				CustomerManager.getCustomer((Long)mysql.getColumn("customer_id")), 
				addressColumn == null ? null : AddressManager.getAddress((Long)addressColumn, false),
				(String)mysql.getColumn("definition"),
				(String)mysql.getColumn("name"),
				(String)mysql.getColumn("description"));
				
		segment.setSegmentId((Long)mysql.getColumn("segment_id"));
		segment.setArchived((Boolean)mysql.getColumn("archived") == null ? false : (Boolean)mysql.getColumn("archived")); 
		segment.setUpdated((Date)mysql.getColumn("updated"));
		segment.setCreated((Date)mysql.getColumn("created"));
		return segment;
	}
	
	public String toString() {
		String string = "\nSegmentId: " + segmentId +
						"\nDefinition: " + definition + 
						"\nName: " + name + 
						"\nDescription: " + description + 
						"\nCustomerId: " + customer.getCustomerId() + 
						"\nArchived: " + archived + 
						"\nUpdated: " + updated +
						"\nCreated: " + created +
						"\nAddressId: ";
		string += address==null ? "null" : address.getAddressId();
		return string;
	}
	
	//Same iterator interface
	//instantiates the iterator. This will have all the UserSegments at the time this method is called. Only nonArchived.
	public void initIterator() throws FatalException, InvalidParameterException {
		nextUser(true);
	}
	
	public User nextUser() throws InvalidParameterException, FatalException {
		return nextUser(false);
	}
	
	public boolean hasNextUser() {
		return hasNextUser;
	}
	
	//convenience function. I broke the abstraction barrier because MySQL.nextRow() is only allowed in the same function that it was queried in.
	private User nextUser(boolean init) throws FatalException, InvalidParameterException {
		if (this.isArchived()) {
			this.hasNextUser = false;
			throw new FatalException("There is no next User because segment is archived");
		}
		if (init) {
			this.mysql = MySQL.getInstance(true);
			
			this.mysql.query("" +
					"SELECT su.* FROM " + MySQL.TABLES.SEGMENT_TO_USER + " su," + MySQL.TABLES.SEGMENT + " s " +
					"WHERE s.segment_id=su.segment_id AND su.segment_id=? AND s.archived=false ORDER BY created",
					this.getSegmentId());
			
			/*long mem0 = Runtime.getRuntime().totalMemory() -
				      Runtime.getRuntime().freeMemory();
		    long mem1 = Runtime.getRuntime().totalMemory() -
	    			  Runtime.getRuntime().freeMemory();
		    this.mysql = null;
		    System.gc(); System.gc(); System.gc(); System.gc();
		    System.gc(); System.gc(); System.gc(); System.gc();
		    System.gc(); System.gc(); System.gc(); System.gc();
		    System.gc(); System.gc(); System.gc(); System.gc();
		    mem0 = Runtime.getRuntime().totalMemory() -
		      Runtime.getRuntime().freeMemory();
		    
		    this.mysql = MySQL.getInstance(true);
			
			this.mysql.query("" +
					"SELECT su.* FROM " + MySQL.TABLES.SEGMENT_TO_USER + " su," + MySQL.TABLES.SEGMENT + " s " +
					"WHERE s.segment_id=su.segment_id AND su.segment_id=? AND s.archived=false ORDER BY created",
					this.getSegmentId());
			System.gc(); System.gc(); System.gc(); System.gc();
			    System.gc(); System.gc(); System.gc(); System.gc();
			    System.gc(); System.gc(); System.gc(); System.gc();
			    System.gc(); System.gc(); System.gc(); System.gc();
		    mem1 = Runtime.getRuntime().totalMemory() -
		    		Runtime.getRuntime().freeMemory();
		    logger.info("SQL MEMORY TOOK: " + (mem1 - mem0) + " bytes");*/
			this.hasNextUser = this.mysql.nextRow();
			return null;
		} else {
			if (hasNextUser) {
				User user = UserManager.getUser((Long)mysql.getColumn("user_id"));
				this.hasNextUser = mysql.nextRow();
				return user;
			} else {
				throw new FatalException("There is no next User, or iterator has not been instantiated");
			}
		}
	}
}
