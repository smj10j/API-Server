package com.viralogy.rewardme.model;

import java.io.Serializable;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.UserManager;

@MySQLTable(name=MySQL.TABLES.SESSION, 
		primaryKey="sessionId",
		transients={
		}
)

public class Session extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = 4749483480815456172L;
	private long sessionId;
	private User user;
	private Customer customer;
	private Address address;
	
	public Session() {
		
	}
	
	public Session(User user, Customer customer, Address address) {
		setUser(user);
		setCustomer(customer);
		setAddress(address);
	}
	
	public long getSessionId() {
		return sessionId;
	}
	
	public void setSessionId( long sessionId ) {
		this.sessionId = sessionId;
	}
	
	public User getUser() {
		return user;
	}
	
	public void setUser(User user) {
		this.user = user;
	}
	
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	public Address getAddress() {
		return address;
	}
	
	public void setAddress(Address address) {
		this.address = address;
	}

	public static Session from(MySQL mysql ) throws FatalException, InvalidParameterException {
		Session session = new Session();
		
		session.setSessionId((Long) mysql.getColumn("session_id"));
		session.setUser(UserManager.getUser((Long) mysql.getColumn("user_id")));
		session.setCustomer(CustomerManager.getCustomer((Long)mysql.getColumn("customer_id")));
		Long addressId = (Long)mysql.getColumn("address_id");
		session.setAddress(addressId == null ? null : AddressManager.getAddress(addressId, false));
		
		session.takeFieldValuesSnapshot();
		
		return session;
	}
	
}
