package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.SurveyResultsType;
import com.viralogy.rewardme.jaxb.SurveyType;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.SurveyManager;
import com.viralogy.rewardme.util.StringUtil;

@MySQLTable(name=MySQL.TABLES.SURVEY, 
		primaryKey="surveyId",
		transients={
			"results",
			"userSurveys",
			"fullResponse"
		}
)
		
public class Survey extends DatabaseBackedObject implements Serializable {
	
	private static Logger logger = Logger.getLogger(Survey.class);

	private static final long serialVersionUID = 8478554842583480891L;
	
	private long surveyId;
	private Customer customer;
	private boolean enabled;
	private boolean availableOnMobile;
	private boolean ableToShowResults;
	private String name;
	private String description;
	private String content;
	private Date updated;
	private Date created;
	
	private List<SurveyResult> results;
	private Set<UserSurvey> userSurveys;
		
	public Survey(String name, String description, String content, Customer customer, boolean availableOnMobile, boolean ableToShowResults, boolean enabled) {
		setName(name);
		setDescription(description);
		setContent(content);
		setCustomer(customer);
		setAvailableOnMobile(availableOnMobile);
		setAbleToShowResults(ableToShowResults);
		setEnabled(enabled);
	}
		
	public SurveyType toSurveyType() throws FatalException, InvalidParameterException {
		SurveyType surveyType = new SurveyType();
		surveyType.setSurveyId(getSurveyId());
		surveyType.setName(getName());
		surveyType.setDescription(getDescription());
		surveyType.setContent(getContent());
		surveyType.setAvailableOnMobile(isAvailableOnMobile());
		surveyType.setAbleToShowResults(isAbleToShowResults());
		surveyType.setEnabled(isEnabled());
		surveyType.setCreated(getCreated() == null ? null: getCreated().getTime());
		surveyType.setUpdated(getUpdated() == null ? null: getUpdated().getTime());
		
		surveyType.setResults(new SurveyResultsType());
		for(SurveyResult surveyResult : getResults()) {
			surveyType.getResults().getResult().add(surveyResult.toSurveyResultType());
		}
		
		return surveyType;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}
	
	public static Survey from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		Survey survey = new Survey(
			(String)mysql.getColumn("name"),
			(String)mysql.getColumn("description"),
			(String)mysql.getColumn("content"),
			CustomerManager.getCustomer((Long)mysql.getColumn("customer_id")),
			(Boolean)mysql.getColumn("available_on_mobile"),
			(Boolean)mysql.getColumn("able_to_show_results"),
			(Boolean)mysql.getColumn("enabled")
		);
		survey.setSurveyId((Long)mysql.getColumn("survey_id"));
		survey.setUpdated((Date)mysql.getColumn("updated"));
		survey.setCreated((Date)mysql.getColumn("created"));
		
		return survey;
	}
	
	public void setSurveyId(long surveyId) {
		this.surveyId = surveyId;
	}

	public long getSurveyId() {
		return surveyId;
	}

	public void setAvailableOnMobile(boolean availableOnMobile) {
		this.availableOnMobile = availableOnMobile;
	}

	public boolean isAvailableOnMobile() {
		return availableOnMobile;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getContent() {
		return content;
	}

	public void setUpdated(Date updated) {
		this.updated = updated;
	}

	public Date getUpdated() {
		return updated;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}
	
	public void setAbleToShowResults(boolean ableToShowResults) {
		this.ableToShowResults = ableToShowResults;
	}

	public boolean isAbleToShowResults() {
		return ableToShowResults;
	}

	public Set<UserSurvey> getUserSurveys() throws FatalException, InvalidParameterException {
		if(userSurveys == null) {
			userSurveys = SurveyManager.getUserSurveys(this);
		}
		return userSurveys;
	}

	public List<SurveyResult> getResults() throws FatalException, InvalidParameterException {
		if(results == null) {
			results = SurveyManager.getSurveyResults(this);
		}
		return results;
	}	
	
	public String getFullResponse(String response) {
		//if the user responds with a partial entry, try and match it up with a full response
		if(StringUtil.isNullOrEmpty(response)) {
			response = "";
		}
		response = response.trim();
		
		String responseGuess = response;
		if(getContent().contains(response)) {
			String[] contentLines = getContent().split("\\\\n");
			for(String contentLine : contentLines) {
				logger.debug("Checking line " + contentLine + " of survey content for response " + response);
				if(contentLine.contains(response)) {
					responseGuess = contentLine;
					break;
				}
			}
		}
		logger.debug("Got survey response of " + response + ", guessing full response is " + responseGuess);
		return responseGuess;
	}
}
