package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.List;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.SurveyResultType;

public class SurveyResult implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String response;
	private long count;
	private int percentage;

	public SurveyResult(String response, long count) {
		setResponse(response);
		setCount(count);
	}
	
	public SurveyResultType toSurveyResultType() throws FatalException, InvalidParameterException {
		SurveyResultType surveyResultType = new SurveyResultType();
		surveyResultType.setResponse(getResponse());
		surveyResultType.setCount(getCount());
		surveyResultType.setPercentage(getPercentage());
		
		return surveyResultType;
	}
	
	public static SurveyResult from(MySQL mysql) throws InvalidParameterException, FatalException {
		SurveyResult surveyResult = new SurveyResult(
			(String)mysql.getColumn("response"),
			(Long)mysql.getColumn("count")
		);
		return surveyResult;
	}	
	
	public static String toString(List<SurveyResult> surveyResults) {
		String str = "";
		int count = 0;
		for(SurveyResult surveyResult : surveyResults) {
			str+= surveyResult.getResponse() + " - " + surveyResult.getPercentage() + "%\n";
			count++;
			if(count == 5) {
				//only show the top 5 results to avoid showing inappropriate minority responses
				break;
			}
		}
		return str;
	}
	
	public void setResponse(String response) {
		this.response = response;
	}

	public String getResponse() {
		return response;
	}

	public void setCount(long count) {
		this.count = count;
	}

	public long getCount() {
		return count;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	public int getPercentage() {
		return percentage;
	}

}
