package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.conf.FatalException;
		
public abstract class Trigger extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = -5933337926917943848L;

	public static enum Type {
		DELETE_EVENT_TRIGGER,
		DELETE_SCHEDULED_TRIGGER,
		DELETE_USER_MESSAGE,
		API_REQUEST,
		URL_CALLBACK
	}
	
	/* 
	 * NOTE! Any fields added here that should be saved MUST be added as getters
	 * in ScheduledTrigger and EventTrigger (see the bottom of each file)
	 */
	private Customer customer;
	private User user;
	private Address address;
	private String data;
	private Type type;
	private Long typeId;
	private boolean triggered;
	private boolean archived;
	private Date created;
	
	public Trigger(Event event, Type type, Long typeId, String data) throws FatalException {
		setCustomer(event.getCustomer());
		setAddress(event.getAddress());
		setUser(event.getUser());
		setType(type);
		setTypeId(typeId);
		setData(data);
	}	
	
	public Trigger(Customer customer, User user, Device device, Address address, Type type, Long typeId, String data) throws FatalException {
		setCustomer(customer);
		setAddress(address);
		//TODO: set device?
		setUser(user);
		setType(type);
		setTypeId(typeId);
		setData(data);
	}	

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public User getUser() {
		return user;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}

	public void setTypeId(Long typeId) {
		this.typeId = typeId;
	}

	public Long getTypeId() {
		return typeId;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Type getType() {
		return type;
	}

	public void setTriggered(boolean triggered) {
		this.triggered = triggered;
	}

	public boolean isTriggered() {
		return triggered;
	}
	
	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public boolean isArchived() {
		return archived;
	}

	public void setArchived(boolean archived) {
		this.archived = archived;
	}

}
