package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.UnlinkedDeviceApplicationType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.ApplicationManager;
import com.viralogy.rewardme.manager.CheckinOptionManager;

@MySQLTable(name=MySQL.TABLES.UNLINKED_DEVICE_APPLICATION, 
		primaryKey="unlinkedDeviceApplicationId",
		transients={}
)

public class UnlinkedDeviceApplication extends DatabaseBackedObject implements Serializable {
		
	private static final long serialVersionUID = -4326078996684821519L;
		
	private long unlinkedDeviceApplicationId;
	private Application application;
	private Address address;
	private CheckinOption checkinOption;
	private Date updated;
	private Date created;
	
	public UnlinkedDeviceApplication() {
		
	}
	
	public UnlinkedDeviceApplicationType toUnlinkedDeviceApplicationType() throws FatalException, InvalidParameterException {
		UnlinkedDeviceApplicationType unlinkedDeviceApplicationType = new UnlinkedDeviceApplicationType();
		unlinkedDeviceApplicationType.setUnlinkedDeviceApplicationId(getUnlinkedDeviceApplicationId());
		unlinkedDeviceApplicationType.setApplication(getApplication().toApplicationType(false));
		unlinkedDeviceApplicationType.setAddress(getAddress().toAddressType());
		unlinkedDeviceApplicationType.setCheckinOption(getCheckinOption() == null ? null : getCheckinOption().toCheckinOptionType());
		unlinkedDeviceApplicationType.setUpdated(getUpdated() == null ? null : getUpdated().getTime());
		unlinkedDeviceApplicationType.setCreated(getCreated() == null ? null : getCreated().getTime());
		return unlinkedDeviceApplicationType;
	}
	
	public static UnlinkedDeviceApplication from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		UnlinkedDeviceApplication unlinkedDeviceApplication = new UnlinkedDeviceApplication();
		unlinkedDeviceApplication.setUnlinkedDeviceApplicationId((Long)mysql.getColumn("unlinked_device_application_id"));
		unlinkedDeviceApplication.setApplication(ApplicationManager.getApplication((Long)mysql.getColumn("application_id")));
		unlinkedDeviceApplication.setAddress(AddressManager.getAddress((Long)mysql.getColumn("address_id"), false));
		Long checkinOptionId = (Long)mysql.getColumn("checkin_option_id");
		if(checkinOptionId != null) {
			unlinkedDeviceApplication.setCheckinOption(CheckinOptionManager.getCheckinOption(checkinOptionId));
		}
		unlinkedDeviceApplication.setUpdated((Date)mysql.getColumn("updated"));		
		unlinkedDeviceApplication.setCreated((Date)mysql.getColumn("created"));		
				
		return unlinkedDeviceApplication;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}

	public void setUpdated(Date updated) {
		this.updated = updated;
	}

	public Date getUpdated() {
		return updated;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}


	public void setCheckinOption(CheckinOption checkinOption) {
		this.checkinOption = checkinOption;
	}


	public CheckinOption getCheckinOption() {
		return checkinOption;
	}

	public void setUnlinkedDeviceApplicationId(long unlinkedDeviceApplicationId) {
		this.unlinkedDeviceApplicationId = unlinkedDeviceApplicationId;
	}

	public long getUnlinkedDeviceApplicationId() {
		return unlinkedDeviceApplicationId;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public Application getApplication() {
		return application;
	}
	
	
}