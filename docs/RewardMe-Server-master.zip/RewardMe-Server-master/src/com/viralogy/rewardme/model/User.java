package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.UserType;
import com.viralogy.rewardme.manager.PointsManager;
import com.viralogy.rewardme.manager.PreferencesManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.social.Social;
import com.viralogy.rewardme.util.StringUtil;

@MySQLTable(name=MySQL.TABLES.USER, 
		primaryKey="userId",
		transients={
			"authorized",
			"shortUserCheckins",
			"userCheckins",
			"points",
			"escrowPoints",
			"userPreference",
			"userPreferences",
			"devices",
			"social"
		}
)

public class User extends DatabaseBackedObject implements Serializable {

	private static Logger logger = Logger.getLogger(User.class);
	
	private static final long serialVersionUID = 7114517961367041976L;

	private long userId;
	private boolean mobile;
	private String phoneNumber;
	private String pinCode;
	private GeoCoord geoCoord;
	
	private Map<Long, List<UserCheckin>> customerToUserCheckins = null;	
	private Map<Long, Map<String, UserPreference>> userPreferences;	
	private List<Device> devices;
	private Map<Long, UserPoints> customerToPoints;
	private Map<Long, UserPoints> customerToEscrowPoints;
	private Social social;
	
	private boolean authorized = false;	//transient - indicates if the user can edit the request's customer
		
	public User() {

	}
	
	public User(long userId) {
		setUserId(userId);
	}
	
	public String toString() {
		return "Id: " + userId;
	}


	public UserType toUserType(Customer customer) throws InvalidParameterException, FatalException {
		PointCategory pointCategory = customer == null ? null : PointsManager.getDefaultPointCategory(customer);
		return toUserType(customer, pointCategory);
	}
		
	public UserType toUserType(Customer customer, PointCategory pointCategory) throws InvalidParameterException, FatalException {
					
		UserType userType = new UserType();
		userType.setUserId(getUserId());
		userType.setPhoneNumber(getPhoneNumber());
		if(customer != null) {
			userType.setPoints(getPoints(customer, pointCategory).toUserPointsType(false));
			userType.setEscrowPoints(getEscrowPoints(customer, pointCategory).toUserPointsType(false));
		}
		userType.setHasPIN(!StringUtil.isNullOrEmpty(getPinCode()));
		userType.setMobile(isMobile());
		
		//set the "name" preference on the user object by default
		UserPreference namePref = getUserPreference(Constants.UserPreference.NAME, null);
		if(namePref != null) {
			userType.setName(namePref.getValue());
		}
		
		return userType;
	}
	
	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getUserId() {
		return userId;
	}
	
	public Map<String, UserPreference> getUserPreferences(Customer customer) throws FatalException, InvalidParameterException {
		long customerId = customer == null ? 0 : customer.getCustomerId();
		if(userPreferences == null) {
			userPreferences = new HashMap<Long, Map<String, UserPreference>>();
		}
		Map<String, UserPreference> customerUserPreferences = userPreferences.get(customerId);
		if(customerUserPreferences == null) {
			customerUserPreferences = PreferencesManager.getUserPreferences(this, customer);
			userPreferences.put(customerId, customerUserPreferences);
		}
		return customerUserPreferences;
	}

	public UserPreference getUserPreference(String name, Customer customer) throws FatalException, InvalidParameterException {
		if(!StringUtil.isNullOrEmpty(name)) {
			name = name.toLowerCase();
		}
		return getUserPreferences(customer).get(name);
	}

	public List<Device> getDevices() throws FatalException, InvalidParameterException {
		if(devices == null) {
			devices = UserManager.getDevices(this);
		}
		return devices;
	}	
	
	public void setGeoCoord(GeoCoord geoCoord) {
		this.geoCoord = geoCoord;
	}

	public GeoCoord getGeoCoord() {
		return geoCoord;
	}
	
	public static User from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		User user = new User((Long)mysql.getColumn("user_id"));
		user.setPhoneNumber((String)mysql.getColumn("phone_number"));
		user.setPinCode((String)mysql.getColumn("pin_code"));
		user.setMobile((Boolean)mysql.getColumn("mobile"));
		if(mysql.getColumn("longitude_radians") != null && mysql.getColumn("latitude_radians") != null) {
			user.setGeoCoord(GeoCoord.fromRadians(
					((BigDecimal)mysql.getColumn("longitude_radians")).doubleValue(), 
					((BigDecimal)mysql.getColumn("latitude_radians")).doubleValue()
				)
			);
		}
		
		user.takeFieldValuesSnapshot();
		
		return user;
	}

	public void setAuthorized(boolean authorized) {
		this.authorized = authorized;
	}

	public boolean isAuthorized() throws FatalException {
		return authorized;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getPinCode() {
		return pinCode;
	}
	
	public List<UserCheckin.ShortFormat> getShortUserCheckins(Customer customer, boolean uniqueCustomersOnly) throws FatalException, InvalidParameterException {
		return UserManager.getShortCheckins(this, customer, uniqueCustomersOnly, 100000);
	}
	
	public List<UserCheckin> getUserCheckins(Customer customer, boolean uniqueCustomersOnly) throws FatalException, InvalidParameterException {
		List<UserCheckin> userCheckins = null;
		Long customerId = customer == null ? null : customer.getCustomerId();
		if(customerToUserCheckins == null) {
			customerToUserCheckins = new HashMap<Long, List<UserCheckin>>();
		}
		if(customer != null) {
			userCheckins = customerToUserCheckins.get(customerId);
			if(userCheckins == null) {
				userCheckins = UserManager.getCheckins(this, customer, uniqueCustomersOnly, 100000);
				customerToUserCheckins.put(customerId, userCheckins);
			}
		}else {
			userCheckins = UserManager.getCheckins(this, null, uniqueCustomersOnly, 100000);
		}
		return userCheckins;
	}

	public UserPoints getPoints(Customer customer, PointCategory pointCategory) throws FatalException, InvalidParameterException {
		Long customerId = customer == null ? null : customer.getCustomerId();
		UserPoints points = null;
		if(customerToPoints == null) {
			customerToPoints = new HashMap<Long, UserPoints>();
		}
		
		points = customerToPoints.get(customerId);
		if(points == null) {
			points = PointsManager.getUserPoints(this, customer, null, pointCategory, null);
			customerToPoints.put(customerId, points);
		}
		return points;
	}
	
	public UserPoints getEscrowPoints(Customer customer, PointCategory pointCategory) throws FatalException, InvalidParameterException {
		Long customerId = customer == null ? null : customer.getCustomerId();
		UserPoints escrowPoints = null;
		if(customerToEscrowPoints == null) {
			customerToEscrowPoints = new HashMap<Long, UserPoints>();
		}
		
		if(customer != null) {
			escrowPoints = customerToEscrowPoints.get(customerId);
			if(escrowPoints == null) {
				UserCheckin userCheckin = UserManager.getLastCheckin(this, customer, true);
				if(userCheckin != null) {
					escrowPoints = PointsManager.getUserPoints(this, customer, UserPoints.Type.CHECKIN, pointCategory, userCheckin.getCheckinOption().getCooldownLength());
				}else {
					escrowPoints = new UserPoints(this, customer, pointCategory, null, 0, 0);					
				}
				customerToEscrowPoints.put(customerId, escrowPoints);
			}
		}else {
			escrowPoints = new UserPoints(this, null, pointCategory, null, 0, 0);
		}
		return escrowPoints;
	}
	
	public Social getSocial() throws FatalException{
		if( social == null ) {
			social = new Social(this, true);
		} 
		return social;
	}

	public boolean isMobile() {
		return mobile;
	}

	public void setMobile(boolean mobile) {
		this.mobile = mobile;
	}

	public void clearTransients() {
		customerToPoints = null;
		customerToEscrowPoints = null;
		customerToUserCheckins = null;
		userPreferences = null;
		devices = null;
	}
}
