package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.ShortUserCheckinType;
import com.viralogy.rewardme.jaxb.UserCheckinType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CheckinOptionManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.DeviceManager;
import com.viralogy.rewardme.manager.UserManager;

public class UserCheckin implements Serializable {

	private static final long serialVersionUID = -9019597210489322851L;
	
	private User user;
	private Address address;
	private Customer customer;
	private CheckinOption checkinOption;
	private DeviceApplication deviceApplication;
	private Date created;
	private Long timeRemainingInCooldown;	//transient

	
	public UserCheckin(User user, Address address, Customer customer, CheckinOption checkinOption, DeviceApplication deviceApplication) {
		setUser(user);
		setAddress(address);
		setCustomer(customer);
		setCheckinOption(checkinOption);
		setDeviceApplication(deviceApplication);
	}
	
	public UserCheckin() {
	}

	public UserCheckinType toUserCheckinType(boolean includeUser) throws FatalException, InvalidParameterException {
		UserCheckinType userCheckinType = new UserCheckinType();
		userCheckinType.setCheckinOption(getCheckinOption().toCheckinOptionType());
		if(includeUser) {
			userCheckinType.setUser(getUser().toUserType(getCustomer()));
		}
		userCheckinType.setAddress(getAddress().toAddressType());
		userCheckinType.setCustomer(getCustomer().toCustomerType(null, false, false));
		
		userCheckinType.setCreated(getCreated() == null ? null : getCreated().getTime());

		return userCheckinType;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public User getUser() {
		return user;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}

	public void setCheckinOption(CheckinOption checkinOption) {
		this.checkinOption = checkinOption;
	}

	public CheckinOption getCheckinOption() {
		return checkinOption;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public static UserCheckin from(MySQL mysql, Customer customer, User user) throws InvalidParameterException, FatalException {
		Long deviceApplicationId = (Long)mysql.getColumn("device_application_id");
		UserCheckin userCheckin = new UserCheckin(
				user == null ? UserManager.getUser((Long)mysql.getColumn("user_id")) : user, 
				AddressManager.getAddress((Long)mysql.getColumn("address_id"), false), 
				customer == null ? CustomerManager.getCustomer((Long)mysql.getColumn("customer_id")) : customer,
				CheckinOptionManager.getCheckinOption((Long)mysql.getColumn("checkin_option_id")), 
				deviceApplicationId == 0 ? null : DeviceManager.getDeviceApplication(deviceApplicationId)
		);
		userCheckin.setCreated((Date)mysql.getColumn("created"));
		
		return userCheckin;
	}
	
	public static UserCheckin from(MySQL mysql) throws InvalidParameterException, FatalException {
		Long deviceApplicationId = (Long)mysql.getColumn("device_application_id");
		Long userId = (Long)mysql.getColumn("user_id");
		UserCheckin userCheckin = new UserCheckin(
				userId == null ? null : UserManager.getUser(userId), 
				AddressManager.getAddress((Long)mysql.getColumn("address_id"), false), 
				CustomerManager.getCustomer((Long)mysql.getColumn("customer_id")),
				CheckinOptionManager.getCheckinOption((Long)mysql.getColumn("checkin_option_id")), 
				deviceApplicationId == 0 ? null : DeviceManager.getDeviceApplication(deviceApplicationId)
		);
		userCheckin.setCreated((Date)mysql.getColumn("created"));
		
		return userCheckin;
	}


	public void setTimeRemainingInCooldown(Long timeRemainingInCooldown) {
		this.timeRemainingInCooldown = timeRemainingInCooldown;
	}

	public Long getTimeRemainingInCooldown() {
		return timeRemainingInCooldown;
	}
	
	
	
	
	
	
	public DeviceApplication getDeviceApplication() {
		return deviceApplication;
	}

	public void setDeviceApplication(DeviceApplication deviceApplication) {
		this.deviceApplication = deviceApplication;
	}






	public static class ShortFormat implements Serializable {

		private static final long serialVersionUID = -9019597210489322851L;
			
		private long addressId;
		private long customerId;
		private Date created;

		public ShortFormat(long customerId, long addressId) {
			setCustomerId(customerId);
			setAddressId(addressId);
		}
		
		public ShortUserCheckinType toShortUserCheckinType() throws FatalException, InvalidParameterException {
			ShortUserCheckinType shortUserCheckinType = new ShortUserCheckinType();
			shortUserCheckinType.setAddressId(getAddressId());
			shortUserCheckinType.setCustomerId(getCustomerId());
			shortUserCheckinType.setCreated(getCreated() == null ? null : getCreated().getTime());
			return shortUserCheckinType;
		}
		
		public static UserCheckin.ShortFormat from(MySQL mysql) throws InvalidParameterException, FatalException {
			UserCheckin.ShortFormat shortUserCheckin = new UserCheckin.ShortFormat(
					(Long)mysql.getColumn("customer_id"),
					(Long)mysql.getColumn("address_id")
			);
			shortUserCheckin.setCreated((Date)mysql.getColumn("created"));
			return shortUserCheckin;
		}

		public void setAddressId(long addressId) {
			this.addressId = addressId;
		}

		public long getAddressId() {
			return addressId;
		}

		public void setCustomerId(long customerId) {
			this.customerId = customerId;
		}

		public long getCustomerId() {
			return customerId;
		}

		public void setCreated(Date created) {
			this.created = created;
		}

		public Date getCreated() {
			return created;
		}

	}
}


