package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.UserMessageType;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.UserManager;

@MySQLTable(name=MySQL.TABLES.USER_MESSAGE, 
		primaryKey="userMessageId",
		transients={})
		
public class UserMessage extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = 7290093610577632050L;
	
	private long userMessageId;
	private Customer customer;
	private User user;
	private String message;
	private boolean sent;
	private Date timestamp;
	private Date created;
	
	public UserMessage(Customer customer, User user, Date timestamp, String message) throws FatalException {
		setCustomer(customer);
		setUser(user);
		setTimestamp(timestamp);
		setMessage(message);
	}
	
	public UserMessageType toUserMessageType() throws InvalidParameterException, FatalException {
		UserMessageType userMessageType = new UserMessageType();
		userMessageType.setUserMessageId(getUserMessageId());
		userMessageType.setSent(isSent());
		userMessageType.setCustomer(customer.toCustomerType(user, false, false));
		userMessageType.setUser(user.toUserType(null));
		userMessageType.setMessage(message);
		userMessageType.setTimestamp(getTimestamp() == null ? null : getTimestamp().getTime());
		userMessageType.setCreated(getCreated() == null ? null : getCreated().getTime());
		return userMessageType;
	}
	
	public String toString() {
		return "userMessageId: " + userMessageId;
	}
	
	public void setUserMessageId(long userMessageId) {
		this.userMessageId = userMessageId;
	}

	public long getUserMessageId() {
		return userMessageId;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
	
	public static UserMessage from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		Customer customer = CustomerManager.getCustomer((Long)mysql.getColumn("customer_id"));
		User user = UserManager.getUser((Long)mysql.getColumn("user_id"));
		String message = (String)mysql.getColumn("message");
		Date timestamp = (Date)mysql.getColumn("timestamp");
		
		UserMessage userMessage = new UserMessage(customer, user, timestamp, message);

		userMessage.setCreated((Date)mysql.getColumn("created"));
		userMessage.setUserMessageId((Long)mysql.getColumn("user_message_id"));
		userMessage.setSent((Boolean)mysql.getColumn("sent"));

		userMessage.takeFieldValuesSnapshot();
		
		return userMessage;
	}


	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public User getUser() {
		return user;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setSent(boolean sent) {
		this.sent = sent;
	}

	public boolean isSent() {
		return sent;
	}
}
