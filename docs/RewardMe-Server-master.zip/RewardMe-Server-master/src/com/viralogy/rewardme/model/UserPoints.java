package com.viralogy.rewardme.model;

import java.io.Serializable;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.UserPointsType;
import com.viralogy.rewardme.util.ListUtil;

public class UserPoints implements Serializable {
	
	private static final long serialVersionUID = -5770014530376404326L;
	
	public static enum Type {
		CHECKIN,
		REFERRAL,
		REDEEM,
		GIFT,
		SOCIAL,
		PROMOTIONAL,
		INCENTIVE,
		CHEATING,
		TRANSFER
	}
	
	private User user;
	private Customer customer;
	private PointCategory pointCategory;
	private long earnedBalance;
	private long currentBalance;
	private Type type;
	
	public UserPoints(User user, Customer customer, PointCategory pointCategory, Type type, long earnedBalance, long currentBalance) {
		setUser(user);
		setType(type);
		setCustomer(customer);
		setPointCategory(pointCategory);
		setEarnedBalance(earnedBalance);
		setCurrentBalance(currentBalance);
	}
	
	public String toString() {
		return "userId: " + user.getUserId() + ", customerId: " + (customer == null ? 0 : customer.getCustomerId()) +", earnedBalance: "+earnedBalance+", currentBalance:"+currentBalance;
	}
	
	public UserPointsType toUserPointsType(boolean includeUser) throws InvalidParameterException, FatalException {
		UserPointsType userPointsType = new UserPointsType();
		if(includeUser) {
			userPointsType.setUser(user.toUserType(null));
		}
		if(customer != null) {
			userPointsType.setCustomer(getCustomer().toCustomerType(user, false, false));
		}
		userPointsType.setCurrentBalance(getCurrentBalance());
		userPointsType.setEarnedBalance(getEarnedBalance());
		if(type != null) {
			userPointsType.setType(getType().toString());
		}
		if(pointCategory != null) {
			userPointsType.setPointCategory(getPointCategory().toPointCategoryType());
		}
		return userPointsType;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}
	
	public void setUser(User user) {
		this.user = user;
	}

	public User getUser() {
		return user;
	}

	public void setEarnedBalance(long earnedBalance) {
		this.earnedBalance = earnedBalance;
	}

	public long getEarnedBalance() {
		return earnedBalance;
	}

	public void setCurrentBalance(long currentBalance) {
		this.currentBalance = currentBalance;
	}

	public long getCurrentBalance() {
		return currentBalance;
	}		
	
	public void credit(long points) {
		earnedBalance+= points;
		currentBalance+= points;
	}
	
	public void debit(long points) throws InvalidParameterException {
		if((currentBalance-points) < 0) {
			throw new InvalidParameterException(Constants.Error.POINTS.INSUFFICIENT_POINTS,ListUtil.from(points+"", currentBalance+"", 0+""));
		}
		currentBalance-= points;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Type getType() {
		return type;
	}

	public PointCategory getPointCategory() {
		return pointCategory;
	}

	public void setPointCategory(PointCategory pointCategory) {
		this.pointCategory = pointCategory;
	}
}
