package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.UserPreferenceType;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.UserManager;

@MySQLTable(name=MySQL.TABLES.USER_PREFERENCE, 
		primaryKey="userPreferenceId",
		transients={}
)

public class UserPreference extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = 8157722218957381855L;
	
	public static final class KEYS {
		public static final String NAME = "name";
	}
	
	private long userPreferenceId;
	private User user;
	private Customer customer;
	private String name;
	private String value;
	private Date updated;
	private Date created;

	public UserPreference() {
		
	}
	
	public UserPreference(User user, Customer customer, String name, String value) {
		setUser(user);
		setCustomer(customer);
		setName(name);
		setValue(value);
	}
	
	public String toString() {
		return "Id: " + userPreferenceId;
	}
	
	public UserPreferenceType toUserPreferenceType() throws InvalidParameterException, FatalException {
		UserPreferenceType userPreferenceType = new UserPreferenceType();
		userPreferenceType.setUserPreferenceId(getUserPreferenceId());
		userPreferenceType.setName(getName());
		userPreferenceType.setValue(getValue());
		userPreferenceType.setCreated(getCreated() == null ? null : getCreated().getTime());
		userPreferenceType.setUpdated(getUpdated().getTime());
		userPreferenceType.setPrivate(getCustomer() == null ? false : true);
		
		return userPreferenceType;
	}
	

	public static UserPreference from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		UserPreference userPreference = new UserPreference();
		userPreference.setUserPreferenceId((Long)mysql.getColumn("user_preference_id"));
		userPreference.setUser(UserManager.getUser((Long)mysql.getColumn("user_id")));
		Long customerId = (Long)mysql.getColumn("customer_id");
		if(customerId != null && customerId != 0) {
			userPreference.setCustomer(CustomerManager.getCustomer(customerId));
		}
		userPreference.setName((String)mysql.getColumn("name"));
		userPreference.setValue((String)mysql.getColumn("value"));	
		userPreference.setCreated((Date)mysql.getColumn("created"));
		userPreference.setUpdated((Date)mysql.getColumn("updated"));
		
		userPreference.takeFieldValuesSnapshot();
		
		return userPreference;
	}

	public void setUserPreferenceId(long userPreferenceId) {
		this.userPreferenceId = userPreferenceId;
	}

	public long getUserPreferenceId() {
		return userPreferenceId;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public User getUser() {
		return user;
	}

	public void setName(String name) {
		this.name = name == null ? null : name.toLowerCase();
	}

	public String getName() {
		return name;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}		
	
	public Date getUpdated() {
		return updated;
	}

	public void setUpdated(Date updated) {
		this.updated = updated;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}
}
