package com.viralogy.rewardme.model;

import java.io.Serializable;

import java.util.Date;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.UserReferralType;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.UserManager;

public class UserReferral implements Serializable {
	
	private static final long serialVersionUID = 8791326550661818416L;
	
	private User referrer;
	private User referred;
	private Customer customer;
	private Date firstUsed;
	
	public UserReferral(User referrer, User referred, Customer customer, Date firstUsed) {
		setReferrer(referrer);
		setReferred(referred);
		setCustomer(customer);
		setFirstUsed(firstUsed);
	}
	
	public String toString() {
		return "Referrer userId: " + referrer.getUserId() + ", Referred userId: " + referred.getUserId();
	}
	
	public UserReferralType toUserReferralType() throws InvalidParameterException, FatalException {
		UserReferralType userReferralType = new UserReferralType();
		userReferralType.setReferrer(getReferrer().toUserType(null));
		userReferralType.setReferred(getReferred().toUserType(null));
		userReferralType.setCustomer(getCustomer().toCustomerType(null, false, false));
		userReferralType.setFirstUsedTs(getFirstUsed() != null ? getFirstUsed().getTime() : null);
		return userReferralType;
	}

	public void setReferrer(User referrer) {
		this.referrer = referrer;
	}

	public User getReferrer() {
		return referrer;
	}

	public void setReferred(User referred) {
		this.referred = referred;
	}

	public User getReferred() {
		return referred;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}
	
	public static UserReferral from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		User referrer = UserManager.getUser((Long)mysql.getColumn("referrer_id"));
		User referred = UserManager.getUser((Long)mysql.getColumn("referred_id"));
		Customer customer = CustomerManager.getCustomer((Long)mysql.getColumn("customer_id"));
		Date firstUsed = (Date)mysql.getColumn("first_used");

		UserReferral userRefferal = new UserReferral(referrer, referred, customer, firstUsed);
		
		return userRefferal;
	}

	public void setFirstUsed(Date firstUsed) {
		this.firstUsed = firstUsed;
	}

	public Date getFirstUsed() {
		return firstUsed;
	}		
}
