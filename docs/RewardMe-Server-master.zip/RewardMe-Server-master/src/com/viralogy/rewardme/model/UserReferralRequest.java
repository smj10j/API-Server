package com.viralogy.rewardme.model;

import java.io.Serializable;


import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.UserReferralRequestType;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.util.StringUtil;

public class UserReferralRequest implements Serializable {
	
	private static final long serialVersionUID = 1648165879185671168L;
	
	private long userReferralRequestId;
	private User referrer;
	private User referred;
	private String referredPhoneNumber;
	private Customer customer;
	
	public UserReferralRequest(User referrer, User referred, String referredPhoneNumber, Customer customer) throws FatalException {
		if(referred != null && !StringUtil.isNullOrEmpty(referredPhoneNumber)) {
			throw new FatalException("Tried to create a user referral request with both a referrer user and a referred phone number. Choose one or the other");
		}else if(referred == null && StringUtil.isNullOrEmpty(referredPhoneNumber)) {	
			throw new FatalException("Tried to create a user referral request with neither a referrer user nor a referred phone number. Must have at least one");
		}
		setReferrer(referrer);
		setReferred(referred);
		setReferredPhoneNumber(referredPhoneNumber);
		setCustomer(customer);
	}
	
	public String toString() {
		return "userReferralRequestIdd: " + userReferralRequestId;
	}
	
	public UserReferralRequestType toUserReferralRequestType() throws InvalidParameterException, FatalException {
		UserReferralRequestType userReferralRequestType = new UserReferralRequestType();
		userReferralRequestType.setUserReferralRequestId(getUserReferralRequestId());
		userReferralRequestType.setReferrer(getReferrer().toUserType(null));
		if(referred != null) userReferralRequestType.setReferred(getReferred().toUserType(null));
		if(referredPhoneNumber != null) userReferralRequestType.setReferredPhoneNumber(getReferredPhoneNumber());
		userReferralRequestType.setCustomer(getCustomer().toCustomerType(null, false, false));
		return userReferralRequestType;
	}

	public void setReferrer(User referrer) {
		this.referrer = referrer;
	}

	public User getReferrer() {
		return referrer;
	}

	public void setReferred(User referred) {
		this.referred = referred;
	}

	public User getReferred() {
		return referred;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}
	
	public static UserReferralRequest from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		User referrer = UserManager.getUser((Long)mysql.getColumn("referrer_id"));
		User referred = null;
		String referredPhoneNumber = null;
		if(mysql.getColumn("referred_id") != null) {
			referred = UserManager.getUser((Long)mysql.getColumn("referred_id"));
		}else if(mysql.getColumn("referred_phone_number") != null) {
			referredPhoneNumber = (String)mysql.getColumn("referred_phone_number");
		}
		Customer customer = CustomerManager.getCustomer((Long)mysql.getColumn("customer_id"));

		UserReferralRequest userRefferalRequest = new UserReferralRequest(referrer, referred, referredPhoneNumber, customer);
		
		long userReferralRequestId = (Long)mysql.getColumn("user_referral_request_id");
		userRefferalRequest.setUserReferralRequestId(userReferralRequestId);
		
		return userRefferalRequest;
	}

	public void setReferredPhoneNumber(String referredPhoneNumber) {
		this.referredPhoneNumber = referredPhoneNumber;
	}

	public String getReferredPhoneNumber() {
		return referredPhoneNumber;
	}

	public void setUserReferralRequestId(long userReferralRequestId) {
		this.userReferralRequestId = userReferralRequestId;
	}

	public long getUserReferralRequestId() {
		return userReferralRequestId;
	}
}
