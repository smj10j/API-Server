package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.UserRewardType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.RewardManager;
import com.viralogy.rewardme.manager.UserManager;


public class UserReward implements Serializable {
	
	private static final long serialVersionUID = -5818056733208906582L;
	
	private User user;
	private Reward reward;
	private Customer customer;
	private Date created;
	private Address address;

	public UserReward(User user, Reward reward, Customer customer, Address address) {
		this.setUser(user);
		this.setReward(reward);
		this.setCustomer(customer);
		this.setAddress(address);
	}
	
	public UserRewardType toUserRewardType( ) throws FatalException, InvalidParameterException{
        UserRewardType userRewardType = new UserRewardType();
        
        userRewardType.setAddress( getAddress().toAddressType());
        userRewardType.setReward( getReward().toRewardType() );
        userRewardType.setTimestamp( getCreated() != null ? getCreated().getTime() : null );
        userRewardType.setUser( getUser().toUserType( null ) );
        
        return userRewardType;
    }
		
	public void setUser(User user) {
		this.user = user;
	}

	public User getUser() {
		return user;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setReward(Reward reward) {
		this.reward = reward;
	}

	public Reward getReward() {
		return reward;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public static UserReward from(MySQL mysql) throws InvalidParameterException, FatalException {
		
		User user = UserManager.getUser((Long)mysql.getColumn("user_id"));
		Customer customer = CustomerManager.getCustomer((Long)mysql.getColumn("customer_id"));
		Reward reward = RewardManager.getReward((Long)mysql.getColumn("reward_id"));
		Address address = AddressManager.getAddress((Long)mysql.getColumn("address_id"), false);
		
		UserReward userReward = new UserReward(
				user, 
				reward,
				customer,
				address
		);
		userReward.setCreated((Date)mysql.getColumn("created"));
				
		return userReward;
	}

	public void setAddress( Address address) {
	    this.address = address;
	}
	
	public Address getAddress() {
	    return address;
	}
}
