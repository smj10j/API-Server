package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import org.json.JSONException;

import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.UserSegmentType;
import com.viralogy.rewardme.manager.SegmentManager;
import com.viralogy.rewardme.manager.UserManager;

public class UserSegment extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = 4774664034646628349L;
	private User user;
	private Segment segment;
	private Date created;

	public UserSegment(User user, Segment segment) {
		this.setUser(user);
		this.setSegment(segment);
	}
	
	public UserSegmentType toUserSegmentType() throws FatalException, InvalidParameterException{
        UserSegmentType userSegmentType = new UserSegmentType();
        
        userSegmentType.setUser( getUser().toUserType( null ) );
        userSegmentType.setSegment( getSegment().toSegmentType());
        userSegmentType.setTimestamp( getCreated() != null ? getCreated().getTime() : null );
        
        return userSegmentType;
    }
		
	public void setUser(User user) {
		this.user = user;
	}

	public User getUser() {
		return user;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setSegment(Segment segment) {
		this.segment = segment;
	}

	public Segment getSegment() {
		return segment;
	}

	public static UserSegment from(MySQL mysql) throws InvalidParameterException, FatalException {
		User user = UserManager.getUser((Long)mysql.getColumn("user_id"));
		Segment segment = SegmentManager.getSegment((Long)mysql.getColumn("segment_id"));
		
		UserSegment userSegment = new UserSegment(user, segment);
		userSegment.setCreated((Date)mysql.getColumn("created"));
		
		return userSegment;
	}

}
