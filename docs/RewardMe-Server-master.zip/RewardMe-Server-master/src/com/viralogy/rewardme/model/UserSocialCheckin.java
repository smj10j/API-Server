package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.UserSocialCheckinType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.social.Social.Type;

@MySQLTable(name=MySQL.TABLES.USER_SOCIAL_CHECKIN, 
		primaryKey="userSocialCheckinId",
		transients={
			"dimensionToValue",
			"factToCount"
		}
)

public class UserSocialCheckin extends DatabaseBackedObject implements Serializable{

	private static final long serialVersionUID = 6057189104526435293L;

	private long userSocialCheckinId;
	private User user;
	private Customer customer;
	private Address address;
	private Type type;
	private Date created;
	
	public UserSocialCheckin(User user, Customer customer, Address address, Type type) {
		setUser(user);
		setCustomer(customer);
		setAddress(address);
		setType(type);
	}
	
	public UserSocialCheckinType toUserSocialCheckinType() throws FatalException, InvalidParameterException {
		UserSocialCheckinType userSocialCheckinType = new UserSocialCheckinType();
		userSocialCheckinType.setUser(getUser().toUserType(customer));
		userSocialCheckinType.setCustomer(getCustomer().toCustomerType(null, false, false));
		userSocialCheckinType.setAddress(getAddress().toAddressType());
		userSocialCheckinType.setType(getType().toString());
		userSocialCheckinType.setCreated(getCreated() == null ? null : getCreated().getTime());
		
		return userSocialCheckinType;
	}
	
	public void setUserSocialCheckinId(long userSocialCheckinId) {
		this.userSocialCheckinId = userSocialCheckinId;
	}
	
	public long getUserSocialCheckinId() {
		return userSocialCheckinId;
	}
	
	public void setUser(User user) {
		this.user = user;
	}
	
	public User getUser() {
		return user;
	}
	
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	public Customer getCustomer() {
		return customer;
	}
	
	public void setAddress(Address address) {
		this.address = address;
	}
	
	public Address getAddress() {
		return address;
	}
	
	public void setType(Type type ) {
		this.type = type;
	}
	
	public Type getType() {
		return type;
	}
	
	public void setCreated(Date created) {
		this.created = created;
	}
	
	public Date getCreated() {
		return created;
	}
	
	public static UserSocialCheckin from(MySQL mysql) throws FatalException, InvalidParameterException{
		User user = UserManager.getUser((Long)mysql.getColumn("user_id"));
		Customer customer = CustomerManager.getCustomer((Long)mysql.getColumn("customer_id"));
		Address address = AddressManager.getAddress((Long)mysql.getColumn("address_id"), false);
		Type type = Type.valueOf((String)mysql.getColumn("type"));
		
		UserSocialCheckin userSocialCheckin = new UserSocialCheckin( user, customer, address, type);
		userSocialCheckin.setCreated((Date)mysql.getColumn("created"));
		userSocialCheckin.setUserSocialCheckinId((Long)mysql.getColumn("user_social_checkin_id"));
		return userSocialCheckin;
	}

}
