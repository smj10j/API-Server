package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.SurveyManager;
import com.viralogy.rewardme.manager.UserManager;

@MySQLTable(name=MySQL.TABLES.USER_SURVEY, 
		primaryKey="userSurveyId",
		transients={
		
		}
)
public class UserSurvey extends DatabaseBackedObject implements Serializable {

	private static final long serialVersionUID = -8558712842764302280L;
	
	private long userSurveyId;
	private User user;
	private Survey survey;
	private Address address;
	private String response;
	private boolean sent;
	private Date created;
	
	public UserSurvey(User user, Survey survey, Address address) {
		setUser(user);
		setSurvey(survey);
		setAddress(address);
	}

	public void setUser(User user) {
		this.user = user;
	}

	public User getUser() {
		return user;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}


	public static UserSurvey from(MySQL mysql) throws InvalidParameterException, FatalException {
		Long addressId = (Long)mysql.getColumn("address_id");
		UserSurvey userSurvey = new UserSurvey(
				UserManager.getUser((Long)mysql.getColumn("user_id")), 
				SurveyManager.getSurvey((Long)mysql.getColumn("survey_id")),
				addressId == null ? null : AddressManager.getAddress(addressId, false) 
		);
		userSurvey.setUserSurveyId((Long)mysql.getColumn("user_survey_id"));
		userSurvey.setResponse((String)mysql.getColumn("response"));
		userSurvey.setSent((Boolean)mysql.getColumn("sent"));
		userSurvey.setCreated((Date)mysql.getColumn("created"));
		
		return userSurvey;
	}	
	
	public void setSurvey(Survey survey) {
		this.survey = survey;
	}

	public Survey getSurvey() {
		return survey;
	}

	public void setUserSurveyId(long userSurveyId) {
		this.userSurveyId = userSurveyId;
	}

	public long getUserSurveyId() {
		return userSurveyId;
	}

	public void setSent(boolean sent) {
		this.sent = sent;
	}

	public boolean isSent() {
		return sent;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getResponse() {
		return response;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}

}


