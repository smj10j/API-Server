package com.viralogy.rewardme.model;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.manager.MessageManager;
import com.viralogy.rewardme.manager.UserManager;


@MySQLTable(name=MySQL.TABLES.USER_TO_CUSTOMER_BROADCAST_MESSAGE, 
		primaryKey="userToCustomerBroadcastMessageId",
		transients={
		
		}
)

public class UserToCustomerBroadcastMessage extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = 7290093610577632050L;
	
	private long userToCustomerBroadcastMessageId;
	private CustomerBroadcastMessage customerBroadcastMessage;
	private boolean viewed;
	private User user;
	private Date created;
	
	public UserToCustomerBroadcastMessage(User user, CustomerBroadcastMessage customerBroadcastMessage, boolean viewed) throws FatalException {
		setCustomerBroadcastMessage(customerBroadcastMessage);
		setUser(user);
		setViewed(viewed);
	}
	
	public static UserToCustomerBroadcastMessage from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		CustomerBroadcastMessage customerBroadcastMessage = MessageManager.getCustomerBroadcastMessage((Long)mysql.getColumn("customer_broadcast_message_id"));
		User user = UserManager.getUser((Long)mysql.getColumn("user_id"));
		UserToCustomerBroadcastMessage userToCustomerBroadcastMessage = new UserToCustomerBroadcastMessage( 
				user,
				customerBroadcastMessage,
				(Boolean)mysql.getColumn("viewed")
		);
		userToCustomerBroadcastMessage.setCreated((Date)mysql.getColumn("created"));
		userToCustomerBroadcastMessage.setUserToCustomerBroadcastMessageId((Long)mysql.getColumn("user_to_customer_broadcast_message_id"));
		
		return userToCustomerBroadcastMessage;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public User getUser() {
		return user;
	}

	public void setCustomerBroadcastMessage(CustomerBroadcastMessage customerBroadcastMessage) {
		this.customerBroadcastMessage = customerBroadcastMessage;
	}

	public CustomerBroadcastMessage getCustomerBroadcastMessage() {
		return customerBroadcastMessage;
	}

	public void setUserToCustomerBroadcastMessageId(long userToCustomerBroadcastMessageId) {
		this.userToCustomerBroadcastMessageId = userToCustomerBroadcastMessageId;
	}

	public long getUserToCustomerBroadcastMessageId() {
		return userToCustomerBroadcastMessageId;
	}

	public void setViewed(boolean viewed) {
		this.viewed = viewed;
	}

	public boolean isViewed() {
		return viewed;
	}
}
