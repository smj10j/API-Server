package com.viralogy.rewardme.pos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.POSDiscountType;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.DatabaseBackedObject;

@MySQLTable(name=MySQL.TABLES.POS.DISCOUNT, 
		primaryKey="posDiscountId",
		transients={
		}
)
		
public class Discount extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = 6975096856344163376L;
	
	public static enum Type {
		PERCENTAGE,
		VALUE
	}
	
	private long posDiscountId;
	private String externalPosDiscountId;
	private Type type;
	private float value;
	private Customer customer;
	private Date created;
	
	public Discount(Customer customer, Type type, float value, String externalPosDiscountId) {
		setCustomer(customer);
		setType(type);
		setValue(value);
		setExternalPosDiscountId(externalPosDiscountId);
	}

	public POSDiscountType toPOSDiscountType(boolean includeCustomer) throws InvalidParameterException, FatalException {
		POSDiscountType posDiscountType = new POSDiscountType();
		
		posDiscountType.setPosDiscountId(getPosDiscountId());
		posDiscountType.setExternalPosDiscountId(getExternalPosDiscountId());
		posDiscountType.setType(getType().toString());
		posDiscountType.setValue(getValue());
		posDiscountType.setCreated(getCreated().getTime());
		
		if(includeCustomer) {
			posDiscountType.setCustomer(getCustomer().toCustomerType(null, false, false));
		}
		
		return posDiscountType;
	}

	public static Discount from(MySQL mysql) throws FatalException, InvalidParameterException {
		Discount discount = new Discount(
				CustomerManager.getCustomer((Long)mysql.getColumn("customer_id")),
				Type.valueOf((String)mysql.getColumn("type")),
				((BigDecimal)(mysql.getColumn("cost"))).floatValue(), 
				(String)mysql.getColumn("external_pos_discount_id")
		);
		discount.setCreated((Date)mysql.getColumn("created"));
		discount.setPosDiscountId((Long)mysql.getColumn("pos_discount_id"));
		
		return discount;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setPosDiscountId(long posDiscountId) {
		this.posDiscountId = posDiscountId;
	}

	public long getPosDiscountId() {
		return posDiscountId;
	}

	public void setValue(float value) {
		this.value = value;
	}

	public float getValue() {
		return value;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Type getType() {
		return type;
	}

	public void setExternalPosDiscountId(String externalPosDiscountId) {
		this.externalPosDiscountId = externalPosDiscountId;
	}

	public String getExternalPosDiscountId() {
		return externalPosDiscountId;
	}

}
