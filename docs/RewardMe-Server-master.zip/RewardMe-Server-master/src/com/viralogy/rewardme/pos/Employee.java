package com.viralogy.rewardme.pos;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.EmployeeType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.DatabaseBackedObject;

@MySQLTable(name=MySQL.TABLES.EMPLOYEE, 
		primaryKey="employeeId",
		transients={
		}
)
		
public class Employee extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = -1874988127876358682L;

	private long employeeId;
	private String externalEmployeeId;
	private String name;
	private Customer customer;
	private Address address;
	private Date created;
	
	public Employee(Customer customer, Address address, String name, String externalEmployeeId) {
		setCustomer(customer);
		setAddress(address);
		setName(name);
		setExternalEmployeeId(externalEmployeeId);
	}

	public EmployeeType toEmployeeType() throws InvalidParameterException, FatalException {
		EmployeeType employeeType = new EmployeeType();
		
		employeeType.setEmployeeId(getEmployeeId());
		employeeType.setName(getName());
		employeeType.setExternalEmployeeId(getExternalEmployeeId());
		employeeType.setCustomer(getCustomer().toCustomerType(null, false, false));
		employeeType.setAddress(getAddress().toAddressType());
		employeeType.setCreated(getCreated().getTime());
		
		return employeeType;
	}

	public static Employee from(MySQL mysql) throws FatalException, InvalidParameterException {
		Employee employee = new Employee(
				CustomerManager.getCustomer((Long)mysql.getColumn("customer_id")), 
				AddressManager.getAddress((Long)mysql.getColumn("address_id"), false),
				(String)mysql.getColumn("name"), 
				(String)mysql.getColumn("external_employee_id")
		);
		employee.setCreated((Date)mysql.getColumn("created"));
		employee.setEmployeeId((Long)mysql.getColumn("employee_id"));
		
		return employee;
	}

	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}

	public long getEmployeeId() {
		return employeeId;
	}

	public void setExternalEmployeeId(String externalEmployeeId) {
		this.externalEmployeeId = externalEmployeeId;
	}

	public String getExternalEmployeeId() {
		return externalEmployeeId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}

}
