package com.viralogy.rewardme.pos;

import java.io.Serializable;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.POSInventoryCategoryType;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.POSManager;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.DatabaseBackedObject;

@MySQLTable(name=MySQL.TABLES.POS.INVENTORY_CATEGORY, 
		primaryKey="posInventoryCategoryId",
		transients={
		}
)
		
public class InventoryCategory extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = -301981564132083596L;
	
	private long posInventoryCategoryId;
	private Customer customer;
	private String externalPosInventoryCategoryId;
	private String name;
	private InventoryCategory parentPosInventoryCategory;
	private Date created;
	
	public InventoryCategory(Customer customer, String name, String externalPosInventoryCategoryId, InventoryCategory parentInventoryCategory) {
		setCustomer(customer);
		setName(name);
		setExternalPosInventoryCategoryId(externalPosInventoryCategoryId);
		setParentPosInventoryCategory(parentPosInventoryCategory);
	}

	public POSInventoryCategoryType toPOSInventoryCategoryType() throws InvalidParameterException, FatalException {
		POSInventoryCategoryType posInventoryCategoryType = new POSInventoryCategoryType();
		
		posInventoryCategoryType.setPosInventoryCategoryId(getPosInventoryCategoryId());
		posInventoryCategoryType.setCustomer(getCustomer().toCustomerType(null, false, false));
		posInventoryCategoryType.setExternalPosInventoryCategoryId(getExternalPosInventoryCategoryId());
		posInventoryCategoryType.setName(getName());
		posInventoryCategoryType.setParentPosInventoryCategory(getParentPosInventoryCategory() == null ? null : getParentPosInventoryCategory().toPOSInventoryCategoryType());
		posInventoryCategoryType.setCreated(getCreated().getTime());

		return posInventoryCategoryType;
	}

	public static InventoryCategory from(MySQL mysql) throws FatalException, InvalidParameterException {
		InventoryCategory inventoryCategory = new InventoryCategory(
				CustomerManager.getCustomer((Long)mysql.getColumn("customer_id")), 
				(String)mysql.getColumn("name"), 
				(String)mysql.getColumn("external_pos_inventory_category_id"), 
				POSManager.getInventoryCategory((Long)mysql.getColumn("parent_pos_inventory_category_id"))
		);
		inventoryCategory.setCreated((Date)mysql.getColumn("created"));
		inventoryCategory.setPosInventoryCategoryId((Long)mysql.getColumn("pos_inventory_category_id"));
		
		return inventoryCategory;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
	
	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public void setParentPosInventoryCategory(InventoryCategory parentPosInventoryCategory) {
		this.parentPosInventoryCategory = parentPosInventoryCategory;
	}

	public InventoryCategory getParentPosInventoryCategory() {
		return parentPosInventoryCategory;
	}

	public void setExternalPosInventoryCategoryId(
			String externalPosInventoryCategoryId) {
		this.externalPosInventoryCategoryId = externalPosInventoryCategoryId;
	}

	public String getExternalPosInventoryCategoryId() {
		return externalPosInventoryCategoryId;
	}

	public void setPosInventoryCategoryId(long posInventoryCategoryId) {
		this.posInventoryCategoryId = posInventoryCategoryId;
	}

	public long getPosInventoryCategoryId() {
		return posInventoryCategoryId;
	}

}
