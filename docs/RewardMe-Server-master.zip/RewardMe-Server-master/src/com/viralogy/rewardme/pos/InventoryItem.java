package com.viralogy.rewardme.pos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.POSDiscountsType;
import com.viralogy.rewardme.jaxb.POSInventoryItemModsType;
import com.viralogy.rewardme.jaxb.POSInventoryItemType;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.POSManager;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.DatabaseBackedObject;

@MySQLTable(name=MySQL.TABLES.POS.INVENTORY_ITEM, 
		primaryKey="posInventoryItemId",
		transients={
			"inventoryCategories",
			"count"
		}
)
		
public class InventoryItem extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = -6399062476582415108L;
	private static Logger logger = Logger.getLogger(InventoryItem.class);

	private long posInventoryItemId;
	private Customer customer;
	private String externalPosInventoryItemId;
	private String kitchenItemName;
	private String name;
	private float price;
	private float cost;
	private Date created;

	private int count;	//transient
	private Set<InventoryCategory> inventoryCategories;
	
	public InventoryItem(Customer customer, String name, String externalPosInventoryItemId, float price, float cost) {
		setCustomer(customer);
		setName(name);
		setExternalPosInventoryItemId(externalPosInventoryItemId);
		setPrice(price);
		setCost(cost);
		
		//although transient - this adds some consistency
		setCount(1);
	}

	public POSInventoryItemType toPOSInventoryItemType(Set<InventoryItemMod> inventoryItemMods, Set<Discount> inventoryItemDiscounts, boolean includeCustomer) throws InvalidParameterException, FatalException {
		POSInventoryItemType posInventoryItemType = new POSInventoryItemType();
		
		posInventoryItemType.setPosInventoryItemId(getPosInventoryItemId());
		posInventoryItemType.setExternalPosInventoryItemId(getExternalPosInventoryItemId());
		posInventoryItemType.setName(getName());
		posInventoryItemType.setKitchenItemName(getKitchenItemName());
		posInventoryItemType.setPrice(getPrice());
		posInventoryItemType.setCost(getCost());
		posInventoryItemType.setQuantity(getCount());
		posInventoryItemType.setCreated(getCreated() == null ? null : getCreated().getTime());
		
		if(includeCustomer) {	
			posInventoryItemType.setCustomer(getCustomer() == null ? null : getCustomer().toCustomerType(null, false, false));			
		}
		
		if(inventoryItemMods != null) {
			posInventoryItemType.setPOSInventoryItemMods(new POSInventoryItemModsType());
			for(InventoryItemMod inventoryItemMod : inventoryItemMods) {
				posInventoryItemType.getPOSInventoryItemMods().getPOSInventoryItemMod().add(inventoryItemMod.toPOSInventoryItemModType(false));
			}
		}
		if(inventoryItemDiscounts != null) {
			posInventoryItemType.setPOSDiscounts(new POSDiscountsType());
			for(Discount discount : inventoryItemDiscounts) {
				posInventoryItemType.getPOSDiscounts().getPOSDiscount().add(discount.toPOSDiscountType(false));
			}
		}		
		
		return posInventoryItemType;
	}

	public static InventoryItem from(MySQL mysql) throws FatalException, InvalidParameterException {
		InventoryItem inventoryItem = new InventoryItem(
				CustomerManager.getCustomer((Long)mysql.getColumn("customer_id")), 
				(String)mysql.getColumn("name"), 
				(String)mysql.getColumn("external_pos_inventory_item_id"), 
				((BigDecimal)(mysql.getColumn("price"))).floatValue(), 
				((BigDecimal)(mysql.getColumn("cost"))).floatValue()
		);
		inventoryItem.setKitchenItemName((String)mysql.getColumn("kitchen_item_name"));
		inventoryItem.setCreated((Date)mysql.getColumn("created"));
		inventoryItem.setPosInventoryItemId((Long)mysql.getColumn("pos_inventory_item_id"));
		
		return inventoryItem;
	}

	public void setPosInventoryItemId(long posInventoryItemId) {
		this.posInventoryItemId = posInventoryItemId;
	}

	public long getPosInventoryItemId() {
		return posInventoryItemId;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
	
	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public void setExternalPosInventoryItemId(String externalPosInventoryItemId) {
		this.externalPosInventoryItemId = externalPosInventoryItemId;
	}

	public String getExternalPosInventoryItemId() {
		return externalPosInventoryItemId;
	}

	public Set<InventoryCategory> getInventoryCategories() throws InvalidParameterException, FatalException {
		if(inventoryCategories == null) {
			inventoryCategories = POSManager.getInventoryCategories(this);
		}
		return inventoryCategories;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getCount() {
		return count;
	}

	public String getKitchenItemName() {
		return kitchenItemName;
	}

	public void setKitchenItemName(String kitchenItemName) {
		this.kitchenItemName = kitchenItemName;
	}
	
	
	
    public boolean equals(Object that){
    	return this.equals((InventoryItem)that);
    }
	
    public boolean equals(InventoryItem that){
    	if(that == null) {
    		return false;
    	}
    	if(this.posInventoryItemId != 0 && that.posInventoryItemId != 0) {
    		return this.posInventoryItemId == that.posInventoryItemId;
    	}else {
    		logger.debug("testing equivalance of items: " + this.getName() + " , " + that.getName());
    		return (this.getCustomer() != null && that.getCustomer() != null && this.getCustomer().getCustomerId() == that.getCustomer().getCustomerId()) && 
    				(this.externalPosInventoryItemId.equals(that.externalPosInventoryItemId));
    	}
    }
}
