package com.viralogy.rewardme.pos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.POSInventoryItemHistoryType;
import com.viralogy.rewardme.manager.POSManager;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.DatabaseBackedObject;

@MySQLTable(name=MySQL.TABLES.POS.INVENTORY_ITEM_HISTORY, 
		primaryKey="posInventoryItemHistoryId",
		transients={
			"customer"
		}
)
		
public class InventoryItemHistory extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = -626157131917981653L;
	
	private long posInventoryItemHistoryId;
	private InventoryItem posInventoryItem;
	private Customer customer;
	private String name;
	private float price;
	private float cost;
	private Date created;
	
	public InventoryItemHistory(InventoryItem inventoryItem) {
		setPosInventoryItem(inventoryItem);
		setCustomer(inventoryItem.getCustomer());
		setName(inventoryItem.getName());
		setPrice(inventoryItem.getPrice());
		setCost(inventoryItem.getCost());
	}
	
	public InventoryItemHistory(InventoryItem inventoryItem, String name, float price, float cost) {
		setPosInventoryItem(inventoryItem);
		setCustomer(inventoryItem.getCustomer());
		setName(name);
		setPrice(price);
		setCost(cost);
	}

	public POSInventoryItemHistoryType toPOSInventoryItemHistoryType() throws InvalidParameterException, FatalException {
		POSInventoryItemHistoryType posInventoryItemHistoryType = new POSInventoryItemHistoryType();
		
		posInventoryItemHistoryType.setPosInventoryItemHistoryId(getPosInventoryItemHistoryId());
		posInventoryItemHistoryType.setPOSInventoryItem(getPosInventoryItem().toPOSInventoryItemType(null, null, false));
		posInventoryItemHistoryType.setCustomer(getCustomer().toCustomerType(null, false, false));
		posInventoryItemHistoryType.setName(getName());
		posInventoryItemHistoryType.setPrice(getPrice());
		posInventoryItemHistoryType.setCost(getCost());
		posInventoryItemHistoryType.setCreated(getCreated().getTime());

		return posInventoryItemHistoryType;
	}

	public static InventoryItemHistory from(MySQL mysql) throws FatalException, InvalidParameterException {
		InventoryItemHistory inventoryItemHistory = new InventoryItemHistory(
				POSManager.getInventoryItem((Long)mysql.getColumn("pos_inventory_item_id")), 
				(String)mysql.getColumn("name"), 
				((BigDecimal)(mysql.getColumn("price"))).floatValue(), 
				((BigDecimal)(mysql.getColumn("cost"))).floatValue()
		);
		inventoryItemHistory.setCreated((Date)mysql.getColumn("created"));
		inventoryItemHistory.setPosInventoryItemHistoryId((Long)mysql.getColumn("pos_inventory_item_history_id"));
		
		return inventoryItemHistory;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
	
	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public void setPosInventoryItemHistoryId(long posInventoryItemHistoryId) {
		this.posInventoryItemHistoryId = posInventoryItemHistoryId;
	}

	public long getPosInventoryItemHistoryId() {
		return posInventoryItemHistoryId;
	}

	public void setPosInventoryItem(InventoryItem inventoryItem) {
		this.posInventoryItem = inventoryItem;
	}

	public InventoryItem getPosInventoryItem() {
		return posInventoryItem;
	}

}
