package com.viralogy.rewardme.pos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.POSInventoryItemModType;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.DatabaseBackedObject;

@MySQLTable(name=MySQL.TABLES.POS.INVENTORY_ITEM_MOD, 
		primaryKey="posInventoryItemModId",
		transients={
			"count"
		}
)
		
public class InventoryItemMod extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = -7214828941882660112L;
	
	private long posInventoryItemModId;
	private Customer customer;
	private String externalPosInventoryItemModId;
	private String kitchenItemName;
	private String name;
	private float price;
	private float cost;
	private Date created;
	
	private int count;	//transient
	
	public InventoryItemMod(Customer customer, String name, String externalPosInventoryItemModId, float price, float cost) {
		setCustomer(customer);
		setName(name);
		setExternalPosInventoryItemModId(externalPosInventoryItemModId);
		setPrice(price);
		setCost(cost);
		
		//although transient - this adds some consistency
		setCount(1);
	}

	public POSInventoryItemModType toPOSInventoryItemModType(boolean includeCustomer) throws InvalidParameterException, FatalException {
		POSInventoryItemModType posInventoryItemModType = new POSInventoryItemModType();
		
		posInventoryItemModType.setPosInventoryItemModId(getPosInventoryItemModId());
		posInventoryItemModType.setExternalPosInventoryItemModId(getExternalPosInventoryItemModId());
		posInventoryItemModType.setKitchenItemName(getKitchenItemName());
		posInventoryItemModType.setName(getName());
		posInventoryItemModType.setPrice(getPrice());
		posInventoryItemModType.setCost(getCost());
		posInventoryItemModType.setQuantity(getCount());
		posInventoryItemModType.setCreated(getCreated() == null ? null : getCreated().getTime());

		if(includeCustomer) {
			posInventoryItemModType.setCustomer(getCustomer().toCustomerType(null, false, false));
		}
		
		return posInventoryItemModType;
	}

	public static InventoryItemMod from(MySQL mysql) throws FatalException, InvalidParameterException {
		InventoryItemMod inventoryItemMod = new InventoryItemMod(
				CustomerManager.getCustomer((Long)mysql.getColumn("customer_id")), 
				(String)mysql.getColumn("name"), 
				(String)mysql.getColumn("external_pos_inventory_item_mod_id"), 
				((BigDecimal)(mysql.getColumn("price"))).floatValue(), 
				((BigDecimal)(mysql.getColumn("cost"))).floatValue()
		);
		inventoryItemMod.setKitchenItemName((String)mysql.getColumn("kitchen_item_name"));
		inventoryItemMod.setCreated((Date)mysql.getColumn("created"));
		inventoryItemMod.setPosInventoryItemModId((Long)mysql.getColumn("pos_inventory_item_mod_id"));
		
		return inventoryItemMod;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
	
	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public void setPosInventoryItemModId(long posInventoryItemModId) {
		this.posInventoryItemModId = posInventoryItemModId;
	}

	public long getPosInventoryItemModId() {
		return posInventoryItemModId;
	}

	public void setExternalPosInventoryItemModId(
			String externalPosInventoryItemModId) {
		this.externalPosInventoryItemModId = externalPosInventoryItemModId;
	}

	public String getExternalPosInventoryItemModId() {
		return externalPosInventoryItemModId;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getCount() {
		return count;
	}

	public String getKitchenItemName() {
		return kitchenItemName;
	}

	public void setKitchenItemName(String kitchenItemName) {
		this.kitchenItemName = kitchenItemName;
	}

	
	
	
	
    public boolean equals(Object that){
    	return this.equals((InventoryItemMod)that);
    }
	
    public boolean equals(InventoryItemMod that){
    	if(that == null) {
    		return false;
    	}
    	if(this.posInventoryItemModId != 0 && that.posInventoryItemModId != 0) {
    		return this.posInventoryItemModId == that.posInventoryItemModId;
    	}else {
    		return (this.getCustomer() != null && that.getCustomer() != null && this.getCustomer().getCustomerId() == that.getCustomer().getCustomerId()) && 
    				(this.externalPosInventoryItemModId.equals(that.externalPosInventoryItemModId));
    	}
    }
}
