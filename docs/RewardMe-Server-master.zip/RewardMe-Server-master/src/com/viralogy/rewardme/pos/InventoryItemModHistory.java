package com.viralogy.rewardme.pos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.POSInventoryItemModHistoryType;
import com.viralogy.rewardme.manager.POSManager;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.DatabaseBackedObject;

@MySQLTable(name=MySQL.TABLES.POS.INVENTORY_ITEM_MOD_HISTORY, 
		primaryKey="posInventoryItemModHistoryId",
		transients={
			"customer"
		}
)
		
public class InventoryItemModHistory extends DatabaseBackedObject implements Serializable {
	
	private static final long serialVersionUID = 8471469696170604937L;
	
	private long posInventoryItemModHistoryId;
	private InventoryItemMod posInventoryItemMod;
	private Customer customer;
	private String name;
	private float price;
	private float cost;
	private Date created;
	
	public InventoryItemModHistory(InventoryItemMod inventoryItemMod) {
		setPosInventoryItemMod(inventoryItemMod);
		setCustomer(inventoryItemMod.getCustomer());
		setName(inventoryItemMod.getName());
		setPrice(inventoryItemMod.getPrice());
		setCost(inventoryItemMod.getCost());
	}
	
	public InventoryItemModHistory(InventoryItemMod inventoryItemMod, String name, float price, float cost) {
		setPosInventoryItemMod(inventoryItemMod);
		setCustomer(inventoryItemMod.getCustomer());
		setName(name);
		setPrice(price);
		setCost(cost);
	}

	public POSInventoryItemModHistoryType toPOSInventoryItemModHistoryType() throws InvalidParameterException, FatalException {
		POSInventoryItemModHistoryType posInventoryItemModHistoryType = new POSInventoryItemModHistoryType();
		
		posInventoryItemModHistoryType.setPosInventoryItemModHistoryId(getPosInventoryItemModHistoryId());
		posInventoryItemModHistoryType.setPOSInventoryItemMod(getPosInventoryItemMod().toPOSInventoryItemModType(false));
		posInventoryItemModHistoryType.setCustomer(getCustomer().toCustomerType(null, false, false));
		posInventoryItemModHistoryType.setName(getName());
		posInventoryItemModHistoryType.setPrice(getPrice());
		posInventoryItemModHistoryType.setCost(getCost());
		posInventoryItemModHistoryType.setCreated(getCreated().getTime());

		return posInventoryItemModHistoryType;
	}

	public static InventoryItemModHistory from(MySQL mysql) throws FatalException, InvalidParameterException {
		InventoryItemModHistory inventoryItemModHistory = new InventoryItemModHistory(
				POSManager.getInventoryItemMod((Long)mysql.getColumn("pos_inventory_item_mod_id")), 
				(String)mysql.getColumn("name"), 
				((BigDecimal)(mysql.getColumn("price"))).floatValue(), 
				((BigDecimal)(mysql.getColumn("cost"))).floatValue()
		);
		inventoryItemModHistory.setCreated((Date)mysql.getColumn("created"));
		inventoryItemModHistory.setPosInventoryItemModHistoryId((Long)mysql.getColumn("pos_inventory_item_mod_history_id"));
		
		return inventoryItemModHistory;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
	
	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public void setPosInventoryItemModHistoryId(long posInventoryItemModHistoryId) {
		this.posInventoryItemModHistoryId = posInventoryItemModHistoryId;
	}

	public long getPosInventoryItemModHistoryId() {
		return posInventoryItemModHistoryId;
	}

	public void setPosInventoryItemMod(InventoryItemMod inventoryItemMod) {
		this.posInventoryItemMod = inventoryItemMod;
	}

	public InventoryItemMod getPosInventoryItemMod() {
		return posInventoryItemMod;
	}

}
