package com.viralogy.rewardme.pos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.POSDiscountsType;
import com.viralogy.rewardme.jaxb.POSInventoryItemsType;
import com.viralogy.rewardme.jaxb.POSTransactionType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.DeviceManager;
import com.viralogy.rewardme.manager.POSManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.DatabaseBackedObject;
import com.viralogy.rewardme.model.Device;
import com.viralogy.rewardme.model.User;

@MySQLTable(name=MySQL.TABLES.POS.TX, 
		primaryKey="posTxId",
		transients={
			"discounts",
			"inventoryItems",
			"inventoryItemMods",
			"inventoryItemDiscounts"
		}
)
		
public class Transaction extends DatabaseBackedObject implements Serializable {
	

	private static Logger logger = Logger.getLogger(Transaction.class);
	private static final long serialVersionUID = -370010796294072279L;

	public static enum PaymentMethod {
		CREDIT,
		CHECK,
		CASH,
		GIFT_CARD,
		HOUSE_TAB,
		MOBILE,
		BARTER,
		DEBIT,
		UNKNOWN
	};
	
	private long posTxId;
	private User user;
	private Customer customer;
	private Address address;
	private Employee employee;
	private Device device;
	private String externalPosTxId;
	private float amount;
	private float amountLessTax;
	private float amountLessTaxAndDiscount;
	private PaymentMethod paymentMethod;
	private Date created;
	
	private Set<Discount> discounts;
	private Set<InventoryItem> inventoryItems;
	private Map<Long, Set<InventoryItemMod>> inventoryItemMods;
	private Map<Long, Set<Discount>> inventoryItemDiscounts;
	
	public Transaction(User user, Customer customer, Address address, Device device, Employee employee, 
			String externalTxId, 
			float amount, float amountLessTax, float amountLessTaxAndDiscount,
			PaymentMethod paymentMethod
	) {
		setUser(user);
		setCustomer(customer);
		setAddress(address);
		setDevice(device);
		setEmployee(employee);
		setExternalPosTxId(externalTxId);
		setAmount(amount);
		setAmountLessTax(amountLessTax);
		setAmountLessTaxAndDiscount(amountLessTaxAndDiscount);
		setPaymentMethod(paymentMethod);
	}

	public Transaction() {
	}

	public POSTransactionType toPOSTransactionType() throws InvalidParameterException, FatalException {
		POSTransactionType posTransactionType = new POSTransactionType();

		posTransactionType.setPosTxId(getPosTxId());
		posTransactionType.setUser(getUser() == null ? null : getUser().toUserType(null));
		posTransactionType.setCustomer(getCustomer().toCustomerType(null, false, false));
		posTransactionType.setAddress(getAddress().toAddressType());
		posTransactionType.setDevice(getDevice().toDeviceType());
		posTransactionType.setEmployee(getEmployee().toEmployeeType());
		posTransactionType.setPaymentMethod(getPaymentMethod().toString());
		posTransactionType.setExternalPosTxId(getExternalPosTxId());
		posTransactionType.setAmount(getAmount());
		posTransactionType.setAmountLessTax(getAmountLessTax());
		posTransactionType.setAmountLessTaxAndDiscount(getAmountLessTaxAndDiscount());
		posTransactionType.setCreated(getCreated().getTime());
		
		posTransactionType.setPOSDiscounts(new POSDiscountsType());
		for(Discount discount : getDiscounts()) {
			posTransactionType.getPOSDiscounts().getPOSDiscount().add(discount.toPOSDiscountType(false));
		}

		posTransactionType.setPOSInventoryItems(new POSInventoryItemsType());
		for(InventoryItem inventoryItem : getInventoryItems()) {
			posTransactionType.getPOSInventoryItems().getPOSInventoryItem().add(
					inventoryItem.toPOSInventoryItemType(
							getInventoryItemMods().get(inventoryItem.getPosInventoryItemId()), 
							getInventoryItemDiscounts().get(inventoryItem.getPosInventoryItemId()),
							false
					)
			);
		}
		
		return posTransactionType;
	}

	public static Transaction from(MySQL mysql) throws FatalException, InvalidParameterException {
		Long userId = (Long)mysql.getColumn("user_id");
		
		Transaction transaction = new Transaction(
				userId == null ? null : UserManager.getUser(userId), 
				CustomerManager.getCustomer((Long)mysql.getColumn("customer_id")), 
				AddressManager.getAddress((Long)mysql.getColumn("address_id"), false), 
				DeviceManager.getDevice((String)mysql.getColumn("device_id")), 
				POSManager.getEmployee((Long)mysql.getColumn("employee_id")), 
				(String)mysql.getColumn("external_pos_tx_id"),
				((BigDecimal)(mysql.getColumn("amount"))).floatValue(),
				((BigDecimal)(mysql.getColumn("amount_less_tax"))).floatValue(),
				((BigDecimal)(mysql.getColumn("amount_less_tax_and_discount"))).floatValue(),
				PaymentMethod.valueOf((String)mysql.getColumn("payment_method"))
		);
		transaction.setCreated((Date)mysql.getColumn("created"));
		transaction.setPosTxId((Long)mysql.getColumn("pos_tx_id"));
		
		transaction.takeFieldValuesSnapshot();
		
		return transaction;
	}

	public void setPosTxId(long posTxId) {
		this.posTxId = posTxId;
	}

	public long getPosTxId() {
		return posTxId;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public User getUser() {
		return user;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getCreated() {
		return created;
	}

	public void setDevice(Device device) {
		this.device = device;
	}

	public Device getDevice() {
		return device;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmountLessTax(float amountLessTax) {
		this.amountLessTax = amountLessTax;
	}

	public float getAmountLessTax() {
		return amountLessTax;
	}

	public Set<InventoryItem> getInventoryItems() throws InvalidParameterException, FatalException {
		if(inventoryItems == null) {
			inventoryItems = POSManager.getInventoryItems(this);
		}
		return inventoryItems;
	}

	public Map<Long, Set<InventoryItemMod>> getInventoryItemMods() throws InvalidParameterException, FatalException {
		if(inventoryItemMods == null) {
			getInventoryItems();
			inventoryItemMods = new HashMap<Long, Set<InventoryItemMod>>();
			for(InventoryItem inventoryItem : inventoryItems) {
				inventoryItemMods.put(inventoryItem.getPosInventoryItemId(), POSManager.getInventoryItemMods(this, inventoryItem));				
			}
		}
		return inventoryItemMods;
	}

	public void setAmountLessTaxAndDiscount(float amountLessTaxAndDiscount) {
		this.amountLessTaxAndDiscount = amountLessTaxAndDiscount;
	}

	public float getAmountLessTaxAndDiscount() {
		return amountLessTaxAndDiscount;
	}

	public Set<Discount> getDiscounts() throws InvalidParameterException, FatalException {
		if(discounts == null) {
			discounts = POSManager.getDiscounts(this);
		}
		return discounts;
	}
	
	// for testing only, should be removed
	public void setDiscounts(Set<Discount> discounts) {
		this.discounts = discounts;
	}

	public Map<Long, Set<Discount>> getInventoryItemDiscounts() throws InvalidParameterException, FatalException {
		if(inventoryItemDiscounts == null) {
			getInventoryItems();
			inventoryItemDiscounts = new HashMap<Long, Set<Discount>>();
			for(InventoryItem inventoryItem : inventoryItems) {
				inventoryItemDiscounts.put(inventoryItem.getPosInventoryItemId(), POSManager.getInventoryItemDiscounts(this, inventoryItem));				
			}
		}
		return inventoryItemDiscounts;		
	}
	
	// for testing only, should be removed
	public void setInventoryItemDiscounts(Map<Long, Set<Discount>> inventoryItemDiscounts ) {
		this.inventoryItemDiscounts = inventoryItemDiscounts;
	}
	
	public void addInventoryItem(InventoryItem inventoryItem) {
		if(inventoryItems == null) {
			inventoryItems = new HashSet<InventoryItem>();
		}
		inventoryItems.add(inventoryItem);
	}
	
	public void addInventoryItemMod(InventoryItem inventoryItem, InventoryItemMod inventoryItemMod) {
		if(inventoryItemMods == null) {
			logger.debug("Inventory item mods is null");
			inventoryItemMods = new HashMap<Long, Set<InventoryItemMod>>();
		}
		Set<InventoryItemMod> inventoryItemModForInventoryItem = inventoryItemMods.get(inventoryItem.getPosInventoryItemId());
		if(inventoryItemModForInventoryItem == null) {
			inventoryItemModForInventoryItem = new HashSet<InventoryItemMod>();
		}
		inventoryItemModForInventoryItem.add(inventoryItemMod);
		inventoryItemMods.put(inventoryItem.getPosInventoryItemId(), inventoryItemModForInventoryItem);
		
	}

	public void setExternalPosTxId(String externalPosTxId) {
		this.externalPosTxId = externalPosTxId;
	}

	public String getExternalPosTxId() {
		return externalPosTxId;
	}

	public PaymentMethod getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(PaymentMethod paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

}