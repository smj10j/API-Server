package com.viralogy.rewardme.provider;

import org.apache.commons.httpclient.NameValuePair;
import org.apache.log4j.Logger;

import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.servlet.GatewayServlet;
import com.viralogy.rewardme.util.RemoteRequestUtil;

public abstract class CellitProvider {

	private static Logger logger = Logger.getLogger(CellitProvider.class);

	public static void subscribe(User user, Customer customer, Address address, String cellitStoreCode, String cellitShortCode, String cellitAId) {
		//TODO: use their horrible SOAP API?:  http://www.ibm.com/developerworks/xml/library/x-soapcl/
		try {

			Long addressId = address == null ? null : address.getAddressId();
			RemoteRequestUtil.post("http://www.couponzap.com/websubscribe.php", 
				new NameValuePair("phone", user.getPhoneNumber()),
				new NameValuePair("acceptterms", "1"),
				new NameValuePair("aid", cellitAId),
				new NameValuePair("sucode", cellitStoreCode),
				new NameValuePair("shortcode", cellitShortCode),
				new NameValuePair("successurl", GatewayServlet.getExternalServerBaseUrl() + "/cellit?userId="+user.getUserId()+"&customerId="+customer.getCustomerId()+"&addressId="+addressId+"&phoneNumber="+user.getPhoneNumber()+"&status=success"),
				new NameValuePair("failureurl", GatewayServlet.getExternalServerBaseUrl() + "/cellit?userId="+user.getUserId()+"&customerId="+customer.getCustomerId()+"&addressId="+addressId+"&phoneNumber="+user.getPhoneNumber()+"&status=failure"),
				new NameValuePair("Submit", "Submit")
			);
		}catch(Exception e) {
			e.printStackTrace();
			logger.error("FAILED TO SUBSCRIBE A NEW USER WITH CELLIT - continuing " + e.getMessage());
		}
	}
	
	public static void send(User user, String customerName, String username, String password, String messageId) {
		try {
			RemoteRequestUtil.post("http://cellit.net/clientwork/"+customerName+"/ws/sendmessage.php", 
				new NameValuePair("username", username),
				new NameValuePair("password", password),
				new NameValuePair("phone", user.getPhoneNumber()),
				new NameValuePair("messageid", messageId)
			);
		}catch(Exception e) {
			e.printStackTrace();
			logger.error("FAILED TO SEND A SCHEDULED MESSAGE WITH CELLIT - continuing " + e.getMessage());
		}	
	}
}
