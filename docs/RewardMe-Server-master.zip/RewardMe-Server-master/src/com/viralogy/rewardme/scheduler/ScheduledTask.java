package com.viralogy.rewardme.scheduler;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.annotation.MySQLTable;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.model.DatabaseBackedObject;

@MySQLTable(name=MySQL.TABLES.SCHEDULED_TASK, 
primaryKey="scheduledTaskId",
transients={}
)
public class ScheduledTask extends DatabaseBackedObject implements Serializable {

	private static final long serialVersionUID = -7046447527917331939L;
	
	private static Logger logger = Logger.getLogger(ScheduledTask.class);

	public static enum Type {
		URL
	}
	
	private long scheduledTaskId;
	private Type type;
	private String data;
	private Date timestamp;
	private boolean archived;
	
	public ScheduledTask(Type type, String data, Date timestamp) throws FatalException, InvalidParameterException {
		setType(type);
		setData(data);
		setTimestamp(timestamp);
	}
	
	public String toString() {
		SimpleDateFormat format = new SimpleDateFormat("hh:mma MMM d");
		String timeString = format.format(timestamp);
		return "scheduledTaskId="+scheduledTaskId+", type="+type.toString()+", data="+data+", timestamp="+timeString+", archived="+archived;
	}
	
	public static ScheduledTask from(MySQL mysql) throws FatalException, InvalidParameterException {
		
		ScheduledTask scheduledTask = new ScheduledTask(
			Type.valueOf((String)mysql.getColumn("type")),
			(String)mysql.getColumn("data"),
			(Date)mysql.getColumn("timestamp")
		);
		scheduledTask.setScheduledTaskId((Long)mysql.getColumn("scheduled_task_id"));
		scheduledTask.setArchived((Boolean)mysql.getColumn("archived"));
		
		scheduledTask.takeFieldValuesSnapshot();
		
		return scheduledTask;
	}
	
	private void setType(Type type) {
		this.type = type;
	}

	public Type getType() {
		return type;
	}

	private void setData(String data) {
		this.data = data;
	}

	public String getData() {
		return data;
	}

	private void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public long getScheduledTaskId() {
		return scheduledTaskId;
	}

	public void setScheduledTaskId(long scheduledTaskId) {
		this.scheduledTaskId = scheduledTaskId;
	}

	public boolean isArchived() {
		return archived;
	}

	public void setArchived(boolean archived) {
		this.archived = archived;
	}


}
