package com.viralogy.rewardme.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.CohortsType;
import com.viralogy.rewardme.jaxb.TestsType;
import com.viralogy.rewardme.manager.ABTestManager;
import com.viralogy.rewardme.model.ABCohort;
import com.viralogy.rewardme.model.ABTest;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Device;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.User;

public abstract class ABTestService {
	
	private static Logger logger = Logger.getLogger(ABTestService.class);
	
	public static void assignUser(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		long abTestId = request.getParameterLong(Constants.Request.AB_TEST_ID, true);
		User user = request.getUser();
		
		ABTest test = ABTestManager.getAbTest(abTestId, customer);
		if(test == null) {
			throw new InvalidParameterException(Constants.Error.ABTEST.NO_TESTS_EXIST);
		}
		ABCohort result = ABTestManager.assignUser(test, user, customer);
		if(result != null) {
			response.get().setCohorts(new CohortsType());
			response.get().getCohorts().getCohort().add(result.toCohortType());
		}
		else {
			throw new FatalException("Could not assign user.");
		}
		//response.get().setMessage("" + result);
	}
	
	public static void logSuccess(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		long displayCohortId = request.getParameterLong(Constants.Request.DISPLAY_COHORT_ID, true);
		long abTestId = request.getParameterLong(Constants.Request.AB_TEST_ID, true);
		
		ABTest test = ABTestManager.getAbTest(abTestId, customer);
		if(test == null) {
			throw new InvalidParameterException(Constants.Error.ABTEST.NO_TESTS_EXIST);
		}
		
		ABCohort cohort = ABTestManager.getAbCohorts(test, displayCohortId, customer).get(0);
		if(cohort == null) {
			throw new InvalidParameterException(Constants.Error.ABTEST.NO_COHORTS_EXIST);
		}
		
		if(ABTestManager.logSuccess(cohort, test, customer) == true) {
			response.get().setMessage("Cohort successfully altered.");
		}
	}
	
	
	
	
	
	
	public static void getAllAbTests(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		int returnCount = request.getParameterInt(Constants.Request.RETURN_COUNT, false);
		
		List<ABTest> tests = ABTestManager.getAllAbTests(returnCount);
		
		response.get().setTests(new TestsType());
		for(ABTest test : tests) {
			response.get().getTests().getTest().add(test.toTestType());
		}
	}
	
	public static void getAbTest(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		long abTestId = request.getParameterLong(Constants.Request.AB_TEST_ID, true);
		
		ABTest test = ABTestManager.getAbTest(abTestId, customer);

		response.get().setTests(new TestsType());
		response.get().getTests().getTest().add(test.toTestType());
	}
	
	public static void getAbTestByCustomer(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		
		ABTest test = ABTestManager.getAbTest(customer);

		response.get().setTests(new TestsType());
		response.get().getTests().getTest().add(test.toTestType());
	}
	
	public static void saveAbTest(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		String testName = request.getParameter(Constants.Request.AB_TEST_NAME, true);
		String description = request.getParameter(Constants.Request.DESCRIPTION, false);
		Customer customer = request.getCustomer();
		Address address = request.getAddress();
		long abTestId = request.getParameterLong(Constants.Request.AB_TEST_ID, false);
		
		ABTest test = new ABTest(testName, customer, address);
		test.setDescription(description);
		if(abTestId > 0) {
			test.setAbTestId(abTestId);
		}
		
		if(ABTestManager.saveAbTest(test) == true){
			response.get().setMessage("New test successfully created.");
		}
		else{
			throw new FatalException("An error occurred, and the test was not created.");
		}
		
	}
	
	
	
	
	
	
	public static void getAllAbCohorts(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		long abTestId = request.getParameterInt(Constants.Request.AB_TEST_ID, false);
		
		ABTest test = ABTestManager.getAbTest(abTestId, customer);
		if(test == null) {
			throw new InvalidParameterException(Constants.Error.ABTEST.NO_TESTS_EXIST);
		}
		List<ABCohort> cohorts = ABTestManager.getAllAbCohorts(test);
		
		response.get().setCohorts(new CohortsType());
		for(ABCohort cohort : cohorts) {
			response.get().getCohorts().getCohort().add(cohort.toCohortType());
		}
	}
	
	public static void getAbCohorts(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		long abTestId = request.getParameterLong(Constants.Request.AB_TEST_ID, true);
		long displayCohortId = request.getParameterLong(Constants.Request.DISPLAY_COHORT_ID, false);
		
		ABTest test = ABTestManager.getAbTest(abTestId, customer);
		if(test == null) {
			throw new InvalidParameterException(Constants.Error.ABTEST.NO_TESTS_EXIST);
		}
		List<ABCohort> cohorts = ABTestManager.getAbCohorts(test, displayCohortId, customer);
		
		response.get().setCohorts(new CohortsType());
		for(ABCohort cohort : cohorts) {
			response.get().getCohorts().getCohort().add(cohort.toCohortType());
		}
	}
	
	public static void saveAbCohort(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		long displayCohortId = request.getParameterLong(Constants.Request.DISPLAY_COHORT_ID, false);
		long abTestId = request.getParameterLong(Constants.Request.AB_TEST_ID, true);
		String description = request.getParameter(Constants.Request.DESCRIPTION, false);
		
		ABTest test = ABTestManager.getAbTest(abTestId, customer);
		if(test == null) {
			throw new InvalidParameterException(Constants.Error.ABTEST.NO_TESTS_EXIST);
		}
		
		ABCohort cohort = new ABCohort(test);
		cohort.setDisplayCohortId(displayCohortId);
		cohort.setSuccesses(0);
		cohort.setViews(1);
		cohort.setDescription(description);
		
		if(ABTestManager.saveAbCohort(cohort, customer) == true){
			response.get().setMessage("New cohort successfully created.");
		}
		else{
			throw new FatalException("An error occurred, and the cohort was not created.");
		}
	}
	
}
