package com.viralogy.rewardme.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.AddressType;
import com.viralogy.rewardme.jaxb.AddressesType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.GeoCoord;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.StringUtil;

public class AddressService {
	
	private static Logger logger = Logger.getLogger(AddressService.class);
	
	public static void getAddress(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, true);
		Address address = AddressManager.getAddress(addressId, false);
		
		response.get().setAddress(address.toAddressType());
	}

	public static void saveAddress(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Customer customer = request.getCustomer();
		Address address = null;
		String addressStr = request.getParameter(Constants.Request.ADDRESS);
		String imageUrl = request.getParameter(Constants.Request.IMAGE_URL);
		String imageUrlSmall = request.getParameter(Constants.Request.IMAGE_URL_SMALL);
		Integer checkinRadius = request.getParameterInt(Constants.Request.CHECKIN_RADIUS, false);
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, false); 
		Boolean enabled = request.getParameterBool(Constants.Request.ENABLED, false);		
		boolean force = request.getParameterBool(Constants.Request.FORCE, false);	
		
		if(addressId != null) {
			address = AddressManager.getAddress(addressId, false);
			if(customer.getCustomerId() != address.getCustomer().getCustomerId()) {
				throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE,ListUtil.from("address",customer.getApiKey()));
			}
			if(!StringUtil.isNullOrEmpty(addressStr)) address.setAddress(addressStr);
			if(checkinRadius != null) address.setCheckinRadius(checkinRadius);
			
			if(!force) {
				address.refreshMetaData();
			}else {
				address.refresh();
			}		
			if(!StringUtil.isNullOrEmpty(imageUrl)) address.getAddressMetaData().setImageUrl(imageUrl);
			if(!StringUtil.isNullOrEmpty(imageUrlSmall)) address.getAddressMetaData().setImageUrlSmall(imageUrlSmall);	
			
			AddressManager.save(address);
			//TODO: Address: add enabled?

		}else {
			if(checkinRadius == null) {
				checkinRadius = Constants.Distance.DEFAULT_CHECKIN;
			}
			address = new Address(customer, addressStr, checkinRadius, imageUrl, imageUrlSmall);
			AddressManager.addAddressToCustomer(address, force);
		}		
		
		response.get().setCustomer(customer.toCustomerType(null, true, false));
	}

	public static void removeAddress(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, true);

		for(Address address : customer.getAddresses()) {
			if(address.getAddressId() == addressId) {
				AddressManager.removeAddressFromCustomer(customer, address);
				break;
			}
		}
		
		response.get().setCustomer(customer.toCustomerType(null, true, false));
	}	

	public static void getAddressesForCustomer(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Customer customer = request.getCustomer();
				
		response.get().setAddresses(new AddressesType());
		for(Address address : customer.getAddresses()) {
			response.get().getAddresses().getAddress().add(address.toAddressType());
		}
	}	
	
	public static void query(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Double longitude = request.getParameterDouble(Constants.Request.LONGITUDE, true);
		Double latitude = request.getParameterDouble(Constants.Request.LATITUDE, true);
		GeoCoord geoCoord = new GeoCoord(longitude, latitude);
				
		Customer customer = request.getCustomer();
		//force a request to see if the user is authorized to get checkinRadius data
		request.isAuthorized();	//sets the authorization status of the user
		String query = request.getParameter(Constants.Request.QUERY);
		if(StringUtil.isNullOrEmpty(query)) {
			query = "";
		}
		String radiusStr = request.getParameter(Constants.Request.RADIUS,false);
		Integer radius = null;
		if(radiusStr.equals("DISTANCE.NEARBY")) {
			radius = Constants.Distance.NEARBY;
		}else {
			try {
				radius = request.getParameterInt(Constants.Request.RADIUS, false);
			}catch(NumberFormatException e) {
				throw new InvalidParameterException(Constants.Error.GATEWAY.INVALID_PARAMETER_TYPE, ListUtil.from(Constants.Request.RADIUS, "Integer", radiusStr));
			}
		}
		int returnCount = request.getParameterInt(Constants.Request.RETURN_COUNT,false);
		int startPageIndex = request.getParameterInt(Constants.Request.START_PAGE_INDEX,false);
		
		logger.debug("Performing query for \"" + query + "\" " + radius + " meters around " + geoCoord + " (want " + returnCount + " results)");
		List<Address> addresses = AddressManager.query(geoCoord, customer, radius, query, returnCount, startPageIndex, true);
		
		AddressesType addressesType = new AddressesType();
		for(Address address : addresses) {
			AddressType addressType = address.toAddressType(null, true);
			addressesType.getAddress().add(addressType);
		}
		
		response.get().setAddresses(addressesType);
	}
	
	public static void refresh(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		Address address = AddressManager.getAddress(request.getParameterLong(Constants.Request.ADDRESS_ID, true), true);
		if(customer.getCustomerId() != address.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE,ListUtil.from("address",customer.getApiKey()));
		}
		address.refreshMetaData();
		AddressManager.save(address);
		response.get().setAddress(address.toAddressType());
	}

}
