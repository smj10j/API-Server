package com.viralogy.rewardme.service;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.ApplicationsType;
import com.viralogy.rewardme.manager.ApplicationManager;
import com.viralogy.rewardme.manager.DeviceManager;
import com.viralogy.rewardme.model.Application;
import com.viralogy.rewardme.model.Application.Type;
import com.viralogy.rewardme.model.ApplicationObservation;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.DeviceApplication;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.util.JSONUtil;
import com.viralogy.rewardme.util.ListUtil;

public abstract class ApplicationService {
	
	private static Logger logger = Logger.getLogger(ApplicationService.class);
	
	public static void getApplicationTypes(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		response.get().setApplications(new ApplicationsType());
		for(Type type : Application.Type.values()) {
			Application application = new Application();
			application.setType(type);
			response.get().getApplications().getApplication().add(application.toApplicationType(true));
		}
	}
	
	public static void getApplication(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		Customer customer = request.getCustomer();
		Application application = ApplicationManager.getApplication(request.getParameterLong(Constants.Request.APPLICATION_ID, false));
		
		if(customer.getCustomerId() != application.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_READ,ListUtil.from("application",customer.getApiKey()));
		}
		
		response.get().setApplication(application.toApplicationType(false));
	}
	
	public static void getApplications(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		Customer customer = request.getCustomer();
		
		List<Application> applications = ApplicationManager.getApplications(customer);
		
		response.get().setApplications(new ApplicationsType());
		for(Application application : applications) {
			response.get().getApplications().getApplication().add(application.toApplicationType(false));
		}
	}
	
	public static void removeApplication(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		Customer customer = request.getCustomer();
		Application application = ApplicationManager.getApplication(request.getParameterLong(Constants.Request.APPLICATION_ID, false));
		
		if(customer.getCustomerId() != application.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE,ListUtil.from("application",customer.getApiKey()));
		}		
		
		ApplicationManager.remove(application);
	}
		
	
	public static void saveApplication(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		Customer customer = request.getCustomer();
		String url = request.getParameter(Constants.Request.URL);
		Application.Type type = request.getParameterType(Constants.Request.TYPE, Application.Type.class, false);
		String name = request.getParameter(Constants.Request.NAME);
		String description = request.getParameter(Constants.Request.DESCRIPTION);
	
		Long applicationId = request.getParameterLong(Constants.Request.APPLICATION_ID, false);

		Application application = null;
		if(applicationId == null) {
			//not yet created
			application = new Application(
				name,
				description,
				customer,
				type,
				url
			);
		}else {
			application = ApplicationManager.getApplication(applicationId);
			if(customer.getCustomerId() != application.getCustomer().getCustomerId()) {
				throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE,ListUtil.from("application",customer.getApiKey()));
			}
		}
		
		//fill in the values
		application.setName(name);
		application.setType(type);
		if(url.equals(Application.HOSTED_STRING)) {
			application.setUrl(null);
		}else {
			application.setUrl(url);
		}			
				
		ApplicationManager.save(application);

		response.get().setApplication(application.toApplicationType(false));
	}
	
	public static void saveObservations(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		Customer customer = request.getCustomer();
		JSONArray jsonObservations = request.getParameterJSONArray(Constants.Request.OBSERVATIONS, true);	
		Application application = ApplicationManager.getApplication(request.getParameterLong(Constants.Request.APPLICATION_ID, true));
		Long deviceApplicationId = request.getParameterLong(Constants.Request.DEVICE_APPLICATION_ID, false);
		DeviceApplication deviceApplication = null;
		if(deviceApplicationId != null) {
			deviceApplication = DeviceManager.getDeviceApplication(deviceApplicationId);
		}

		if(customer.getCustomerId() != application.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE,ListUtil.from("application",customer.getApiKey()));
		}
		
		try {
			for(int i = 0; i < jsonObservations.length(); i++) {
				JSONObject jsonObservation = jsonObservations.getJSONObject(i);
				
				//not nullable
				long observationsInstanceId = jsonObservation.getLong("observationsInstanceId");
				Date timestamp = new Date(jsonObservation.getLong("timestamp"));

				//nullable
				String module = JSONUtil.getSafe(jsonObservation, "module");
				String element = JSONUtil.getSafe(jsonObservation, "element");
				String action = JSONUtil.getSafe(jsonObservation, "action");
				String data = JSONUtil.getSafe(jsonObservation, "data");
				String userIdStr = JSONUtil.getSafe(jsonObservation, "userId");
				Long userId = userIdStr == null ? null : Long.parseLong(userIdStr);
				
				/*logger.debug("Adding observation ("+ListUtil.implode(ListUtil.from(
						observationsInstanceId+"",
						userId+"",
						module,
						element,
						action,
						data,
						timestamp+""
				), ",")+")");*/
				
				ApplicationManager.save(new ApplicationObservation(
						application, 
						deviceApplication, 
						observationsInstanceId, 
						timestamp,
						module, 
						element, 
						action, 
						data, userId == null ? null : new User(userId)
				));
				
			}
		} catch (JSONException e) {
			throw new InvalidParameterException(Constants.Error.GENERAL.INVALID_JSON, ListUtil.from(Constants.Request.OBSERVATIONS, e.getMessage()));
		}
	}
}
