package com.viralogy.rewardme.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;

import javax.servlet.ServletException;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.servlet.GatewayServlet;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.RemoteRequestUtil;

public abstract class BatchService {

	private static Logger logger = Logger.getLogger(BatchService.class);
	
	public static void chain(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		String data = request.getParameter(Constants.Request.DATA);
		List<String> apiCallStrings = ListUtil.explode(data, ",");
		
		int counter = 0;

		for(String apiCallString : apiCallStrings) {
			
			//clone the original request, and use the same http response
			RewardMeRequest childRequest = new RewardMeRequest(request.getHttpServletRequest());
			childRequest.setNewRequest(false);
			RewardMeResponse childResponse = new RewardMeResponse(response.getHttpServletResponse());
			
			//remove certain parameters
			String[] sharedRequestKeysToRemove = {
				Constants.Request.DATA,
				Constants.Request.API_KEY,
				Constants.Request.SIGNATURE,
				Constants.Request.TIMESTAMP,
				Constants.Request.RESPONSE_FORMAT
			};
			for(String sharedRequestKeyToRemove : sharedRequestKeysToRemove) {
				childRequest.overrideParameter(sharedRequestKeyToRemove, null);	
			}
			
			//and add in any parameters
			String decodedApiCallString;
			try {
				decodedApiCallString = URLDecoder.decode(apiCallString, "UTF-8");
			}catch(IllegalArgumentException e) {
				throw new InvalidParameterException(Constants.Error.GENERAL.BATCH_CHAIN_BAD_FORMAT_APICALL,ListUtil.from(apiCallString));				
			} catch (UnsupportedEncodingException e) {
				throw new InvalidParameterException(Constants.Error.GENERAL.BATCH_CHAIN_BAD_FORMAT_APICALL);				
			}
			
			try {
				logger.debug("Preparing chained api call: " + decodedApiCallString);
				List<String> keyValuePairs = ListUtil.explode(decodedApiCallString, "&");
				for(String keyValuePair : keyValuePairs) {
					String[] kv = keyValuePair.split("=");
					if(kv.length == 2) {
						//currently ignoring bad parameter strings
						try {
							childRequest.overrideParameter(kv[0], URLDecoder.decode(kv[1], "UTF-8"));
						}catch(IllegalArgumentException e) {
							throw new InvalidParameterException(Constants.Error.GENERAL.BATCH_CHAIN_BAD_FORMAT_APICALL,ListUtil.from(apiCallString));				
						} catch (UnsupportedEncodingException e) {
							throw new InvalidParameterException(Constants.Error.GENERAL.BATCH_CHAIN_BAD_FORMAT_APICALL);				
						}
					}
				}
				
				if(childRequest.getParameter(Constants.Request.METHOD).equalsIgnoreCase("batch.chain")) {
					//loop
					throw new InvalidParameterException(Constants.Error.GENERAL.BATCH_CHAIN_LOOP);
				}
				
				logger.debug("About to run chained api call with query: " + RemoteRequestUtil.getQueryString(childRequest));
				
				//false here indicates that the GatewayServlet cannot marshal or close the output stream
				(new GatewayServlet()).processRequest(childRequest, childResponse, false);
				response.getMulti().getRewardMe().add(childResponse.get());
				
			}  catch (ServletException e) {
				throw new FatalException(e);
			} catch (IOException e) {
				throw new FatalException(e);
			}
			
			counter++;
		}
		
		response.setBatchRequest(true);
	}
	
}
