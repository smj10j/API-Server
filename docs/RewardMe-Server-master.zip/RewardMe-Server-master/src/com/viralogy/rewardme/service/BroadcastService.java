package com.viralogy.rewardme.service;

import java.util.Date;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.MessageManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerBroadcastMessage;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.scheduler.ScheduledTask;
import com.viralogy.rewardme.scheduler.ScheduledTask.Type;
import com.viralogy.rewardme.servlet.GatewayServlet;
import com.viralogy.rewardme.util.ListUtil;

public class BroadcastService {
	
	private static Logger logger = Logger.getLogger(BroadcastService.class);
		
	public static void schedule(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		Customer customer = request.getCustomer();
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, false);
		Address address = addressId == null ? null : AddressManager.getAddress(addressId, false);
		if(address != null && address.getCustomer().getCustomerId() != customer.getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.ADDRESS_ID, ListUtil.from(address.getAddressId()+""));
		}
		Date timestamp = request.getParameterDate(Constants.Request.DELIVERY_TIMESTAMP, true);
		String message = request.getParameter(Constants.Request.MESSAGE);
		
		if(message != null && message.length() > 160) {
			throw new InvalidParameterException(Constants.Error.GENERAL.INVALID_MESSAGE_LENGTH,ListUtil.from(160+"",message.length()+""));
		}
		
		if(timestamp.equals(new Date()) || timestamp.before(new Date())) {
			//if specified as immediate, do it in 10 seconds so the database row is for sure created
			timestamp = new Date(timestamp.getTime()+(10*1000));
		}	
		
		//create the message
		CustomerBroadcastMessage customerBroadcastMessage = new CustomerBroadcastMessage(customer, address, message, timestamp);
		MessageManager.save(customerBroadcastMessage);
		
		String baseUrl = GatewayServlet.getLocalServerBaseUrl() + "schedule";
		String queryString = "customerId="+customer.getCustomerId()+"&customerBroadcastMessageId="+customerBroadcastMessage.getCustomerBroadcastMessageId();
		
		//schedule it
		String url = baseUrl + "?" + queryString;
		(new ScheduledTask(Type.URL, url, customerBroadcastMessage.getTimestamp())).save();
	}
}
