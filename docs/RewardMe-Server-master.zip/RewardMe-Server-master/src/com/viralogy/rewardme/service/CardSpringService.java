package com.viralogy.rewardme.service;

import java.io.IOException;

import org.apache.commons.httpclient.NameValuePair;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.CardSpringType;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.util.RemoteRequestUtil;

public abstract class CardSpringService {

	private static Logger logger = Logger.getLogger(CardSpringService.class);

	public static class User {
		
		public static void addCard(RewardMeRequest request,
				RewardMeResponse response) throws InvalidParameterException,
				FatalException, IOException {
			User.save(request, response);
			Card.add(request, response);
		}

		public static void get(RewardMeRequest request,
				RewardMeResponse response) throws InvalidParameterException,
				FatalException, IOException {
			String resp = RemoteRequestUtil.get(
					Constants.CardSpring.TEST.BASE_URL + "/users/"
							+ request.getUser().getUserId() + "."
							+ request.getParameter("responseFormat"), 
					"",
					Constants.CardSpring.TEST.API_ID,
					Constants.CardSpring.TEST.API_SECRET, 
					false
			);

			outputCardSpring(request, response, resp);
		}

		public static void save(RewardMeRequest request,
				RewardMeResponse response) throws InvalidParameterException,
				FatalException, IOException {
			NameValuePair[] parameters = { 
					new NameValuePair("user_id", request.getUser().getUserId() + "") 
			};
			String resp = RemoteRequestUtil.get(
					Constants.CardSpring.TEST.BASE_URL + "/users/"
							+ request.getUser().getUserId() + "."
							+ request.getParameter("responseFormat"), 
					"",
					Constants.CardSpring.TEST.API_ID,
					Constants.CardSpring.TEST.API_SECRET, 
					false
			);
			try {
				JSONObject obj = new JSONObject(resp);
				try {
					obj.get("status");
					resp = RemoteRequestUtil.post(
							Constants.CardSpring.TEST.BASE_URL + "/users" + "."
									+ request.getParameter("responseFormat"),
							parameters, 
							Constants.CardSpring.TEST.API_ID,
							Constants.CardSpring.TEST.API_SECRET, 
							false
					);
				} catch (Exception e) {
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}

		public static void delete(RewardMeRequest request,
				RewardMeResponse response) throws InvalidParameterException,
				FatalException, IOException {
			String resp = RemoteRequestUtil.delete(
					Constants.CardSpring.TEST.BASE_URL + "/users" + "/"
							+ request.getUser().getUserId() + "."
							+ request.getParameter("responseFormat"),
					Constants.CardSpring.TEST.API_ID,
					Constants.CardSpring.TEST.API_SECRET, 
					false
			);
			outputCardSpring(request, response, resp);
		}

		public static void add(RewardMeRequest request,
				RewardMeResponse response) throws InvalidParameterException,
				FatalException, IOException {
			NameValuePair[] parameters = { new NameValuePair("user_id",
					request.getParameter("userId")) };
			String resp = RemoteRequestUtil.post(
					Constants.CardSpring.TEST.BASE_URL + "/users" + "."
							+ request.getParameter("responseFormat"),
					parameters, 
					Constants.CardSpring.TEST.API_ID,
					Constants.CardSpring.TEST.API_SECRET, 
					false
			);
			outputCardSpring(request, response, resp);
		}
	}

	public static class Card {
		public static void get(RewardMeRequest request,
				RewardMeResponse response) throws InvalidParameterException,
				FatalException, IOException {
			String resp = RemoteRequestUtil.get(
					Constants.CardSpring.TEST.BASE_URL + "/users/"
							+ request.getUser().getUserId() + "/cards/"
							+ request.getParameter("token") + "."
							+ request.getParameter("responseFormat"), 
					"",
					Constants.CardSpring.TEST.API_ID,
					Constants.CardSpring.TEST.API_SECRET, 
					false
			);
			outputCardSpring(request, response, resp);
		}

		public static void delete(RewardMeRequest request,
				RewardMeResponse response) throws InvalidParameterException,
				FatalException, IOException {
			String resp = RemoteRequestUtil.delete(
					Constants.CardSpring.TEST.BASE_URL + "/users/"
							+ request.getUser().getUserId() + "/cards/"
							+ request.getParameter("token") + "."
							+ request.getParameter("responseFormat"),
					Constants.CardSpring.TEST.API_ID,
					Constants.CardSpring.TEST.API_SECRET, 
					false
			);
			outputCardSpring(request, response, resp);
		}

		public static void add(RewardMeRequest request,
				RewardMeResponse response) throws InvalidParameterException,
				FatalException, IOException {
			NameValuePair[] parameters = {
					new NameValuePair("pan", request.getParameter("cardNumber")),
					new NameValuePair("expiration",	request.getParameter("cardExpirationYear")
									+ "-"
									+ request.getParameter("cardExpirationMonth")) 
			};
			String resp = RemoteRequestUtil.post(
					Constants.CardSpring.TEST.BASE_URL + "/users/"
							+ request.getUser().getUserId() + "/cards" + "."
							+ request.getParameter("responseFormat"),
					parameters, 
					Constants.CardSpring.TEST.API_ID,
					Constants.CardSpring.TEST.API_SECRET, 
					false
			);
			outputCardSpring(request, response, resp);
		}
	}

	public static class Business {
		public static void get(RewardMeRequest request,
				RewardMeResponse response) throws InvalidParameterException,
				FatalException, IOException {
			String resp = RemoteRequestUtil.get(
					Constants.CardSpring.TEST.BASE_URL + "/businesses/"
							+ request.getParameter("businessId") + "."
							+ request.getParameter("responseFormat"), 
					"",
					Constants.CardSpring.TEST.API_ID,
					Constants.CardSpring.TEST.API_SECRET, 
					false
			);
			outputCardSpring(request, response, resp);
		}

		public static void createConnection(RewardMeRequest request,
				RewardMeResponse response) throws InvalidParameterException,
				FatalException {

			NameValuePair[] parameters = {
			};
			
			String resp = RemoteRequestUtil.post(
					Constants.CardSpring.TEST.BASE_URL + "/businesses/"
							+ request.getParameter("businessId")
							+ "/connection."
							+ request.getParameter("responseFormat"),
					parameters, 
					Constants.CardSpring.TEST.API_ID,
					Constants.CardSpring.TEST.API_SECRET, 
					false
			);
			outputCardSpring(request, response, resp);
		}

		public static void createApp(RewardMeRequest request,
				RewardMeResponse response) throws InvalidParameterException,
				FatalException {

			NameValuePair[] parameters = {
					new NameValuePair("auto_connect",
							request.getParameter("all")),
					new NameValuePair("notification[type]",
							"all_payment_events") };
			String resp = RemoteRequestUtil.post(
					Constants.CardSpring.TEST.BASE_URL + "/businesses/"
							+ request.getParameter("businessId") + "/apps."
							+ request.getParameter("responseFormat"),
					parameters, 
					Constants.CardSpring.TEST.API_ID,
					Constants.CardSpring.TEST.API_SECRET, 
					false
			);
			outputCardSpring(request, response, resp);
		}

		public static void deleteApp(RewardMeRequest request,
				RewardMeResponse response) throws InvalidParameterException,
				FatalException {

			String resp = RemoteRequestUtil.delete(
					Constants.CardSpring.TEST.BASE_URL + "/businesses/"
							+ request.getParameter("businessId") + "/apps/"
							+ request.getParameter("appId") + "."
							+ request.getParameter("responseFormat"),
					Constants.CardSpring.TEST.API_ID,
					Constants.CardSpring.TEST.API_SECRET, 
					false
			);
			outputCardSpring(request, response, resp);
		}
	}

	// USED FOR TESTING PURPOSES ONLY
	public static class Transaction {
		public static void get(RewardMeRequest request,
				RewardMeResponse response) throws InvalidParameterException,
				FatalException, IOException {
			String resp = RemoteRequestUtil.get(
					Constants.CardSpring.TEST.BASE_URL + "/transactions/"
							+ request.getParameter("transactionId") + "."
							+ request.getParameter("responseFormat"), 
					"",
					Constants.CardSpring.TEST.API_ID,
					Constants.CardSpring.TEST.API_SECRET, 
					false
			);
			outputCardSpring(request, response, resp);
		}

		public static void create(RewardMeRequest request,
				RewardMeResponse response) throws InvalidParameterException,
				FatalException {

			NameValuePair[] parameters = {
					new NameValuePair("card_token", request.getParameter("token")),
					new NameValuePair("store_id", request.getParameter("storeId")),
					new NameValuePair("amount", request.getParameter("amount")),
					new NameValuePair("event_type",	request.getParameter("eventType")) 
			};
			String resp = RemoteRequestUtil.post(
					Constants.CardSpring.TEST.BASE_URL + "/transactions."+ request.getParameter("responseFormat"),
					parameters, 
					Constants.CardSpring.TEST.API_ID,
					Constants.CardSpring.TEST.API_SECRET, 
					false
			);
			outputCardSpring(request, response, resp);
		}

	}

	public static void outputCardSpring(RewardMeRequest request,
			RewardMeResponse response, String raw) {
		JSONObject obj;
		try {
			obj = new JSONObject(raw);
			logger.debug(obj.toString());
			CardSpringType c = new CardSpringType();
			c.setResponse(obj.toString());
			response.get().setCardSpring(c);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
}
