package com.viralogy.rewardme.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.CheckinOptionsType;
import com.viralogy.rewardme.manager.CheckinOptionManager;
import com.viralogy.rewardme.manager.PointsManager;
import com.viralogy.rewardme.model.CheckinOption;
import com.viralogy.rewardme.model.CheckinOption.Type;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.PointCategory;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.StringUtil;

public class CheckinOptionService {
	
	private static Logger logger = Logger.getLogger(CheckinOptionService.class);
	
	public static void getCheckinOption(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Customer customer = request.getCustomer();
		long checkinOptionId = request.getParameterLong(Constants.Request.CHECKIN_OPTION_ID, true);
		CheckinOption checkinOption = CheckinOptionManager.getCheckinOption(checkinOptionId);
		
		boolean hasWritePermissions = false;
		for(CheckinOption checkinOption2 : customer.getCheckinOptions()) {
			if(checkinOption2.getCheckinOptionId() == checkinOption.getCheckinOptionId()) {
				hasWritePermissions = true;
				break;
			}
		}
		if(!hasWritePermissions) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_READ,ListUtil.from("checkinOption",customer.getApiKey()));
		}
		
		response.get().setCheckinOption(checkinOption.toCheckinOptionType());
	}
	
	public static void saveCheckinOption(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		//path to default checkin options '../images/checkin/defaultOptions/'
		
		Customer customer = request.getCustomer();
		CheckinOption checkinOption = null;
		String name = request.getParameter(Constants.Request.NAME);
		String imageUrl = request.getParameter(Constants.Request.IMAGE_URL);
		int pointAward = request.getParameterInt(Constants.Request.POINT_AWARD, true);
		int referralPointAward = request.getParameterInt(Constants.Request.REFERRAL_POINT_AWARD, true);
		int recurringReferralPointAward = request.getParameterInt(Constants.Request.RECURRING_REFERRAL_POINT_AWARD, true);
		int cooldownLength = request.getParameterInt(Constants.Request.COOLDOWN_LENGTH, true);
		Boolean enabled = request.getParameterBool(Constants.Request.ENABLED, false);
		Type type = request.getParameterType(Constants.Request.TYPE, Type.class, true);
		Long checkinOptionId = request.getParameterLong(Constants.Request.CHECKIN_OPTION_ID, false); 

		PointCategory pointCategory = null;
		String pointCategoryName = request.getParameter(Constants.Request.POINT_CATEGORY);
		if(!StringUtil.isNullOrEmpty(pointCategoryName)) {
			pointCategory = PointsManager.getPointCategory(customer, pointCategoryName);
		}else {
			pointCategory = PointsManager.getDefaultPointCategory(customer);
		}

		if(checkinOptionId != null) {
			boolean hasWritePermissions = false;
			checkinOption = CheckinOptionManager.getCheckinOption(checkinOptionId);
			for(CheckinOption checkinOption2 : customer.getCheckinOptions()) {
				if(checkinOption2.getCheckinOptionId() == checkinOption.getCheckinOptionId()) {
					hasWritePermissions = true;
					break;
				}
			}
			if(!hasWritePermissions) {
				throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE,ListUtil.from("checkinOption",customer.getApiKey()));
			}
			checkinOption.setName(name);
			checkinOption.setType(type);
			checkinOption.setImageUrl(imageUrl);
			checkinOption.setPointAward(pointAward);
			checkinOption.setReferralPointAward(referralPointAward);
			checkinOption.setRecurringReferralPointAward(recurringReferralPointAward);
			checkinOption.setCooldownLength(cooldownLength);
			checkinOption.setPointCategory(pointCategory);
			//TODO: Address: add enabled?
			
			CheckinOptionManager.save(customer, checkinOption);
		}else {
			CheckinOptionManager.addCheckinOptionToCustomer(customer,
					new CheckinOption(
						name, 
						type,
						imageUrl, 
						pointCategory,
						pointAward, 
						referralPointAward, 
						recurringReferralPointAward, 
						cooldownLength
					)
			);
		}

		response.get().setCustomer(customer.toCustomerType(null, true, false));
	}	
	
	public static void removeCheckinOption(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		long checkinOptionId = request.getParameterLong(Constants.Request.CHECKIN_OPTION_ID, true);
		
		for(CheckinOption checkinOption : customer.getCheckinOptions()) {
			if(checkinOption.getCheckinOptionId() == checkinOptionId) {
				CheckinOptionManager.removeCheckinOptionFromCustomer(customer, checkinOption);
				break;
			}
		}

		response.get().setCustomer(customer.toCustomerType(null, true, false));
	}	
	
	public static void getCheckinOptionsForCustomer(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Customer customer = request.getCustomer();
		boolean ignoreSchedules = request.getParameterBool(Constants.Request.IGNORE_SCHEDULES, false);
		
		List<CheckinOption> checkinOptions = CheckinOptionManager.getAllCheckinOptions(customer, ignoreSchedules);
		
		response.get().setCheckinOptions(new CheckinOptionsType());
		for(CheckinOption checkinOption : checkinOptions) {
			response.get().getCheckinOptions().getCheckinOption().add(checkinOption.toCheckinOptionType());
		}
	}

}
