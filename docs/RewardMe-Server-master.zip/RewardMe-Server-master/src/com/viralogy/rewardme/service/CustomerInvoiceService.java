package com.viralogy.rewardme.service;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.manager.CustomerInvoiceManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.model.CustomerContact;
import com.viralogy.rewardme.model.CustomerInvoice;
import com.viralogy.rewardme.model.CustomerInvoiceItem;
import com.viralogy.rewardme.model.CustomerInvoicePayment;
import com.viralogy.rewardme.model.CustomerInvoiceRecurring;
import com.viralogy.rewardme.model.FreshbooksResponse;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.CustomerBilling;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.FreshbooksUtil;

public abstract class CustomerInvoiceService {

	private static Logger logger = Logger.getLogger(CustomerInvoiceService.class);

	/**
	 * Creates a brand new customerBilling for a customer or updates the current one with a new contact.
	 * 
	 * customerContactId is required if there are multiple customerContacts linking to the given customer
	 * 
	 * @param request - contains apiKey(required) and customerContactId(!required)
	 * @param response - contains a customerBillingType
	 * @throws InvalidParameterException 
	 * @throws FatalException
	 */
	public static void saveBilling(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
	    
	    CustomerBilling customerBilling = null;
	    CustomerContact customerContact = null;
	    
	    String apiKey = request.getParameter(Constants.Request.API_KEY);
	    Long customerContactId = request.getParameterLong(Constants.Request.CUSTOMER_CONTACT_ID, false);
	    
	    Customer customer = null;
	    try {
	        customer = CustomerManager.getCustomer( apiKey );
	    }
	    catch( InvalidParameterException e) {
	        throw new InvalidParameterException(Constants.Error.INVALID_ID.API_KEY);
	    }
	    
	    try {     
	        customerBilling = customer.getBilling();
	    } catch (InvalidParameterException e) {
	        // no existing billing for customer
	    }
	    
	    // if there is pre-existing customer billing
	    if(customerBilling != null ) {
	        
            // if contact is in request and it is different from the previous contact
	        if(customerContactId != null && customerContactId != customerBilling.getCustomerContact().getCustomerContactId()) {
	            
    	        // checks that contact corresponds to customer
    	        customerContact = CustomerManager.getContact(customerContactId);
                if( customer.getCustomerId() == customerContact.getCustomer().getCustomerId()) {
                    
                    long freshbooksClientId = customerBilling.getFreshbooksClientId();
                    FreshbooksUtil.updateClient(freshbooksClientId, customerContact.getName(), customerContact.getEmail(), customerContact.getPassword(), !request.getRequestURL().contains("gerald"));
                    customerBilling.setCustomerContact( customerContact );
                }
                else {
                    throw new InvalidParameterException(Constants.Error.PERMISSIONS.CONTACT_DOESNT_MATCH_CUSTOMER, ListUtil.from(customerContactId+"", customer.getCustomerId()+""));
                }
	        } else {
	            // do nothing since there is already a billing with given contact id
	        }
	    }
	    else {
            customerBilling = new CustomerBilling();
            customerBilling.setCustomer( customer );
            
            List<CustomerContact> customerContacts = CustomerManager.getContacts( customer );
            
            // if there are no contacts matching to the customer
            if(customerContacts.size() == 0) {
                throw new InvalidParameterException(Constants.Error.GENERAL.CONTACT_CUSTOMER_HAS_NO_CUSTOMER_CONTACT, ListUtil.from(customer.getApiKey()+""));
            }
            // if there is only one contact to customer
            else if( customerContacts.size() == 1) {
                // good, use that customer
                customerContact = customerContacts.get( 0 );
            }
            // if there is more than one possible customer and the customer contact is not specified
            else if( customerContactId == null ) {
                // there are multiple possible contact possibilities, so throw exception
                throw new InvalidParameterException(Constants.Error.GATEWAY.MISSING_REQUIRED_PARAMETER, ListUtil.from( Constants.Request.CUSTOMER_CONTACT_ID ));
            }
            // else a customer contact is given and there is more than one contact corresponding to the customer
            else {
                
                CustomerContact contact = CustomerManager.getContact(customerContactId);
                // if customer contact matches the customer
                if( customer.getCustomerId() == contact.getCustomer().getCustomerId()) {
                    customerContact = contact;
                }
                else {
                    throw new InvalidParameterException(Constants.Error.PERMISSIONS.CONTACT_DOESNT_MATCH_CUSTOMER, ListUtil.from(customerContactId+"", customer.getCustomerId()+""));
                }
            }
            customerBilling.setCustomerContact( customerContact );
            
            long freshbooksClientId = FreshbooksUtil.createClient( customerContact.getName(), customer.getName(), customerContact.getEmail(), customerContact.getPassword(), !request.getRequestURL().contains("gerald") );
            customerBilling.setFreshbooksClientId( freshbooksClientId );
	    }

        CustomerInvoiceManager.save( customerBilling );
        
        response.get().setBilling( customerBilling.toCustomerBillingType(true) );
	}
	
	public static void getBilling(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
	    
	    Customer customer = request.getCustomer();
	    
	    response.get().setBilling( customer.getBilling().toCustomerBillingType( false ));
	}
	
	
	public static void createRecurring(RewardMeRequest request, RewardMeResponse response ) throws InvalidParameterException, FatalException {
	    
	    Customer customer = request.getCustomer();
	    CustomerBilling customerBilling = null;
	    CustomerInvoiceRecurring customerInvoiceRecurring = null;
	    
	    try {     
            customerBilling = customer.getBilling();
        } catch (InvalidParameterException e) {
            // no existing billing for customer
        }
        
        if( customerBilling == null ) {
            throw new InvalidParameterException(Constants.Error.BILLING.NO_BILLING_FOR_CUSTOMER, ListUtil.from( customer.getCustomerId()+""));
        }
        
        try {
            customerInvoiceRecurring = CustomerInvoiceManager.getCustomerInvoiceRecurring( customerBilling.getCustomerBillingId() );
        } catch (InvalidParameterException e) {
            // no existing customerInvoiceRecurring
        }
        
        if( customerInvoiceRecurring == null ) {
            
            logger.debug("Making customerinvoiceRecurring");
            CustomerInvoiceItem customerInvoiceAddressItem = CustomerInvoiceManager.getCustomerInvoiceItem (
                Constants.Freshbooks.SERVICE_FEE_ITEM_NAME, Constants.Freshbooks.SERVICE_FEE_ITEM_DESCRIPTION, 
                Constants.Freshbooks.DEFAULT_SERVICE_FEE_PER_ADDRESS, customer.getAddresses().size(), true);
            
            CustomerInvoiceItem customerInvoiceTabletItem = CustomerInvoiceManager.getCustomerInvoiceItem( 
                Constants.Freshbooks.TABLET_ITEM_NAME, Constants.Freshbooks.TABLET_ITEM_DESCRIPTION,
                Constants.Freshbooks.DEFAULT_TABLET_FEE, customer.getAddresses().size() * Constants.Freshbooks.NUMBER_TABLETS_PER_ADDRESS, true);
            
            customerInvoiceRecurring = new CustomerInvoiceRecurring();
            customerInvoiceRecurring.setCustomerBilling( customerBilling );
            customerInvoiceRecurring.setStopped( true );
            customerInvoiceRecurring.setAutoBill( false );
            
            CustomerInvoiceManager.save( customerInvoiceRecurring );
            CustomerInvoiceManager.addCustomerInvoiceItemsToCustomerInvoiceRecurring(ListUtil.from(customerInvoiceAddressItem, customerInvoiceTabletItem), customerInvoiceRecurring);
            
            long freshbooksRecurringId = FreshbooksUtil.createRecurring( customerBilling.getFreshbooksClientId(), ListUtil.from( customerInvoiceAddressItem, customerInvoiceTabletItem ), !request.getRequestURL().contains("gerald"));
            customerInvoiceRecurring.setFreshbooksRecurringId( freshbooksRecurringId );
            
            CustomerInvoiceManager.save( customerInvoiceRecurring );
        } else {
            logger.debug( "Recurring already exists, so skipping everything");
            // will need method to update recurring
        }
        
	    response.get().setCustomerInvoiceRecurring( customerInvoiceRecurring.toCustomerInvoiceRecurringType() );
	    
	}
	
	/**
	 * Does not take a response because this is a Webhooks freshbooks call from the FreshbooksServlet
	 * @param request - contains object_id which is the newly created invoice's id
	 */
	public static void saveInvoice( RewardMeRequest request ) throws InvalidParameterException, FatalException{
	    long freshbooksInvoiceId = request.getParameterLong( Constants.Freshbooks.OBJECT_ID, true );

        FreshbooksResponse freshbooksResponse = FreshbooksUtil.getCustomerInvoice( freshbooksInvoiceId, !request.getRequestURL().contains("gerald"));

        CustomerInvoice customerInvoice = freshbooksResponse.getCustomerInvoice();

        logger.debug("Date: " + customerInvoice.getDueDate());
        logger.debug("About to save invoice");
        CustomerInvoiceManager.save( customerInvoice );
        logger.debug("Date: " + customerInvoice.getDueDate());
        
        List<CustomerInvoiceItem> customerInvoiceItems = freshbooksResponse.getCustomerInvoiceItems();
        for(CustomerInvoiceItem customerInvoiceItem : customerInvoiceItems) {
            long customerInvoiceItemId = CustomerInvoiceManager.getCustomerInvoiceItemId( customerInvoiceItem );
            customerInvoiceItem.setCustomerInvoiceItemId( customerInvoiceItemId );
        }   
        CustomerInvoiceManager.addCustomerInvoiceItemsToCustomerInvoice(customerInvoiceItems, customerInvoice);
	    
	}
	
	public static void savePayment( RewardMeRequest request) throws InvalidParameterException, FatalException {
	    long freshbooksPaymentId = request.getParameterLong( Constants.Freshbooks.OBJECT_ID, true );
	    
	    FreshbooksResponse freshbooksResponse = FreshbooksUtil.getPayment( freshbooksPaymentId, !request.getRequestURL().contains( "gerald" ));
	    
	    CustomerInvoicePayment customerInvoicePayment = freshbooksResponse.getCustomerInvoicePayment();
	    CustomerInvoice customerInvoice = CustomerInvoiceManager.getCustomerInvoice(customerInvoicePayment.getFreshbooksInvoiceId());
	    
	    customerInvoice.setPaidDate( new Date()  );
	    
	    CustomerInvoiceManager.save( customerInvoice );
	}
	
}
