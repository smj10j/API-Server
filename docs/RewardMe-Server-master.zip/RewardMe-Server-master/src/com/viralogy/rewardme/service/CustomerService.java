package com.viralogy.rewardme.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.CustomerContactsType;
import com.viralogy.rewardme.jaxb.CustomerFeaturesType;
import com.viralogy.rewardme.jaxb.CustomerType;
import com.viralogy.rewardme.jaxb.CustomersType;
import com.viralogy.rewardme.jaxb.EventsType;
import com.viralogy.rewardme.jaxb.UserRewardsType;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.DeviceManager;
import com.viralogy.rewardme.manager.FeatureManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerContact;
import com.viralogy.rewardme.model.CustomerFeature;
import com.viralogy.rewardme.model.CustomerFeature.Feature;
import com.viralogy.rewardme.model.Device;
import com.viralogy.rewardme.model.Event;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserReward;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.StringUtil;

public class CustomerService {
	
	private static Logger logger = Logger.getLogger(CustomerService.class);
	
	public static void saveCustomer(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Customer customer = null;
		User user = request.getUser();
		Long customerId = request.getParameterLong(Constants.Request.CUSTOMER_ID, false); 
		String name = request.getParameter(Constants.Request.NAME);
		String subdomain = request.getParameter(Constants.Request.SUBDOMAIN);
		String apiKey = request.getParameter(Constants.Request.NEW_API_KEY);
		boolean enabled = request.getParameterBool(Constants.Request.ENABLED, true);
		
		if(customerId == null) {
			try {
				customer = CustomerManager.getCustomer(apiKey);
			}catch(InvalidParameterException e) {
				//good - no existing customer
			}
			if(customer != null) {
				throw new InvalidParameterException(Constants.Error.GENERAL.CUSTOMER_ALREADY_EXISTS,ListUtil.from(apiKey, name));
			}
			customer = new Customer();
			customer.setApiKey(apiKey);
			
			String secretKey = "";
			for(int i = 0; i < 40; i++) {
				secretKey+= (char)Math.floor(Math.random()*90+35);
			}
			customer.setSecretKey(secretKey);
			
			String authCode = "";
			for(int i = 0; i < 6; i++) {
				authCode+= (int)(Math.floor(Math.random()*10));
			}
			customer.setAuthCode(authCode);			
			
		}else {
			customer = CustomerManager.getCustomer(customerId);
			customer.setApiKey(apiKey);
		}
		
		customer.setName(name);
		customer.setEnabled(enabled);
		customer.setSubdomain(subdomain);
		customer.setUser(user);

		CustomerManager.save(customer);
		
		CustomerType customerType = customer.toCustomerType(null, true, false);
		if(customerId == null) {
			customerType.setAuthCode(customer.getAuthCode());
		}

		response.get().setCustomer(customerType);
	}	
		
	public static void getCustomer(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
	
		Customer customer = request.getCustomer();
		
		if(customer == null) {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.API_KEY, ListUtil.from(request.getParameter(Constants.Request.API_KEY)));
		}
		
		//force a request to see if the user is authorized to get billing info
		request.isAuthorized();

		response.get().setCustomer(customer.toCustomerType(request.getUser(), true, false));
	}
	
	public static void getSecretKey(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
	
		Customer customer = request.getCustomer();
		String authCode = request.getParameter(Constants.Request.AUTH_CODE, true);
		if(customer == null) {
			throw new InvalidParameterException(Constants.Error.GATEWAY.MISSING_REQUIRED_PARAMETER, ListUtil.from(Constants.Request.API_KEY));
		}
		
		if(StringUtil.isNullOrEmpty(customer.getAuthCode()) || !authCode.equals(customer.getAuthCode())) {
			throw new InvalidParameterException(Constants.Error.GATEWAY.INVALID_AUTHENTICATION);
		}
		
		CustomerType customerType = customer.toCustomerType(request.getUser(), false, false);
		customerType.setSecretKey(customer.getSecretKey());
		
		response.get().setCustomer(customerType);
	}	
		
	public static void getAdminEvents(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Customer customer = request.getCustomer();
		int returnCount = request.getParameterInt(Constants.Request.RETURN_COUNT, false);

		List<Event> events = CustomerManager.getAdminEvents(customer, returnCount);
		
		response.get().setEvents(new EventsType());
		for(Event event : events) {
			response.get().getEvents().getEvent().add(event.toEventType());
		}		
	}
	
	public static void getFeatures(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Customer customer = request.getCustomer();
			
		response.get().setFeatures(new CustomerFeaturesType());
		for(CustomerFeature customerFeature : customer.getFeatures()) {
			response.get().getFeatures().getFeature().add(customerFeature.toCustomerFeatureType(true));
		}
	}
	
	public static void getBilling(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Customer customer = request.getCustomer();
			
		response.get().setBilling(customer.getBilling().toCustomerBillingType(true));
		
	}
	
	public static void getRewardRedemptionList(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
	        
        Customer customer = request.getCustomer();
        int returnCount = request.getParameterInt(Constants.Request.RETURN_COUNT,false);
        
        List<UserReward> userRewards = CustomerManager.getRedeemedRewards(customer, returnCount);
        
        response.get().setUserRewards( new UserRewardsType() );
        
        for(UserReward userReward : userRewards) {
            response.get().getUserRewards().getUserReward().add( userReward.toUserRewardType());
        }
    }
			
	public static void saveContact(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Customer customer = request.getCustomer();
		User user = request.getUser();
		CustomerContact customerContact = null;
		Long customerContactId = request.getParameterLong(Constants.Request.CUSTOMER_CONTACT_ID, false);
		String name = request.getParameter(Constants.Request.NAME, false);
		String email = request.getParameter(Constants.Request.EMAIL, false);
		String password = request.getParameter(Constants.Request.PASSWORD, false);

		if(customerContactId != null) {
			customerContact = CustomerManager.getContact(customerContactId);
			if(customer.getCustomerId() != customerContact.getCustomer().getCustomerId()) {
				throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE,ListUtil.from("customerContact",customer.getApiKey()));
			}
			if(!StringUtil.isNullOrEmpty(name)) {
				customerContact.setName(name);				
			}
			if(!StringUtil.isNullOrEmpty(email)) {
				customerContact.setEmail(email);				
			}
			if(!StringUtil.isNullOrEmpty(password)) {
				customerContact.setPassword(password);				
			}

		}else {
			//force these to be required for new customer contacts
			name = request.getParameter(Constants.Request.NAME, true);
			email = request.getParameter(Constants.Request.EMAIL, true);
			password = request.getParameter(Constants.Request.PASSWORD, true);
			
			customerContact = new CustomerContact(customer, name, email, password, user);
		}
		CustomerManager.save(customerContact);

		response.get().setCustomer(customer.toCustomerType(null, true, false));
	}		
	
	public static void removeContact(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Customer customer = request.getCustomer();
		CustomerContact customerContact = CustomerManager.getContact(request.getParameterLong(Constants.Request.CUSTOMER_CONTACT_ID, true));
		CustomerManager.removeContact(customerContact);

		response.get().setCustomer(customer.toCustomerType(null, true, false));
	}		
	
	public static void getContacts(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Customer customer = request.getCustomer();
				
		response.get().setCustomerContacts(new CustomerContactsType());
		for(CustomerContact customerContact : customer.getCustomerContacts()) {
			response.get().getCustomerContacts().getCustomerContact().add(customerContact.toCustomerContactType(true));
		}
	}	
	
	public static void saveFeature(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Customer customer = request.getCustomer();
		CustomerFeature customerFeature = null;
		String featureStr = request.getParameter(Constants.Request.FEATURE);
		int amount = request.getParameterInt(Constants.Request.AMOUNT, true);
		Long customerFeatureId = request.getParameterLong(Constants.Request.CUSTOMER_FEATURE_ID, false); 

		Feature feature;
		try {
			feature = Feature.valueOf(featureStr.toUpperCase());
		}catch(Exception e) {
			throw new InvalidParameterException(Constants.Error.GATEWAY.INVALID_PARAMETER_TYPE, ListUtil.from(Constants.Request.FEATURE, "PUSH_NOTIFICATION, ACTIVITY_NOTIFICATION, etc.", featureStr));
		}
	
		if(customerFeatureId != null) {
			customerFeature = FeatureManager.getCustomerFeature(customerFeatureId);
			if(customer.getCustomerId() != customerFeature.getCustomer().getCustomerId()) {
				throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE,ListUtil.from("customerFeature",customer.getApiKey()));
			}
			customerFeature.setAmount(amount);
		}else {
			
			boolean alreadyExists = false;
			try { 
				//see if we have a feature by this name already setup for this customer
				//if so, throw an exception because the person should be accessing it by id
				customerFeature = FeatureManager.getCustomerFeature(customer, feature);
				alreadyExists = true;
			}catch(InvalidParameterException e) {
				//doesn't exist - great
				alreadyExists = false;
			}
			if(alreadyExists) {
				throw new InvalidParameterException(Constants.Error.GENERAL.FEATURE_EXISTS_ALREADY,ListUtil.from(customer.getCustomerId()+"",feature.toString()));
			}
			
			customerFeature = new CustomerFeature(customer, feature, amount);
		}
		FeatureManager.saveCustomerFeature(customerFeature);

		response.get().setCustomer(customer.toCustomerType(null, true, false));
	}	
	
	public static void removeCustomer(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		
		CustomerManager.removeCustomer(customer);
	}
	
	public static void query(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		String query = request.getParameter(Constants.Request.QUERY);
		Integer returnCount = request.getParameterInt(Constants.Request.RETURN_COUNT,false);
		
		logger.debug("Performing customer query for \"" + query + "\" (want " + returnCount + " results)");
		List<Customer> customers = CustomerManager.query(query, returnCount);
				
		CustomersType customersType = new CustomersType();
		for(Customer customer : customers) {
			CustomerType customerType = customer.toCustomerType(request.getUser(), false, false);
			customersType.getCustomer().add(customerType);
		}
		
		response.get().setCustomers(customersType);
	}	
	
}
