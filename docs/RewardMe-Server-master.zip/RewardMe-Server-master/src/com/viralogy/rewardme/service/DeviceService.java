package com.viralogy.rewardme.service;

import java.util.Calendar;
import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.ApplicationDAO;
import com.viralogy.rewardme.jaxb.CustomerType;
import com.viralogy.rewardme.jaxb.DeviceApplicationType;
import com.viralogy.rewardme.jaxb.DeviceLinksType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.AdminManager;
import com.viralogy.rewardme.manager.CheckinOptionManager;
import com.viralogy.rewardme.manager.DeviceManager;
import com.viralogy.rewardme.manager.ServerManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Application;
import com.viralogy.rewardme.model.CheckinOption;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Device;
import com.viralogy.rewardme.model.DeviceApplication;
import com.viralogy.rewardme.model.DeviceLink;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.SecretKey;
import com.viralogy.rewardme.model.Server;
import com.viralogy.rewardme.model.UnlinkedDeviceApplication;
import com.viralogy.rewardme.servlet.GatewayServlet;
import com.viralogy.rewardme.util.EmailUtil;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.SecurityUtil;

public abstract class DeviceService {
	
	private static Logger logger = Logger.getLogger(DeviceService.class);

	public static void authenticate(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		String authCode = SecurityUtil.cleanHash(request.getParameter(Constants.Request.AUTH_CODE, true));
		
		//TODO: authCodeTimestamp should be required here and in services.xml after 5/1/12
		Long authCodeTimestamp = request.getParameterLong(Constants.Request.AUTH_CODE_TIMESTAMP, false);
		
		//TODO: customer (apiKey) should be required here after all devices >= 1.0.8.6. it should remain in noApiKey required in 
		//services.xml so that a normal signature is not needed
		Customer customer = request.getCustomer();
		
		SecretKey.Type type = request.getParameterType(Constants.Request.TYPE, SecretKey.Type.class, true);
		
		
		if(authCodeTimestamp != null) {
			String targetAuthCode = null;
			boolean authCodeIsValid = false;
			
			if(customer != null) {
				targetAuthCode = SecurityUtil.calculateSignature(authCodeTimestamp+"", customer.getSecretKey());
				if(GatewayServlet.isSandbox()) {
					logger.debug("Testing customer secret key, generatedSig=" + targetAuthCode);
				}
				if(targetAuthCode.equals(authCode)) {
					authCodeIsValid = true;
					logger.debug("Authcode matched customer secret key");
				}				
			}
			
			if(!authCodeIsValid) {
				for(SecretKey adminSecretKey : Constants.Request.ADMIN_SECRET_KEYS) {
					targetAuthCode = SecurityUtil.calculateSignature(authCodeTimestamp+"", adminSecretKey.getSecretKey());
					if(GatewayServlet.isSandbox()) {
						logger.debug("Testing secretKey=" + adminSecretKey.getSecretKeyId() + ", generatedSig=" + targetAuthCode);
					}
					if(targetAuthCode.equals(authCode)) {
						authCodeIsValid = true;
						logger.debug("Authcode matched an admin secret key");
						break;
					}
				}
			}
	
			if(authCodeIsValid) {
		
				long now = Calendar.getInstance().getTimeInMillis()/1000;
				if(now + 300 < authCodeTimestamp) {
					//5 minute leeway - this prevents forward dating a request
					logger.warn("Invalid authCodeTimestamp (in the future). authCodeTimestamp="+authCodeTimestamp + ", now="+now + ", diff="+(authCodeTimestamp-now)+" seconds");
					throw new InvalidParameterException(Constants.Error.PERMISSIONS.SIGNATURE_INVALID_AUTH_CODE_IN_THE_FUTURE, ListUtil.from((authCodeTimestamp-now)+""));								
				}
				if(now - authCodeTimestamp > 300) {
					//requests are only valid for 5 minutes after generating the signature
					logger.warn("Invalid authCodeTimestamp (created too long ago). authCodeTimestamp="+authCodeTimestamp + ", now="+now + ", diff="+(now-authCodeTimestamp)+" seconds");
					throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_AUTH_CODE_EXPIRED, ListUtil.from((now-authCodeTimestamp)+""));								
				}		
				
				response.get().setMessage("Authenticated");
	
			}else {
				logger.warn("Invalid authCode. authCode="+authCode+", expected="+targetAuthCode+", data="+authCodeTimestamp);
				throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_AUTH_CODE);			
			}
		}else {
			/*
			 * TODO: remove this after:
			 * 		POSHero is secure
			 * 		RMPrinter is no longer in use
			 */
			
			try {
				//now try it unhashed
				AdminManager.getSecretKey(authCode, type);
			}catch(InvalidParameterException e2) {
				//and lastly try using the EVERYTHING type
				AdminManager.getSecretKey(authCode, SecretKey.Type.EVERYTHING);
			}
			
			response.get().setMessage("Authenticated");			
		}
	}
	
	public static void sendLog(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		//Device device = request.getDevice();
		String email = "steve@rewardme.com";
		String subject = request.getParameter(Constants.Request.SUBJECT);
		String body = request.getParameter(Constants.Request.BODY);
		
		try {						
			EmailUtil.email(null, "log-notifier", ListUtil.from(email), subject, body.getBytes(), "txt", null);
			
			logger.info("Device Log with subject " + subject + " sent to " + email + " successfully");
			
		} catch (FatalException e) {
			//oh bonkers
			logger.error("Error while trying to send device log", e);	    			
		}
	}	
	
	public static void createDevice(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		String newDeviceId = request.getParameter(Constants.Request.NEW_DEVICE_ID);
		
		Device device = null;
		
		//TODO: remove the following and uncomment the commented line
		//device = DeviceManager.getDevice(newDeviceId, false);
		try {
			device = DeviceManager.getDevice(newDeviceId, false);
			response.get().setDevice(device.toDeviceType());
		}catch(InvalidParameterException e) {
			//ignore - we're preventing new device creation right now
		}
	}
	
	//replaces createDevice
	public static void saveDevice(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		String deviceId = request.getParameter(Constants.Request.DEVICE_ID);
		String remoteDeviceUUID = request.getParameter(Constants.Request.REMOTE_DEVICE_UUID);
		String osName = request.getParameter(Constants.Request.OS_NAME);
		String osVersion = request.getParameter(Constants.Request.OS_VERSION);
		String model = request.getParameter(Constants.Request.MODEL);
		
		Device device = DeviceManager.getDevice(deviceId, true);
		if(remoteDeviceUUID != null) device.setRemoteDeviceUUID(remoteDeviceUUID);
		if(osName != null) device.setOsName(osName);
		if(osVersion != null) device.setOsVersion(osVersion);
		if(model != null) device.setModel(model);
		DeviceManager.save(device);
		
		response.get().setDevice(device.toDeviceType());
	}
	
	public static void getApplication(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		Customer customer = request.getCustomer();
		Device device = DeviceManager.getDevice(request.getParameter(Constants.Request.DEVICE_ID));
		DeviceApplication deviceApplication = DeviceManager.getDeviceApplication(device);
		
		/*
		 * Including the below can break device startup (tablet uses "viralogy" apiKey to get initial device application)
		 * 
		 * if(customer.getCustomerId() != deviceApplication.getApplication().getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_READ,ListUtil.from("application",customer.getApiKey()));
		}*/		
		
		response.get().setDeviceApplication(deviceApplication.toDeviceApplicationType());
	}
	
	public static void removeApplication(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		Customer customer = request.getCustomer();
		Device device = DeviceManager.getDevice(request.getParameter(Constants.Request.DEVICE_ID));
		DeviceApplication deviceApplication = DeviceManager.getDeviceApplication(device);
		
		if(customer.getCustomerId() != deviceApplication.getApplication().getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE,ListUtil.from("application",customer.getApiKey()));
		}
		
		DeviceManager.remove(deviceApplication);
	}
	
	public static void saveUnlinkedApplication(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		Customer customer = request.getCustomer();
		Address address = AddressManager.getAddress(request.getParameterLong(Constants.Request.ADDRESS_ID, true), false);
		Long checkinOptionId = request.getParameterLong(Constants.Request.CHECKIN_OPTION_ID, false);
		CheckinOption checkinOption = null;
		if(checkinOptionId != null) {
			checkinOption = CheckinOptionManager.getCheckinOption(checkinOptionId);
		}
		
		Application application = ApplicationDAO.getApplication(request.getParameterLong(Constants.Request.APPLICATION_ID, true));

		if(customer.getCustomerId() != application.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE,ListUtil.from("application",customer.getApiKey()));
		}
		if(customer.getCustomerId() != address.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_ADDRESS_FOR_CUSTOMER,ListUtil.from( address.getAddressId() + "",customer.getApiKey()));
		}
		
		UnlinkedDeviceApplication unlinkedDeviceApplication = new UnlinkedDeviceApplication();
		unlinkedDeviceApplication.setAddress(address);
		unlinkedDeviceApplication.setCheckinOption(checkinOption);
		unlinkedDeviceApplication.setApplication(application);

		DeviceManager.save(unlinkedDeviceApplication);

		response.get().setUnlinkedDeviceApplication(unlinkedDeviceApplication.toUnlinkedDeviceApplicationType());
	}
		
	
	public static void setUnlinkedApplication(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		Device device = request.getDevice();
		UnlinkedDeviceApplication unlinkedDeviceApplication = DeviceManager.getUnlinkedDeviceApplication(request.getParameterLong(Constants.Request.UNLINKED_DEVICE_APPLICATION_ID, true));
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, false);
		Address address = addressId == null ? null : AddressManager.getAddress(addressId, false);
		boolean removeOnSuccess = request.getParameterBool(Constants.Request.REMOVE_ON_SUCCESS, false);
		
		if(removeOnSuccess && unlinkedDeviceApplication.getUnlinkedDeviceApplicationId() == Constants.Demo.DEMO_UNLINKED_DEVICE_APPLICATION_ID) {
			logger.info("Overriding removeOnSuccess parameter and setting to false because this is the sample application");
			removeOnSuccess = false;
		}
		
		DeviceApplication previousDeviceApplication = null;
		try {
			previousDeviceApplication = DeviceManager.getDeviceApplication(device);
		}catch(InvalidParameterException e) {
			//no previous application set - this is fine
		}
		
		if(address != null) {
			//override the unlinkedDeviceApplication if the customer is still correct
			if(unlinkedDeviceApplication.getApplication().getCustomer().getCustomerId() != address.getCustomer().getCustomerId()) {
				throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_ADDRESS_FOR_CUSTOMER,ListUtil.from( address.getAddressId() + "",unlinkedDeviceApplication.getApplication().getCustomer().getApiKey()));
			}			
			unlinkedDeviceApplication.setAddress(address);
		}
		
		//create a new device application using the unlinked device application info and the previous deviceApplicationId if applicable
		DeviceApplication deviceApplication = DeviceManager.createDeviceApplication(device, previousDeviceApplication, unlinkedDeviceApplication, removeOnSuccess);
		
		//set the secret key
		DeviceApplicationType deviceApplicationType = deviceApplication.toDeviceApplicationType();
		CustomerType customerType = deviceApplicationType.getApplication().getCustomer();
		customerType.setSecretKey(deviceApplication.getApplication().getCustomer().getSecretKey());
		
		response.get().setDeviceApplication(deviceApplicationType);
	}		
	
	public static void setApplication(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		Device device = DeviceManager.getDevice(request.getParameter(Constants.Request.DEVICE_ID));
		Customer customer = request.getCustomer();
		Address address = AddressManager.getAddress(request.getParameterLong(Constants.Request.ADDRESS_ID, true), false);
		Long checkinOptionId = request.getParameterLong(Constants.Request.CHECKIN_OPTION_ID, false);
		CheckinOption checkinOption = null;
		if(checkinOptionId != null) {
			checkinOption = CheckinOptionManager.getCheckinOption(checkinOptionId);
		}
		
		Application application = ApplicationDAO.getApplication(request.getParameterLong(Constants.Request.APPLICATION_ID, true));

		if(customer.getCustomerId() != application.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE,ListUtil.from("application",customer.getApiKey()));
		}
		if(customer.getCustomerId() != address.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_ADDRESS_FOR_CUSTOMER,ListUtil.from( address.getAddressId() + "",customer.getApiKey()));
		}
		
		DeviceApplication deviceApplication = null;
		try {
			deviceApplication = DeviceManager.getDeviceApplication(device);
		}catch(InvalidParameterException e) {
			//not yet created
			deviceApplication = new DeviceApplication();
			deviceApplication.setDevice(device);
		}
		
		deviceApplication.setAddress(address);
		deviceApplication.setCheckinOption(checkinOption);
		deviceApplication.setApplication(application);

		DeviceManager.save(deviceApplication);

		response.get().setDeviceApplication(deviceApplication.toDeviceApplicationType());
	}
	
	public static void saveDeviceLink(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		String deviceId = request.getParameter(Constants.Request.DEVICE_ID);
		String otherDeviceId = request.getParameter(Constants.Request.OTHER_DEVICE_ID);
		Device device;
		Device otherDevice;
		Server server = ServerManager.getServer(request.getParameterLong(Constants.Request.SERVER_ID, true));

		try {
			otherDevice = DeviceManager.getDevice(otherDeviceId);
		}catch(InvalidParameterException e) {
			//create the device
			otherDevice = new Device(otherDeviceId);
			DeviceManager.save(otherDevice);
		}
		try {
			device = DeviceManager.getDevice(deviceId);
		}catch(InvalidParameterException e) {
			//create the device
			device = new Device(otherDeviceId);
			DeviceManager.save(device);
		}		
		
			
		DeviceLink deviceLink = null;
		try {
			//edit
			deviceLink = DeviceManager.getDeviceLink(device, otherDevice);
			deviceLink.setServer(server);
		}catch(InvalidParameterException e) {
			//create
			deviceLink = new DeviceLink(device, otherDevice, server);			
		}
		
		DeviceManager.save(deviceLink);
		
		response.get().setDeviceLink(deviceLink.toDeviceLinkType());
		
	}

	public static void removeDeviceLink(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Device device = DeviceManager.getDevice(request.getParameter(Constants.Request.DEVICE_ID));
		Device otherDevice = DeviceManager.getDevice(request.getParameter(Constants.Request.OTHER_DEVICE_ID));

		DeviceLink deviceLink = DeviceManager.getDeviceLink(device, otherDevice);	
		DeviceManager.remove(deviceLink);
				
	}
	
	public static void removeDeviceLinks(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Device device = DeviceManager.getDevice(request.getParameter(Constants.Request.DEVICE_ID));

		Set<DeviceLink> deviceLinks = DeviceManager.getDeviceLinks(device);
		for(DeviceLink deviceLink : deviceLinks) {
			DeviceManager.remove(deviceLink);
		}	
	}
	
	public static void getLinkedDevices(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Device device = DeviceManager.getDevice(request.getParameter(Constants.Request.DEVICE_ID));
		
		Set<DeviceLink> deviceLinks = DeviceManager.getDeviceLinks(device);
		
		response.get().setDeviceLinks(new DeviceLinksType());
		for(DeviceLink deviceLink : deviceLinks) {
			response.get().getDeviceLinks().getDeviceLink().add(deviceLink.toDeviceLinkType());
		}

	}
}
