package com.viralogy.rewardme.service;

import java.util.*;

import javax.xml.bind.DatatypeConverter;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.util.EmailUtil;
import com.viralogy.rewardme.util.ListUtil;

public class EmailService {
	
	private static Logger logger = Logger.getLogger(EmailService.class);

	public static void send(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		String email = request.getParameter(Constants.Request.EMAIL);
		String subject = request.getParameter(Constants.Request.SUBJECT);
		String body = request.getParameter(Constants.Request.BODY);

		try {						
			EmailUtil.email(request.getCustomer(), "no-reply", ListUtil.from(email), subject, body.getBytes(), "txt", null);
			
			logger.info("Email with subject " + subject + " sent to " + email + " successfully");
			
		} catch (FatalException e) {
			//oh bonkers
			logger.error("Error while trying to send email " + e.getMessage());	    			
		}
				
	}
	
	public static void sendSES(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		String sender = request.getParameter(Constants.Request.SENDER);
		String subject = request.getParameter(Constants.Request.SUBJECT);
		String recipientsString = request.getParameter(Constants.Request.EMAIL_RECIPIENTS);
		String bodyCode = request.getParameter(Constants.Request.BODY);
		String fileFormat = request.getParameter(Constants.Request.FILE_FORMAT);
		
		byte[] bytes = DatatypeConverter.parseBase64Binary(bodyCode);
		
		logger.debug("bodyCode is " + bodyCode);
		
		List<String> recipients = Arrays.asList(recipientsString.split(","));
		
		EmailUtil.email(customer, sender, recipients, subject, bytes, fileFormat, Constants.Prices.EMAIL);
		
	}
}
