package com.viralogy.rewardme.service;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.EventsType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.EventManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Event;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;

public abstract class EventService {

	private static Logger logger = Logger.getLogger(EventService.class);
	
	public static void log(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		String name = request.getParameter(Constants.Request.NAME);
		String value = request.getParameter(Constants.Request.VALUE);
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, false);
		Address address = null;
		if(addressId != null) {
			address = AddressManager.getAddress(addressId, false);
		}
		Boolean admin = request.getParameterBool(Constants.Request.VALUE, false);
		Boolean async = request.getParameterBool(Constants.Request.ASYNC, false);
		
		Event event = new Event(request.getCustomer(), request.getUser(), request.getDevice(), address, name, value, admin, null);

		if(!async) {
			EventManager.save(event);	
		}else {
			event.saveAsync();
		}

		response.get().setEvents(new EventsType());
		response.get().getEvents().getEvent().add(event.toEventType());
	}
}
