package com.viralogy.rewardme.service;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;

public abstract class ImportService {

	private static Logger logger = Logger.getLogger(ImportService.class);
	
	public static void fromData(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		String format = request.getParameter(Constants.Request.FORMAT);
		String data = request.getParameter(Constants.Request.DATA);
		

		
	}
	
}
