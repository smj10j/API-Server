package com.viralogy.rewardme.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.InventoryItemsType;
import com.viralogy.rewardme.manager.InventoryItemManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.InventoryItem;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.User;

public abstract class InventoryItemService {

	private static Logger logger = Logger.getLogger(InventoryItemService.class);
	
	public static void getInventoryItem(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		InventoryItem inventoryItem = null;
		String serial = request.getParameter(Constants.Request.SERIAL, false);
		
		inventoryItem = InventoryItemManager.getInventoryItem(serial);	

		response.get().setInventoryItems(new InventoryItemsType());
		response.get().getInventoryItems().getInventoryItem().add(inventoryItem.toInventoryItemType());
	}
	
	public static void getAllInventory(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		User user = request.getUser();
		String type = request.getParameter(Constants.Request.TYPE, false);

		List<InventoryItem> inventoryItems = InventoryItemManager.getInventoryItems(user, type);
		
		response.get().setInventoryItems(new InventoryItemsType());
		for(InventoryItem inventoryItem : inventoryItems) {
			response.get().getInventoryItems().getInventoryItem().add(inventoryItem.toInventoryItemType());			
		}
	}

	public static void saveInventory(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException{
		
		String serial = request.getParameter(Constants.Request.SERIAL, false);
		InventoryItemManager.removeInventoryItem(serial);

		InventoryItem inventoryItem = null;
		User user = request.getUser();
		Customer customer = request.getCustomer();
		Address address = request.getAddress();
		
		String type = request.getParameter(Constants.Request.TYPE, false);
		String description = request.getParameter(Constants.Request.DESCRIPTION, false);
		
		inventoryItem = new InventoryItem(serial, address, customer, user, type, description);

		InventoryItemManager.save(inventoryItem);
		
	}

	public static void removeInventory(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		String serial = request.getParameter(Constants.Request.SERIAL, false);

		InventoryItemManager.removeInventoryItem(serial);

		
	}
	
}