package com.viralogy.rewardme.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.manager.LotteryManager;
import com.viralogy.rewardme.manager.RewardManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Lottery;
import com.viralogy.rewardme.model.Reward;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.User;

public class LotteryService {
	
	private static Logger logger = Logger.getLogger(LotteryService.class);
	
	public static void getLotteryReward (RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException { 
		
		User user = request.getUser();
		Customer customer = request.getCustomer();
		Address address = request.getAddress();
		request.isAuthorized();	//sets the authorization status of the user
		List<Lottery> lotteries = LotteryManager.getAllLotteries(customer);
		
		Reward reward = LotteryManager.getLotteryReward(user, customer, lotteries);
		
		if (reward != null) {
			RewardManager.redeem(user, reward, address, request.getSession(), true);
			response.get().setReward(reward.toRewardType());
		}
	}
}
