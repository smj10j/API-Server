package com.viralogy.rewardme.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.POSTransactionsType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.DeviceManager;
import com.viralogy.rewardme.manager.POSManager;
import com.viralogy.rewardme.manager.PreferencesManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Device;
import com.viralogy.rewardme.model.DeviceApplication;
import com.viralogy.rewardme.model.Receipt;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserPreference;
import com.viralogy.rewardme.pos.Employee;
import com.viralogy.rewardme.pos.InventoryItem;
import com.viralogy.rewardme.pos.InventoryItemMod;
import com.viralogy.rewardme.pos.Transaction;
import com.viralogy.rewardme.pos.Transaction.PaymentMethod;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.StringUtil;

public class POSService {
	
	private static Logger logger = Logger.getLogger(POSService.class);
	
	public static void saveTransaction(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		User user = request.getUser();
		JSONObject jsonTransaction = request.getParameterJSONObject(Constants.Request.DATA, true);
		DeviceApplication deviceApplication = DeviceManager.getDeviceApplication(DeviceManager.getDevice(request.getParameter(Constants.Request.DEVICE_ID)));
		
		if(customer.getCustomerId() != deviceApplication.getApplication().getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_READ,ListUtil.from("deviceApplication",customer.getApiKey()));
		}
		
		try {
			String externalTxId = jsonTransaction.getString("externalTxId");
			Double amount = jsonTransaction.getDouble("amount");
			Double amountLessTax = jsonTransaction.getDouble("amountLessTax");
			Double amountLessTaxAndDiscount = jsonTransaction.getDouble("amountLessTaxAndDiscount");
			JSONArray jsonItems = jsonTransaction.getJSONArray("items");
			
			//TODO: POS: add discounts eventually
			
			JSONObject jsonEmployee = jsonTransaction.getJSONObject("employee");
			String externalEmployeeId = jsonEmployee.getString("externalEmployeeId");
			String employeeName = jsonEmployee.getString("name");
			
			Employee employee;
			try {
				employee = POSManager.getEmployee(customer, deviceApplication.getAddress(), externalEmployeeId);
			}catch(InvalidParameterException e) {
				//create the employee
				employee = new Employee(customer, deviceApplication.getAddress(), employeeName, externalEmployeeId);
				POSManager.save(employee);
			}
						
			//POSHero often sends the same externalTxId for different transaction, let's make a new one if that occurs
			try {
				POSManager.getTransaction(customer, deviceApplication.getAddress(), externalTxId);
				//if we reach this line the tx exists already, let's make a new tx id
				externalTxId+= "-" + StringUtil.getRandomNumber(10);
			}catch(InvalidParameterException e) {
				if(e.code == Constants.Error.INVALID_ID.EXTERNAL_TX_ID) {
					//new, unique transaction. this is the correct behavior					
				}else {
					logger.debug("error: " ,e);
					throw e;
				}
			}
			logger.debug("Creating transaction with externalTxId: " + externalTxId);
			
			Transaction transaction = new Transaction(
				user, 
				customer, 
				deviceApplication.getAddress(), 
				deviceApplication.getDevice(), 
				employee,
				externalTxId, 
				amount.floatValue(), 
				amountLessTax.floatValue(), 
				amountLessTaxAndDiscount.floatValue(),
				PaymentMethod.UNKNOWN
			);			
			
			for(int i = 0; i < jsonItems.length(); i++) {
				JSONObject jsonItem = jsonItems.getJSONObject(i);
				String externalItemId = jsonItem.getString("externalItemId");
				String itemName = jsonItem.getString("name");
				Double itemPrice = jsonItem.getDouble("price");
				Double itemCost = jsonItem.getDouble("cost");
				int inventoryItemCount = jsonItem.getInt("count");
				
				if(itemPrice >= 0) {
					//item
					InventoryItem inventoryItem;
					try {
						inventoryItem = POSManager.getInventoryItem(customer, externalItemId);
						if(	!inventoryItem.getName().equals(itemName) ||
							inventoryItem.getPrice() != itemPrice.floatValue() || 
							inventoryItem.getCost() != itemCost.floatValue() 
						) {
							//item has changed in some way - save the changes and create a history item
							inventoryItem.setName(itemName);
							inventoryItem.setCost(itemCost.floatValue());
							inventoryItem.setPrice(itemPrice.floatValue());
							POSManager.save(inventoryItem);		
							logger.debug("Updated inventoryItemId: " + inventoryItem.getPosInventoryItemId());
						}
					}catch(InvalidParameterException e) {
						//create the inventory item on the fly
						inventoryItem = new InventoryItem(customer, itemName, externalItemId, itemPrice.floatValue(), itemCost.floatValue());
						POSManager.save(inventoryItem);
						logger.debug("Added inventoryItemId: " + inventoryItem.getPosInventoryItemId());
					}
					
					inventoryItem.setCount(inventoryItemCount);
					transaction.addInventoryItem(inventoryItem);
					
					JSONArray jsonMods = jsonItem.getJSONArray("mods");
					for(int j = 0; j < jsonMods.length(); j++) {
						JSONObject jsonMod = jsonMods.getJSONObject(j);
						String externalModId = jsonMod.getString("externalModId");
						String modName = jsonMod.getString("name");
						Double modPrice = jsonMod.getDouble("price");
						Double modCost = jsonMod.getDouble("cost");
						int inventoryItemModCount = jsonMod.getInt("count");
						
						InventoryItemMod inventoryItemMod;
						try {
							inventoryItemMod = POSManager.getInventoryItemMod(customer, externalModId);
							if(	!inventoryItemMod.getName().equals(modName) ||
								inventoryItemMod.getPrice() != modPrice.floatValue() || 
								inventoryItemMod.getCost() != modCost.floatValue() 
							) {
								//item has changed in some way - save the changes and create a history item
								inventoryItemMod.setName(modName);
								inventoryItemMod.setCost(modCost.floatValue());
								inventoryItemMod.setPrice(modPrice.floatValue());
								POSManager.save(inventoryItemMod);						
								logger.debug("Updated inventoryItemModId: " + inventoryItemMod.getPosInventoryItemModId());
							}						
						}catch(InvalidParameterException e) {
							inventoryItemMod = new InventoryItemMod(customer, modName, externalModId, modPrice.floatValue(), modCost.floatValue());
							POSManager.save(inventoryItemMod);
							logger.debug("Added inventoryItemModId: " + inventoryItemMod.getPosInventoryItemModId());
						}
						
						inventoryItemMod.setCount(inventoryItemModCount);
						transaction.addInventoryItemMod(inventoryItem, inventoryItemMod);
					}		
				}else {
					//items that have prices < 0 are discounts in SOME POS system (cough. POSHero)
					//TODO: add discounts eventually			
				
				}
			}
			
			//we should now have a built up model of a transaction
			POSManager.save(request.getSession(), transaction, null);
			logger.debug("Added transactionId: " + transaction.getPosTxId());

			response.get().setPOSTransaction(transaction.toPOSTransactionType());
			
		} catch (JSONException e) {
			throw new InvalidParameterException(Constants.Error.GENERAL.INVALID_JSON, ListUtil.from(e.getMessage()));
		}
		
	}		
	
	public static void linkTransaction(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();
		Customer customer = request.getCustomer();
		Transaction transaction = POSManager.getTransaction(request.getParameterLong(Constants.Request.POS_TX_ID, true));
		DeviceApplication deviceApplication = DeviceManager.getDeviceApplication(DeviceManager.getDevice(request.getParameter(Constants.Request.DEVICE_ID)));
		
		if(customer.getCustomerId() != deviceApplication.getApplication().getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_READ,ListUtil.from("deviceApplication",customer.getApiKey()));
		}
		
		if(transaction.getDevice().getDeviceApplication().getDeviceApplicationId() != deviceApplication.getDeviceApplicationId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_DEVICE_APPLICATION_PERMISSIONS_READ,ListUtil.from("transaction",deviceApplication.getDeviceApplicationId()+""));			
		}
		
		if(transaction.getUser() != null) {
			throw new InvalidParameterException(Constants.Error.POS.TRANSACTION_ALREADY_LINKED, ListUtil.from(transaction.getUser().getUserId()+"", transaction.getPosTxId()+""));
		}
		
		transaction.setUser(user);
		POSManager.save(request.getSession(), transaction, null);
		
		response.get().setPOSTransaction(transaction.toPOSTransactionType());
	}
	
	public static void saveReceipt(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		User user = request.getUser();
		Customer customer = request.getCustomer();
		Address address = AddressManager.getAddress(request.getParameterLong(Constants.Request.ADDRESS_ID, true), false);
		Device device = DeviceManager.getDevice(request.getParameter(Constants.Request.DEVICE_ID));
		String data = request.getParameter(Constants.Request.DATA);

		/*
		//DeviceApplication deviceApplication = DeviceManager.getDeviceApplication(DeviceManager.getDevice(request.getParameter(Constants.Request.DEVICE_ID)));
		if(customer.getCustomerId() != deviceApplication.getApplication().getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_READ,ListUtil.from("deviceApplication",customer.getApiKey()));
		}*/
		
		Receipt receipt = new Receipt(user, customer, device, address, data);
		logger.debug("Receipt: \n" + receipt.toString());
		
		//save the transaction
		if(receipt.getTotal() != 0) {
			Transaction transaction = receipt.toTransaction();
			
			try {
				transaction = POSManager.getTransaction(customer, address, transaction.getExternalPosTxId());
				//transaction already exists - just return the info
				logger.debug("Transaction already exists for that customer, address, externalTxId - returning the transaction");
				
			}catch(InvalidParameterException ipe) {
				
				//transaction does not already exist - save it!
				logger.debug("About to save new transaction");
				
				//save the user name preference if not already set
				if(user != null && !StringUtil.isNullOrEmpty(receipt.getUserName())) {
					UserPreference userPreference = user.getUserPreference(Constants.UserPreference.NAME, null);
					if(userPreference == null || StringUtil.isNullOrEmpty(userPreference.getValue())) {
						userPreference = new UserPreference(user, null, Constants.UserPreference.NAME, receipt.getUserName());
						PreferencesManager.save(userPreference);
					}
				}
	
				//we should now have a built up model of a transaction
				try {
					POSManager.save(request.getSession(), transaction, receipt);
					logger.debug("Added transactionId: " + transaction.getPosTxId());
				}catch(Exception e) {
					//we're failing silently because these transactions were duplicate when checked
					//this occurs because some location print receipts in duplicates or even triplicates
					//and this behavior is not yet handled for by our Printer software
					e.printStackTrace();
					logger.error("Failed to save transaction but still continuing: " + e.getMessage());				
				}
			}
		}else {
			logger.warn("Not saving transaction because total is 0.00");
		}
		
		response.get().setReceipt(receipt.toReceiptType());
	}

	public static void getTransactions(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		User user = request.getUser();
		Customer customer = request.getCustomer();
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, false);
		Address address = addressId == null ? null : AddressManager.getAddress(addressId, false);

		List<Transaction> transactions = POSManager.getTransactions(customer, address, user);
		
		response.get().setPOSTransactions(new POSTransactionsType());
		for(Transaction transaction : transactions) {
			response.get().getPOSTransactions().getPOSTransaction().add(transaction.toPOSTransactionType());
		}
	}
}
