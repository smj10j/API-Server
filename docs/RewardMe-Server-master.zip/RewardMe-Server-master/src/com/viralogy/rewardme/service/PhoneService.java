package com.viralogy.rewardme.service;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.Constants.NotificationType;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.customer.CustomerConstants;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.MessageManager;
import com.viralogy.rewardme.manager.PhoneManager;
import com.viralogy.rewardme.manager.PointsManager;
import com.viralogy.rewardme.manager.PreferencesManager;
import com.viralogy.rewardme.manager.SurveyManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerBroadcastMessage;
import com.viralogy.rewardme.model.PointCategory;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserMessage;
import com.viralogy.rewardme.model.UserPoints;
import com.viralogy.rewardme.model.UserPreference;
import com.viralogy.rewardme.model.UserSurvey;
import com.viralogy.rewardme.servlet.GatewayServlet;
import com.viralogy.rewardme.util.EmailUtil;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.StringUtil;
import com.viralogy.rewardme.util.TwilioUtil;

public class PhoneService {
	
	private static Logger logger = Logger.getLogger(PhoneService.class);
	
	private static final Set<String> YES_WORDS = new HashSet<String>();
	static {
		YES_WORDS.add("Y");
		YES_WORDS.add("YES");
		YES_WORDS.add("YES!");
		YES_WORDS.add("YEAH");
		YES_WORDS.add("YEA");
		YES_WORDS.add("OK");
		YES_WORDS.add("OKAY");
	}
	
	private static final Set<String> BALANCE_WORDS = new HashSet<String>();
	static {
		BALANCE_WORDS.add("BAL");
		BALANCE_WORDS.add("BALANCE");
		BALANCE_WORDS.add("POINTS");
	}	
	
	private static final Set<String> STOP_WORDS = new HashSet<String>();
	static {
		STOP_WORDS.add("STOP");
		STOP_WORDS.add("STOP ALL");
	}	
	
	private static final Set<String> HELP_WORDS = new HashSet<String>();
	static {
		HELP_WORDS.add("HELP");
	}		
	
	private static final Set<String> FORGOT_PIN_WORDS = new HashSet<String>();
	static {
		FORGOT_PIN_WORDS.add("FORGOT");
	}			
	
	public static void checkIfMobile(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		String phoneNumber = request.getParameter(Constants.Request.PHONE_NUMBER);
		phoneNumber = TwilioUtil.cleanNumber(phoneNumber);
		
		boolean isMobile = PhoneManager.isMobile(phoneNumber);
		response.get().setMessage(isMobile ? "true" : "false");
	}

	//called when we get a new text message - happens when a user responds to our text
	public static void receiveSMS(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
				
		//indicate we don't want to output a result from this API
		response.disableOutput();
		
		String to = request.getParameter(TwilioUtil.TWILIO_TO);
		String from = request.getParameter(TwilioUtil.TWILIO_FROM);
		String body = request.getParameter(TwilioUtil.TWILIO_BODY);
		Customer customer = null;

		if(from == null || to == null || body == null) {
			//invalid requests - probably not from Twilio
			return;
		}

		logger.info("Received an SMS from=" + from + ", body=" + body + ", to=" + to);
		
		body = body.trim();
		from = TwilioUtil.cleanNumber(from);			
		
		User user = null;
		boolean isNewUser = false;
		try {
			user = UserManager.getUserByPhoneNumber(from);
		}catch(InvalidParameterException e) {
			//user doesn't exist - create
			user = new User();
			user.setPhoneNumber(from);
			UserManager.save(user);
			isNewUser = true;
		}
		
		//see if the first word of the message is an apikey
		String[] words = body.split(" ");
		if(words != null && words.length == 2) {
			try {
				customer = CustomerManager.getCustomer(words[0].toLowerCase());
				body = body.replace(words[0] + " ", "").trim();
			}catch(InvalidParameterException e) {
				//nope
			}
		}
		
		if(customer == null) {
			UserMessage lastUserMessage = MessageManager.getLastUserMessage(user);
			CustomerBroadcastMessage lastCustomerBroadcastMessage = MessageManager.getLastCustomerBroadcastMessage(user);
			if(lastUserMessage != null && lastCustomerBroadcastMessage != null) {
				//use the latest
				if(lastUserMessage.getTimestamp().after(lastCustomerBroadcastMessage.getTimestamp())) {
					customer = lastUserMessage.getCustomer();
				}else {
					customer = lastCustomerBroadcastMessage.getCustomer();
				}
			}else if(lastCustomerBroadcastMessage != null) {
				customer = lastCustomerBroadcastMessage.getCustomer();
			}else if(lastUserMessage != null) {
				customer = lastUserMessage.getCustomer();
			}else {
				customer = CustomerManager.getCustomer("viralogy");
			}
		}
		
		UserPreference userPreferenceOptInInitiated = user.getUserPreference(Constants.UserPreference.NOTIFICATION_TEXT_OPT_IN_INITIATED, customer);
		boolean optInInitiated = userPreferenceOptInInitiated != null && userPreferenceOptInInitiated.getValue().equals(Constants.YES);
		
		
		
		
		if(STOP_WORDS.contains(body.toUpperCase())) {
			//turn off all notifications to this user
						
			UserPreference userPreference = user.getUserPreference(Constants.UserPreference.NOTIFICATION_TEXT_ALL, customer);
			if(userPreference == null) {
				userPreference = new UserPreference(user, customer, Constants.UserPreference.NOTIFICATION_TEXT_ALL, Constants.NO);
			}else {
				userPreference.setValue(Constants.NO);
			}
			PreferencesManager.save(userPreference);
			
			String allNotificationsOff = "Notifications for " + customer.getName() + " have been turned off.\n" +
					(customer.is(CustomerConstants.LE_BOULANGER) ? "" : "Manage notifications on "+Constants.URL.MY_REWARDME);
			UserMessage userMessage = new UserMessage(customer, user, new Date(), allNotificationsOff);
			MessageManager.send(userMessage, NotificationType.TEXT_SYSTEM, true);
			return;
		}else if(HELP_WORDS.contains(body.toUpperCase())) {
			PhoneManager.sendMenu(user, customer, false);
			return;
		}else if(BALANCE_WORDS.contains(body.toUpperCase())) {
			PointCategory pointCategory = PointsManager.getDefaultPointCategory(customer);
			UserPoints userPoints = user.getPoints(customer, pointCategory);
			String balanceMessage = 
					customer.getName() + " Rewards\n" + 
					"You currently have " + userPoints.getCurrentBalance() + " points.\n" + 
					(customer.is(CustomerConstants.LE_BOULANGER) ? "" : "Manage your account on "+customer.getWebsiteUrl())+"\n" 
					;
				UserMessage userMessage = new UserMessage(customer, user, new Date(), balanceMessage);
				MessageManager.send(userMessage, NotificationType.TEXT_SYSTEM, true);			
			return;
		}else if(FORGOT_PIN_WORDS.contains(body.toUpperCase())) {
			UserManager.resetPIN(user, customer);
			return;
		}else if(YES_WORDS.contains(body.toUpperCase()) && optInInitiated) {
			//user has started the opt-in process
			
			//user has started opt-in process
			UserPreference userPreference = user.getUserPreference(Constants.UserPreference.NOTIFICATION_TEXT_ALL, customer);
			if(userPreference == null) {
				userPreference = new UserPreference(user, customer, Constants.UserPreference.NOTIFICATION_TEXT_ALL, Constants.YES);
			}else {
				if(userPreference.getValue().equals(Constants.YES)) {
					//already enabled
					String confirmationMessage = 
							customer.getName() + " Rewards\n" + 
							"You're already part of the text club.\n" + 
							(customer.is(CustomerConstants.LE_BOULANGER) ? "" : "Manage notifications on "+customer.getWebsiteUrl()) 
							;
						UserMessage userMessage = new UserMessage(customer, user, new Date(), confirmationMessage);
						MessageManager.send(userMessage, NotificationType.TEXT_SYSTEM, true);							
					return;
				}
				userPreference.setValue(Constants.YES);
			}
			PreferencesManager.save(userPreference);
			
			//completed double opt-in
			String confirmationMessage = 
				"Welcome to " + customer.getName() + " Rewards!\n" + 
				(customer.is(CustomerConstants.LE_BOULANGER) ? "" : "Manage notifications on "+customer.getWebsiteUrl())+"\n" + 
				"Reply HELP for help, STOP to cancel. 4 msgs/mo"
				;
			UserMessage userMessage = new UserMessage(customer, user, new Date(), confirmationMessage);
			MessageManager.send(userMessage, NotificationType.TEXT_SYSTEM, true);					

			return;
		}
		
		//now see if the message is for one of our customers signup processes
		try {
			Customer customerInText = CustomerManager.getCustomer(body.toLowerCase());
			UserManager.startTextMessageOptIn(user, customerInText);
			return;
		}catch(InvalidParameterException e) {
			//nope
		}
		
		
		//set the users response and respond to them with results if necessary
		UserSurvey userSurvey = SurveyManager.getLatestUserSurvey(user);
		if(userSurvey != null && StringUtil.isNullOrEmpty(userSurvey.getResponse())) {
			
			String surveyResponse = userSurvey.getSurvey().getFullResponse(body);	
			
			//set the users response and respond to them with results if necessary
			SurveyManager.respond(userSurvey, surveyResponse);
			
			return;
		}
		
		
		
		
		//we weren't expecting this text message... text back a menu
		PhoneManager.sendMenu(user, customer, true);
		logger.warn("Unexpected text message: " + body);
		//email a notice to admins			
		try {
			String emailSubject = "Unexpected text message on RewardMe ("+GatewayServlet.getHostname()+")";
			String emailBody = "Unexpected text message: " + body + "\n" + 
							   "Sender: " + from + "\n" + 
							   "Last Message from: " + (customer == null ? "none" : customer.getName());

			EmailUtil.email(null, "warn-notifier", ListUtil.from(EmailUtil.getInternalAdminEmail()), emailSubject, emailBody.getBytes(), "txt", null);
			
		} catch (FatalException e) {
			//oh bonkers
			logger.error("Error while trying to email admins about unexpected text message!", e);	    			
		}
		
	}
	
	//called when the status of a sent text message changes
	public static void sendSMSCallback(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		String status = request.getParameter(TwilioUtil.TWILIO_SMS_STATUS);
		String smsSid = request.getParameter(TwilioUtil.TWILIO_SMS_SID);

		//Cache.put(status, smsSid, Cache.namespace.SMS_VALIDATION_STATUS_BY_SID);
		
		if(status.equalsIgnoreCase("sent")) {
			logger.info("Text message with smsSid=" + smsSid + " sent successfully");
		}else {
			logger.info("Text message with smsSid=" + smsSid + " send failed!");
		}
		
	}
}
