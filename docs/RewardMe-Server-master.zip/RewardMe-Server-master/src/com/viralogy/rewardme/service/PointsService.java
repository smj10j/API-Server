package com.viralogy.rewardme.service;

import java.util.Date;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.PointsManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.PointCategory;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserPoints;
import com.viralogy.rewardme.model.UserPoints.Type;
import com.viralogy.rewardme.util.Cache;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.StringUtil;

public abstract class PointsService {
	
	private static Logger logger = Logger.getLogger(PointsService.class);
	
	public static void credit(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();	
		Customer customer = request.getCustomer();
		Type type = request.getParameterType(Constants.Request.TYPE, Type.class, true);
		Address address = null;
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, false);
		if(addressId != null) {
			address = AddressManager.getAddress(addressId, false);
		}
		long amount = request.getParameterInt(Constants.Request.AMOUNT, true);
		
		PointCategory pointCategory = null;
		String pointCategoryName = request.getParameter(Constants.Request.POINT_CATEGORY);
		if(!StringUtil.isNullOrEmpty(pointCategoryName)) {
			pointCategory = PointsManager.getPointCategory(customer, pointCategoryName);
		}else {
			pointCategory = PointsManager.getDefaultPointCategory(customer);
		}
		
		//only one TRANSFER is allowed per account 
		if(type.equals(Type.TRANSFER)) {
			UserPoints userPoints = PointsManager.getUserPoints(user, customer, type, pointCategory, null);
			if(userPoints.getEarnedBalance() != 0) {
				throw new InvalidParameterException(Constants.Error.POINTS.ONLY_ONE_TRANSFER_PER_ACCOUNT_ALLOWED, ListUtil.from(userPoints.getEarnedBalance()+""));
			}
		}
		
		PointsManager.credit(user, customer, address, type, pointCategory, amount);
	}
	
	public static void debit(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();	
		Customer customer = request.getCustomer();
		Type type = request.getParameterType(Constants.Request.TYPE, Type.class, true);
		Address address = null;
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, false);
		if(addressId != null) {
			address = AddressManager.getAddress(addressId, false);
		}		
		long amount = request.getParameterInt(Constants.Request.AMOUNT, true);

		PointCategory pointCategory = null;
		String pointCategoryName = request.getParameter(Constants.Request.POINT_CATEGORY);
		if(!StringUtil.isNullOrEmpty(pointCategoryName)) {
			pointCategory = PointsManager.getPointCategory(customer, pointCategoryName);
		}else {
			pointCategory = PointsManager.getDefaultPointCategory(customer);
		}
		
		PointsManager.debit(user, customer, address, type, pointCategory, amount);
	}
	
	public static void getPoints(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();	
		Customer customer = request.getCustomer();
		request.isAuthorized();	//sets the authorization status of the user
		Date startDate = request.getParameterDate(Constants.Request.START_DATE, false);
		Long secondsAgo = request.getParameterLong(Constants.Request.SECONDS_AGO, false);
		if(secondsAgo != null && startDate != null) {
			throw new InvalidParameterException("secondsAgo and startDate are exclusive - please provide one or the other");
		}
		if(startDate != null) {
			secondsAgo = (System.currentTimeMillis() - startDate.getTime())/1000l;
			if(Math.abs(secondsAgo) < 5) {
				//if we're dealing with really small values here - optimize
				secondsAgo = null;
			}
		}
		
		PointCategory pointCategory = null;
		String pointCategoryName = request.getParameter(Constants.Request.POINT_CATEGORY);
		if(!StringUtil.isNullOrEmpty(pointCategoryName)) {
			pointCategory = PointsManager.getPointCategory(customer, pointCategoryName);
		}else {
			pointCategory = PointsManager.getDefaultPointCategory(customer);
		}
		
		//get all the user's addresses 		
		response.get().setUser(user.toUserType(customer, pointCategory));
	}	
}
