package com.viralogy.rewardme.service;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.CustomerPreferencesType;
import com.viralogy.rewardme.jaxb.UserPreferencesType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.PreferencesManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerPreference;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserPreference;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.StringUtil;

public abstract class PreferencesService {
	
	private static Logger logger = Logger.getLogger(PreferencesService.class);

	public static void saveUserPreference(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		User user = request.getUser();	
		String name = request.getParameter(Constants.Request.NAME);
		String value = request.getParameter(Constants.Request.VALUE);
		boolean isPrivate = request.getParameterBool(Constants.Request.PRIVATE, false);
		
		UserPreference userPreference = user.getUserPreference(name, isPrivate ? customer : null);
		if(userPreference == null) {
			userPreference = new UserPreference(user, isPrivate ? customer : null, name, value);
			PreferencesManager.save(userPreference);
		}else {
			if(isPrivate && customer.getCustomerId() != userPreference.getCustomer().getCustomerId()) {
				throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE,ListUtil.from("userPreference",customer.getApiKey()));
			}
			
			userPreference.setValue(value);
			if(isPrivate) {
				userPreference.setCustomer(customer);
			}else {
				userPreference.setCustomer(null);
			}
			
			if(StringUtil.isNullOrEmpty(value)) {
				PreferencesManager.remove(userPreference);
			}else {
				PreferencesManager.save(userPreference);
			}
		}
	}
	
	public static void getUserPreference(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		User user = request.getUser();	
		String name = request.getParameter(Constants.Request.NAME);
		boolean isPrivate = request.getParameterBool(Constants.Request.PRIVATE, false);
		
		UserPreference userPreference = user.getUserPreference(name, isPrivate ? customer : null);
		if(userPreference == null) {
			throw new InvalidParameterException(Constants.Error.GENERAL.INVALID_USER_PREFERENCE_NAME,ListUtil.from(name));
		}
		response.get().setUserPreference(userPreference.toUserPreferenceType());
	}
	
	public static void getUserPreferences(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		User user = request.getUser();	
		boolean isPrivate = request.getParameterBool(Constants.Request.PRIVATE, false);
		
		response.get().setUserPreferences(new UserPreferencesType());
		for(UserPreference userPreference : user.getUserPreferences(isPrivate ? customer : null).values()) {
			response.get().getUserPreferences().getPreference().add(userPreference.toUserPreferenceType());
		}
		
	}
	
	public static void saveCustomerPreference(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		String name = request.getParameter(Constants.Request.NAME);
		String value = request.getParameter(Constants.Request.VALUE);
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, false);
		Address address = addressId == null ? null : AddressManager.getAddress(addressId, false);
		
		if( address != null && address.getCustomer().getCustomerId() != customer.getCustomerId() ) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_ADDRESS_FOR_CUSTOMER, ListUtil.from(address.getAddressId() + "", customer.getCustomerId() + ""));
		}
		
		CustomerPreference customerPreference = customer.getCustomerPreference(name, address);
		if(customerPreference == null ) {
			customerPreference = new CustomerPreference(customer, address, name, value);
			PreferencesManager.save(customerPreference);
		} else {
			customerPreference.setValue(value);
			
			if(StringUtil.isNullOrEmpty(value)) {
				PreferencesManager.remove(customerPreference);
			} else {
				PreferencesManager.save(customerPreference);
			}
		}
	}
	
	public static void getCustomerPreference(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		String name = request.getParameter(Constants.Request.NAME);
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, false);
		Address address = addressId == null ? null : AddressManager.getAddress(addressId, false);
		
		CustomerPreference customerPreference = customer.getCustomerPreference(name, address);
		if( customerPreference == null ) {
			throw new InvalidParameterException( Constants.Error.GENERAL.INVALID_CUSTOMER_PREFERENCE_NAME, ListUtil.from(name));
		} 
		response.get().setCustomerPreference(customerPreference.toCustomerPreferenceType());
	}
	
	public static void getCustomerPreferences(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, false);
		Address address = addressId == null ? null : AddressManager.getAddress(addressId, false);
		
		response.get().setCustomerPreferences(new CustomerPreferencesType());
		for(CustomerPreference customerPreference : customer.getCustomerPreferences(address).values()) {
			response.get().getCustomerPreferences().getPreference().add(customerPreference.toCustomerPreferenceType());
		}
		
	}
}
