package com.viralogy.rewardme.service;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.PrinterDataType;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.util.FileUtil;
import com.viralogy.rewardme.util.JSONUtil;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.ShellUtil;
import com.viralogy.rewardme.util.StringUtil;

public class PrinterService {
	
	private static Logger logger = Logger.getLogger(PrinterService.class);
	
	private static final float MM_PER_PT = 0.352777777778f; 
	private static final float PT_PER_MM = 1/MM_PER_PT; 

	public static void convertToPostscript(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		String html = request.getParameter(Constants.Request.HTML);
		JSONObject userOptions = request.getParameterJSONObject(Constants.Request.OPTIONS, true);
		String defaultOptions = "--no-numbered --no-title --no-toc --no-strict --pscommands --embedfonts --continuous";

		//parse the user options
		List<String> validUserOptions = ListUtil.from(
				"--size", 
				"--top", 
				"--bottom",
				"--left",
				"--right");
		
		int width = 240;								//80mm
		int height = 650;								//offset from bottom
		int widthOffset = (int) (208.8 * PT_PER_MM);	//209mm or 8.25 inches
		int heightOffset = (int) (277.8 * PT_PER_MM);	//278mm or 11 inches
		
		StringBuilder userOptionsString = new StringBuilder();
		Iterator<?> keys = userOptions.keys();
		while(keys.hasNext()) {
			String key = (String) keys.next();
			if(validUserOptions.contains(key)) {
				//valid key, see if there is a value
				String value = JSONUtil.getSafe(userOptions, key);				
				if(!StringUtil.isNullOrEmpty(value)) {
					
					//sanitize
					value = value.replaceAll("[><|&;]", "");
					
					if(key.equals("--size")) {
						//split it up
						String[] wh = value.split("x");
						if(wh[0].contains("mm")) {
							int w = Integer.valueOf(wh[0].replace("mm", ""));
							int h = Integer.valueOf(wh[1].replace("mm", ""));
							
							width = widthOffset - (int)(w*PT_PER_MM);
							height = heightOffset - (int)(h*PT_PER_MM);
						}
					}
					
					//only allow short values as an added precaution
					if(value.length() <= 10) {
						userOptionsString.append(key).append(" ").append(value).append(" ");
					}else {
						logger.warn("Invalid user option value=" + value + " for key=" + key + " - skipping");
					}
				}else {
					userOptionsString.append(key).append(" ");
				}
			}else {
				logger.warn("Invalid user option key=" + key + " - skipping");
			}
		}

		
		File inputTempFile = FileUtil.writeTempFile(html, "htmldoc-", ".html");
		logger.debug("Created input temp file at " + inputTempFile.getAbsolutePath());
		
		
		try {
			
			StringBuilder postscript = new StringBuilder();
			
			String cmd = "htmldoc -t ps3 " +
						defaultOptions + " " +
						userOptionsString.toString() + " " +
						inputTempFile.getAbsolutePath();				
			logger.debug("Executing cmd: " + cmd);
			List<String> output = ShellUtil.exec(cmd, ListUtil.from(""));
			String lastLine = null;
			for(String line : output) {
				//logger.debug("Got line: " + line);
				if(line.contains(" SF 0 0 M(")) {
					//this is a page title - remove it
					continue;
				}else if(line.contains("M(1)S")) {
					//this is a page number - remove it
					continue;
				}else if(line.equals("GR")) {
					//at the end of the content- add in our own
					
					//Format: {fontHeight} FS/F{fontWeight} SF {leftOffset} {bottomOffset} M({text})S
					postscript.append("11 FS/F4 SF 0 " + height + " M(http://"+Constants.URL.MY_REWARDME+")S").append("\n");
					
				}
				postscript.append(line).append("\n");
				lastLine = line;
			}
			
			
						
			//we encode the postscript before sending it (so it ends up double encoded) because
			//it can be a several-hundred KB file and the client is likely just passing along the
			//postscript somewhere else - our work saves them work
			String encodedPostscript = null;
			try {
				encodedPostscript = URLEncoder.encode(postscript.toString(), "UTF-8");
			} catch (UnsupportedEncodingException e) {
				throw new FatalException(e);
			}
			
			PrinterDataType printerDataType = new PrinterDataType();
			printerDataType.setEncodedPostscript(encodedPostscript);
			printerDataType.setText(html);
			response.get().setPrinterData(printerDataType);
			
		} finally {
			//remove the temp file once we're all done
			logger.debug("Deleting input temp file at " + inputTempFile.getAbsolutePath());
			inputTempFile.delete();
		}
	}
	
}
