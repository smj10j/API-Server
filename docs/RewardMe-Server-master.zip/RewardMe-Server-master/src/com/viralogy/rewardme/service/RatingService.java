package com.viralogy.rewardme.service;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.manager.POSManager;
import com.viralogy.rewardme.manager.RatingManager;
import com.viralogy.rewardme.model.Rating;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.pos.Transaction;
import com.viralogy.rewardme.util.ListUtil;

public abstract class RatingService {
	
	
	public static void save(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException{
		Long posTxId = request.getParameterLong(Constants.Request.POS_TX_ID, true);
		Long score = request.getParameterLong(Constants.Request.SCORE, true);
		String data = request.getParameter(Constants.Request.DATA, false);
		
		Transaction transaction = POSManager.getTransaction(posTxId);
		if(score < 1 || score > 5) {
			throw new InvalidParameterException(Constants.Error.RATING.INVALID_SCORE, ListUtil.from(score + ""));
		}
		
		Rating rating = new Rating(transaction, score, data);
		
		RatingManager.save(rating);
		
		response.get().setRating(rating.toRatingType());
	}
}
