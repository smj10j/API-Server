package com.viralogy.rewardme.service;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.UserReferralRequestsType;
import com.viralogy.rewardme.manager.MessageManager;
import com.viralogy.rewardme.manager.ReferralManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserMessage;
import com.viralogy.rewardme.model.UserPreference;
import com.viralogy.rewardme.model.UserReferral;
import com.viralogy.rewardme.model.UserReferralRequest;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.StringUtil;

public abstract class ReferralService {
	
	private static Logger logger = Logger.getLogger(ReferralService.class);

	
	public static void create(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();
		Customer customer = request.getCustomer();
		String referredPhoneNumber = request.getParameter(Constants.Request.REFERRED_PHONE_NUMBER);
		User recipient = UserManager.getUserByPhoneNumber(referredPhoneNumber);
		
		//save the referral request
		UserReferralRequest userReferralRequest = ReferralManager.createUserReferralRequest(user, recipient, customer);
	
		response.get().setReferralRequest(userReferralRequest.toUserReferralRequestType());
	}
	
	
	public static void accept(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();
		long userReferralRequestId = request.getParameterLong(Constants.Request.USER_REFERRAL_REQUEST_ID, true);

		UserReferralRequest userReferralRequest = ReferralManager.getUserReferralRequest(userReferralRequestId);
		if(userReferralRequest.getReferred() != null && user.getUserId() != userReferralRequest.getReferred().getUserId()) {
			//this is a specific device referral and the users don't match up
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.CANNOT_RESPOND_TO_SOMEONE_ELSES_REFERRAL, ListUtil.from(userReferralRequestId+"", userReferralRequest.getReferred().getUserId()+""));
		}else if(user.getPhoneNumber() != null && userReferralRequest.getReferredPhoneNumber() != null && 
				!user.getPhoneNumber().equals(userReferralRequest.getReferredPhoneNumber())) {
			//this is a phone number referral and the users don't match up
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.CANNOT_RESPOND_TO_SOMEONE_ELSES_REFERRAL, ListUtil.from(userReferralRequestId+"", userReferralRequest.getReferred().getUserId()+""));
		}else if (userReferralRequest.getReferred() == null && !StringUtil.isNullOrEmpty(userReferralRequest.getReferredPhoneNumber()) && StringUtil.isNullOrEmpty(user.getPhoneNumber())){
			//this is a phone number referral and the user doesn't have a phone number
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.CANNOT_RESPOND_TO_SOMEONE_ELSES_REFERRAL, ListUtil.from(userReferralRequestId+"", userReferralRequest.getReferred().getUserId()+""));			
		}
				
		//alright!
		//since this user is accepting a request, that means it was either from a push notification or a text message (not an instant request)
		//if it was a text message, we should be able to tie the phone number to this user if it doesn't exist yet	
		if(!StringUtil.isNullOrEmpty(userReferralRequest.getReferredPhoneNumber())) {
			user.setPhoneNumber(userReferralRequest.getReferredPhoneNumber());
		}

		if(userReferralRequest.getReferrer() != null && user != null) {
			UserReferral userReferral = ReferralManager.createUserReferral(
					userReferralRequest.getReferrer(), 
					user, 
					userReferralRequest.getCustomer()
			);
			
			//send a notification to the referrer
			UserPreference namePreference = user.getUserPreference(UserPreference.KEYS.NAME, null);
			String name = namePreference == null ? "Your friend" : namePreference.getValue();
			MessageManager.save(
				new UserMessage(
					userReferralRequest.getCustomer(), 
					userReferralRequest.getReferrer(),
					new Date(),
					name + " has accepted your referral to " + userReferral.getCustomer().getName()
				)
			);
						
			response.get().setReferral(userReferral.toUserReferralType());
		}
	}

	public static void reject(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();
		long userReferralRequestId = request.getParameterLong(Constants.Request.USER_REFERRAL_REQUEST_ID, true);

		UserReferralRequest userReferralRequest = ReferralManager.getUserReferralRequest(userReferralRequestId);
		if(userReferralRequest.getReferred() != null && user.getUserId() != userReferralRequest.getReferred().getUserId()) {
			//this is a specific device referral and the users dont' match up
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.CANNOT_RESPOND_TO_SOMEONE_ELSES_REFERRAL, ListUtil.from(userReferralRequestId+"", userReferralRequest.getReferred().getUserId()+""));
		}else if(user.getPhoneNumber() != null && userReferralRequest.getReferredPhoneNumber() != null && 
				!user.getPhoneNumber().equals(userReferralRequest.getReferredPhoneNumber())) {
			//this is a phone number referral and the users dont' match up
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.CANNOT_RESPOND_TO_SOMEONE_ELSES_REFERRAL, ListUtil.from(userReferralRequestId+"", userReferralRequest.getReferred().getUserId()+""));
		}else if (userReferralRequest.getReferred() == null && !StringUtil.isNullOrEmpty(userReferralRequest.getReferredPhoneNumber()) && StringUtil.isNullOrEmpty(user.getPhoneNumber())){
			//this is a phone number referral and the user doesn't have a phone number
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.CANNOT_RESPOND_TO_SOMEONE_ELSES_REFERRAL, ListUtil.from(userReferralRequestId+"", userReferralRequest.getReferred().getUserId()+""));			
		}

		if(userReferralRequest.getReferred() == null) {
			userReferralRequest.setReferred(user);
		}
		
		if(userReferralRequest.getReferrer() != null) {
			ReferralManager.archiveUserReferralRequest(userReferralRequest);
		
			//send a notification to the referrer
			UserPreference namePreference = user.getUserPreference(UserPreference.KEYS.NAME, null);
			String name = namePreference == null ? "Your friend" : namePreference.getValue();
			MessageManager.save(
				new UserMessage(
					userReferralRequest.getCustomer(), 
					userReferralRequest.getReferrer(),
					new Date(),
					name + " has rejected your referral to " + userReferralRequest.getCustomer().getName()
				)
			);
		}
	}	
	
	public static void getRequests(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();
		int returnCount = request.getParameterInt(Constants.Request.RETURN_COUNT,false);

		List<UserReferralRequest> userReferralRequests = ReferralManager.getUserReferralRequests(user, returnCount);
		
		//we do this instead of adding it to the user object because we don't want to bloat that object in memcache
		if(response.get().getUser() == null) {
			response.get().setUser(user.toUserType(null));
		}
		response.get().getUser().setReferralRequests(new UserReferralRequestsType());
		for(UserReferralRequest userReferralRequest : userReferralRequests) {
			response.get().getUser().getReferralRequests().getUserReferralRequest().add(userReferralRequest.toUserReferralRequestType());
		}
	}
	
}
