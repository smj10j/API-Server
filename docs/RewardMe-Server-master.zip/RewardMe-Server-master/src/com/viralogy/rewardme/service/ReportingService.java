package com.viralogy.rewardme.service;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.GeneratedReportType;
import com.viralogy.rewardme.jaxb.ReportsType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.ReportingManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Report;
import com.viralogy.rewardme.model.Report.PeriodType;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.util.ListUtil;

public abstract class ReportingService {

	private static Logger logger = Logger.getLogger(ReportingService.class);

	public static void saveReport(RewardMeRequest request,
			RewardMeResponse response) throws InvalidParameterException,
			FatalException {

		Long reportId = request.getParameterLong(
				Constants.Request.Reporting.REPORT_ID, false);
		String name = request.getParameter(Constants.Request.NAME);
		String groupName = request
				.getParameter(Constants.Request.Reporting.GROUP_NAME);
		String description = request
				.getParameter(Constants.Request.DESCRIPTION);
		JSONObject definition = request.getParameterJSONObject(
				Constants.Request.Reporting.DEFINITION, true);

		Report report = null;

		if (reportId != null) {
			report = ReportingManager.getReport(reportId);
			report.setName(name);
			report.setDescription(description);
			report.setDefinition(definition);

		} else {
			report = new Report(name, groupName, description, definition);
		}
		ReportingManager.save(report);

		response.get().setReport(report.toReportType());
	}

	public static void getReports(RewardMeRequest request,
			RewardMeResponse response) throws InvalidParameterException,
			FatalException {

		List<Report> reports = ReportingManager.getReports();

		response.get().setReports(new ReportsType());
		for (Report report : reports) {
			response.get().getReports().getReport().add(report.toReportType());
		}
	}

	public static void getReport(RewardMeRequest request,
			RewardMeResponse response) throws InvalidParameterException,
			FatalException {

		long reportId = request.getParameterLong(
				Constants.Request.Reporting.REPORT_ID, true);

		Report report = ReportingManager.getReport(reportId);
		response.get().setReport(report.toReportType());
	}

	public static void runReport(RewardMeRequest request,
			RewardMeResponse response) throws InvalidParameterException,
			FatalException {

		long reportId = request.getParameterLong(
				Constants.Request.Reporting.REPORT_ID, true);
		Date startDate = request.getParameterDate(Constants.Request.START_DATE,
				true);
		Date endDate = request.getParameterDate(Constants.Request.END_DATE,
				true);
		PeriodType periodType = request
				.getParameterType(Constants.Request.Reporting.PERIOD_TYPE,
						PeriodType.class, true);
		Customer customer = request.getCustomer();
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID,
				false);
		Address address = addressId == null ? null : AddressManager.getAddress(
				addressId, false);
		if (address != null) {
			customer = address.getCustomer();
		}

		/*
		 * Reports should only be run with either: 1) An admin secretKey 2) A
		 * customer secret key matching the apiKey
		 * 
		 * We currently require an admin secret key to be used with report.*
		 * requests, so the following is largely moot
		 */

		if (request.getAdminSecretKey() == null) {
			// not an admin
			if (customer == null) {
				// customer not allowed to view all the datas!
				throw new InvalidParameterException(
						Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_READ,
						ListUtil.from("report", "GLOBAL"));
			}
			if (!request.getSecretKey().equals(customer.getSecretKey())) {
				// customer can't view another customer's data
				throw new InvalidParameterException(
						Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_READ,
						ListUtil.from("report", customer.getApiKey()));
			}
			if (address != null
					&& address.getCustomer().getCustomerId() != customer
							.getCustomerId()) {
				// customer can't view the address
				throw new InvalidParameterException(
						Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_READ,
						ListUtil.from("address", customer.getApiKey()));
			}
		}

		Report report = ReportingManager.getReport(reportId);
		report.run(customer, address, startDate, endDate, periodType);

		response.get().setReport(report.toReportType());
	}

	public static void generateReport(RewardMeRequest request,
			RewardMeResponse response) throws InvalidParameterException,
			IOException, FatalException, JSONException {
		GeneratedReportType report = new GeneratedReportType();
		long customerId = request.getCustomer().getCustomerId();
		String numRewardRedeemedQuery = "select r.reward_id, r.headline, count(u.reward_id) from "
				+ MySQL.TABLES.CUSTOMER_TO_REWARD
				+ " cr, "
				+ MySQL.TABLES.REWARD
				+ " r left outer join "
				+ MySQL.TABLES.USER_TO_REWARD
				+ " u on u.reward_id = r.reward_id where cr.reward_id=u.reward_id and cr.customer_id = ?"
				+ " and u.created > date_sub(now(), interval ? ?) group by r.reward_id";
		MySQL mysql = MySQL.getInstance(true);
		mysql.query(numRewardRedeemedQuery, new Object[] { customerId, "1",
				"Month" });
		JSONArray responseArray = new JSONArray();
		while (mysql.nextRow()) {
			JSONObject reward = new JSONObject();
			reward.put("rewardId", mysql.getColumn("r.reward_id"));
			reward.put("rewardHeadline", mysql.getColumn("r.reward_headline"));
			reward.put("count", mysql.getColumn("r.count(u.reward_id)"));
			responseArray.put(reward);
		}
		report.setReport(responseArray.toString());
		logger.debug(report.toString());
		response.get().setGeneratedReport(report);
	}
}
