package com.viralogy.rewardme.service;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.RewardsType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.PointsManager;
import com.viralogy.rewardme.manager.RewardManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.PointCategory;
import com.viralogy.rewardme.model.Reward;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.Session;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.StringUtil;

public class RewardService {
	
	private static Logger logger = Logger.getLogger(RewardService.class);
	
	public static void getReward(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Customer customer = request.getCustomer();
		long rewardId = request.getParameterLong(Constants.Request.REWARD_ID, true);
		Reward reward = RewardManager.getReward(rewardId);
		
		if(customer.getCustomerId() != reward.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_READ,ListUtil.from("reward",customer.getApiKey()));
		}
		
		response.get().setReward(reward.toRewardType());
	}
	
	public static void saveReward(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		Reward reward = null;
		String headline = request.getParameter(Constants.Request.HEADLINE);
		String shortDescription = request.getParameter(Constants.Request.SHORT_DESCRIPTION);
		String description = request.getParameter(Constants.Request.DESCRIPTION);
		String instructions = request.getParameter(Constants.Request.INSTRUCTIONS);
		String imageUrl = request.getParameter(Constants.Request.IMAGE_URL);
		String imageUrlSmall = request.getParameter(Constants.Request.IMAGE_URL_SMALL);
		long pointsRequired = request.getParameterLong(Constants.Request.POINTS_REQUIRED, true);
		long redemptionLimit = request.getParameterLong(Constants.Request.REDEMPTION_LIMIT, true);
		Date startDate = request.getParameterDate(Constants.Request.START_DATE, false);
		Date endDate = request.getParameterDate(Constants.Request.END_DATE, false);
		boolean enabled = request.getParameterBool(Constants.Request.ENABLED, true);
		Boolean isPromoted = request.getParameterBool(Constants.Request.IS_PROMOTED, false);
		Long rewardId = request.getParameterLong(Constants.Request.REWARD_ID, false); 
		
		//if the startDate or endDate were set to NOW (0) - null them out
		if(startDate != null && Math.abs(startDate.getTime()-(new Date()).getTime()) < 1000) {
			startDate = null;
		}
		if(endDate != null && Math.abs(endDate.getTime()-(new Date()).getTime()) < 1000) {
			endDate = null;
		}		
		
		PointCategory pointCategory = null;
		String pointCategoryName = request.getParameter(Constants.Request.POINT_CATEGORY);
		if(!StringUtil.isNullOrEmpty(pointCategoryName)) {
			pointCategory = PointsManager.getPointCategory(customer, pointCategoryName);
		}else {
			pointCategory = PointsManager.getDefaultPointCategory(customer);
		}
		
		Reward.Type type = request.getParameterType(Constants.Request.TYPE, Reward.Type.class, false);
		
		if(rewardId != null) {
			reward = RewardManager.getReward(rewardId);
			if(customer.getCustomerId() != reward.getCustomer().getCustomerId()) {
				throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE,ListUtil.from("reward",customer.getApiKey()));
			}
			reward.setHeadline(headline);
			reward.setShortDescription(shortDescription);
			reward.setDescription(description);
			reward.setInstructions(instructions);
			if(!StringUtil.isNullOrEmpty(imageUrl)) reward.setImageUrl(imageUrl);
			if(!StringUtil.isNullOrEmpty(imageUrlSmall)) reward.setImageUrlSmall(imageUrlSmall);
			reward.setType(type);
			reward.setPointsRequired(pointsRequired);
			reward.setRedemptionLimit(redemptionLimit);
			reward.setStartDate(startDate);
			reward.setEndDate(endDate);
			reward.setEnabled(enabled);
			reward.setCustomer(customer);
			reward.setPointCategory(pointCategory);
			if(isPromoted != null) {
				reward.setPromoted(isPromoted);
			}
			
			RewardManager.save(reward);
			
		}else {
			if(isPromoted == null) {
				isPromoted = customer.getRewards().size() == 0;
			}
			reward = new Reward(enabled, type, 
					headline, shortDescription, description, instructions, imageUrl, imageUrlSmall, 
					pointCategory, pointsRequired, redemptionLimit, 
					startDate, endDate, isPromoted);
		
			RewardManager.addRewardToCustomer(customer, reward);
		}

		response.get().setCustomer(customer.toCustomerType(null, true, false));
	}

	public static void removeReward(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		long rewardId = request.getParameterLong(Constants.Request.REWARD_ID, true);
		
		for(Reward reward : customer.getRewards()) {
			if(reward.getRewardId() == rewardId) {
				RewardManager.removeRewardFromCustomer(customer, reward);
				break;
			}
		}

		response.get().setCustomer(customer.toCustomerType(null, true, false));
	}
	
	public static void redeem(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		User user = request.getUser();
		request.isAuthorized();	//sets the authorization status of the user
		String md5PinCode = request.getParameter(Constants.Request.MD5_PIN_CODE);
		boolean autoComplete = request.getParameterBool(Constants.Request.AUTO_COMPLETE, false);
		Session session = request.getSession();
		
		if(StringUtil.isNullOrEmpty(user.getPinCode()) || StringUtil.isNullOrEmpty(md5PinCode) || !md5PinCode.equals(user.getPinCode())) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_PINCODE_AUTHENTICATION);						
		}
		Reward reward = RewardManager.getReward(request.getParameterLong(Constants.Request.REWARD_ID, true));
		Address address = AddressManager.getAddress(request.getParameterLong(Constants.Request.ADDRESS_ID, true), false);
		
		if(customer.getCustomerId() != reward.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_READ,ListUtil.from("reward",customer.getApiKey()));
		}
		if(customer.getCustomerId() != address.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.CUSTOMER_DOES_NOT_MATCH,ListUtil.from("address",customer.getApiKey()));
		}
		
		//do the redeem!
		RewardManager.redeem(user, reward, address, session, false);
		
		if(autoComplete) {
			//and complete it
			RewardManager.completeRedeem(user, reward, address);			
		}
		
		response.get().setUser(user.toUserType(customer));	
	}		
	
	public static void completeRedeem(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();
		Customer customer = request.getCustomer();
		Reward reward = RewardManager.getReward(request.getParameterLong(Constants.Request.REWARD_ID, true));
		Address address = AddressManager.getAddress(request.getParameterLong(Constants.Request.ADDRESS_ID, true), false);
		
		if(customer.getCustomerId() != reward.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_READ,ListUtil.from("reward",customer.getApiKey()));
		}
		
		//complete the redeem!
		RewardManager.completeRedeem(user, reward, address);
		
		response.get().setUser(user.toUserType(customer));
	}		
	
	public static void credit(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();
		Customer customer = request.getCustomer();
		Reward reward = RewardManager.getReward(request.getParameterLong(Constants.Request.REWARD_ID, true));
		Session session = request.getSession();
		
		if(customer.getCustomerId() != reward.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_READ,ListUtil.from("reward",customer.getApiKey()));
		}
		
		RewardManager.credit(user, reward, session);
	
		response.get().setUser(user.toUserType(customer));
	}		
	
	public static void getRewardsAvailableToUser(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();	
		Customer customer = request.getCustomer();
		request.isAuthorized();	//sets the authorization status of the user
		
		PointCategory pointCategory = null;
		String pointCategoryName = request.getParameter(Constants.Request.POINT_CATEGORY);
		if(!StringUtil.isNullOrEmpty(pointCategoryName)) {
			pointCategory = PointsManager.getPointCategory(customer, pointCategoryName);
		}else {
			pointCategory = PointsManager.getDefaultPointCategory(customer);
		}		
		
		List<Reward> availableRewards = RewardManager.getAllCustomerRewardsAvailableToUser(customer, user, pointCategory);
		
		response.get().setRewards(new RewardsType());
		for(Reward reward : availableRewards) {
			response.get().getRewards().getReward().add(reward.toRewardType());
		}
		response.get().setUser(user.toUserType(customer, pointCategory));
	}	
}
