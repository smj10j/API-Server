package com.viralogy.rewardme.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.dao.UserDAO;
import com.viralogy.rewardme.jaxb.SegmentsType;
import com.viralogy.rewardme.jaxb.UserSegmentsType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.SegmentManager;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.Segment;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserSegment;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.jaxb.SegmentsType;
import com.viralogy.rewardme.jaxb.UserSegmentsType;

public abstract class SegmentService {
	private static Logger logger = Logger.getLogger(SegmentService.class);

	public static void getSegment(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException,
			FatalException {

		Customer customer = request.getCustomer();
		long segmentId = request.getParameterLong(Constants.Request.SEGMENT_ID,	true);
		Segment segment = SegmentManager.getSegment(segmentId, true);

		if (customer.getCustomerId() != segment.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_READ, ListUtil.from("segment", customer.getApiKey()));
		}

		response.get().setSegment(segment.toSegmentType());
	}

	public static void removeSegment(RewardMeRequest request,
			RewardMeResponse response) throws InvalidParameterException,
			FatalException {

		Customer customer = request.getCustomer();
		long segmentId = request.getParameterLong(Constants.Request.SEGMENT_ID,
				true);
		Segment segment = SegmentManager.getSegment(segmentId, true);

		// if the customer requesting the removal of the segment is not the
		// owner of the segment
		if (customer.getCustomerId() != segment.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE,	ListUtil.from("segment", customer.getApiKey()));
		}

		SegmentManager.remove(segment);
		response.get().setSegment(segment.toSegmentType());
	}

	public static void saveSegment(RewardMeRequest request,
			RewardMeResponse response) throws InvalidParameterException,
			FatalException {

		Customer customer = request.getCustomer();
		Segment segment = null;
		Long segmentId = request.getParameterLong(Constants.Request.SEGMENT_ID, false); 
		JSONObject definition = request.getParameterJSONObject(Constants.Request.DEFINITION, true);
		String name = request.getParameter(Constants.Request.NAME);
		String description = request.getParameter(Constants.Request.DESCRIPTION);
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, false);
		
		if(segmentId != null) { //update an old segment
			segment = SegmentManager.getSegment(segmentId, true);
			
			if (customer.getCustomerId() != segment.getCustomer().getCustomerId()) {
				throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE,	ListUtil.from("segment", customer.getApiKey()));
			}
			if ((segment.getAddress() != null && (addressId == null || addressId != segment.getAddress().getAddressId())) || (segment.getAddress() == null && addressId != null)) {
				// all checks required to make sure the addressId given does not
				// conflict with global segments or wrong addresses
				throw new InvalidParameterException(Constants.Error.INVALID_ID.ADDRESS_ID,	ListUtil.from(addressId + ""));
			}
			
			if (!(segment.getDefinition().toString()).equals(definition.toString())) {//if changing the definition, need to set definitionUpdated to true to notify the cache.
				segment.setDefinitionUpdated(true);
			} else {
				segment.setDefinitionUpdated(false); 
			}
			segment.setDefinition(definition);
			segment.setName(name);
			segment.setDescription(description);
		}else { //create a new segment
			if(addressId != null) {
				segment = new Segment(customer, AddressManager.getAddress(addressId, true), definition, 
						  name, description);
			}else { //create a global segment
				segment = new Segment(customer, null, definition, 
						  name, description);
			}
		}
		SegmentManager.save(segment);
		response.get().setSegment(segment.toSegmentType());
	}

	// Gets the list of available segments for the customer.
	// If addressId is specified, only segments from that address will be
	// returned, else all global segments will be returned.
	public static void getAllCustomerSegments(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException,
			FatalException {
		Customer customer = request.getCustomer();
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID,	false);

		List<Segment> segments;
		if(addressId == null) {
			segments = SegmentManager.getAllSegments(customer, null);
		}else {
			segments = SegmentManager.getAllSegments(customer, AddressManager.getAddress(addressId, true)); 

		}

		response.get().setSegments(new SegmentsType());
		for (Segment segment : segments) {
			if (!segment.isArchived()) {
				response.get().getSegments().getSegment().add(segment.toSegmentType());
			}
		}
	}

	// Gets the list of available segments for the given user.
	// If addressId is specified only segments from that address will be
	// returned, else all global segments will be returned.
	public static void getSegmentsAvailableToUser(RewardMeRequest request,
			RewardMeResponse response) throws InvalidParameterException,
			FatalException {
		User user = request.getUser();
		Customer customer = request.getCustomer();
		request.isAuthorized(); // sets the authorization status of the user
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID,	false);

		List<UserSegment> availableSegments;
		if (addressId != null) {
			availableSegments = SegmentManager.getAllSegmentsAvailableToUser(customer, AddressManager.getAddress(addressId, true), user);
		}else {
			availableSegments = SegmentManager.getAllSegmentsAvailableToUser(customer, null, user);
		}

		response.get().setUserSegments(new UserSegmentsType());
		for (UserSegment userSegment : availableSegments) {
			if (!userSegment.getSegment().isArchived()) {
				response.get().getUserSegments().getUserSegment().add(userSegment.toUserSegmentType());
			}
		}
	}
	
}
