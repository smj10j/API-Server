package com.viralogy.rewardme.service;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.PointsManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserPoints;
import com.viralogy.rewardme.social.Social;
import com.viralogy.rewardme.util.ListUtil;

public class SocialService {
	
	private static Logger logger = Logger.getLogger(SocialService.class);

	public static void getOauthURI(RewardMeRequest request, RewardMeResponse response ) throws InvalidParameterException, FatalException {
		User user = request.getUser();
		Social.Type type = request.getParameterType(Constants.Request.TYPE, Social.Type.class, true);
		
		Social social  = new Social(user, false);
		String oauthUri = social.getOauthURI(type);
		
		response.get().setOauthUri( oauthUri );
	}
	
	public static void disconnect(RewardMeRequest request, RewardMeResponse response ) throws InvalidParameterException, FatalException{
		User user = request.getUser();
		Social.Type type = request.getParameterType( Constants.Request.TYPE, Social.Type.class, true );
		
		Social social = new Social(user, false);
		social.disconnect( type );
		social.refreshAccessTokens();
		
		response.get().setSocial(social.toSocialType());
	}
	
	public static void checkin(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		Address address = AddressManager.getAddress(request.getParameterLong(Constants.Request.ADDRESS_ID, true), false);

		if(customer.getCustomerId() != address.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_ADDRESS_FOR_CUSTOMER,ListUtil.from( address.getAddressId() + "",customer.getApiKey()));
		}
		
		User user = request.getUser();
		Social.Type type = request.getParameterType( Constants.Request.TYPE, Social.Type.class, true );
		
		Social social = new Social( user, true );
		try {
			social.checkin(type, address);
		} catch( InvalidParameterException e ) {
			if( e.code == Constants.Error.SOCIAL.INVALID_ACCESS_TOKEN) {
				social.disconnect(type);
				MySQL.commit();
			}
			throw e;
		}
		
		//give the user 25 points for the checkin
		PointsManager.credit(user, customer, address, UserPoints.Type.SOCIAL, PointsManager.getDefaultPointCategory(customer), 25);
		
		response.get().setSocial(social.toSocialType());
	}

	public static void post(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException{
		Customer customer = request.getCustomer();
		User user = request.getUser();
		Social.Type type = request.getParameterType( Constants.Request.TYPE, Social.Type.class, true );
		
		throw new InvalidParameterException(Constants.Error.GATEWAY.METHOD_NOT_YET_IMPLEMENTED);
		
	}

	public static void like(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException{
		Customer customer = request.getCustomer();
		User user = request.getUser();
		Social.Type type = request.getParameterType( Constants.Request.TYPE, Social.Type.class, true );
		
		//Facebook does not yet support LIKE through the API (only on web via iFrame)
		throw new InvalidParameterException(Constants.Error.GATEWAY.METHOD_NOT_YET_IMPLEMENTED);
		
		/*
		if(!type.equals(Social.Type.FACEBOOK)) {
			throw new InvalidParameterException(Constants.Error.SOCIAL.FACEBOOK_ONLY);
		}
		
		Social social = new Social(user, true);
		try {
			social.like(type, customer);
		} catch( InvalidParameterException e ) {
			if( e.code == Constants.Error.SOCIAL.INVALID_ACCESS_TOKEN) {
				social.disconnect(type);
				MySQL.commit();
			}
			throw e;
		}
		
		response.get().setSocial(social.toSocialType());*/
	}	
	
	public static void status(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException{
		User user = request.getUser();
		Social social = new Social( user, true);
		
		response.get().setSocial(social.toSocialType( ) );
		
	}
}