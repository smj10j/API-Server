package com.viralogy.rewardme.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.*;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.stripe.exception.StripeException;
import com.stripe.model.Charge;
import com.stripe.model.Event;
import com.stripe.model.Invoice;
import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.StripeType;
import com.viralogy.rewardme.manager.StripeManager;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;

public class StripeService {

	private static Logger logger = Logger.getLogger(StripeService.class);
	
	public static void updateCustomer(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		String token = request.getParameter(Constants.Request.CARD_TOKEN, false);
		String description = request.getParameter(Constants.Request.DESCRIPTION, false);
		String plan = request.getParameter(Constants.Request.PLAN, false);
		
		if(customer.getStripeCustomerId().equals("") && token == null && description == null && plan == null) {
			throw new InvalidParameterException(Constants.Error.STRIPE.NO_PARAMETERS_PROVIDED);
		}
		
		StripeManager.updateCustomer(customer, token, description, plan);
		
		response.get().setMessage("Customer Stripe details successfully updated.");
	}
	
	public static void addInvoiceItem(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		int amount = request.getParameterInt(Constants.Request.AMOUNT, true);
		String description = request.getParameter(Constants.Request.DESCRIPTION, false);
		String currency = request.getParameter(Constants.Request.CURRENCY, false);
		
		StripeManager.addInvoiceItem(customer, amount, description, currency);
		
		response.get().setMessage("Charge successfully added to invoice.");
	}
	
	public static void getNextInvoice(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		
		Invoice invoice = StripeManager.getNextInvoice(customer);
		
		Gson gson = new Gson();
		String json = gson.toJson(invoice);
		
		StripeType returned = new StripeType();
		returned.setResponse(json);
		
		response.get().setStripe(returned);
	}
	
	public static void getInvoices(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		int count = request.getParameterInt(Constants.Request.COUNT, false);
		if(count > 100) {
			count = 100;
		}
		if(count < 1) {
			count = 1;
		}
		int offset = request.getParameterInt(Constants.Request.OFFSET, false);
		
		List<Invoice> invoices = StripeManager.getInvoices(customer, count, offset);
		
		Gson gson = new Gson();
		String json = gson.toJson(invoices);
		
		StripeType returned = new StripeType();
		returned.setResponse(json);
		
		response.get().setStripe(returned);
	}
	
	public static void getCharges(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		int count = request.getParameterInt(Constants.Request.COUNT, false);
		if(count > 100) {
			count = 100;
		}
		if(count < 1) {
			count = 1;
		}
		int offset = request.getParameterInt(Constants.Request.OFFSET, false);
		
		List<Charge> charges = StripeManager.getCharges(customer, count, offset);
		
		Gson gson = new Gson();
		String json = gson.toJson(charges);
		
		StripeType returned = new StripeType();
		returned.setResponse(json);
		
		response.get().setStripe(returned);
	}
	
}
