package com.viralogy.rewardme.service;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.SurveysType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.SurveyManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.Survey;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserSurvey;
import com.viralogy.rewardme.scheduler.ScheduledTask;
import com.viralogy.rewardme.scheduler.ScheduledTask.Type;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.StringUtil;

public class SurveyService {
	
	private static Logger logger = Logger.getLogger(SurveyService.class);
	
	public static void saveSurvey(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Customer customer = request.getCustomer();
		Survey survey = null;
		Long surveyId = request.getParameterLong(Constants.Request.SURVEY_ID, false);
		String name = request.getParameter(Constants.Request.NAME, true);
		String description = request.getParameter(Constants.Request.DESCRIPTION, true);
		String content = request.getParameter(Constants.Request.CONTENT, true);
		boolean availableOnMobile = request.getParameterBool(Constants.Request.AVAILABLE_ON_MOBILE, true);
		boolean ableToShowResults = request.getParameterBool(Constants.Request.ABLE_TO_SHOW_RESULTS, true);
		boolean enabled = request.getParameterBool(Constants.Request.ENABLED, true);
		
		if(availableOnMobile && content.length() > 160) {
			throw new InvalidParameterException(Constants.Error.SURVEY.INVALID_SURVEY_LENGTH,ListUtil.from(160+"",content.length()+""));
		}
		
		if(!availableOnMobile) {
			throw new InvalidParameterException(Constants.Error.GATEWAY.METHOD_NOT_YET_IMPLEMENTED,ListUtil.from("survey.save with availableOnMobile=false"));			
		}
		
		if(surveyId != null) {
			survey = SurveyManager.getSurvey(surveyId);
			if(customer.getCustomerId() != survey.getCustomer().getCustomerId()) {
				throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE,ListUtil.from("survey",customer.getApiKey()));
			}
			survey.setName(name);
			survey.setDescription(description);
			survey.setContent(content);
			survey.setAvailableOnMobile(availableOnMobile);
			survey.setAbleToShowResults(ableToShowResults);
			survey.setEnabled(enabled);
			
		}else {
			//force these to be required for new customer contacts
			survey = new Survey(name, description, content, customer, availableOnMobile, ableToShowResults, enabled);
		}
		SurveyManager.save(survey);
		
		response.get().setSurveys(new SurveysType());
		response.get().getSurveys().getSurvey().add(survey.toSurveyType());
	}		
	
		
	public static void getSurvey(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
	
		Customer customer = request.getCustomer();

		Survey survey = SurveyManager.getSurvey(request.getParameterLong(Constants.Request.SURVEY_ID, true));
		
		if(customer.getCustomerId() != survey.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_READ,ListUtil.from("survey",customer.getApiKey()));
		}		

		response.get().setSurveys(new SurveysType());
		response.get().getSurveys().getSurvey().add(survey.toSurveyType());
	}
	
	public static void getSurveys(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Customer customer = request.getCustomer();
		int returnCount = request.getParameterInt(Constants.Request.RETURN_COUNT, false);
		boolean enabledOnly = request.getParameterBool(Constants.Request.ENABLED_ONLY,false);

		List<Survey> surveys = SurveyManager.getSurveys(customer, returnCount, enabledOnly);
		
		response.get().setSurveys(new SurveysType());
		for(Survey survey : surveys) {
			response.get().getSurveys().getSurvey().add(survey.toSurveyType());			
		}
	}
	
	
	public static void schedule(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		Customer customer = request.getCustomer();
		User user = request.getUser();
		Date timestamp = request.getParameterDate(Constants.Request.DELIVERY_TIMESTAMP, true);
		Long surveyId = request.getParameterLong(Constants.Request.SURVEY_ID, false);
		Address address = null;
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, false);
		if(addressId != null) {
			address = AddressManager.getAddress(addressId, false);
		}

		if(timestamp.equals(new Date()) || timestamp.before(new Date())) {
			//if specified as immediate, do it in 10 seconds so the database row is for sure created
			timestamp = new Date(timestamp.getTime()+(10*1000));
		}	
		
		//get the survey
		Survey survey = null;
		UserSurvey userSurvey = null;
		if(surveyId != null) {
			//specific survey
			survey = SurveyManager.getSurvey(surveyId);
			
			try {
				userSurvey = SurveyManager.getUserSurvey(user, survey);
			}catch(InvalidParameterException e) {
				//yay
			}
			if(userSurvey != null) {
				throw new InvalidParameterException(Constants.Error.SURVEY.USER_ALREADY_TAKING_SURVEY,ListUtil.from(user.getUserId()+"",surveyId+""));
			}
			
		}else {
			//pick a random one
			survey = null;
			for(Survey aSurvey : customer.getSurveys()) {
				try {
					userSurvey = SurveyManager.getUserSurvey(user, aSurvey);
				}catch(InvalidParameterException e) {
					//yay
					survey = aSurvey;
					break;
				}
			}
			if(survey == null) {
				throw new InvalidParameterException(Constants.Error.SURVEY.CUSTOMER_HAS_NO_UNTAKEN_SURVEYS,ListUtil.from(customer.getApiKey(),user.getUserId()+""));
			}
		}		

		//link the survey to the user
		userSurvey = new UserSurvey(user, survey, address);
		SurveyManager.save(userSurvey);
				
		String baseUrl = request.getBaseURL() + "/schedule";
		String queryString = "customerId="+customer.getCustomerId()+"&"+
							 "userSurveyId="+userSurvey.getUserSurveyId();
		
		//schedule it
		String url = baseUrl + "?" + queryString;
		(new ScheduledTask(Type.URL, url, timestamp)).save();
	}
	

	public static void respond(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		Customer customer = request.getCustomer();
		User user = request.getUser();
		Survey survey = SurveyManager.getSurvey(request.getParameterLong(Constants.Request.SURVEY_ID, true));
		String surveyResponse = request.getParameter(Constants.Request.RESPONSE);
		UserSurvey userSurvey = SurveyManager.getUserSurvey(user, survey);
		
		if(!StringUtil.isNullOrEmpty(userSurvey.getResponse())) {
			throw new InvalidParameterException(Constants.Error.SURVEY.USER_ALREADY_RESPONDED_TO_SURVEY,ListUtil.from(user.getUserId()+"",survey.getSurveyId()+""));
		}

		if(customer.getCustomerId() != userSurvey.getSurvey().getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_CUSTOMER_PERMISSIONS_WRITE,ListUtil.from("survey",customer.getApiKey()));
		}
		
		surveyResponse = survey.getFullResponse(surveyResponse);
		
		//set the users response and respond to them with results if necessary
		SurveyManager.respond(userSurvey, surveyResponse);
	}	
	
}
