package com.viralogy.rewardme.service;

import java.io.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.servlet.ServletException;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.ApiMethodFilterType;
import com.viralogy.rewardme.jaxb.ApiMethodFiltersType;
import com.viralogy.rewardme.jaxb.ApiMethodParameterType;
import com.viralogy.rewardme.jaxb.ApiMethodParametersType;
import com.viralogy.rewardme.jaxb.ApiMethodType;
import com.viralogy.rewardme.jaxb.ApiMethodsType;
import com.viralogy.rewardme.jaxb.ErrorCodeType;
import com.viralogy.rewardme.jaxb.ErrorCodesType;
import com.viralogy.rewardme.jaxb.ServersType;
import com.viralogy.rewardme.manager.AdminManager;
import com.viralogy.rewardme.manager.ServerManager;
import com.viralogy.rewardme.model.MethodParameter;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.Server;
import com.viralogy.rewardme.servlet.GatewayServlet;
import com.viralogy.rewardme.util.Cache;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.RemoteRequestUtil;
import com.viralogy.rewardme.util.SecurityUtil;

public class TestPGAO {
	
	private static Logger logger = Logger.getLogger(ServerService.class);
	
	public static void helloWorld (RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		response.get().setMessage("HELLO WORLD");
	}
	
}
