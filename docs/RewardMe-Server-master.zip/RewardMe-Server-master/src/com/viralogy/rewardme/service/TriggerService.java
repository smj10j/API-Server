package com.viralogy.rewardme.service;

import java.util.Date;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.TriggerManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Event;
import com.viralogy.rewardme.model.EventTrigger;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.ScheduledTrigger;
import com.viralogy.rewardme.model.Trigger.Type;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.util.ListUtil;

public class TriggerService {
	
	private static Logger logger = Logger.getLogger(TriggerService.class);
		
	public static void saveEventTrigger(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		Customer customer = request.getCustomer();
		User user = request.getUser();
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, false);
		Address address = addressId == null ? null : AddressManager.getAddress(addressId, false);
		if(address != null && address.getCustomer().getCustomerId() != customer.getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.ADDRESS_ID, ListUtil.from(address.getAddressId()+""));
		}
		Type type = request.getParameterType(Constants.Request.TYPE, Type.class, true);
		Long typeId = null;
		String name = request.getParameter(Constants.Request.EVENT_NAME);
		String value = request.getParameter(Constants.Request.EVENT_VALUE);		
		String data = request.getParameter(Constants.Request.DATA);
		
		if(type.equals(Type.DELETE_EVENT_TRIGGER)) {
			try {
				typeId = Long.parseLong(data);
			}catch(NumberFormatException e) {
				throw new InvalidParameterException("data must be a Long when using type="+Type.DELETE_EVENT_TRIGGER);
			}
		}else if(type.equals(Type.DELETE_SCHEDULED_TRIGGER)) {
			try {
				typeId = Long.parseLong(data);
			}catch(NumberFormatException e) {
				throw new InvalidParameterException("data must be a Long when using type="+Type.DELETE_SCHEDULED_TRIGGER);
			}
		}else if(type.equals(Type.DELETE_USER_MESSAGE)) {
			try {
				typeId = Long.parseLong(data);
			}catch(NumberFormatException e) {
				throw new InvalidParameterException("data must be a Long when using type="+Type.DELETE_USER_MESSAGE);
			}
		}
		
		//set the trigger
		EventTrigger eventTrigger = new EventTrigger(
			new Event(
				customer, 
				user,
				request.getDevice(), 
				address, 
				name, 
				value, 
				request.isAdminWrite(), 
				request.getAdminSecretKey()
			), 
			type, 
			typeId, 
			data
		);
		TriggerManager.save(eventTrigger);
		
		response.get().setEventTrigger(eventTrigger.toEventTriggerType());
	}
	
	public static void saveScheduledTrigger(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {

		Customer customer = request.getCustomer();
		User user = request.getUser();
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, false);
		Address address = addressId == null ? null : AddressManager.getAddress(addressId, false);
		if(address != null && address.getCustomer().getCustomerId() != customer.getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.ADDRESS_ID, ListUtil.from(address.getAddressId()+""));
		}
		Type type = request.getParameterType(Constants.Request.TYPE, Type.class, true);
		Long typeId = null;
		Date timestamp = request.getParameterDate(Constants.Request.TRIGGER_DATE, true);	
		if(timestamp.equals(new Date()) || timestamp.before(new Date())) {
			//if specified as immediate, do it in 10 seconds so the database row is for sure created
			timestamp = new Date(timestamp.getTime()+(10*1000));
		}
		
		String data = request.getParameter(Constants.Request.DATA);
		
		if(type.equals(Type.DELETE_EVENT_TRIGGER)) {
			try {
				typeId = Long.parseLong(data);
			}catch(NumberFormatException e) {
				throw new InvalidParameterException("data must be a Long when using type="+Type.DELETE_EVENT_TRIGGER);
			}
		}else if(type.equals(Type.DELETE_SCHEDULED_TRIGGER)) {
			try {
				typeId = Long.parseLong(data);
			}catch(NumberFormatException e) {
				throw new InvalidParameterException("data must be a Long when using type="+Type.DELETE_SCHEDULED_TRIGGER);
			}
		}else if(type.equals(Type.DELETE_USER_MESSAGE)) {
			try {
				typeId = Long.parseLong(data);
			}catch(NumberFormatException e) {
				throw new InvalidParameterException("data must be a Long when using type="+Type.DELETE_USER_MESSAGE);
			}
		}
		
		//set the trigger
		ScheduledTrigger scheduledTrigger = new ScheduledTrigger(
			customer, 
			user,
			request.getDevice(), 
			address, 
			type, 
			typeId, 
			data,
			timestamp
		);
		TriggerManager.save(scheduledTrigger);
		
		response.get().setScheduledTrigger(scheduledTrigger.toScheduledTriggerType());
	}	
}
