package com.viralogy.rewardme.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.CustomerType;
import com.viralogy.rewardme.jaxb.CustomersType;
import com.viralogy.rewardme.jaxb.ShortUserCheckinsType;
import com.viralogy.rewardme.jaxb.UserCheckinsType;
import com.viralogy.rewardme.jaxb.UserMessagesType;
import com.viralogy.rewardme.jaxb.UserRewardsType;
import com.viralogy.rewardme.jaxb.UserType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CheckinOptionManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.DeviceManager;
import com.viralogy.rewardme.manager.MessageManager;
import com.viralogy.rewardme.manager.PhoneManager;
import com.viralogy.rewardme.manager.PointsManager;
import com.viralogy.rewardme.manager.PreferencesManager;
import com.viralogy.rewardme.manager.RewardManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.CheckinOption;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.Device;
import com.viralogy.rewardme.model.DeviceApplication;
import com.viralogy.rewardme.model.PointCategory;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.RewardMeResponse;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserCheckin;
import com.viralogy.rewardme.model.UserMessage;
import com.viralogy.rewardme.model.UserPoints;
import com.viralogy.rewardme.model.UserPoints.Type;
import com.viralogy.rewardme.model.UserPreference;
import com.viralogy.rewardme.model.UserReward;
import com.viralogy.rewardme.servlet.GatewayServlet;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.StringUtil;
import com.viralogy.rewardme.util.TwilioUtil;

public abstract class UserService {
	
	private static Logger logger = Logger.getLogger(UserService.class);
	
	public static void authenticateAsAdmin(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		response.get().setMessage("Authenticated");
	}
	
	
	public static void getAllAvailableAdminCustomers(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();
		//get the list of customers who this user can modify
		List<Customer> customers = CustomerManager.getModifiableCustomers(user);
		
		CustomersType customersType = new CustomersType();
		for(Customer customer : customers) {
			CustomerType customerType = customer.toCustomerType(request.getUser(), false, false);
			customersType.getCustomer().add(customerType);
		}
		
		response.get().setCustomers(customersType);
	}
	
	public static void authenticate(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();
		String md5PinCode = request.getParameter(Constants.Request.MD5_PIN_CODE);
		boolean withAuthenticatedCustomers = request.getParameterBool(Constants.Request.WITH_AUTHENTICATED_CUSTOMERS, false);

		if(StringUtil.isNullOrEmpty(user.getPinCode()) || StringUtil.isNullOrEmpty(md5PinCode) || !md5PinCode.equals(user.getPinCode())) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_AUTHENTICATION);						
		}
		
		if(withAuthenticatedCustomers) {
			//get the list of customers who this user can modify
			List<Customer> customers = CustomerManager.getModifiableCustomers(user);
			
			CustomersType customersType = new CustomersType();
			for(Customer customer : customers) {
				CustomerType customerType = customer.toCustomerType(request.getUser(), false, false);
				customersType.getCustomer().add(customerType);
			}
			
			response.get().setCustomers(customersType);
		}
		
		response.get().setUser(user.toUserType(null));
		response.get().setMessage("Authenticated");
	}
	
	public static void reset(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();
		
		throw new InvalidParameterException(Constants.Error.GATEWAY.METHOD_DISABLED_TEMPORARILY, ListUtil.from("user.reset"));
		
		//UserManager.reset(user);
	}
	
	public static void remove(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();
		
		throw new InvalidParameterException(Constants.Error.GATEWAY.METHOD_DISABLED_TEMPORARILY, ListUtil.from("user.remove"));
		//UserManager.remove(user);
	}
	
	public static void resetPinCode(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Customer customer = request.getCustomer();
		User user = request.getUser();
		
		UserManager.resetPIN(user, customer);
		
		response.get().setUser(user.toUserType(null));
	}
	
	public static void addDevice(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();
		Device device = request.getDevice();
		UserManager.addDeviceToUser(user, device);
		
		response.get().setUser(user.toUserType(null));
		response.get().setDevice(device.toDeviceType());
	}
	
	public static void saveUser(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		
		Customer customer = request.getCustomer();
		User user = request.getUser();
		String newUserPhoneNumber = request.getParameter(Constants.Request.NEW_USER_PHONE_NUMBER,false);
		String md5PinCode = request.getParameter(Constants.Request.MD5_PIN_CODE, false);
		String newMd5PinCode = request.getParameter(Constants.Request.NEW_MD5_PIN_CODE);
		boolean allowLandline = request.getParameterBool(Constants.Request.ALLOW_LANDLINE, false);
		boolean isNewUser = false;
		
		Long addressId = request.getParameterLong(Constants.Request.ADDRESS_ID, false);
		Address address = addressId == null ? null : AddressManager.getAddress(addressId, false);

		//clean the phone number if provided
		if(!StringUtil.isNullOrEmpty(newUserPhoneNumber)) {
			newUserPhoneNumber = TwilioUtil.cleanNumber(newUserPhoneNumber);
		}
				
		if((user != null && Constants.Demo.numberIsAlwaysANewUser.contains(user.getPhoneNumber()))
			|| (newUserPhoneNumber != null && Constants.Demo.numberIsAlwaysANewUser.contains(newUserPhoneNumber))
		) {
			logger.info("Using the demo account for phone number: " + user.getPhoneNumber());
			if(!StringUtil.isNullOrEmpty(newMd5PinCode)) {
				user.setPinCode(newMd5PinCode);
			}
			UserManager.save(user);
			
			//make the points set to 0 for the user at this customer
			PointCategory pointCategory = PointsManager.getDefaultPointCategory(customer);
			UserPoints userPoints = PointsManager.getUserPoints(user, customer, null, pointCategory, null);
			PointsManager.debit(user, customer, address, Type.CHEATING, pointCategory, userPoints.getCurrentBalance());
			user = UserManager.getUser(user.getUserId());
			logger.info("Set points to 0 for phone number: " + user.getPhoneNumber());
						
			response.get().setUser(user.toUserType(customer));
			
			return;
		}
		
		boolean isMobile = false;
		if(!StringUtil.isNullOrEmpty(newUserPhoneNumber)) {		
			//validate the number
			isMobile = PhoneManager.isMobile(newUserPhoneNumber);
			
			if(!isMobile) {
				if(allowLandline) {
					logger.debug("Allowing landline numbers...");
					if(!PhoneManager.isValid(newUserPhoneNumber)) {
						throw new InvalidParameterException(Constants.Error.PHONE.UNKNOWN_PHONE_NUMBER, ListUtil.from(newUserPhoneNumber));
					}				
				}else {
					throw new InvalidParameterException(Constants.Error.PHONE.INVALID_MOBILE_PHONE_NUMBER, ListUtil.from(newUserPhoneNumber));
				}
			}
		}
		
		if(user == null) {
			
			//creating a new user
			isNewUser = true;
			
			if(StringUtil.isNullOrEmpty(newUserPhoneNumber)) {
				throw new InvalidParameterException(Constants.Error.GATEWAY.MISSING_REQUIRED_PARAMETER, ListUtil.from(Constants.Request.NEW_USER_PHONE_NUMBER));
			}
			
			//try and get the user 
			//if he exists, error
			try {
				user = UserManager.getUserByPhoneNumber(newUserPhoneNumber);
			}catch(InvalidParameterException e) {
				//ignore - this is what we want
			}
			if(user != null) {
				throw new InvalidParameterException(Constants.Error.GENERAL.USER_ALREADY_EXISTS_WITH_PHONE_NUMBER,ListUtil.from(newUserPhoneNumber));
			}
			
			user = new User();
		}else {
			//verify the pincode
			if(!StringUtil.isNullOrEmpty(user.getPinCode()) && !user.getPinCode().equals(md5PinCode)) {
				throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_AUTHENTICATION);				
			}
		}

		if(!StringUtil.isNullOrEmpty(newUserPhoneNumber)) {
			user.setPhoneNumber(newUserPhoneNumber);
			user.setMobile(isMobile);
		}
		if(!StringUtil.isNullOrEmpty(newMd5PinCode)) {
			user.setPinCode(newMd5PinCode);
			UserPreference updatedPinCodePreference = user.getUserPreference(Constants.UserPreference.CHANGED_PIN, null);
			if(updatedPinCodePreference != null) {
				PreferencesManager.remove(updatedPinCodePreference);
			}
		}
				
		UserManager.save(user);
		
		if(isNewUser) {
			if(address != null) {
				logger.info("Setting favorite addressId="+address.getAddressId());
				UserPreference userPreference = user.getUserPreference(Constants.UserPreference.FAVORITE_ADDRESS_ID, customer);
				if(userPreference == null) {
					userPreference = new UserPreference(user, customer, Constants.UserPreference.FAVORITE_ADDRESS_ID, address.getAddressId()+"");
				}else {
					userPreference.setValue(address.getAddressId()+"");
				}
				PreferencesManager.save(userPreference);
			}			
		}
		
		if(!GatewayServlet.isSandbox()) {
			UserManager.welcomeNewUser(customer, address, user, isNewUser, true);
		}
		
		response.get().setUser(user.toUserType(customer));
	}
	
	public static void startTextMessageOptIn(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();
		Customer customer = request.getCustomer();
		
		UserManager.startTextMessageOptIn(user, customer);
	}
	
	public static void getUser(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();
		Customer customer = request.getCustomer();
	
		UserType userType = user.toUserType(customer);
		
		if(Constants.Demo.numberIsAlwaysANewUser.contains(user.getPhoneNumber())) {
			
			logger.info("Using the demo account for phone number: " + user.getPhoneNumber());
			
			//make the points set to 0 for the user at this customer
			PointCategory pointCategory = PointsManager.getDefaultPointCategory(customer);
			UserPoints userPoints = PointsManager.getUserPoints(user, customer, null, pointCategory, null);
			PointsManager.debit(user, customer, null, Type.CHEATING, pointCategory, userPoints.getCurrentBalance());
			user = UserManager.getUser(user.getUserId());
			logger.info("Set points to 0 for phone number: " + user.getPhoneNumber());
			
			userType = user.toUserType(customer);
			userType.setHasPIN(false);
		}
		
		if(!GatewayServlet.isSandbox()) {		
			UserManager.welcomeNewUser(customer, null, user, false, true);
		}
		
		response.get().setUser(userType);		
	}
		
	public static void getMessages(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		User user = request.getUser();
		int returnCount = request.getParameterInt(Constants.Request.RETURN_COUNT,false);

		List<UserMessage> userMessages = MessageManager.getUserMessages(customer, user, returnCount);
		
		if(response.get().getUser() == null) {
			response.get().setUser(user.toUserType(customer));
		}
		response.get().getUser().setMessages(new UserMessagesType());
		for(UserMessage userMessage : userMessages) {
			response.get().getUser().getMessages().getUserMessage().add(userMessage.toUserMessageType());
		}
	}
	
	public static void getRewards(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		Customer customer = request.getCustomer();
		User user = request.getUser();
	
		List<UserReward> userRewards = RewardManager.getActiveRewards(customer, user);
		
		response.get().setUserRewards(new UserRewardsType());
		for(UserReward userReward : userRewards) {
			response.get().getUserRewards().getUserReward().add(userReward.toUserRewardType());
		}
	}
		
	public static void checkin(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();
		Customer customer = request.getCustomer();
		Address address = AddressManager.getAddress(request.getParameterLong(Constants.Request.ADDRESS_ID, true), false);
		CheckinOption checkinOption = CheckinOptionManager.getCheckinOption(request.getParameterLong(Constants.Request.CHECKIN_OPTION_ID, true));
		Integer pointAward = request.getParameterInt(Constants.Request.POINT_AWARD, false);
		Long deviceApplicationId = request.getParameterLong(Constants.Request.DEVICE_APPLICATION_ID, false);
		DeviceApplication deviceApplication = null;
		if(deviceApplicationId != null) {
			deviceApplication = DeviceManager.getDeviceApplication(deviceApplicationId);
		}		
		request.isAuthorized();	//sets the authorization status of the user
		
		if(customer.getCustomerId() != address.getCustomer().getCustomerId()) {
			throw new InvalidParameterException(Constants.Error.PERMISSIONS.INVALID_ADDRESS_FOR_CUSTOMER,ListUtil.from( address.getAddressId() + "",customer.getApiKey()));
		}
		
		if(pointAward == null) {
			if(checkinOption.getType().equals(CheckinOption.Type.VALUE_BASED)) {
				throw new InvalidParameterException(Constants.Error.CHECKIN.POINT_AWARD_MUST_BE_SPECIFIED_FOR_VALUE_BASED_CHECKINS);
			}
			pointAward = (int)checkinOption.getPointAward();
		}else {
			if(checkinOption.getType().equals(CheckinOption.Type.VISIT_BASED)) {
				throw new InvalidParameterException(Constants.Error.CHECKIN.POINT_AWARD_MUST_NOT_BE_SPECIFIED_FOR_VISIT_BASED_CHECKINS);
			}
		}
		
		//do the checkin
		UserCheckin userCheckin = UserManager.checkin(customer, user, address, checkinOption, deviceApplication, pointAward);
		userCheckin.getCheckinOption().setPointAward(pointAward);
		response.get().setCheckin(userCheckin.toUserCheckinType(true));
	}
	
	public static void getCheckins(RewardMeRequest request, RewardMeResponse response) throws InvalidParameterException, FatalException {
		User user = request.getUser();
		Customer customer = request.getCustomer();
		boolean shortFormat = request.getParameterBool(Constants.Request.SHORT_FORMAT, false);
		boolean uniqueCustomersOnly = request.getParameterBool(Constants.Request.UNIQUE_CUSTOMERS_ONLY, false);
		boolean showAllCustomers = request.getParameterBool(Constants.Request.SHOW_ALL_CUSTOMERS, false);
		
		UserType userType = user.toUserType(customer);
		
		if(shortFormat) {
			userType.setShortCheckins(new ShortUserCheckinsType());
			for(UserCheckin.ShortFormat shortUserCheckin : user.getShortUserCheckins(showAllCustomers ? null : customer, uniqueCustomersOnly)) {
				userType.getShortCheckins().getShortCheckin().add(shortUserCheckin.toShortUserCheckinType());
			}
		}else {
			userType.setCheckins(new UserCheckinsType());
			for(UserCheckin userCheckin : user.getUserCheckins(showAllCustomers ? null : customer, uniqueCustomersOnly)) {
				userType.getCheckins().getCheckin().add(userCheckin.toUserCheckinType(false));
			}
		}

		response.get().setUser(userType);
	}
		
}
