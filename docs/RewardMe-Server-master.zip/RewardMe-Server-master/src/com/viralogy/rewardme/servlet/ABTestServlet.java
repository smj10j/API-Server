package com.viralogy.rewardme.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.Constants.NotificationType;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.MessageManager;
import com.viralogy.rewardme.manager.SurveyManager;
import com.viralogy.rewardme.manager.TriggerManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerBroadcastMessage;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserMessage;
import com.viralogy.rewardme.model.UserSurvey;
import com.viralogy.rewardme.util.ListUtil;


public class ABTestServlet extends HttpServlet {
	
	private static final long serialVersionUID = -8290234433215754439L;
	private static Logger logger = Logger.getLogger(ABTestServlet.class);
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        processRequest(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        processRequest(request, response);
    }

	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
		PrintWriter out = response.getWriter();
		
		try {
			
			RewardMeRequest rewardMeRequest = new RewardMeRequest(request);
						
			Long customerId = rewardMeRequest.getParameterLong(Constants.Request.CUSTOMER_ID, false);
			Customer customer = customerId == null ? null : CustomerManager.getCustomer(customerId);
			Long userId = rewardMeRequest.getParameterLong(Constants.Request.USER_ID, false);
			User user = userId == null ? null : UserManager.getUser(userId);
			
			//id-based scheduling
			Long customerBroadcastMessageId = rewardMeRequest.getParameterLong(Constants.Request.CUSTOMER_BROADCAST_MESSAGE_ID, false);
			Long userMessageId = rewardMeRequest.getParameterLong(Constants.Request.USER_MESSAGE_ID, false);
			Long userSurveyId = rewardMeRequest.getParameterLong(Constants.Request.USER_SURVEY_ID, false);
			
			//command-based scheduling
			String action = rewardMeRequest.getParameter(Constants.Request.ACTION, false);
			
			if(customerBroadcastMessageId != null) {
					
				logger.info("Sending scheduled customerBroadcastMessageId="+customerBroadcastMessageId);
				CustomerBroadcastMessage customerBroadcastMessage = MessageManager.getCustomerBroadcastMessage(customerBroadcastMessageId);
				
				if(customerBroadcastMessage.getCustomer().getCustomerId() != customer.getCustomerId()) {
					throw new InvalidParameterException(Constants.Error.INVALID_ID.CUSTOMER_BROADCAST_MESSAGE_ID, ListUtil.from(customerBroadcastMessage.getCustomerBroadcastMessageId()+""));
				}
				
				if(customerBroadcastMessage.isSent()) {
					throw new InvalidParameterException(Constants.Error.GENERAL.CUSTOMER_BROADCAST_MESSAGE_ALREADY_SENT, ListUtil.from(customerBroadcastMessage.getCustomerBroadcastMessageId()+""));				
				}
				
				MessageManager.send(customerBroadcastMessage, NotificationType.TEXT_APP, false);
				
			}else if(userMessageId != null) {
				logger.info("Sending scheduled userMessageId="+userMessageId);
				UserMessage userMessage = MessageManager.getUserMessage(userMessageId);
				
				//notification type
				NotificationType notificationType = rewardMeRequest.getParameterType(Constants.Request.NOTIFICATION_TYPE, NotificationType.class, true);
				
				if(userMessage.getCustomer().getCustomerId() != customer.getCustomerId()) {
					throw new InvalidParameterException(Constants.Error.INVALID_ID.USER_MESSAGE_ID, ListUtil.from(userMessage.getUserMessageId()+""));
				}
				
				if(userMessage.isSent()) {
					throw new InvalidParameterException(Constants.Error.GENERAL.USER_MESSAGE_ALREADY_SENT, ListUtil.from(userMessage.getUserMessageId()+""));				
				}
				
				MessageManager.send(userMessage, notificationType, false);				
				
			}else if(userSurveyId != null) {
				logger.info("Sending scheduled userSurveyId="+userSurveyId);
				UserSurvey userSurvey = SurveyManager.getUserSurvey(userSurveyId);
				
				if(userSurvey.getSurvey().getCustomer().getCustomerId() != customer.getCustomerId()) {
					throw new InvalidParameterException(Constants.Error.INVALID_ID.USER_MESSAGE_ID, ListUtil.from(userSurvey.getSurvey().getSurveyId()+""));
				}
				
				if(userSurvey.isSent()) {
					throw new InvalidParameterException(Constants.Error.SURVEY.USER_SURVEY_ALREADY_SENT, ListUtil.from(userSurvey.getUserSurveyId()+""));				
				}
				
				SurveyManager.send(userSurvey);
				
			}else {
				throw new InvalidParameterException(Constants.Error.GATEWAY.MISSING_REQUIRED_PARAMETER, ListUtil.from(Constants.Request.CUSTOMER_BROADCAST_MESSAGE_ID + ", " + Constants.Request.USER_MESSAGE_ID+ ", " + Constants.Request.USER_SURVEY_ID));								
			}
			
			MySQL.commit();	
			
		} catch (FatalException e) {
			logger.error(e);
			e.printStackTrace();
		} catch (InvalidParameterException e) {
			out.write(e.toString());
			logger.error(e);
		} catch (Exception e) {
			out.write(e.toString());
			e.printStackTrace();
			logger.error(e);
		} finally {
			out.close();
		}
		
	}
}
