package com.viralogy.rewardme.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.NameValuePair;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.manager.ApplicationManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.DeviceManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.DeviceApplication;
import com.viralogy.rewardme.model.UserCheckin;
import com.viralogy.rewardme.pos.Transaction;
import com.viralogy.rewardme.util.RemoteRequestUtil;


public class AdminServlet extends HttpServlet {
	
	private static final long serialVersionUID = -6162607162260574861L;
	private static Logger logger = Logger.getLogger(AdminServlet.class);


	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		processRequest(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    	processRequest(request, response);
    }

	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		    	
		PrintWriter out = response.getWriter();
		
		try {
			Customer customer = CustomerManager.getCustomer(request.getParameter(Constants.Request.API_KEY));
			
			String subscribeServerUrl = "sandbox-subscribe.rewardme.com";
			if(GatewayServlet.isProduction()) {
				subscribeServerUrl = "subscribe.rewardme.com";
			}else if(GatewayServlet.isBeta()) {
				subscribeServerUrl = "beta-subscribe.rewardme.com";
			}
			
			NameValuePair[] parameters = {
				new NameValuePair("_type", "system"),
				new NameValuePair("action", "getDevices"),
			};
					
			String subscribeServerResponse = RemoteRequestUtil.get("https://"+subscribeServerUrl, parameters, false);
			try {
				JSONObject connectedServers = new JSONObject(subscribeServerResponse);
				Set<DeviceApplication> deviceApplications = new LinkedHashSet <DeviceApplication>();
				
		        MySQL mysql = MySQL.getSlaveInstance(true);
	        
		        mysql.query("" +
		                "SELECT * FROM " + MySQL.TABLES.DEVICE_APPLICATION + " da, " + MySQL.TABLES.APPLICATION + " a " +
		        		"WHERE da.application_id = a.application_id AND a.customer_id=? " +
		                "ORDER BY da.application_id ASC, da.address_id ASC", customer.getCustomerId());
		        
		        while(mysql.nextRow()) {
		        	DeviceApplication deviceApplication = null;
		        	try {
		        		deviceApplication = DeviceApplication.from(mysql);
		        	}catch(InvalidParameterException e) {
		        		if(e.code == Constants.Error.INVALID_ID.ADDRESS_ID) {
		        			deviceApplication = new DeviceApplication();
		        			deviceApplication.setApplication(ApplicationManager.getApplication((Long)mysql.getColumn("application_id")));
		        			deviceApplication.setDevice(DeviceManager.getDevice((String)mysql.getColumn("device_id")));	
		        			deviceApplication.setAddress(new Address(deviceApplication.getApplication().getCustomer(), "Unknown - Removed Address", 0, null, null));
		        		}else {
		        			throw e;
		        		}
		        	}
		        	deviceApplications.add(deviceApplication);
		        }

		        
		        //store all info we need to output in one JSONObject.
	            JSONObject devicesList = new JSONObject();

		        //get some basic, reusable information about the device application's current state
		        for(DeviceApplication deviceApplication : deviceApplications) {
		            boolean isOnline = false;
		            JSONObject deviceInfo = new JSONObject();
		            String deviceId = deviceApplication.getDevice().getDeviceId();
		            String location = deviceApplication.getAddress().getAddress().toString();
		      

		            for(int i = 0; i < connectedServers.getJSONArray("clients").length(); i++) {
		            	JSONObject connectedServer = connectedServers.getJSONArray("clients").getJSONObject(i);
		            	JSONObject client = connectedServer.getJSONObject("client");
		            	JSONObject device = client.getJSONObject("device");
		            	if(device.getString("deviceId").equalsIgnoreCase(deviceId)) {
		            		isOnline = true;
		            		break;
		            	}
		            }
		            
		            Transaction lastTransaction = getLastTransaction(deviceApplication);				   
				    UserCheckin lastCheckin = getLastCheckin(deviceApplication);
				    
				    deviceInfo.put("Device", deviceId);
				    deviceInfo.put("Location", location);
				    deviceInfo.put("Status", isOnline);
				    deviceInfo.put("Last Transaction", lastTransaction == null ? null : lastTransaction.getCreated().getTime());
				    deviceInfo.put("Last Checkin", lastCheckin == null ? null : lastCheckin.getCreated().getTime());
				    
				    devicesList.put(deviceId, deviceInfo);

		        }
		        
		        out.write(devicesList.toString());

		        
				MySQL.commit();
				
			} catch (JSONException e) {
				e.printStackTrace();
				logger.error("Failed to parse JSON from " + subscribeServerUrl + ", received: " + subscribeServerResponse);
			} catch (InvalidParameterException e) {
				e.printStackTrace();
			}
			
		
		} catch (FatalException e) {
			logger.error(e);
			e.printStackTrace();
		} /*catch (InvalidParameterException e) {
			out.write(e.toString());
			logger.error(e);
		} catch (IllegalAccessException e) {
			logger.error(e);
			e.printStackTrace();
		}*/ catch (IllegalArgumentException e) {
			logger.error(e);
			e.printStackTrace();
		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
		} finally {
			out.close();
			
		}
	}

		
	

	public static Transaction getLastTransaction(DeviceApplication deviceApplication) throws InvalidParameterException, FatalException {	
		
		Transaction transaction = null;
		try {
			transaction = DeviceManager.getLastTransaction(deviceApplication);
		}catch(InvalidParameterException e) {
			if(e.code == Constants.Error.INVALID_ID.ADDRESS_ID) {
				transaction = new Transaction();
				transaction.setDevice(deviceApplication.getDevice());
				transaction.setCreated(Calendar.getInstance().getTime());
			}else if(e.code == Constants.Error.INVALID_ID.TRANSACTION_BY_DEVICE_APPLICATION_ID) {
				transaction = new Transaction();
				transaction.setDevice(deviceApplication.getDevice());
				transaction.setCreated(Calendar.getInstance().getTime());
			}else {
				throw e;
			}
		}

		return transaction;
	}

	
	public static UserCheckin getLastCheckin(DeviceApplication deviceApplication) throws InvalidParameterException, FatalException {	
        
		UserCheckin userCheckin = null;
    	try {
    		userCheckin = DeviceManager.getLastCheckin(deviceApplication);
    	}catch(InvalidParameterException e) {
    		if(e.code == Constants.Error.INVALID_ID.ADDRESS_ID) {
    			userCheckin = new UserCheckin();
    			userCheckin.setDeviceApplication(deviceApplication);
    			userCheckin.setCreated(Calendar.getInstance().getTime());
    		}else if(e.code == Constants.Error.INVALID_ID.USER_CHECKIN_BY_DEVICE_APPLICATION_ID) {
    			userCheckin = new UserCheckin();
    			userCheckin.setDeviceApplication(deviceApplication);
    			userCheckin.setCreated(Calendar.getInstance().getTime());
			}else {
    			throw e;
    		}
    	}
		return userCheckin;
	}	
	

	
}


