package com.viralogy.rewardme.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.CustomerDAO;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.dao.UserDAO;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.AdminManager;
import com.viralogy.rewardme.manager.DeviceManager;
import com.viralogy.rewardme.manager.EventManager;
import com.viralogy.rewardme.manager.SegmentManager;
import com.viralogy.rewardme.model.Event;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.Segment;
import com.viralogy.rewardme.util.RemoteRequestUtil;
import com.viralogy.rewardme.util.StringUtil;
import com.viralogy.rewardme.util.WhitelistUtil;


public class AsynchronousLoggingServlet extends HttpServlet {
	
	private static final long serialVersionUID = -8290234433215754439L;
	private static Logger logger = Logger.getLogger(AsynchronousLoggingServlet.class);
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        processRequest(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        processRequest(request, response);
    }

	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
		PrintWriter out = response.getWriter();
		
		try {
			
			RewardMeRequest rewardMeRequest = new RewardMeRequest(request);

			WhitelistUtil.validate(rewardMeRequest.getIp());

			Long userId = rewardMeRequest.getParameterLong(Constants.Request.USER_ID, false);
			Long customerId = rewardMeRequest.getParameterLong(Constants.Request.CUSTOMER_ID, false);
			Long addressId = rewardMeRequest.getParameterLong(Constants.Request.ADDRESS_ID, false);
			Long secretKeyId = rewardMeRequest.getParameterLong(Constants.Request.SECRET_KEY_ID, false);
			String deviceId = rewardMeRequest.getParameter(Constants.Request.DEVICE_ID, false);
			String name = rewardMeRequest.getParameter(Constants.Request.NAME, true);
			String value = rewardMeRequest.getParameter(Constants.Request.VALUE, false);
			Boolean admin = rewardMeRequest.getParameterBool(Constants.Request.ADMIN, false);
			
			Event event = new Event(
				customerId == null ? null : CustomerDAO.getCustomer(customerId), 
				userId == null ? null : UserDAO.getUser(userId), 
				StringUtil.isNullOrEmpty(deviceId) ? null : DeviceManager.getDevice(deviceId), 
				addressId == null ? null : AddressManager.getAddress(addressId, false), 
				name, 
				value, 
				admin == null ? false : admin, secretKeyId == null ? null : AdminManager.getSecretKey(secretKeyId) 
			);
			EventManager.save(event);
			
			if (customerId != null && !name.equals("customer.remove") && !name.equals("segment.save") && !name.equals("segment.remove") && !name.equals("segment.getAvailableToUser")) {
				long segmentsStartTime = System.currentTimeMillis();
				if (addressId != null && !name.equals("address.remove")) {
					long getAllSegmentsStartTime = System.currentTimeMillis();
					boolean first = true;
					for (Segment segment : SegmentManager.getAllSegments(event.getCustomer(), event.getAddress())) {//get all nonglobal segments
						if (first) {
							long getAllSegmentsElapsed =  (System.currentTimeMillis() - getAllSegmentsStartTime);
							logger.info("Nonglobal getAllSegments took : " + getAllSegmentsElapsed + "ms with customer: " + event.getCustomer().getApiKey() + " and address: " + event.getAddress());
							first = false;
						}
						long processStartTime = System.currentTimeMillis();
						SegmentManager.processSegment(segment, event);
						long processElapsed =  (System.currentTimeMillis() - processStartTime);
						logger.info("Segment: " + segment.getSegmentId() + " with definition: " + segment.getDefinition() + " took " + processElapsed + "ms in Thread: " + Thread.currentThread().getId());
					}
				}
				long getAllSegmentsStartTime = System.currentTimeMillis();
				boolean first2 = true;
				for (Segment segment : SegmentManager.getAllSegments(event.getCustomer(), null)) {//get all global segments, the event can be "customer.remove, where it removes it first and then attempts this.
					if (first2) {
						long getAllSegmentsElapsed = (System.currentTimeMillis() - getAllSegmentsStartTime);
						logger.info("Global getAllSegments took : " + getAllSegmentsElapsed + "ms with customer: " + event.getCustomer().getApiKey());
						first2 = false;
					}
					long processStartTime = System.currentTimeMillis();
					SegmentManager.processSegment(segment, event);
					long processElapsed =  (System.currentTimeMillis() - processStartTime);
					logger.info("Segment: " + segment.getSegmentId() + " with definition: " + segment.getDefinition() + " took " + processElapsed + "ms in Thread: " + Thread.currentThread().getId());
				}
				long segmentsElapsed =  (System.currentTimeMillis() - segmentsStartTime);
				logger.info("Total time processing all segments took: " + segmentsElapsed + "ms");
			}			

			if(SchedulerServlet.CAN_PROCESS_SCHEDULED_TASKS && 
					(System.currentTimeMillis() - SchedulerServlet.LAST_PROCESS_SCHEDULED_TASKS_TIMESTAMP > (Constants.Time.MINUTE * 1000))) {
				//check at most once a minute for scheduled tasks to process
				RemoteRequestUtil.get(GatewayServlet.getLocalServerBaseUrl() + "schedule", "", true);
			}

			MySQL.commit();	
			
		} catch (FatalException e) {
			logger.error(e);
			e.printStackTrace();
			try {
				MySQL.rollback();
			} catch (FatalException e1) {
				logger.error("Failed to rollback in AsynchronousLoggingServlet after FatalException!");
				e1.printStackTrace();
			}
		} catch (InvalidParameterException e) {
			out.write(e.toString());
			logger.error(e);
			try {
				MySQL.rollback();
			} catch (FatalException e1) {
				logger.error("Failed to rollback in AsynchronousLoggingServlet after InvalidParameterException!");
				e1.printStackTrace();
			}
		} finally {
			out.close();
		}
		
	}
}
