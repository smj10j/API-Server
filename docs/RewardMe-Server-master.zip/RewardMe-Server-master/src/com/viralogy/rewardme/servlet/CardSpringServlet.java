package com.viralogy.rewardme.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.CustomerManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.CardSpringTransaction;
import com.viralogy.rewardme.model.CardSpringTransaction.Type;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.RewardMeRequest;

public class CardSpringServlet extends HttpServlet {

	private static final long serialVersionUID = 4006065853373294042L;

	private static Logger logger = Logger.getLogger(CardSpringServlet.class);

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		processRequest(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		processRequest(request, response);
	}

	protected void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		RewardMeRequest req = new RewardMeRequest(request);

		try {
			Type type;
			if (req.getParameter("event_type").equals(Type.AUTHORIZATION.value))
				type = Type.AUTHORIZATION;
			else
				type = Type.SETTLEMENT;
			DateFormat df = new SimpleDateFormat("yyyy-MM-DD HH:mm:ss");
			Customer customer = CustomerManager.getCustomerFromCardspring(req.getParameter("business_id"));
			if (customer == null){
				logger.warn("Cardspring Business Id has no matching customer");
			} else {
				CardSpringTransaction cst = new CardSpringTransaction(
					UserManager.getUser(req.getParameterLong("user_id", true)),
					customer,
					type, 
					req.getParameterLong("amount", true), 
					req.getParameter("currency"),
					df.parse(req.getParameter("purchase_date_time"))
				);
				cst.save();
			
				Address addr = null;
				addr = AddressManager.getAddressFromCardspring(req.getParameter("store_id"), customer);
				if (addr == null){
					logger.warn("Cardspring Store Id has no matching address");
				} else {
					UserManager.checkin(customer, cst.getUser(),addr , customer.getCheckinOptions().get(0), null, (int) (customer.getCheckinOptions().get(0).getPointAward()*Math.round(cst.getAmount())));
					MySQL.commit();
				}
			}

		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
		} finally {
			out.close();
		}

	}
}
