package com.viralogy.rewardme.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.NameValuePair;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.manager.ApplicationManager;
import com.viralogy.rewardme.manager.DeviceManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.CustomerContact;
import com.viralogy.rewardme.model.DeviceApplication;
import com.viralogy.rewardme.model.DeviceLink;
import com.viralogy.rewardme.model.GeoCoord;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.util.DateUtil;
import com.viralogy.rewardme.util.EmailUtil;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.RemoteRequestUtil;
import com.viralogy.rewardme.util.ServletUtil;
import com.viralogy.rewardme.util.ShellUtil;
import com.viralogy.rewardme.util.StringUtil;

public class DeviceServlet extends HttpServlet {

	private static final long serialVersionUID = -6162607162260574861L;
	private static Logger logger = Logger.getLogger(DeviceServlet.class);

	private static String timezoneOffset = " - interval 7 hour";

	private static Map<String, Method> sectionMap = new HashMap<String, Method>();
	static {
		try {
			sectionMap.put("getDevices", DeviceServlet.class.getDeclaredMethod(
					"getDevices", RewardMeRequest.class, PrintWriter.class,
					CustomerContact.class));
		} catch (NoSuchMethodException e) {
			logger.error(e);
			e.printStackTrace();
		} catch (SecurityException e) {
			logger.error(e);
			e.printStackTrace();
		}
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		processRequest(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		processRequest(request, response);
	}

	protected void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// MonitorServlet requires HTTPS via Nginx (otherwise basic auth would
		// be a horrible idea!)
		// requires basic authentication with phone/pin
		CustomerContact customerContact = ServletUtil.authorize(request,
				response,
				"Enter your credentials to access RewardMe Monitoring");
		if (customerContact == null) {
			return;
		}

		PrintWriter out = response.getWriter();
		RewardMeRequest rewardMeRequest = new RewardMeRequest(request);
		getDevices(rewardMeRequest, out, customerContact);

		out.close();
	}

	private static void updatelastTxAndCheckin(
			DeviceApplication deviceApplication,
			Map<DeviceApplication, Date> deviceApplicationLastCheckinDate,
			Map<DeviceApplication, Date> deviceApplicationLastTransactionDate)
			throws FatalException {

		MySQL mysql = MySQL.getSlaveInstance(true);

		mysql.query(
				"SELECT (created"
						+ timezoneOffset
						+ ") as 'last_checkin' FROM "
						+ MySQL.TABLES.USER_CHECKIN
						+ " WHERE device_application_id=? ORDER BY created DESC LIMIT 1",
				deviceApplication.getDeviceApplicationId());
		if (mysql.nextRow()) {
			deviceApplicationLastCheckinDate.put(deviceApplication,
					(Date) mysql.getColumn("last_checkin"));
		}

		mysql.query("SELECT (created" + timezoneOffset + ") as 'last_tx' FROM "
				+ MySQL.TABLES.POS.TX
				+ " WHERE device_id=? ORDER BY created DESC LIMIT 1",
				deviceApplication.getDevice().getDeviceId());
		if (mysql.nextRow()) {
			deviceApplicationLastTransactionDate.put(deviceApplication,
					(Date) mysql.getColumn("last_tx"));
		}
	}

	private static void getDevices(RewardMeRequest request, PrintWriter out,
			CustomerContact customerContact) {
		try {
			Set<DeviceApplication> deviceApplications = new LinkedHashSet<DeviceApplication>();

			Map<DeviceApplication, Date> deviceApplicationLastCheckinDate = new HashMap<DeviceApplication, Date>();
			Map<DeviceApplication, Date> deviceApplicationLastTransactionDate = new HashMap<DeviceApplication, Date>();
			MySQL mysql;
			NameValuePair[] parameters = {
					new NameValuePair("_type", "system"),
					new NameValuePair("action", "getDevices"), };
			String subscribeServerUrl = "sandbox-subscribe.rewardme.com";
			if (GatewayServlet.isProduction()) {
				subscribeServerUrl = "subscribe.rewardme.com";
			} else if (GatewayServlet.isBeta()) {
				subscribeServerUrl = "beta-subscribe.rewardme.com";
			}
			String subscribeServerResponse;
			subscribeServerResponse = RemoteRequestUtil.get("https://"
					+ subscribeServerUrl, parameters, false);
			JSONObject connectedServers = new JSONObject(
					subscribeServerResponse);
			mysql = MySQL.getSlaveInstance(true);

			mysql.query(""
					+ "SELECT da.* "
					+ "FROM "
					+ MySQL.TABLES.DEVICE_APPLICATION
					+ " da, "
					+ MySQL.TABLES.APPLICATION
					+ " a "
					+ "WHERE da.application_id=a.application_id "
					+ (customerContact.getCustomer() == null ? ""
							: " AND a.customer_id=? ")
					+ "ORDER BY da.application_id ASC,da.address_id ASC",
					customerContact.getCustomer() == null ? null
							: customerContact.getCustomer().getCustomerId());

			while (mysql.nextRow()) {
				DeviceApplication deviceApplication = null;
				try {
					deviceApplication = DeviceApplication.from(mysql);
				} catch (InvalidParameterException e) {
					if (e.code == Constants.Error.INVALID_ID.ADDRESS_ID) {
						deviceApplication = new DeviceApplication();
						deviceApplication.setApplication(ApplicationManager
								.getApplication((Long) mysql
										.getColumn("application_id")));
						deviceApplication.setDevice(DeviceManager
								.getDevice((String) mysql
										.getColumn("device_id")));
						deviceApplication.setAddress(new Address(
								deviceApplication.getApplication()
										.getCustomer(),
								"Unknown - Removed Address", 0, null, null));
					} else {
						throw e;
					}
				}

				updatelastTxAndCheckin(deviceApplication,
						deviceApplicationLastCheckinDate,
						deviceApplicationLastTransactionDate);

				deviceApplications.add(deviceApplication);
			}
			boolean padded = false;
			if (request.getParameter("callback") != null) {
				padded = true;
			}
			if (padded) {
				out.write(request.getParameter("callback") + "(");
			}
			JSONArray output = new JSONArray();
			for (DeviceApplication dev : deviceApplications) {
				GeoCoord address = dev.getAddress().getGeoCoord();
				JSONObject devApp = new JSONObject();
				devApp.put("status", "offline");
				for (int i = 0; i < connectedServers.getJSONArray("clients")
						.length(); i++) {
					JSONObject connectedServer = connectedServers.getJSONArray(
							"clients").getJSONObject(i);
					JSONObject client = connectedServer.getJSONObject("client");
					JSONObject device = client.getJSONObject("device");
					if (device.getString("deviceId").equalsIgnoreCase(
							dev.getDevice().getDeviceId())) {
						devApp.put("status", "online");
						break;
					}
				}
				devApp.put("id", dev.getDeviceApplicationId());
				JSONObject device = new JSONObject();
				device.put("deviceId", dev.getDevice().getDeviceId());
				device.put("model", dev.getDevice().getModel());
				device.put("osName", dev.getDevice().getOsName());
				device.put("osVersion", dev.getDevice().getOsVersion());
				device.put("removeDeviceUUID", dev.getDevice()
						.getRemoteDeviceUUID());
				JSONObject customer = new JSONObject();
				customer.put("name", dev.getApplication().getCustomer()
						.getName());
				customer.put("application", dev.getApplication().getName());
				String addr = dev.getAddress().getAddress();
				customer.put("city", addr.substring(addr.indexOf(",") + 1)
						.trim());
				device.put("deviceId", dev.getDevice().getDeviceId());
				device.put("model", dev.getDevice().getModel());
				device.put("osName", dev.getDevice().getOsName());
				device.put("osVersion", dev.getDevice().getOsVersion());
				device.put("removeDeviceUUID", dev.getDevice()
						.getRemoteDeviceUUID());
				devApp.put("device", device);
				devApp.put("customer", customer);
				devApp.put("addressId", dev.getAddress().getAddressId());
				devApp.put("address", dev.getAddress().getAddress());
				devApp.put("latitude", address.getLatitude());
				devApp.put("longitude", address.getLongitude());
				devApp.put("lastCheckin",
						deviceApplicationLastCheckinDate.get(dev));
				devApp.put("lastTransaction",
						deviceApplicationLastCheckinDate.get(dev));

				output.put(devApp);
			}
			out.write(output.toString());
			if (padded) {
				out.write(");");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
