package com.viralogy.rewardme.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.manager.MessageManager;
import com.viralogy.rewardme.manager.PointsManager;
import com.viralogy.rewardme.manager.PreferencesManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.model.PointCategory;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserMessage;
import com.viralogy.rewardme.model.UserPoints;
import com.viralogy.rewardme.model.UserPreference;
import com.viralogy.rewardme.social.Facebook;
import com.viralogy.rewardme.social.Social;
import com.viralogy.rewardme.social.Social.Type;
import com.viralogy.rewardme.util.Cache;
import com.viralogy.rewardme.util.JSONUtil;
import com.viralogy.rewardme.util.StringUtil;

public class FacebookServlet extends HttpServlet{

	private static final long serialVersionUID = -1318007478583232937L;
	private static Logger logger = Logger.getLogger(FacebookServlet.class);
	
	private Social.Type type = Social.Type.FACEBOOK;
    
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        processRequest(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        processRequest(request, response);
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) {
        
		RewardMeRequest rewardMeRequest = new RewardMeRequest( request);
		PrintWriter out = null;
   	
        try {
    		try {
				out = response.getWriter();
			} catch (IOException e) {
				throw new FatalException(e);
			}
       	
    		String action = rewardMeRequest.getParameter(Constants.Request.ACTION);
    		if(!StringUtil.isNullOrEmpty(action)) {
    			if(action.toLowerCase().equals("canvas")) {
    				out.println("<script>window.location.href = 'http://'"+Constants.URL.MY_REWARDME+"</script>");
    			}
    		}else {
        	
    			//facebook connect
    			
				String authCode = null;
				String requestURI = request.getRequestURI();
				String withoutLastSlash = requestURI.substring(0, requestURI.length()-1);
				String md5PhoneNumber = withoutLastSlash.substring(withoutLastSlash.lastIndexOf('/') + 1);
				String phoneNumber = Cache.get(md5PhoneNumber, Cache.namespace.MD5_PHONE_NUMBER_TO_PHONE_NUMBER);
				
				if(StringUtil.isNullOrEmpty(phoneNumber)) {
					logger.warn("phoneNumber was not in cache when looked up by the Facebook servlet");
					return;
				}
				
				User user = UserManager.getUserByPhoneNumber(phoneNumber);
	
				Social social = new Social(user, true);
				if( !social.isEnabled(type)) {
					
					try {
						authCode = rewardMeRequest.getParameter(Constants.Oauth.AUTH_CODE);
					} catch(InvalidParameterException e ) {
						// user had denied access
					} 
					
					if( !StringUtil.isNullOrEmpty(authCode) && !JSONUtil.isJSON(authCode) ) {
						String accessToken = Facebook.getAccessToken( authCode, md5PhoneNumber );
						UserPreference userPreference = new UserPreference( user, null, Constants.UserPreference.FACEBOOK_ACCESS_TOKEN, accessToken);
						PreferencesManager.save(userPreference);
						
						//do any thing that should occur at auth (like post-dated checkins!)
						social.refreshAccessTokens();
						
						//do anything that happens on connect
						social.onConnect(Type.FACEBOOK);
	
						//give the user 50 points for connecting
						UserMessage lastUserMessage = MessageManager.getLastUserMessage(user);
						if(lastUserMessage != null) {
							PointCategory pointCategory = PointsManager.getDefaultPointCategory(lastUserMessage.getCustomer());
							PointsManager.credit(user, lastUserMessage.getCustomer(), null, UserPoints.Type.SOCIAL, pointCategory, 50);
						}else {
							//TODO: rewardme points?
							//PointsManager.credit(user, UserPoints.Type.SOCIAL, 100);						
						}
						
	
					} else {
						logger.warn("Access denied: " + authCode);
					}
				}

				logger.debug("Sending them to: " + Constants.Oauth.SUCCESSFUL_CONNECT_CONFIRMATION_URL);
				out.println("<script>window.location.href = '" + Constants.Oauth.SUCCESSFUL_CONNECT_CONFIRMATION_URL +"'</script>");

				MySQL.commit();	

    		}
			
			
		} catch(InvalidParameterException e) {
        	
        	try {
				MySQL.rollback();
			} catch (FatalException e1) {
				e1.printStackTrace();
			}
        	logger.error( e );
        } catch( FatalException e ) {
  
        	try {
				MySQL.rollback();
			} catch (FatalException e1) {
				e1.printStackTrace();
			}
			logger.error( e );
        } finally {
        	if(out != null) {
        		out.close();
        	}
		}
    }   
}
