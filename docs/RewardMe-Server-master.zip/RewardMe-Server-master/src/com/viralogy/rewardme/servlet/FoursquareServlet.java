package com.viralogy.rewardme.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.manager.MessageManager;
import com.viralogy.rewardme.manager.PointsManager;
import com.viralogy.rewardme.manager.PreferencesManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.model.PointCategory;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserMessage;
import com.viralogy.rewardme.model.UserPoints;
import com.viralogy.rewardme.model.UserPreference;
import com.viralogy.rewardme.social.Foursquare;
import com.viralogy.rewardme.social.Social;
import com.viralogy.rewardme.social.Social.Type;
import com.viralogy.rewardme.util.Cache;
import com.viralogy.rewardme.util.JSONUtil;
import com.viralogy.rewardme.util.StringUtil;

public class FoursquareServlet extends HttpServlet{

	private static final long serialVersionUID = 5072250215401645866L;
	private static Logger logger = Logger.getLogger(FoursquareServlet.class);
	
	private Social.Type type = Social.Type.FOURSQUARE;
    
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        processRequest(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        processRequest(request, response);
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) {
        
        try {
			RewardMeRequest rewardMeRequest = new RewardMeRequest( request);
			String authCode = null;
			String requestURI = request.getRequestURI();
			String withoutLastSlash = requestURI.substring(0, requestURI.length()-1);
			String md5PhoneNumber = withoutLastSlash.substring(withoutLastSlash.lastIndexOf('/') + 1);
			logger.debug("md5 phone number: " + md5PhoneNumber);
			String phoneNumber = Cache.get(md5PhoneNumber, Cache.namespace.MD5_PHONE_NUMBER_TO_PHONE_NUMBER);
			logger.debug("Phone Number: " + phoneNumber);
			
			User user = UserManager.getUserByPhoneNumber(phoneNumber);
			
			Social social = new Social(user, true);
			if( !social.isEnabled(type)) {
				
				logger.debug("User id: " + user.getUserId());
				
				try {
					authCode = rewardMeRequest.getParameter(Constants.Oauth.AUTH_CODE);
				} catch(InvalidParameterException e ) {
					// user had denied access
				} 
				
				
				if( !StringUtil.isNullOrEmpty(authCode) && !JSONUtil.isJSON(authCode) ) {
					logger.debug("Received auth code: " + authCode);
					
					String accessToken = Foursquare.getAccessToken( authCode, md5PhoneNumber );
					logger.debug("Access Token: " + accessToken);
					UserPreference userPreference = new UserPreference( user, null, Constants.UserPreference.FOURSQUARE_ACCESS_TOKEN, accessToken);
					PreferencesManager.save(userPreference);

					//do anything that happens on connect
					social.onConnect(Type.FOURSQUARE);					
					
					//give the user 50 points for connecting
					UserMessage lastUserMessage = MessageManager.getLastUserMessage(user);
					if(lastUserMessage != null) {
						PointCategory pointCategory = PointsManager.getDefaultPointCategory(lastUserMessage.getCustomer());
						PointsManager.credit(user, lastUserMessage.getCustomer(), null, UserPoints.Type.SOCIAL, pointCategory, 50);
					}else {
						//TODO: rewardme points?
						//PointsManager.credit(user, UserPoints.Type.SOCIAL, 100);						
					}
					
				} else {
					logger.debug("Access denied: " + authCode);
				}
			}
			
			try {
				PrintWriter out = response.getWriter();
				logger.debug("Sending them to: " + Constants.Oauth.SUCCESSFUL_CONNECT_CONFIRMATION_URL);
				out.println("<script>window.location.href = '" + Constants.Oauth.SUCCESSFUL_CONNECT_CONFIRMATION_URL +"'</script>");
			} catch( IOException e ) {
				throw new FatalException (e);
			}
			
			MySQL.commit();	
			
		} catch(InvalidParameterException e) {
        	
        	try {
        		logger.debug("About to roll back because of InvalidParam");
				MySQL.rollback();
			} catch (FatalException e1) {
				e1.printStackTrace();
			}
        	logger.error( e );
        } catch( FatalException e ) {
  
        	try {
        		logger.debug("About to roll back because of FatalException");
				MySQL.rollback();
			} catch (FatalException e1) {
				e1.printStackTrace();
			}
			logger.error( e );
        }
    }   
}
