package com.viralogy.rewardme.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.service.CustomerInvoiceService;
import com.viralogy.rewardme.util.FreshbooksUtil;

public class FreshbooksServlet extends HttpServlet{

    private static final long serialVersionUID = 830662840670411013L;
    private static Logger logger = Logger.getLogger(FreshbooksServlet.class);
    
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        processRequest(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        processRequest(request, response);
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) {
        logger.debug("Request URL: " + request.getRequestURL());            
        logger.debug("Request URI: " + request.getRequestURI());            
        logger.debug("Request QueryString: " + request.getQueryString());   

        try {
            RewardMeRequest rewardMeRequest = new RewardMeRequest( request);

            String system = rewardMeRequest.getParameter(Constants.Request.SYSTEM);
            String methodName = rewardMeRequest.getParameter(Constants.Freshbooks.NAME, true);
            Long userId = rewardMeRequest.getParameterLong(Constants.Freshbooks.USER_ID, true);
            Long objectId = rewardMeRequest.getParameterLong(Constants.Freshbooks.OBJECT_ID, true);

            logger.debug("Method name: " + methodName);
            logger.debug("User Id: " + userId);
            logger.debug("Object Id: " + objectId );
            
            if( FreshbooksUtil.getSystemUrl(!request.getRequestURL().toString().contains("gerald")).equals( system ) && Constants.Freshbooks.DEFAULT_USER_ID == userId ) {
                logger.debug("Valid webhooks request");
                
                if( Constants.Freshbooks.CREATE_INVOICE.equals( methodName )) {
                    CustomerInvoiceService.saveInvoice( rewardMeRequest );
                } else if( Constants.Freshbooks.CREATE_PAYMENT.equals( methodName )) {
                	CustomerInvoiceService.savePayment( rewardMeRequest );
                }
            }

            MySQL.commit(); 
            
        } catch(InvalidParameterException e) {
        	
        	/* TODO: Freshbooks: rollback freshbooks account */
        	
        	try {
				MySQL.rollback();
			} catch (FatalException e1) {
				e1.printStackTrace();
			}
        	logger.error( e );
        } catch( FatalException e ) {
  
        	/* TODO: Freshbooks: rollback freshbooks account */

        	try {
				MySQL.rollback();
			} catch (FatalException e1) {
				e1.printStackTrace();
			}
			logger.error( e );
        }
        
    }
}
