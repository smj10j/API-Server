package com.viralogy.rewardme.servlet;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.NameValuePair;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.manager.ApplicationManager;
import com.viralogy.rewardme.manager.DeviceManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.CustomerContact;
import com.viralogy.rewardme.model.DeviceApplication;
import com.viralogy.rewardme.model.DeviceLink;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.util.DateUtil;
import com.viralogy.rewardme.util.EmailUtil;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.RemoteRequestUtil;
import com.viralogy.rewardme.util.ServletUtil;
import com.viralogy.rewardme.util.ShellUtil;
import com.viralogy.rewardme.util.StringUtil;

public class MonitorServlet extends HttpServlet {

	private static final long serialVersionUID = -6162607162260574861L;
	private static Logger logger = Logger.getLogger(MonitorServlet.class);

	private static String mysqlHost = "db-slave.rewardme.com";
	private static String timezoneOffset = " - interval 7 hour";
	private static String monitorHtml = "";
	private static Map<String, Method> sectionMap = new HashMap<String, Method>();
	static {
		try {
			sectionMap.put("subscribe", MonitorServlet.class.getDeclaredMethod(
					"subscribe", RewardMeRequest.class, PrintWriter.class,
					CustomerContact.class));
			sectionMap.put("subscribeOld", MonitorServlet.class
					.getDeclaredMethod("subscribeOld", RewardMeRequest.class,
							PrintWriter.class, CustomerContact.class));
			sectionMap.put("checkins", MonitorServlet.class.getDeclaredMethod(
					"checkins", RewardMeRequest.class, PrintWriter.class,
					CustomerContact.class));
			sectionMap.put("errors", MonitorServlet.class.getDeclaredMethod(
					"errors", RewardMeRequest.class, PrintWriter.class,
					CustomerContact.class));
			sectionMap.put("disconnects", MonitorServlet.class
					.getDeclaredMethod("disconnects", RewardMeRequest.class,
							PrintWriter.class, CustomerContact.class));

		} catch (NoSuchMethodException e) {
			logger.error(e);
			e.printStackTrace();
		} catch (SecurityException e) {
			logger.error(e);
			e.printStackTrace();
		}
	}

	@Override
	public void init() {
		FileInputStream fis;
		InputStreamReader in;
		monitorHtml = "No response";
		try {
			fis = new FileInputStream(Constants.SERVLET_CONTEXT_PATH
					+ "WEB-INF/monitor/monitor.html");
			in = new InputStreamReader(fis);
			Scanner s = new Scanner(in);
			monitorHtml = "";
			while (s.hasNextLine()) {
				monitorHtml += s.nextLine() + "\n";
			}
		} catch (IOException e) {
			monitorHtml = e.getMessage();
		}
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		processRequest(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		processRequest(request, response);
	}

	protected void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// MonitorServlet requires HTTPS via Nginx (otherwise basic auth would
		// be a horrible idea!)
		// requires basic authentication with phone/pin
		CustomerContact customerContact = ServletUtil.authorize(request,
				response,
				"Enter your credentials to access RewardMe Monitoring");
		if (customerContact == null) {
			return;
		}

		PrintWriter out = response.getWriter();
		RewardMeRequest rewardMeRequest = new RewardMeRequest(request);

		// at this point the user is authorized - let's see for which servers

		String section = null;
		try {
			section = rewardMeRequest.getParameter("section", false);
		} catch (InvalidParameterException e1) {
			e1.printStackTrace();
		}

		try {

			out.write("<html><head><title>RewardMe API Monitor</title></head>");
			out.write("<body>");

			if (StringUtil.isNullOrEmpty(section)) {
				index(rewardMeRequest, out);

			} else if (sectionMap.containsKey(section)) {
				sectionMap.get(section).invoke(null, rewardMeRequest, out,
						customerContact);
			}

			out.write("</body></html>");

			/*
			 * We want to periodically check the health of the servers This page
			 * is loaded frequently - so let's do it here
			 */
			checkEventLogHealth();

			if (DateUtil.getCurrentMinute() <= 5
					&& DateUtil.getCurrentHour() % 8 == 0) {
				// periodically update the calendar table
				MySQL mysql = MySQL.getInstance(true);
				mysql.query("INSERT IGNORE INTO " + MySQL.TABLES.CALENDAR
						+ " (date) (SELECT created FROM "
						+ MySQL.TABLES.USER_CHECKIN
						+ " GROUP BY date(created));");
			}

			MySQL.commit();

		} catch (FatalException e) {
			logger.error(e);
			e.printStackTrace();
		} /*
		 * catch (InvalidParameterException e) { out.write(e.toString());
		 * logger.error(e); }
		 */catch (IllegalAccessException e) {
			logger.error(e);
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			logger.error(e);
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			logger.error(e);
			e.printStackTrace();
		} finally {
			out.close();
		}

	}

	private static void checkEventLogHealth() throws FatalException {

		MySQL mysql = MySQL.getSlaveInstance(true);

		String eventName = "user.get";
		double countNow = 0;
		double countLastWeek = 0;

		mysql.query("select count(*) as 'count' from " + MySQL.TABLES.EVENT
				+ " where name='" + eventName
				+ "' and created>= utc_timestamp()-interval 1 day");
		if (mysql.nextRow()) {
			Object rawCountValue = MySQL.getValue(mysql, "count");
			try {
				countNow = (Double) rawCountValue;
			} catch (ClassCastException e) {
				countNow = (Long) rawCountValue;
			}
		}
		logger.debug("Number of " + eventName + " requests in the last day: "
				+ countNow);

		mysql.query("select count(*) as 'count' from " + MySQL.TABLES.EVENT
				+ " where name='" + eventName
				+ "' and created>= utc_timestamp()-interval 7 day");
		if (mysql.nextRow()) {

			Object rawCountValue = MySQL.getValue(mysql, "count");
			try {
				countLastWeek = (Double) rawCountValue;
			} catch (ClassCastException e) {
				countLastWeek = (Long) rawCountValue;
			}
		}

		double countLastWeekAvg = Math.round(countLastWeek / 7);
		logger.debug("Average Number of " + eventName
				+ " requests each day in the last week: " + countLastWeekAvg);

		double diffPercent = Math.round(Math.abs((countNow - countLastWeekAvg)
				/ countLastWeekAvg) * 100);
		logger.debug("Number of " + eventName + " requests is " + diffPercent
				+ "% off of what it was in the past week");

		if (diffPercent >= 10 && DateUtil.getCurrentMinute() <= 5
				&& DateUtil.getCurrentHour() % 6 == 0) {
			try {
				String subject = "Abnormal " + eventName + " Event Log on " + GatewayServlet.getHostname() + "!";
				String body = "Count now: " + countNow + "\n"
						+ "Average Count each day last week: "
						+ countLastWeekAvg + "\n" + "Percentage difference: "
						+ diffPercent + "%\n" + "Time: "
						+ (new Date()).toString();

				EmailUtil.email(null, "warn-notifier", ListUtil.from(EmailUtil.getInternalAdminEmail()), subject, body.getBytes(), "txt", null);

			} catch (FatalException e) {
				// oh bonkers
				logger.error("Error while trying to email admins about abnormal event log!", e);
			} catch (InvalidParameterException e) {
				logger.error("Error while trying to email admins about abnormal event log!", e);
			}
		}

	}

	// row and column are 0-based
	private static String getMetric(Map<String, List<String>> commandToOutput,
			String command, List<String> input, String separator, int row,
			int column) throws FatalException {

		String result = null;

		String key = command;
		if (input != null) {
			for (String line : input) {
				key += "." + line;
			}
		}
		List<String> output = commandToOutput.get(key);
		if (output == null) {
			// logger.debug("Running " + command);
			output = ShellUtil.exec(command, input);
			// logger.debug("Finished running " + command);

			for (int i = 0; i < output.size(); i++) {
				output.set(i, output.get(i).trim());
				// logger.debug(output.get(i));
			}

			commandToOutput.put(key, output);
		}

		if (row < 0) {
			row = output.size() + row;
		}
		if (row >= 0 && row < output.size()) {
			// logger.debug("Row Match: " + output.get(row));
			Pattern pattern = Pattern.compile("[" + separator + "]+");
			String[] fields = pattern.split(output.get(row));
			if (column >= 0 && column < fields.length) {
				// logger.debug("Column Match: " + fields[column]);
				result = fields[column];
			}
		}

		return result;
	}

	private static void index(RewardMeRequest request, PrintWriter out)
			throws FatalException {
		out.write("<ul>\n");

		for (String section : sectionMap.keySet()) {
			out.write("<li><a href='"
					+ GatewayServlet.getExternalServerBaseUrl()
					+ "monitor?section=" + section + "'>" + section
					+ "</a></li>\n");
		}

		out.write("</ul>\n");
	}

	@SuppressWarnings("unused")
	private static void disconnects(RewardMeRequest request, PrintWriter out,
			CustomerContact customerContact) throws FatalException {
		MySQL mysql = MySQL.getSlaveInstance(true);

		out.write("<h3>Total MANUAL Application Launches in the Last Week (ordered by most recent first)</h3>\n");

		mysql.query("SELECT device_application_id,count(*) as 'count',max(created"
				+ timezoneOffset
				+ ") as 'created' FROM "
				+ MySQL.TABLES.APPLICATION_OBSERVATION
				+ " WHERE "
				+ "element='init' AND action='complete' AND data='manual' "
				+ "AND created>=utc_timestamp() - INTERVAL 1 WEEK "
				+ "GROUP BY device_application_id " + "ORDER BY created DESC");
		while (mysql.nextRow()) {
			double count = 0;
			Object rawCountValue = MySQL.getValue(mysql, "count");
			try {
				count = (Double) rawCountValue;
			} catch (ClassCastException e) {
				count = (Long) rawCountValue;
			}

			long deviceApplicationId = (Long) mysql
					.getColumn("device_application_id");
			try {
				DeviceApplication deviceApplication = DeviceManager
						.getDeviceApplication(deviceApplicationId);
				List<Date> recentLaunches = getRecentLaunchesFor(deviceApplication);
				out.write("<div>");
				out.write("<span style='font-size:1.2em'>"
						+ deviceApplication.getApplication().getCustomer()
								.getName() + " | "
						+ deviceApplication.getAddress().getAddress()
						+ "</span> <span style='font-size:.8em'>("
						+ deviceApplication.getDevice().getDeviceId() + " | "
						+ deviceApplicationId + ")</span> - " + count
						+ " launches");
				out.write("<ul style='list-style-type:circle'>");
				for (Date launchDate : recentLaunches) {
					out.write("<li>Launched at "
							+ DateFormat.getDateTimeInstance(DateFormat.MEDIUM,
									DateFormat.SHORT).format(launchDate)
							+ "</li>");
				}
				out.write("</ul>");
				out.write("</div>\n");

			} catch (InvalidParameterException e) {
				logger.warn("Failed to load info for deviceApplicationId="
						+ deviceApplicationId);
			}
		}

		out.write("<br/><br/>");

		out.write("<h3>Total Disconnects in the Last Week (ordered by most recent first)</h3>\n");

		mysql.query("SELECT device_application_id,count(*) as 'count',max(created"
				+ timezoneOffset
				+ ") as 'created' FROM "
				+ MySQL.TABLES.APPLICATION_OBSERVATION
				+ " WHERE "
				+ "element='TCPSocket' AND action='disconnect' "
				+ "AND created>=utc_timestamp() - INTERVAL 1 WEEK "
				+ "GROUP BY device_application_id " + "ORDER BY created DESC");
		while (mysql.nextRow()) {
			double count = 0;
			Object rawCountValue = MySQL.getValue(mysql, "count");
			try {
				count = (Double) rawCountValue;
			} catch (ClassCastException e) {
				count = (Long) rawCountValue;
			}

			long deviceApplicationId = (Long) mysql
					.getColumn("device_application_id");
			try {
				DeviceApplication deviceApplication = DeviceManager
						.getDeviceApplication(deviceApplicationId);
				List<Date> recentDisconnects = getRecentDisconnectsFor(deviceApplication);
				out.write("<div>");
				out.write("<span style='font-size:1.2em'>"
						+ deviceApplication.getApplication().getCustomer()
								.getName() + " | "
						+ deviceApplication.getAddress().getAddress()
						+ "</span> <span style='fnt-size:.8em'>("
						+ deviceApplication.getDevice().getDeviceId() + " | "
						+ deviceApplicationId + ")</span> - " + count
						+ " disconnects");
				out.write("<ul style='list-style-type:circle'>");
				for (Date disconnectDate : recentDisconnects) {
					out.write("<li>Disconnect at "
							+ DateFormat.getDateTimeInstance(DateFormat.MEDIUM,
									DateFormat.SHORT).format(disconnectDate)
							+ "</li>");
				}
				out.write("</ul>");
				out.write("</div>\n");

			} catch (InvalidParameterException e) {
				logger.warn("Failed to load info for deviceApplicationId="
						+ deviceApplicationId);
			}
		}

	}

	private static List<Date> getRecentLaunchesFor(
			DeviceApplication deviceApplication) throws FatalException {

		MySQL mysql = MySQL.getSlaveInstance(true);

		List<Date> launchDates = new ArrayList<Date>();

		mysql.query("SELECT (created" + timezoneOffset + ") as 'created' FROM "
				+ MySQL.TABLES.APPLICATION_OBSERVATION + " WHERE "
				+ "element='init' AND action='complete' AND data='manual' "
				+ "AND device_application_id=? "
				+ "ORDER BY created DESC LIMIT 3",
				deviceApplication.getDeviceApplicationId());
		while (mysql.nextRow()) {
			launchDates.add((Date) mysql.getColumn("created"));
		}

		return launchDates;
	}

	private static List<Date> getRecentDisconnectsFor(
			DeviceApplication deviceApplication) throws FatalException {

		MySQL mysql = MySQL.getSlaveInstance(true);

		List<Date> disconnectDates = new ArrayList<Date>();

		mysql.query("SELECT (created" + timezoneOffset + ") as 'created' FROM "
				+ MySQL.TABLES.APPLICATION_OBSERVATION + " WHERE "
				+ "element='TCPSocket' AND action='disconnect' "
				+ "AND device_application_id=? "
				+ "ORDER BY created DESC LIMIT 3",
				deviceApplication.getDeviceApplicationId());
		while (mysql.nextRow()) {
			disconnectDates.add((Date) mysql.getColumn("created"));
		}

		return disconnectDates;
	}

	@SuppressWarnings("unused")
	private static void checkins(RewardMeRequest request, PrintWriter out,
			CustomerContact customerContact) throws FatalException {

		List<String> inputs;
		int row = 0;
		Map<String, List<String>> commandToOutput = new HashMap<String, List<String>>();

		out.write("<h3>Total Checkins By Date</h3>\n");
		inputs = new ArrayList<String>();
		inputs.add("select date(created"
				+ timezoneOffset
				+ ") as 'd',count(*) as 'count' from user_checkin where created>(utc_timestamp() - interval 7 day"
				+ timezoneOffset + ") group by d desc\\G");
		inputs.add("exit");

		row = 0;
		while (!StringUtil.isNullOrEmpty(getMetric(commandToOutput, "mysql -h "
				+ mysqlHost + " -u rewardme_admin -pworknet rewardme", inputs,
				",\\s", ++row, 1))) {
			String date = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row++, 1);
			String checkins = getMetric(commandToOutput, "mysql -h "
					+ mysqlHost + " -u rewardme_admin -pworknet rewardme",
					inputs, ",\\s", row++, 1);

			out.write("<strong>" + date + "</strong> - " + checkins
					+ " checkins<br/>\n");
		}

		/**********/

		out.write("<h3>Checkins By Date, Customer, Address</h3>\n");
		inputs = new ArrayList<String>();
		inputs.add("select date(created"
				+ timezoneOffset
				+ ") as 'd',(select name from customer c where c.customer_id=uc.customer_id) as 'customer',(select address from address a where a.address_id=uc.address_id) as 'address',count(*) as 'count' from user_checkin uc where created>(utc_timestamp() - interval 7 day) group by d,customer_id,address_id having count > 0 order by d desc,count desc,customer asc\\G");
		inputs.add("exit");

		row = 0;
		String lastDate = null;
		while (!StringUtil.isNullOrEmpty(getMetric(commandToOutput, "mysql -h "
				+ mysqlHost + " -u rewardme_admin -pworknet rewardme", inputs,
				",\\s", ++row, 1))) {
			String date = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row++, 1);
			String customer = getMetric(commandToOutput, "mysql -h "
					+ mysqlHost + " -u rewardme_admin -pworknet rewardme",
					inputs, ":", row++, 1);
			String address = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ":",
					row++, 1);
			String checkins = getMetric(commandToOutput, "mysql -h "
					+ mysqlHost + " -u rewardme_admin -pworknet rewardme",
					inputs, ",\\s", row++, 1);

			if (lastDate != null && !lastDate.equals(date)) {
				out.write("<br/>\n");
			}
			lastDate = date;

			// 1411 North Custer Rd, McKinney, TX 75071 => McKinney, TX 75071
			String city = address.substring(address.indexOf(",") + 1).trim();

			out.write("<strong>" + date + "</strong> - " + customer + ", "
					+ city + " - " + checkins + " checkins<br/>\n");
		}

		/**********/

		out.write("<h3>Checkins By Week, Customer</h3>\n");
		inputs = new ArrayList<String>();
		inputs.add("select yearweek(created"
				+ timezoneOffset
				+ ") as 'd',(select name from customer c where c.customer_id=uc.customer_id) as 'customer',count(*) as 'count' from user_checkin uc where created>(utc_timestamp() - interval 6 week) group by d,customer_id having count > 0 order by d desc,count desc,customer asc\\G");
		inputs.add("exit");

		row = 0;
		lastDate = null;
		while (!StringUtil.isNullOrEmpty(getMetric(commandToOutput, "mysql -h "
				+ mysqlHost + " -u rewardme_admin -pworknet rewardme", inputs,
				",\\s", ++row, 1))) {
			String week = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row++, 1);
			String customer = getMetric(commandToOutput, "mysql -h "
					+ mysqlHost + " -u rewardme_admin -pworknet rewardme",
					inputs, ":", row++, 1);
			String checkins = getMetric(commandToOutput, "mysql -h "
					+ mysqlHost + " -u rewardme_admin -pworknet rewardme",
					inputs, ",\\s", row++, 1);

			if (lastDate != null && !lastDate.equals(week)) {
				out.write("<br/>\n");
			}
			lastDate = week;

			out.write("<strong>" + week + "</strong> - " + customer + " - "
					+ checkins + " checkins<br/>\n");
		}

		/**********/

		out.write("<h3>New Users By Week, Customer</h3>\n");
		inputs = new ArrayList<String>();
		inputs.add("select yearweek(created"
				+ timezoneOffset
				+ ") as 'd',(select name from customer c where c.customer_id=uc.customer_id) as 'customer',count(distinct user_id) as 'count' from user_checkin uc where user_id in (select user_id from user u where yearweek(u.created)=yearweek(uc.created)) and created>(utc_timestamp() - interval 6 week) group by d,customer_id having count > 0 order by d desc,count desc,customer asc\\G");
		inputs.add("exit");

		row = 0;
		lastDate = null;
		while (!StringUtil.isNullOrEmpty(getMetric(commandToOutput, "mysql -h "
				+ mysqlHost + " -u rewardme_admin -pworknet rewardme", inputs,
				",\\s", ++row, 1))) {
			String week = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row++, 1);
			String customer = getMetric(commandToOutput, "mysql -h "
					+ mysqlHost + " -u rewardme_admin -pworknet rewardme",
					inputs, ":", row++, 1);
			String users = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row++, 1);

			if (lastDate != null && !lastDate.equals(week)) {
				out.write("<br/>\n");
			}
			lastDate = week;

			out.write("<strong>" + week + "</strong> - " + customer + " - "
					+ users + " new users<br/>\n");
		}
		/**********/

		Map<String, Long> customerDayToTxCounts = new HashMap<String, Long>();
		out.write("<h3>Usage By Date, Customer, Address</h3>\n");

		inputs = new ArrayList<String>();
		inputs.add("select date(created"
				+ timezoneOffset
				+ ") as 'd',(select name from customer c where c.customer_id=tx.customer_id) as 'customer',(select address from address a where a.address_id=tx.address_id) as 'address',count(*) as 'count' from pos_tx tx where created>(utc_timestamp() - interval 6 day) group by d,customer_id,address_id order by d desc,count desc,customer asc,address asc\\G");
		inputs.add("exit");

		row = 0;
		while (!StringUtil.isNullOrEmpty(getMetric(commandToOutput, "mysql -h "
				+ mysqlHost + " -u rewardme_admin -pworknet rewardme", inputs,
				",\\s", ++row, 1))) {
			String d = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row++, 1);
			String customer = getMetric(commandToOutput, "mysql -h "
					+ mysqlHost + " -u rewardme_admin -pworknet rewardme",
					inputs, ":", row++, 1);
			String address = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ":",
					row++, 1);
			String txCount = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row++, 1);

			// 1411 North Custer Rd, McKinney, TX 75071 => McKinney, TX 75071
			String city = address.substring(address.indexOf(",") + 1).trim();

			customerDayToTxCounts.put(customer + "-" + city + "-" + d,
					Long.parseLong(txCount));
		}

		inputs = new ArrayList<String>();
		inputs.add("select date(created"
				+ timezoneOffset
				+ ") as 'd',(select name from customer c where c.customer_id=uc.customer_id) as 'customer',(select address from address a where a.address_id=uc.address_id) as 'address',count(*) as 'count' from user_checkin uc where created>(utc_timestamp() - interval 6 day) group by d,customer_id,address_id order by d desc,count desc,customer asc,address asc\\G");
		inputs.add("exit");

		row = 0;
		lastDate = null;
		while (!StringUtil.isNullOrEmpty(getMetric(commandToOutput, "mysql -h "
				+ mysqlHost + " -u rewardme_admin -pworknet rewardme", inputs,
				",\\s", ++row, 1))) {
			String d = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row++, 1);
			String customer = getMetric(commandToOutput, "mysql -h "
					+ mysqlHost + " -u rewardme_admin -pworknet rewardme",
					inputs, ":", row++, 1);
			String address = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ":",
					row++, 1);
			String txWithRewardMeCount = getMetric(commandToOutput, "mysql -h "
					+ mysqlHost + " -u rewardme_admin -pworknet rewardme",
					inputs, ",\\s", row++, 1);

			/*
			 * if(lastDate != null && !lastDate.equals(d)) {
			 * out.write("<br/>\n"); } lastDate = d;
			 */

			// 1411 North Custer Rd, McKinney, TX 75071 => McKinney, TX 75071
			String city = address.substring(address.indexOf(",") + 1).trim();

			Long customerDayToTxCount = customerDayToTxCounts.get(customer
					+ "-" + city + "-" + d);
			if (customerDayToTxCount != null) {
				customerDayToTxCounts.remove(customer + "-" + city + "-" + d);

				float usage = (float) Long.parseLong(txWithRewardMeCount)
						/ (float) customerDayToTxCount;
				usage *= 100;

				NumberFormat usageFormatter = NumberFormat.getInstance();
				usageFormatter.setMaximumFractionDigits(2);
				usageFormatter.setGroupingUsed(false);
				String formattedUsage = usageFormatter.format(usage);

				out.write("<strong>" + d + "</strong> - " + customer + ", "
						+ city + " - " + formattedUsage + "% RewardMe usage ("
						+ txWithRewardMeCount + " checkins / "
						+ customerDayToTxCount + " transactions)" + "<br/>\n");
			} else {
				out.write("<strong>" + d + "</strong> - " + customer + ", "
						+ city + " - " + "100% RewardMe usage ("
						+ txWithRewardMeCount + " checkins / " + 0
						+ " transactions)" + "<br/>\n");

			}
		}

		// output all the locations with 0 checkins
		for (String key : customerDayToTxCounts.keySet()) {
			Long customerDayToTxCount = customerDayToTxCounts.get(key);
			out.write("<strong>" + key + "</strong> - 0% RewardMe usage (" + 0
					+ " checkins / " + customerDayToTxCount + " transactions)"
					+ "<br/>\n");

		}

		/**********/

		out.write("<h3>Latest Checkins</h3>\n");
		inputs = new ArrayList<String>();
		inputs.add("select (select name from customer c where c.customer_id=uc.customer_id) as 'customer',(created"
				+ timezoneOffset
				+ ") as 'created' from user_checkin uc order by user_checkin_id desc limit 10\\G");
		inputs.add("exit");

		row = 0;
		while (!StringUtil.isNullOrEmpty(getMetric(commandToOutput, "mysql -h "
				+ mysqlHost + " -u rewardme_admin -pworknet rewardme", inputs,
				",\\s", ++row, 1))) {
			String customer = getMetric(commandToOutput, "mysql -h "
					+ mysqlHost + " -u rewardme_admin -pworknet rewardme",
					inputs, ":", row++, 1);
			String date = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row, 1);
			String time = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row++, 2);

			out.write("<strong>" + date + "</strong> " + time + " - "
					+ customer + "<br/>\n");
		}
		/**********/
	}

	@SuppressWarnings("unused")
	private static void subscribe(RewardMeRequest request, PrintWriter out,
			CustomerContact customerContact) throws FatalException {
		String subscribeServerUrl = "sandbox-subscribe.rewardme.com";
		if (GatewayServlet.isProduction()) {
			subscribeServerUrl = "subscribe.rewardme.com";
		} else if (GatewayServlet.isBeta()) {
			subscribeServerUrl = "beta-subscribe.rewardme.com";
		}

		String subscribeServerAction = null;
		String subscribeServerActionDeviceId = null;
		String subscribeServerArgument = null;
		try {
			subscribeServerAction = request.getParameter(
					"subscribeServerAction", false);
			subscribeServerActionDeviceId = request.getParameter(
					Constants.Request.DEVICE_ID, false);
			subscribeServerArgument = request.getParameter(
					"subscribeServerArgument", false);
		} catch (InvalidParameterException e) {
			logger.error(e);
		}
		if (!StringUtil.isNullOrEmpty(subscribeServerAction)) {
			NameValuePair[] parameters = {
					new NameValuePair("_type", "system"),
					new NameValuePair("action", subscribeServerAction),
					new NameValuePair("deviceId", subscribeServerActionDeviceId),
					new NameValuePair("argument", subscribeServerArgument), };
			String subscribeServerResponse = RemoteRequestUtil.get("https://"
					+ subscribeServerUrl, parameters, false);
			out.write(subscribeServerResponse);
			return;
		}

		out.write(monitorHtml);
	}

	@SuppressWarnings("unused")
	private static void subscribeOld(RewardMeRequest request, PrintWriter out,
			CustomerContact customerContact) throws FatalException {

		String subscribeServerUrl = "sandbox-subscribe.rewardme.com";
		if (GatewayServlet.isProduction()) {
			subscribeServerUrl = "subscribe.rewardme.com";
		} else if (GatewayServlet.isBeta()) {
			subscribeServerUrl = "beta-subscribe.rewardme.com";
		}

		String subscribeServerAction = null;
		String subscribeServerActionDeviceId = null;
		String subscribeServerArgument = null;
		try {
			subscribeServerAction = request.getParameter(
					"subscribeServerAction", false);
			subscribeServerActionDeviceId = request.getParameter(
					Constants.Request.DEVICE_ID, false);
			subscribeServerArgument = request.getParameter(
					"subscribeServerArgument", false);
		} catch (InvalidParameterException e) {
			logger.error(e);
		}
		if (!StringUtil.isNullOrEmpty(subscribeServerAction)) {
			NameValuePair[] parameters = {
					new NameValuePair("_type", "system"),
					new NameValuePair("action", subscribeServerAction),
					new NameValuePair("deviceId", subscribeServerActionDeviceId),
					new NameValuePair("argument", subscribeServerArgument), };
			String subscribeServerResponse = RemoteRequestUtil.get("https://"
					+ subscribeServerUrl, parameters, false);
			out.write(subscribeServerResponse);
			return;
		}

		out.write("<h3>Clients connected to the the subscribe server at "
				+ subscribeServerUrl + "</h3>\n");

		NameValuePair[] parameters = { new NameValuePair("_type", "system"),
				new NameValuePair("action", "getDevices"), };

		String subscribeServerResponse = RemoteRequestUtil.get("https://"
				+ subscribeServerUrl, parameters, false);
		try {
			JSONObject connectedServers = new JSONObject(
					subscribeServerResponse);
			// out.write(connectedServers.getJSONArray("clients").toString().replace("}}},",
			// "}}},<br/>\n"));

			Set<String> accountedForDevices = new LinkedHashSet<String>();
			Set<String> offlineDevices = new LinkedHashSet<String>();

			Set<DeviceApplication> deviceApplications = new LinkedHashSet<DeviceApplication>();
			Map<DeviceApplication, JSONObject> deviceApplicationsServers = new LinkedHashMap<DeviceApplication, JSONObject>();
			Set<DeviceApplication> offlineDeviceApplications = new LinkedHashSet<DeviceApplication>();
			Map<DeviceApplication, Date> deviceApplicationLastCheckinDate = new HashMap<DeviceApplication, Date>();
			Map<DeviceApplication, Date> deviceApplicationLastTransactionDate = new HashMap<DeviceApplication, Date>();

			MySQL mysql = MySQL.getSlaveInstance(true);

			mysql.query(""
					+ "SELECT da.* "
					+ "FROM "
					+ MySQL.TABLES.DEVICE_APPLICATION
					+ " da, "
					+ MySQL.TABLES.APPLICATION
					+ " a "
					+ "WHERE da.application_id=a.application_id "
					+ (customerContact.getCustomer() == null ? ""
							: " AND a.customer_id=? ")
					+ "ORDER BY da.application_id ASC,da.address_id ASC",
					customerContact.getCustomer() == null ? null
							: customerContact.getCustomer().getCustomerId());

			while (mysql.nextRow()) {
				DeviceApplication deviceApplication = null;
				try {
					deviceApplication = DeviceApplication.from(mysql);
				} catch (InvalidParameterException e) {
					if (e.code == Constants.Error.INVALID_ID.ADDRESS_ID) {
						deviceApplication = new DeviceApplication();
						deviceApplication.setApplication(ApplicationManager
								.getApplication((Long) mysql
										.getColumn("application_id")));
						deviceApplication.setDevice(DeviceManager
								.getDevice((String) mysql
										.getColumn("device_id")));
						deviceApplication.setAddress(new Address(
								deviceApplication.getApplication()
										.getCustomer(),
								"Unknown - Removed Address", 0, null, null));
					} else {
						throw e;
					}
				}

				updatelastTxAndCheckin(deviceApplication,
						deviceApplicationLastCheckinDate,
						deviceApplicationLastTransactionDate);

				deviceApplications.add(deviceApplication);
			}

			// get some basic, reusable information about the device
			// application's current state
			for (DeviceApplication deviceApplication : deviceApplications) {
				boolean isOnline = false;

				for (int i = 0; i < connectedServers.getJSONArray("clients")
						.length(); i++) {
					JSONObject connectedServer = connectedServers.getJSONArray(
							"clients").getJSONObject(i);
					JSONObject client = connectedServer.getJSONObject("client");
					JSONObject device = client.getJSONObject("device");
					if (device.getString("deviceId").equalsIgnoreCase(
							deviceApplication.getDevice().getDeviceId())) {
						isOnline = true;
						accountedForDevices.add(deviceApplication.getDevice()
								.getDeviceId());
						deviceApplicationsServers.put(deviceApplication,
								connectedServer);
						break;
					}
				}
				if (!isOnline) {
					offlineDeviceApplications.add(deviceApplication);
				} else {
					// see if the linked devices are offline
					Set<DeviceLink> deviceLinks = DeviceManager
							.getDeviceLinks(deviceApplication.getDevice());
					if (deviceLinks.size() > 0) {
						for (DeviceLink deviceLink : deviceLinks) {
							String deviceIdOfDeviceLink = deviceLink
									.getDevice1().getDeviceId();
							// logger.debug("Comparing " +
							// deviceApplication.getDevice().getDeviceId() +
							// " and " + deviceIdOfDeviceLink);
							if (deviceApplication.getDevice().getDeviceId()
									.equalsIgnoreCase(deviceIdOfDeviceLink)) {
								deviceIdOfDeviceLink = deviceLink.getDevice2()
										.getDeviceId();
								// logger.debug("Match! using: " +
								// deviceIdOfDeviceLink);
							}
							isOnline = false;

							JSONObject linkedDeviceConnectedServer = null;
							JSONObject linkedDeviceClient = null;
							for (int i = 0; i < connectedServers.getJSONArray(
									"clients").length(); i++) {
								linkedDeviceConnectedServer = connectedServers
										.getJSONArray("clients").getJSONObject(
												i);
								linkedDeviceClient = linkedDeviceConnectedServer
										.getJSONObject("client");
								JSONObject device = linkedDeviceClient
										.getJSONObject("device");
								if (device.getString("deviceId")
										.equalsIgnoreCase(deviceIdOfDeviceLink)) {
									isOnline = true;
									break;
								}
							}

							if (isOnline) {
								accountedForDevices.add(deviceIdOfDeviceLink);
							} else {
								offlineDevices.add(deviceIdOfDeviceLink);
							}
						}

					}
				}
			}

			// output the offline device applications first
			out.write("<h2>Offline Tablets</h2>\n");
			for (DeviceApplication deviceApplication : offlineDeviceApplications) {
				String address = deviceApplication.getAddress().getAddress();
				// 1411 North Custer Rd, McKinney, TX 75071 => McKinney, TX
				// 75071
				String city = address.substring(address.indexOf(",") + 1)
						.trim();

				out.write("<strong>"
						+ deviceApplication.getApplication().getCustomer()
								.getName() + " - " + city + "</strong><br/>\n");
				out.write("<span>"
						+ deviceApplication.getApplication().getName()
						+ " Application on Device "
						+ deviceApplication.getDevice().getDeviceId()
						+ "</span>" + "<br/>\n");
				out.write("<span>Status: <span style='color:red'>Offline</span></span><br/>\n");
				Date lastCheckinDate = deviceApplicationLastCheckinDate
						.get(deviceApplication);
				Date lastTransactionDate = deviceApplicationLastTransactionDate
						.get(deviceApplication);
				out.write("<span>Last Checkin: "
						+ (lastCheckinDate == null ? "Never" : DateFormat
								.getDateTimeInstance(DateFormat.MEDIUM,
										DateFormat.SHORT).format(
										lastCheckinDate)) + "</span><br/>\n");
				out.write("<span>Last Transaction: "
						+ (lastTransactionDate == null ? "Never" : DateFormat
								.getDateTimeInstance(DateFormat.MEDIUM,
										DateFormat.SHORT).format(
										lastTransactionDate))
						+ "</span><br/>\n");
				out.write("<hr/><br/>\n");
			}
			out.write("<br/><br/>");

			out.write("<h2>Offline Printers</h2>\n");
			for (String deviceId : offlineDevices) {
				out.write(deviceId + "<br/>\n");
			}
			out.write("<br/><br/>");

			out.write("<h2>Full Device List</h2>\n");

			for (DeviceApplication deviceApplication : deviceApplications) {
				boolean isOnline = !offlineDeviceApplications
						.contains(deviceApplication);

				String address = deviceApplication.getAddress().getAddress();
				// 1411 North Custer Rd, McKinney, TX 75071 => McKinney, TX
				// 75071
				String city = address.substring(address.indexOf(",") + 1)
						.trim();

				out.write("<strong>"
						+ deviceApplication.getApplication().getCustomer()
								.getName() + " - " + city + "</strong><br/>\n");
				if (isOnline) {
					JSONObject connectedServer = deviceApplicationsServers
							.get(deviceApplication);
					JSONObject client = connectedServer.getJSONObject("client");
					JSONObject device = client.getJSONObject("device");

					String version = "Unknown";
					String namespace = "Unknown";
					String ipAddress = "Unknown";
					try {
						version = client.getString("version");
						namespace = client.getString("namespace");
						ipAddress = client.getString("ipAddress");
					} catch (JSONException e) {
						// no version given
					}

					out.write("<span class='onlineDeviceId'>"
							+ deviceApplication.getApplication().getName()
							+ " Application on Device "
							+ deviceApplication.getDevice().getDeviceId()
							+ "</span>");
					out.write("<span style='font-size:.8em;display:none' class='deviceOptions'> -- "
							+ "<span>Update ("
							+ " <a href='#' onclick='deviceUpdate(\""
							+ deviceApplication.getDevice().getDeviceId()
							+ "\",\"true\"); return false'>Now</a> | "
							+ " <a href='#' onclick='deviceUpdate(\""
							+ deviceApplication.getDevice().getDeviceId()
							+ "\",\"false\"); return false'>On Restart</a> "
							+ ")</span> | "
							+ " <a href='#' onclick='deviceDebug(\""
							+ deviceApplication.getDevice().getDeviceId()
							+ "\"); return false'>Enable Debug Mode</a> | "
							+ " <a href='#' onclick='deviceShowInitialSetupOptions(\""
							+ deviceApplication.getDevice().getDeviceId()
							+ "\"); return false'>Show Setup Options</a> | "
							+ " <a href='#' onclick='deviceLink(\""
							+ deviceApplication.getDevice().getDeviceId()
							+ "\"); return false'>Show Link Device Screen</a> | "
							+ "<span>Test Redeem ("
							+ " <a href='#' onclick='deviceTestRedeem(\""
							+ deviceApplication.getDevice().getDeviceId()
							+ "\",\"true\"); return false'>Local</a> | "
							+ " <a href='#' onclick='deviceTestRedeem(\""
							+ deviceApplication.getDevice().getDeviceId()
							+ "\",\"false\"); return false'>Remote</a> "
							+ ")</span> | "
							+ "<span>Reload ("
							+ " <a href='#' onclick='deviceReload(\""
							+ deviceApplication.getDevice().getDeviceId()
							+ "\",\"true\"); return false'>Hard</a> | "
							+ " <a href='#' onclick='deviceReload(\""
							+ deviceApplication.getDevice().getDeviceId()
							+ "\",\"false\"); return false'>Soft</a> "
							+ ")</span> | "
							+ " <a href='#' onclick='deviceAlert(\""
							+ deviceApplication.getDevice().getDeviceId()
							+ "\"); return false'>Show Alert</a> " + "</span>");
					out.write("<br/>\n");

					out.write("<span>Device Version: " + version
							+ ", Namespace: " + namespace 
							+ ", ipAddress: " + ipAddress 						
							+ "</span><br/>\n");
					out.write("<span>Connected to: "
							+ connectedServer.getString("apiServer")
							+ ", with session: "
							+ client.getString("sessionId") + "</span><br/>\n");
					out.write("<span>Status: <span style='color:green'>Online</span></span><br/>\n");
				} else {
					out.write("<span>"
							+ deviceApplication.getApplication().getName()
							+ " Application on Device "
							+ deviceApplication.getDevice().getDeviceId()
							+ "</span><br/>\n");
					out.write("<span>Status: <span style='color:red'>Offline</span></span><br/>\n");
				}
				Date lastCheckinDate = deviceApplicationLastCheckinDate
						.get(deviceApplication);
				Date lastTransactionDate = deviceApplicationLastTransactionDate
						.get(deviceApplication);
				out.write("<span>Last Checkin: "
						+ (lastCheckinDate == null ? "Never" : DateFormat
								.getDateTimeInstance(DateFormat.MEDIUM,
										DateFormat.SHORT).format(
										lastCheckinDate)) + "</span><br/>\n");
				out.write("<span>Last Transaction: "
						+ (lastTransactionDate == null ? "Never" : DateFormat
								.getDateTimeInstance(DateFormat.MEDIUM,
										DateFormat.SHORT).format(
										lastTransactionDate))
						+ "</span><br/>\n");

				Set<DeviceLink> deviceLinks = DeviceManager
						.getDeviceLinks(deviceApplication.getDevice());
				if (deviceLinks.size() > 0) {
					out.write("<div>Linked Devices</div>\n");
					for (DeviceLink deviceLink : deviceLinks) {
						String deviceIdOfDeviceLink = deviceLink.getDevice1()
								.getDeviceId();
						if (deviceApplication.getDevice().getDeviceId()
								.equalsIgnoreCase(deviceIdOfDeviceLink)) {
							deviceIdOfDeviceLink = deviceLink.getDevice2()
									.getDeviceId();
							if (deviceApplication.getDevice().getDeviceId()
									.equalsIgnoreCase(deviceIdOfDeviceLink)) {
								// multiple links - ignore this one
								continue;
							}
						}
						isOnline = false;

						JSONObject linkedDeviceConnectedServer = null;
						JSONObject linkedDeviceClient = null;
						for (int i = 0; i < connectedServers.getJSONArray(
								"clients").length(); i++) {
							linkedDeviceConnectedServer = connectedServers
									.getJSONArray("clients").getJSONObject(i);
							linkedDeviceClient = linkedDeviceConnectedServer
									.getJSONObject("client");
							JSONObject device = linkedDeviceClient
									.getJSONObject("device");
							if (device.getString("deviceId").equalsIgnoreCase(
									deviceIdOfDeviceLink)) {
								isOnline = true;
								accountedForDevices.add(deviceIdOfDeviceLink);
								break;
							}
						}

						String version = "Unknown";
						String namespace = "Unknown";
						String ipAddress = "ipAddress";
						if (linkedDeviceClient != null) {
							try {
								version = linkedDeviceClient.getString("version");
								namespace = linkedDeviceClient.getString("namespace");
								ipAddress = linkedDeviceClient.getString("ipAddress");
							} catch (JSONException e) {
								// no version given
							}
						}

						out.write("<div style='margin-left:10px'>");
						out.write("<span class='onlineDeviceId'>Device: "
								+ deviceIdOfDeviceLink + "</span>");
						if (isOnline) {
							if (namespace.equals("Switchboard")) {
								out.write("<span style='font-size:.8em;display:none' class='deviceOptions'> -- "
										+ "<a href='#' onclick='deviceReload(\""
										+ deviceIdOfDeviceLink
										+ "\"); return false'>Reload</a>"
										+ "</span>");
							}
							out.write("<br/>\n");
							out.write("<span>Device Version: " + version
									+ ", Namespace: " + namespace
									+ ", ipAddress: " + ipAddress
									+ "</span><br/>\n");
							out.write("<span>Connected to: "
									+ linkedDeviceConnectedServer
											.getString("apiServer")
									+ ", with session: "
									+ linkedDeviceClient.getString("sessionId")
									+ "</span><br/>\n");
							out.write("<span>Status: <span style='color:green'>Online</span></span><br/>\n");
						} else {
							out.write("<br/>\n");
							out.write("<span>Status: <span style='color:red'>Offline</span></span><br/>\n");
						}
						out.write("</div>");
					}

				}

				out.write("<hr/><br/>\n");
			}

			if (customerContact == null) {
				// show devices that are connected that don't have device
				// applications and aren't on the linked devices list
				out.write("<h4>Unknown devices connected</h4>\n");
				for (int i = 0; i < connectedServers.getJSONArray("clients")
						.length(); i++) {
					JSONObject connectedServer = connectedServers.getJSONArray(
							"clients").getJSONObject(i);
					JSONObject client = connectedServer.getJSONObject("client");
					JSONObject device = client.getJSONObject("device");
					if (!accountedForDevices.contains(device
							.getString("deviceId"))) {
						// unnaccounted for device
						out.write("<span>" + connectedServer.toString()
								+ "</span><br/>\n");
					}
				}
			}

			// scriptzzz
			String userAgent = request.getHttpServletRequest().getHeader(
					"User-Agent");
			boolean isMobile = userAgent.toLowerCase().contains("mobile");
			out.write(""
					+ "<iframe id='subscribeServerActionsIFrame' src='' height=1 width=1 style='position:absolute;top:0px;left:0px;height:1px:width:1px'></iframe>"
					+ "<script type='text/javascript' src='https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js'></script>"
					+ "<script type='text/javascript'>"
					+ "var deviceActionsEnabled = false;"
					+ "var deviceUpdate = function(deviceId, argument) {if(!deviceActionsEnabled || !confirm('Please confirm that you would like to UPDATE this device.')) return; document.getElementById('subscribeServerActionsIFrame').src= '"
					+ GatewayServlet.getExternalServerBaseUrl()
					+ "monitor?section=subscribe&subscribeServerAction=deviceUpdate&subscribeServerArgument='+argument+'&deviceId='+deviceId;};"
					+ "var deviceDebug = function(deviceId, argument) {if(!deviceActionsEnabled || !confirm('Please confirm that you would like to DEBUG this device.')) return; document.getElementById('subscribeServerActionsIFrame').src= '"
					+ GatewayServlet.getExternalServerBaseUrl()
					+ "monitor?section=subscribe&subscribeServerAction=deviceDebug&subscribeServerArgument='+argument+'&deviceId='+deviceId;};"
					+ "var deviceShowInitialSetupOptions = function(deviceId, argument) {if(!deviceActionsEnabled || !confirm('Please confirm that you would like to SHOW PRINTER OPTIONS on this device.')) return; document.getElementById('subscribeServerActionsIFrame').src= '"
					+ GatewayServlet.getExternalServerBaseUrl()
					+ "monitor?section=subscribe&subscribeServerAction=deviceShowInitialSetupOptions&subscribeServerArgument='+argument+'&deviceId='+deviceId;};"
					+ "var deviceReload = function(deviceId, argument) {if(!deviceActionsEnabled || !confirm('Please confirm that you would like to RELOAD this device.')) return; document.getElementById('subscribeServerActionsIFrame').src= '"
					+ GatewayServlet.getExternalServerBaseUrl()
					+ "monitor?section=subscribe&subscribeServerAction=deviceReload&subscribeServerArgument='+argument+'&deviceId='+deviceId;};"
					+ "var deviceLink = function(deviceId, argument) {if(!deviceActionsEnabled || !confirm('Please confirm that you would like to SHOW LINK OPTIONS on this device.')) return; document.getElementById('subscribeServerActionsIFrame').src= '"
					+ GatewayServlet.getExternalServerBaseUrl()
					+ "monitor?section=subscribe&subscribeServerAction=deviceLink&subscribeServerArgument='+argument+'&deviceId='+deviceId;};"
					+ "var deviceTestRedeem = function(deviceId, argument) {if(!deviceActionsEnabled || !confirm('Please confirm that you would like to TEST A REDEEM on this device.')) return; document.getElementById('subscribeServerActionsIFrame').src= '"
					+ GatewayServlet.getExternalServerBaseUrl()
					+ "monitor?section=subscribe&subscribeServerAction=deviceTestRedeem&subscribeServerArgument='+argument+'&deviceId='+deviceId;};"
					+ "var deviceAlert = function(deviceId, argument) {if(!deviceActionsEnabled || !(argument=prompt('What message would you like to display?'))) return; document.getElementById('subscribeServerActionsIFrame').src= '"
					+ GatewayServlet.getExternalServerBaseUrl()
					+ "monitor?section=subscribe&subscribeServerAction=deviceAlert&subscribeServerArgument='+escape(argument)+'&deviceId='+deviceId;};"
					+ "$('.onlineDeviceId').live('"
					+ (isMobile ? "touchend" : "click")
					+ "', function() { var thiss = $(this); setTimeout(function() { thiss.next().toggle(); setTimeout(function() { deviceActionsEnabled = !deviceActionsEnabled;}, 350); }, 100)});"
					+ "</script>");

		} catch (JSONException e) {
			e.printStackTrace();
			logger.error("Failed to parse JSON from " + subscribeServerUrl
					+ ", received: " + subscribeServerResponse);
		} catch (InvalidParameterException e) {
			e.printStackTrace();
		}

	}

	private static void updatelastTxAndCheckin(
			DeviceApplication deviceApplication,
			Map<DeviceApplication, Date> deviceApplicationLastCheckinDate,
			Map<DeviceApplication, Date> deviceApplicationLastTransactionDate)
			throws FatalException {

		MySQL mysql = MySQL.getSlaveInstance(true);

		mysql.query(
				"SELECT (created"
						+ timezoneOffset
						+ ") as 'last_checkin' FROM "
						+ MySQL.TABLES.USER_CHECKIN
						+ " WHERE device_application_id=? ORDER BY created DESC LIMIT 1",
				deviceApplication.getDeviceApplicationId());
		if (mysql.nextRow()) {
			deviceApplicationLastCheckinDate.put(deviceApplication,
					(Date) mysql.getColumn("last_checkin"));
		}

		mysql.query("SELECT (created" + timezoneOffset + ") as 'last_tx' FROM "
				+ MySQL.TABLES.POS.TX
				+ " WHERE device_id=? ORDER BY created DESC LIMIT 1",
				deviceApplication.getDevice().getDeviceId());
		if (mysql.nextRow()) {
			deviceApplicationLastTransactionDate.put(deviceApplication,
					(Date) mysql.getColumn("last_tx"));
		}
	}

	@SuppressWarnings("unused")
	private static void errors(RewardMeRequest request, PrintWriter out,
			CustomerContact customerContact) throws FatalException {

		List<String> inputs;
		int row = 0;
		Map<String, List<String>> commandToOutput = new HashMap<String, List<String>>();

		out.write("<h3>Event Stats</h3>\n");
		inputs = new ArrayList<String>();
		inputs.add("select date(created"
				+ timezoneOffset
				+ ") as 'd',count(*) as 'count' from event where created>(utc_timestamp() - interval 7 day) group by d desc\\G");
		inputs.add("exit");

		row = 0;
		while (!StringUtil.isNullOrEmpty(getMetric(commandToOutput, "mysql -h "
				+ mysqlHost + " -u rewardme_admin -pworknet rewardme", inputs,
				",\\s", ++row, 1))) {
			String date = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row++, 1);
			String checkins = getMetric(commandToOutput, "mysql -h "
					+ mysqlHost + " -u rewardme_admin -pworknet rewardme",
					inputs, ",\\s", row++, 1);

			out.write("<strong>" + date + "</strong> - " + checkins
					+ " total log events<br/>\n");
		}
		/**********/

		out.write("<h3>Total Errors Today <a style='font-size:12px' target='_blank' href='http://api.rewardme.com/rewardme/api?method=server.getErrorCodes&responseFormat=json'>Error Codes</a></h3>\n");
		inputs = new ArrayList<String>();
		inputs.add("select value,count(*) as 'count' from event where (value = 'fatal error' or value like 'invalid parameter%') and date(utc_timestamp())=date(created) group by value order by count desc limit 10\\G");
		inputs.add("exit");

		row = 0;
		while (!StringUtil.isNullOrEmpty(getMetric(commandToOutput, "mysql -h "
				+ mysqlHost + " -u rewardme_admin -pworknet rewardme", inputs,
				",\\s", ++row, 1))) {
			String type = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ":",
					row, 1);
			String code = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ":",
					row++, 2);
			String count = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row++, 1);

			if (code == null) {
				code = ""; // for fatal errors (which do not have a code)
			}

			out.write("<strong>" + type + code + "</strong>: " + count
					+ " errors<br/>\n");
		}
		/**********/

		out.write("<h3>Latest Fatal Errors</h3>\n");
		inputs = new ArrayList<String>();
		inputs.add("select (created"
				+ timezoneOffset
				+ ") as 'created',name,user_id,if(customer_id is not null,(select name from customer c where c.customer_id=le.customer_id),'null') as 'customer' from event le where value = 'fatal error' order by event_id desc limit 10\\G");
		inputs.add("exit");

		row = 0;
		while (!StringUtil.isNullOrEmpty(getMetric(commandToOutput, "mysql -h "
				+ mysqlHost + " -u rewardme_admin -pworknet rewardme", inputs,
				",\\s", ++row, 1))) {
			String date = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row, 1);
			String time = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row++, 2);
			String name = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ":",
					row++, 1);
			String userId = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row++, 1);
			String customer = getMetric(commandToOutput, "mysql -h "
					+ mysqlHost + " -u rewardme_admin -pworknet rewardme",
					inputs, ":", row++, 1);

			out.write("<strong>" + date + "</strong> " + time + " - " + name
					+ " User: " + userId + " Customer: " + customer + "<br/>\n");
		}
		/**********/

		out.write("<h3>Latest IPE Errors</h3>\n");
		inputs = new ArrayList<String>();
		inputs.add("select (created"
				+ timezoneOffset
				+ ") as 'created',name,value,user_id,if(customer_id is not null,(select name from customer c where c.customer_id=le.customer_id),'null') as 'customer' from event le where value like 'invalid parameter%' order by event_id desc limit 10\\G");
		inputs.add("exit");

		row = 0;
		while (!StringUtil.isNullOrEmpty(getMetric(commandToOutput, "mysql -h "
				+ mysqlHost + " -u rewardme_admin -pworknet rewardme", inputs,
				",\\s", ++row, 1))) {
			String date = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row, 1);
			String time = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row++, 2);
			String name = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ":",
					row++, 1);
			String value = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ":",
					row, 1)
					+ ": "
					+ getMetric(commandToOutput, "mysql -h " + mysqlHost
							+ " -u rewardme_admin -pworknet rewardme", inputs,
							":", row++, 2);
			String userId = getMetric(commandToOutput, "mysql -h " + mysqlHost
					+ " -u rewardme_admin -pworknet rewardme", inputs, ",\\s",
					row++, 1);
			String customer = getMetric(commandToOutput, "mysql -h "
					+ mysqlHost + " -u rewardme_admin -pworknet rewardme",
					inputs, ":", row++, 1);

			out.write("<strong>" + date + "</strong> " + time + " - " + name
					+ " | <strong>" + value + "</strong> User: " + userId
					+ " Customer: " + customer + "<br/>\n");
		}
	}
}
