package com.viralogy.rewardme.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.ParseException;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.stripe.model.Event;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.manager.StripeManager;

public class StripeServlet extends HttpServlet {
	private static Logger logger = Logger.getLogger(StripeServlet.class);
    
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        processRequest(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        processRequest(request, response);
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) {
        logger.debug("Request URL: " + request.getRequestURL());            
        logger.debug("Request URI: " + request.getRequestURI());            
        logger.debug("Request QueryString: " + request.getQueryString());   

        try {
            String data = (String) request.getAttribute((String)request.getAttributeNames().nextElement());
            
			logger.debug("data is: " + data);
			
			JSONObject decoded;
			try {
				decoded = new JSONObject(data);
				StripeManager.webhookNotify((String) decoded.get("id"));
			} 
			catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			response.setStatus(200);
        } 
        catch(InvalidParameterException e) {
        	logger.error(e);
        } 
        catch( FatalException e ) {
			logger.error(e);
        }
        
    }
}
