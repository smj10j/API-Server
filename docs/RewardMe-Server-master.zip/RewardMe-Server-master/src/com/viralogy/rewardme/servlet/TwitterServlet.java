package com.viralogy.rewardme.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.manager.MessageManager;
import com.viralogy.rewardme.manager.PointsManager;
import com.viralogy.rewardme.manager.PreferencesManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.model.PointCategory;
import com.viralogy.rewardme.model.RewardMeRequest;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserMessage;
import com.viralogy.rewardme.model.UserPoints;
import com.viralogy.rewardme.model.UserPreference;
import com.viralogy.rewardme.social.Social;
import com.viralogy.rewardme.social.Twitter;
import com.viralogy.rewardme.social.Social.Type;
import com.viralogy.rewardme.util.Cache;
import com.viralogy.rewardme.util.StringUtil;

public class TwitterServlet extends HttpServlet{
	
	private static final long serialVersionUID = -2483399343753655181L;
	private static Logger logger = Logger.getLogger(TwitterServlet.class);
	private Social.Type type = Social.Type.TWITTER;
    
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        processRequest(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        processRequest(request, response);
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) {
        
        try {
			RewardMeRequest rewardMeRequest = new RewardMeRequest( request);
			String oauthVerifier = null;
			String accessToken = null;
			String accessTokenSecret = null;
			String requestURI = request.getRequestURI();
			String md5PhoneNumber = requestURI.substring(requestURI.lastIndexOf('/') + 1);
			String phoneNumber = Cache.get(md5PhoneNumber, Cache.namespace.MD5_PHONE_NUMBER_TO_PHONE_NUMBER);
			
			User user = UserManager.getUserByPhoneNumber(phoneNumber);
			
			Social social = new Social(user, true);
			if( !social.isEnabled(type)) {
				
				try {
					oauthVerifier = rewardMeRequest.getParameter(Constants.Oauth.OAUTH_VERIFIER);
				} catch(InvalidParameterException e ) {
					// user had denied access
				} 
				
				if( !StringUtil.isNullOrEmpty(oauthVerifier) ) {

					Map<String, String> tokenInformation = Twitter.getTokenInformation(oauthVerifier, md5PhoneNumber);
					accessToken = tokenInformation.get(Constants.UserPreference.TWITTER_ACCESS_TOKEN);
					accessTokenSecret = tokenInformation.get(Constants.UserPreference.TWITTER_ACCESS_TOKEN_SECRET);
					
					UserPreference userPreference = new UserPreference( user, null, Constants.UserPreference.TWITTER_ACCESS_TOKEN, accessToken);
					UserPreference userPreferenceSecret = new UserPreference( user, null, Constants.UserPreference.TWITTER_ACCESS_TOKEN_SECRET, accessTokenSecret);
					PreferencesManager.save(userPreference);
					PreferencesManager.save(userPreferenceSecret);
					
					//do anything that happens on connect
					social.onConnect(Type.TWITTER);					
					
					//give the user 50 points for connecting
					UserMessage lastUserMessage = MessageManager.getLastUserMessage(user);
					if(lastUserMessage != null) {
						PointCategory pointCategory = PointsManager.getDefaultPointCategory(lastUserMessage.getCustomer());
						PointsManager.credit(user, lastUserMessage.getCustomer(), null, UserPoints.Type.SOCIAL, pointCategory, 50);
					}else {
						//TODO: rewardme points?
						//PointsManager.credit(user, UserPoints.Type.SOCIAL, 100);						
					}
					
				} else {
					logger.warn("Access denied: " + oauthVerifier);
				}
			}
			
			try {
				PrintWriter out = response.getWriter();
				logger.debug("Sending them to: " + Constants.Oauth.SUCCESSFUL_CONNECT_CONFIRMATION_URL);
				out.println("<script>window.location.href = '" + Constants.Oauth.SUCCESSFUL_CONNECT_CONFIRMATION_URL +"'</script>");
			} catch( IOException e ) {
				throw new FatalException (e);
			}
			MySQL.commit();	
			
		} catch(InvalidParameterException e) {
        	
        	try {
				MySQL.rollback();
			} catch (FatalException e1) {
				e1.printStackTrace();
			}
        	logger.error( e );
        } catch( FatalException e ) {
  
        	try {
				MySQL.rollback();
			} catch (FatalException e1) {
				e1.printStackTrace();
			}
			logger.error( e );
        }
        
    }   
}
