package com.viralogy.rewardme.social;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.apache.commons.httpclient.NameValuePair;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.FacebookType;
import com.viralogy.rewardme.manager.PreferencesManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerPreference;
import com.viralogy.rewardme.model.GeoCoord;
import com.viralogy.rewardme.model.UserPreference;
import com.viralogy.rewardme.model.UserSocialCheckin;
import com.viralogy.rewardme.servlet.GatewayServlet;
import com.viralogy.rewardme.util.Cache;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.RemoteRequestUtil;
import com.viralogy.rewardme.util.SecurityUtil;
import com.viralogy.rewardme.util.StringUtil;

public class Facebook extends  SocialSite implements Serializable{
	
	private static final long serialVersionUID = -4811562133708209373L;

	private static Logger logger = Logger.getLogger(Facebook.class);
    
    private static final String ID = "166854303343672";
    private static final String SECRET = "3e44faa287c57212e787161ec793059c";
    
    private static final String API_BETA_REDIRECT_URI = "https://api-beta.rewardme.com/rewardme/facebook";
    private static final String API_SANDBOX_REDIRECT_URI = "https://api-sandbox.rewardme.com/rewardme/facebook";
    private static final String PRODUCTION_REDIRECT_URI = "https://api.rewardme.com/rewardme/facebook";
    
    private static final String OAUTH_URI = "https://www.facebook.com/dialog/oauth";
    private static final String PERMISSIONS = "offline_access, publish_checkins, publish_actions";

    private static final String GRAPH_API_URL = "https://graph.facebook.com/";
    private static final String AUTH_URI = GRAPH_API_URL + "oauth/access_token";
    
    private static final String CHECKIN_URL = GRAPH_API_URL + "me/checkins";
    private static final String SEARCH_LOCATION_URL = GRAPH_API_URL + "search";
    
    public Facebook() {
    	setType( Social.Type.FACEBOOK);
    }
   
	@Override
	public void onConnect() {
		//TODO: fetch and store preferences (name, birthday, etc.)
	}
    
    private static String getRedirectURI () {
    	if (GatewayServlet.isBeta())
    		return API_BETA_REDIRECT_URI;
    	else if (GatewayServlet.isSandbox())
    		return API_SANDBOX_REDIRECT_URI;
    	else
    		return PRODUCTION_REDIRECT_URI;
    }
    
    public String getOauthURI(String phoneNumber) throws FatalException{
    	String md5PhoneNumber = SecurityUtil.md5(phoneNumber);
    	Cache.put(phoneNumber, md5PhoneNumber, Cache.namespace.MD5_PHONE_NUMBER_TO_PHONE_NUMBER);
    	String encodedRedirectURI = null;
    	try {
        	encodedRedirectURI = URLEncoder.encode(getRedirectURI() + "/" + md5PhoneNumber + "/","UTF-8");
    		
    	} catch( UnsupportedEncodingException e) {
    		throw new FatalException (e);
    	}
    	
    	return OAUTH_URI + "?" + Constants.Oauth.CLIENT_ID + "=" + ID + 
    			"&" + Constants.Oauth.REDIRECT_URI + "=" + encodedRedirectURI + 
    			"&" + Constants.Facebook.PERMISSIONS + "=" + PERMISSIONS;
    }
    
    public static String getAccessToken(String authCode, String md5PhoneNumber ) throws FatalException{
    	
    	NameValuePair[] pairs = {
                new NameValuePair(Constants.Oauth.CLIENT_ID, ID ),
                new NameValuePair(Constants.Oauth.REDIRECT_URI, getRedirectURI() + "/" + md5PhoneNumber+"/"),
                new NameValuePair(Constants.Oauth.CLIENT_SECRET, SECRET),
                new NameValuePair(Constants.Oauth.AUTH_CODE, authCode)
            };
        // The password is arbitrary since Freshbooks uses only the authentication token
        String response = RemoteRequestUtil.get( AUTH_URI, pairs, false );
        
        //response returns accessToken=###
        String accessToken = response.substring( response.indexOf('=') + 1);
    	return accessToken;
    }
    
    public void checkin( Address address) throws FatalException, InvalidParameterException {
    	
    	if( !isEnabled()) {
    		throw new InvalidParameterException( Constants.Error.SOCIAL.NOT_ENABLED, ListUtil.from( getType().toString()));
    	}
    	
    	String placeId = null;
    	JSONObject jsonGeoCoord = null;
    	
    	
	    	
	    placeId = getPlaceId( address );
	    try {
		    GeoCoord geoCoord = address.getGeoCoord();
	    	jsonGeoCoord = new JSONObject();
	    	if(geoCoord != null) {
		    	jsonGeoCoord.put(Constants.Request.LATITUDE, geoCoord.getLatitude());
		    	jsonGeoCoord.put(Constants.Request.LONGITUDE, geoCoord.getLongitude());
	    	}
    	} catch ( JSONException e ) {
    		throw new FatalException (e);
    	}
    	
    	String message;
    	Customer customer = address.getCustomer();
    	CustomerPreference customerPreference = customer.getCustomerPreference(Constants.CustomerPreference.Keys.FACEBOOK_CHECKIN_MESSAGE, address);
		if( customerPreference != null ) {
			//address-specific
			message = customerPreference.getValue();
		} else {
			customerPreference = customer.getCustomerPreference(Constants.CustomerPreference.Keys.FACEBOOK_CHECKIN_MESSAGE, null);
			if( customerPreference != null ) { 
				//customer-specific
				message = customerPreference.getValue(); 
			} else {
				//default
				String pageReplace = customer.getName();
				/*CustomerPreference facebookFanPageId = customer.getCustomerPreference(Constants.CustomerPreference.Keys.FACEBOOK_FAN_PAGE_ID, null);
				if(facebookFanPageId != null) {
					pageReplace = "http://www.facebook.com/profile.php?id="+facebookFanPageId;
				}*/
				message = Constants.SocialSite.DEFAULT_CHECKIN_MESSAGE.replace("%s", pageReplace);
			}
		}
    	
    	NameValuePair[] pairs = {
    			new NameValuePair(Constants.Oauth.ACCESS_TOKEN, getAccessToken()),
    			new NameValuePair(Constants.Facebook.MESSAGE, message),
    			new NameValuePair(Constants.Facebook.PLACE, placeId),
    			new NameValuePair(Constants.Facebook.COORDINATES, jsonGeoCoord.toString() )
    	};
		String response = RemoteRequestUtil.post(CHECKIN_URL, pairs);
		
		try {
			JSONObject jsonObject = new JSONObject(response);
			if( jsonObject.has(Constants.Facebook.ERROR)) {
	    		UserPreference userPreference = getSocial().getUser().getUserPreference(Constants.UserPreference.FACEBOOK_ACCESS_TOKEN, null);
	    		PreferencesManager.remove(userPreference);
            	logger.debug("Response: " + response);
    			throw new InvalidParameterException( Constants.Error.SOCIAL.INVALID_ACCESS_TOKEN, ListUtil.from(Social.Type.FACEBOOK.toString(), Social.Type.FACEBOOK.toString()));
			}else {
				// checkin successful!
				UserSocialCheckin userSocialCheckin = new UserSocialCheckin(this.getSocial().getUser(), customer, address, this.getType());
				UserManager.save(userSocialCheckin);
			}
		} catch( JSONException e) {
			throw new FatalException(e);
		}
    }
    
    public String getPlaceId(Customer customer) throws FatalException, InvalidParameterException{
    	CustomerPreference customerPreference = customer.getCustomerPreference(Constants.CustomerPreference.Keys.FACEBOOK_PLACE_ID, null);
    	if( customerPreference != null ) {
    		return customerPreference.getValue();
    	}
    	throw new InvalidParameterException(Constants.Error.SOCIAL.FACEBOOK_NO_PLACEID_FOUND_OR_SETUP, ListUtil.from("null (global)"));
    }
    
    public String getPlaceId( Address address ) throws FatalException, InvalidParameterException{
    	
    	Customer customer = address.getCustomer();
    	CustomerPreference customerPreference = customer.getCustomerPreference(Constants.CustomerPreference.Keys.FACEBOOK_PLACE_ID, address);
    	if( customerPreference != null ) {
    		return customerPreference.getValue();
    	}
    	String placeId = "";
    	String curPlaceId = "";
    	int highestCheckins = -1;

    	GeoCoord geoCoord = address.getGeoCoord();
    	String geoCoordCenter = geoCoord.getLatitude() + "," + geoCoord.getLongitude();
    	
    	NameValuePair[] pairs = {
    			new NameValuePair(Constants.Facebook.QUERY, address.getCustomer().getName()),
    			new NameValuePair(Constants.Facebook.TYPE, Constants.Facebook.PLACE),
    			new NameValuePair(Constants.Facebook.CENTER, geoCoordCenter),
    			new NameValuePair(Constants.Facebook.DISTANCE, Constants.Facebook.SEARCH_DISTANCE + ""),
    			new NameValuePair(Constants.Oauth.ACCESS_TOKEN, getAccessToken() )
    	};
    	 
    	String response = RemoteRequestUtil.get(SEARCH_LOCATION_URL, pairs, false );
    	
    	try {

        	JSONObject jsonData = new JSONObject( response );
        	
        	if( jsonData.has(Constants.Facebook.ERROR)) {
        		UserPreference userPreference = getSocial().getUser().getUserPreference(Constants.UserPreference.FACEBOOK_ACCESS_TOKEN, null);
        		PreferencesManager.remove(userPreference);
            	logger.debug("Response: " + response);
        		throw new InvalidParameterException( Constants.Error.SOCIAL.INVALID_ACCESS_TOKEN, ListUtil.from(Social.Type.FACEBOOK.toString(), Social.Type.FACEBOOK.toString()));
        	}
        	JSONArray jsonArray = jsonData.getJSONArray(Constants.Facebook.DATA);
        	for( int i = 0; i < jsonArray.length(); i++ ) {
        		JSONObject page = (JSONObject)jsonArray.get(i);
        		
				curPlaceId = (String) page.get(Constants.Facebook.ID);

				String curResponse = RemoteRequestUtil.get(GRAPH_API_URL + curPlaceId, "", false );
				JSONObject curJsonData = new JSONObject( curResponse);
				int checkins = curJsonData.has(Constants.Facebook.CHECKINS) ? curJsonData.getInt(Constants.Facebook.CHECKINS) : 0;
				if( checkins > highestCheckins ) {
					highestCheckins = checkins;
					placeId = curPlaceId;
				}
        	}
        	
    	} catch (JSONException e ) {
    		throw new FatalException (e);
    	}
    	if(StringUtil.isNullOrEmpty(placeId)) {
    		throw new InvalidParameterException(Constants.Error.SOCIAL.FACEBOOK_NO_PLACEID_FOUND_OR_SETUP, ListUtil.from(address.getAddressId()+""));
    	}
    	
    	customerPreference = new CustomerPreference( customer, address, Constants.CustomerPreference.Keys.FACEBOOK_PLACE_ID, placeId);
    	PreferencesManager.save(customerPreference);
    	return placeId;
    }
    
    public void like(String id) throws InvalidParameterException, FatalException{
    	if( !isEnabled()) {
    		throw new InvalidParameterException( Constants.Error.SOCIAL.NOT_ENABLED, ListUtil.from( getType().toString()));
    	}
    	
    	NameValuePair[] pairs = {
    			new NameValuePair(Constants.Oauth.ACCESS_TOKEN, getAccessToken())
    	};
    	String LIKE_URL = GRAPH_API_URL + id + "/likes";
    	
		String response = RemoteRequestUtil.post(LIKE_URL, pairs);
		logger.debug("Facebook Like response: " + response);
		
		try {
			JSONObject jsonObject = new JSONObject(response);
			if( jsonObject.has(Constants.Facebook.ERROR)) {
	    		UserPreference userPreference = getSocial().getUser().getUserPreference(Constants.UserPreference.FACEBOOK_ACCESS_TOKEN, null);
	    		PreferencesManager.remove(userPreference);
            	logger.debug("Response: " + response);
    			throw new InvalidParameterException( Constants.Error.SOCIAL.INVALID_ACCESS_TOKEN, ListUtil.from(Social.Type.FACEBOOK.toString(), Social.Type.FACEBOOK.toString()));
			}else {
				// like successful!
				//TODO: store this in the database
			}
		} catch( JSONException e) {
			throw new FatalException(e);
		}		
		
    }

	@Override
	public void post() {
		//TODO: SOCIAL: implement post() for Social
	}
	
	public FacebookType toFacebookType() {
		FacebookType facebookType = new FacebookType();
		facebookType.setEnabled(isEnabled());
		return facebookType;
	}
}
