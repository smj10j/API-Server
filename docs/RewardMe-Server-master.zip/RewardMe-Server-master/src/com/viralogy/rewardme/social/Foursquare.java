package com.viralogy.rewardme.social;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.apache.commons.httpclient.NameValuePair;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.FoursquareType;
import com.viralogy.rewardme.manager.PreferencesManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerPreference;
import com.viralogy.rewardme.model.GeoCoord;
import com.viralogy.rewardme.model.UserSocialCheckin;
import com.viralogy.rewardme.servlet.GatewayServlet;
import com.viralogy.rewardme.util.Cache;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.RemoteRequestUtil;
import com.viralogy.rewardme.util.SecurityUtil;

public class Foursquare extends SocialSite implements Serializable {

	private static final long serialVersionUID = -180871811020340055L;

	private static Logger logger = Logger.getLogger(Foursquare.class);
	
    private static final String ID = "HS5A2SIG21BG4PKKWWU5NVT4IQU3KRMNJCEFE4QXOAD0CANN";
    private static final String SECRET = "YZKTCAKDC23UEUS2TIL1Z54OFMUAZRUGVINJ35BDOJTG0EPP";
    
    private static final String API_BETA_REDIRECT_URI = "https://api-beta.rewardme.com/rewardme/foursquare";
    private static final String API_SANDBOX_REDIRECT_URI = "https://api-sandbox.rewardme.com/rewardme/foursquare";
    private static final String PRODUCTION_REDIRECT_URI = "https://api.rewardme.com/rewardme/foursquare";
    
    private static final String OAUTH_URI = "https://foursquare.com/oauth2/authenticate";
    private static final String AUTH_URI = "https://foursquare.com/oauth2/access_token";
    
    private static final String SEARCH_VENUE_URL = "https://api.foursquare.com/v2/venues/search";
    private static final String CHECKIN_URL = "https://api.foursquare.com/v2/checkins/add";
    
    // the date this code was written so it corresponds with the right Foursquare api version
    private static final String VERSION = "20110620";
    
    // in meters
    private static final int MAX_DISTANCE = 1000;
    
    
    public Foursquare() {
    	setType( Social.Type.FOURSQUARE);
    }
    
	@Override
	public void onConnect() {
		//TODO: fetch and store preferences (name, birthday, etc.)
	}    
    
    private static String getRedirectURI () {
    	if (GatewayServlet.isBeta())
    		return API_BETA_REDIRECT_URI;
    	else if (GatewayServlet.isSandbox())
    		return API_SANDBOX_REDIRECT_URI;
    	else
    		return PRODUCTION_REDIRECT_URI;
    }
    	        

	public String getOauthURI(String phoneNumber) throws FatalException {
    	String md5PhoneNumber = SecurityUtil.md5(phoneNumber);
    	Cache.put(phoneNumber, md5PhoneNumber, Cache.namespace.MD5_PHONE_NUMBER_TO_PHONE_NUMBER);
    	String encodedRedirectURI = null;
    	try {
        	encodedRedirectURI = URLEncoder.encode(getRedirectURI() + "/" + md5PhoneNumber + "/","UTF-8");
    		
    	} catch( UnsupportedEncodingException e) {
    		throw new FatalException (e);
    	}
    	
    	return OAUTH_URI + "?" + Constants.Oauth.CLIENT_ID + "=" + ID + 
    			"&" + Constants.Oauth.RESPONSE_TYPE + "=" + Constants.Oauth.AUTH_CODE +
    			"&" + Constants.Oauth.REDIRECT_URI + "=" + encodedRedirectURI;
	}
	
	public static String getAccessToken(String authCode, String md5PhoneNumber ) throws FatalException{
			  
    	NameValuePair[] pairs = {
                new NameValuePair(Constants.Oauth.CLIENT_ID, ID ),
                new NameValuePair(Constants.Oauth.CLIENT_SECRET, SECRET),
                new NameValuePair(Constants.Oauth.GRANT_TYPE, Constants.Oauth.AUTHORIZATION_CODE),
                new NameValuePair(Constants.Oauth.REDIRECT_URI, getRedirectURI() + "/" + md5PhoneNumber+"/"),
                new NameValuePair(Constants.Oauth.AUTH_CODE, authCode)
            };
    	
        String response = RemoteRequestUtil.get( AUTH_URI, pairs, false );
        String accessToken;
        try {
        	JSONObject jsonObject = new JSONObject( response );
        	accessToken = jsonObject.getString(Constants.Oauth.ACCESS_TOKEN);
        } catch (JSONException e ) {
        	throw new FatalException(e);
        }
    	return accessToken;
    }
	
	public void checkin(Address address) throws FatalException, InvalidParameterException {
    	if( !isEnabled()) {
    		throw new InvalidParameterException( Constants.Error.SOCIAL.NOT_ENABLED, ListUtil.from( getType().toString()));
    	}
    	
    	String venueId = getVenueId(address);
    	String message;
    	Customer customer = address.getCustomer();
    	CustomerPreference customerPreference = customer.getCustomerPreference(Constants.CustomerPreference.Keys.FOURSQUARE_CHECKIN_MESSAGE, address);
    	
		if( customerPreference != null )
			message = customerPreference.getValue();
		else {

			customerPreference = customer.getCustomerPreference(Constants.CustomerPreference.Keys.FOURSQUARE_CHECKIN_MESSAGE, null);
			if( customerPreference != null ) 
				message = customerPreference.getValue(); 
			else 
				message = Constants.SocialSite.DEFAULT_CHECKIN_MESSAGE.replace("%s", customer.getName());
			
		}
    	
    	NameValuePair[] pairs = {
    			new NameValuePair(Constants.Foursquare.VENUE_ID, venueId),
    			new NameValuePair(Constants.Foursquare.SHOUT, message),
    			new NameValuePair(Constants.Oauth.OAUTH_TOKEN,getAccessToken()),
    			new NameValuePair(Constants.Foursquare.BROADCAST_TYPE, Constants.Foursquare.PUBLIC),
    			new NameValuePair(Constants.Foursquare.VERSION, VERSION)
    	};
    	
    	String response = RemoteRequestUtil.post(CHECKIN_URL, pairs);
    	
    	// "code":401,"errorType":"invalid_auth","errorDetail":"OAuth token not found or has been revoked."
    	if(response.contains("invalid_auth")) {
    		throw new InvalidParameterException( Constants.Error.SOCIAL.INVALID_ACCESS_TOKEN, ListUtil.from(Social.Type.FOURSQUARE.toString(), Social.Type.FOURSQUARE.toString()));
    	} else {
    		// successful checkin!
    		UserSocialCheckin userSocialCheckin = new UserSocialCheckin(this.getSocial().getUser(), customer, address, this.getType());
    		UserManager.save(userSocialCheckin);
    	}
    	
    	logger.debug("Response: " + response );
		
	}
	
	private String getVenueId( Address address ) throws FatalException, InvalidParameterException {
		
		Customer customer = address.getCustomer();
		CustomerPreference customerPreference = customer.getCustomerPreference(Constants.CustomerPreference.Keys.FOURSQUARE_VENUE_ID, address);
		
		if( customerPreference != null ) {
			return customerPreference.getValue();
		}
    	
		String venueId = "";

    	GeoCoord geoCoord = address.getGeoCoord();
    	String coordinates = geoCoord.getLatitude() + "," + geoCoord.getLongitude();
    	
    	int highestCheckins = -1;
    	
    	NameValuePair[] pairs = {
    			new NameValuePair(Constants.Foursquare.QUERY, address.getCustomer().getName()),
    			new NameValuePair(Constants.Foursquare.COORDINATES, coordinates),
    			new NameValuePair(Constants.Oauth.OAUTH_TOKEN, getAccessToken()),
    			new NameValuePair(Constants.Foursquare.VERSION, VERSION)
    	};
    	

    	String response = RemoteRequestUtil.get(SEARCH_VENUE_URL, pairs, false );
    	try {
    		JSONObject jsonData = new JSONObject(response);
    		JSONObject jsonResponse = jsonData.getJSONObject(Constants.Foursquare.RESPONSE);
    		JSONArray venues = jsonResponse.getJSONArray(Constants.Foursquare.VENUES);
    		JSONObject venue;
    		// for now, it trusts foursquare's search to make the best match based on restaurant name and proximity to given coordinates
    		//JSONObject venue = venues.getJSONObject(0);
    		
    		
    		// checks the location by checking the distance and if the number of the address matches
    		// then it picks the location with the most checkins
    		for( int i = 0; i < venues.length(); i++ ) {
    			venue = venues.getJSONObject(i); 
    			JSONObject location = venue.getJSONObject(Constants.Foursquare.LOCATION);
    			int distance = location.getInt(Constants.Foursquare.DISTANCE);
    			String streetAddress = location.getString( Constants.Foursquare.ADDRESS);
    			
    			String streetNumber = Integer.parseInt(streetAddress.substring(0, streetAddress.indexOf(' '))) + "";
    			if( distance < MAX_DISTANCE && address.getAddress().indexOf(streetNumber) >= 0) {
    				int checkins = venue.getJSONObject(Constants.Foursquare.STATS).getInt(Constants.Foursquare.CHECKINS_COUNT);
    				if( checkins > highestCheckins ) {
    					highestCheckins = checkins;
    					venueId = venue.getString(Constants.Foursquare.ID);
    				}
    			}
    		}
    		
    	} catch (JSONException e ) {
    		throw new FatalException(e);
    	}
    	
		customerPreference = new CustomerPreference( customer, address, Constants.CustomerPreference.Keys.FOURSQUARE_VENUE_ID, venueId);
		PreferencesManager.save(customerPreference);
		return venueId;
	}

	@Override
	public void post() {
		//TODO: SOCIAL: implement post() for Social
	}
	
	@Override
    public void like(String id) throws InvalidParameterException, FatalException{
		throw new InvalidParameterException(Constants.Error.SOCIAL.FACEBOOK_ONLY);
	}
	
	public FoursquareType toFoursquareType() {
		FoursquareType foursquareType = new FoursquareType();
		foursquareType.setEnabled(isEnabled());
		return foursquareType;
	}
}
