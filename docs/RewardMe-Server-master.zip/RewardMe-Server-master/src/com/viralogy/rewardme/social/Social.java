package com.viralogy.rewardme.social;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.jaxb.AccountsType;
import com.viralogy.rewardme.jaxb.SocialType;
import com.viralogy.rewardme.manager.AddressManager;
import com.viralogy.rewardme.manager.PreferencesManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.model.UserPreference;
import com.viralogy.rewardme.util.DateUtil;

public class Social implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4390311156999919075L;
	private static Logger logger = Logger.getLogger(Social.class);


	public static enum Type {
		FACEBOOK,
		TWITTER,
		FOURSQUARE
	}
	
	private User user;
	
	private Facebook facebook;
	private Twitter twitter;
	private Foursquare foursquare;
	
	private Map<Type, SocialSite> typeToSocialSite;
		
	public Social (User user, boolean needAccessTokens ) throws FatalException {
		this.user = user;
		facebook = new Facebook();
		twitter = new Twitter();
		foursquare = new Foursquare();
		
		typeToSocialSite = new HashMap<Type, SocialSite>();
		
		typeToSocialSite.put(Type.FACEBOOK, facebook);
		typeToSocialSite.put(Type.TWITTER, twitter);
		typeToSocialSite.put(Type.FOURSQUARE, foursquare);
				
		for( Type type : Type.values()) {
			typeToSocialSite.get(type).setSocial(this);
		}
		
		if( needAccessTokens ) {
			setAccessTokens();
		}
	}
	
	public boolean isEnabled( Type type ) {
		SocialSite socialSite = typeToSocialSite.get( type );
		return socialSite.isEnabled();
	}
	
	public void setUser( User user) {
		this.user = user;
	}
	
	public User getUser() {
		return user;
	}
	
	public void refreshAccessTokens() throws FatalException {
		setAccessTokens();
	}
	
	private void setAccessTokens() throws FatalException {

		String preferenceName;
		SocialSite socialSite;
		String accessToken;
		
		for(Type type : Type.values() ) {
			logger.info("Refreshing access tokens for " + type.toString());
			preferenceName = Constants.UserPreference.socialTypeToAccessTokenPreferenceName.get(type);
			socialSite = typeToSocialSite.get(type);
			try {
				UserPreference userPreference = user.getUserPreference(preferenceName, null );
				if( userPreference == null ) {
					socialSite.setAccessToken( null );
					socialSite.setEnabled(false);
					logger.debug("No access token for " + type.toString() + ". Setting to disabled");
				} else {
					accessToken = userPreference.getValue();
					socialSite.setAccessToken( accessToken );
					socialSite.setEnabled( accessToken != null);
					
					// Twitter also requires an access token secret
					if(type.equals(Social.Type.TWITTER))
					{
						userPreference = user.getUserPreference(Constants.UserPreference.TWITTER_ACCESS_TOKEN_SECRET, null);
						String accessTokenSecret = userPreference.getValue();
						((Twitter)socialSite).setAccessTokenSecret(accessTokenSecret);
						socialSite.setEnabled( accessTokenSecret != null );
					}
					
					logger.debug("Found access token preference="+accessToken+" for " + type.toString() + ". Enabled="+ socialSite.isEnabled());				
					
					//remove the intent to share preferences
					if(socialSite.isEnabled()) {
						if(type.equals(Social.Type.FACEBOOK)) {
							userPreference = user.getUserPreference( Constants.UserPreference.FACEBOOK_INTENT_TO_SHARE, null);
							if(userPreference != null) {
								//intended to share on Facebook - let's do the share now!
								if(userPreference.getCreated().after(DateUtil.getDate(Constants.Time.HOUR))) {
									//the intent happened within the past hour - yay!
									try {
										Long addressId = Long.valueOf(userPreference.getValue()); 
										if(addressId != null) {
											Address address = AddressManager.getAddress(addressId, false);
											checkin(Social.Type.FACEBOOK, address);
											logger.debug("Post-dated a Facebook checkin!");				
										}
									}catch (InvalidParameterException e) {
										logger.warn("Failed to do a post-dated Facebook checkin", e);
									}catch(NumberFormatException e)  {
										logger.warn("Failed to do a post-dated Facebook checkin", e);										
									}
								}else {
									//actually... this was a while ago - let's just ignore it
									logger.warn("Failed to do a post-dated Facebook checkin because the time difference was too large");										
								}
								
								PreferencesManager.remove(userPreference);
							}
						}else if(type.equals(Social.Type.TWITTER)) {
							userPreference = user.getUserPreference( Constants.UserPreference.TWITTER_INTENT_TO_SHARE, null);
							if(userPreference != null) {
								PreferencesManager.remove(userPreference);
							}
						}else if(type.equals(Social.Type.FOURSQUARE)) {
							userPreference = user.getUserPreference( Constants.UserPreference.FOURSQUARE_INTENT_TO_SHARE, null);
							if(userPreference != null) {
								PreferencesManager.remove(userPreference);
							}
						}
					}
					
				}
			} catch( InvalidParameterException e) {
				socialSite.setAccessToken( null );
				socialSite.setEnabled( false);
			}
		}
	}
	 
	public void onConnect(Type type) throws FatalException, InvalidParameterException {
		SocialSite socialSite = typeToSocialSite.get(type);
		socialSite.onConnect();
	}	
	
	public String getOauthURI( Type type) throws FatalException, InvalidParameterException {
		SocialSite socialSite = typeToSocialSite.get(type);
		return socialSite.getOauthURI( user.getPhoneNumber() );
	}
	
	public void checkin( Type type, Address address) throws FatalException, InvalidParameterException{
		SocialSite socialSite = typeToSocialSite.get(type);
		socialSite.checkin(address);
	}
	
	public void like(Type type, Customer customer) throws FatalException, InvalidParameterException{
		SocialSite socialSite = typeToSocialSite.get(type);
		String placeId = facebook.getPlaceId(customer);
		socialSite.like(placeId);
	}	
	
	public void disconnect( Type type ) throws InvalidParameterException, FatalException{
		SocialSite socialSite = typeToSocialSite.get(type);
		socialSite.disconnect();
		user = UserManager.getUser(user.getUserId());
	}
	
	public SocialType toSocialType( ) throws FatalException, InvalidParameterException{
		SocialType socialType = new SocialType();
		socialType.setUser(getUser().toUserType(null));
		
		AccountsType accounts = new AccountsType();
		accounts.setFacebook(facebook.toFacebookType());
		accounts.setTwitter(twitter.toTwitterType());
		accounts.setFoursquare(foursquare.toFoursquareType());
		
		socialType.setAccounts(accounts);
		
		return socialType;
	}
	
}
