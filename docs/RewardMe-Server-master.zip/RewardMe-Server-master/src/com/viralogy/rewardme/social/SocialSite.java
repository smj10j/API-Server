package com.viralogy.rewardme.social;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.manager.PreferencesManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.UserPreference;
import com.viralogy.rewardme.util.Cache;
import com.viralogy.rewardme.util.ListUtil;

public abstract class SocialSite {

	private String accessToken;
	private Social.Type type;
	private boolean enabled;
	private Social social;
	
    public abstract void like(String id) throws InvalidParameterException, FatalException;
	public abstract void checkin( Address address) throws FatalException, InvalidParameterException;
	public abstract String getOauthURI( String phoneNumber ) throws FatalException;
	public abstract void post();
	public abstract void onConnect();
	
	public void disconnect() throws InvalidParameterException, FatalException{
		String preferenceName = Constants.UserPreference.socialTypeToAccessTokenPreferenceName.get(getType());
		UserPreference userPreference = social.getUser().getUserPreference(preferenceName, null);
		if( userPreference == null ) {
			throw new InvalidParameterException( Constants.Error.SOCIAL.ALREADY_DISABLED, ListUtil.from(type.toString()));
		} else {
			PreferencesManager.remove(userPreference);
			if( Constants.UserPreference.TWITTER_ACCESS_TOKEN.equals(preferenceName)) {
				userPreference = social.getUser().getUserPreference( Constants.UserPreference.TWITTER_ACCESS_TOKEN_SECRET, null);
				PreferencesManager.remove(userPreference);
			}
			// customer is set to null
			Cache.remove(social.getUser().getUserId() + "", null + "", Cache.namespace.USER_PREFERENCES);
		}
	}
	
	public void setEnabled( boolean enabled ) {
		this.enabled = enabled;
	}
	
	public boolean isEnabled( ) {
		return enabled;
	}
	
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	
	public String getAccessToken() {
		return accessToken;
	}
	
	public void setType( Social.Type type ){
		this.type = type;
	}
	
	public Social.Type getType( ) {
		return type;
	}
	
	public void setSocial( Social social) {
		this.social = social;
	}
	
	public Social getSocial() {
		return social;
	}
	
}
