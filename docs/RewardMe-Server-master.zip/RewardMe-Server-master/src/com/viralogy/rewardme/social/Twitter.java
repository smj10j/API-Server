package com.viralogy.rewardme.social;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.scribe.builder.ServiceBuilder;
import org.scribe.builder.api.TwitterApi;
import org.scribe.model.OAuthRequest;
import org.scribe.model.Response;
import org.scribe.model.Token;
import org.scribe.model.Verb;
import org.scribe.model.Verifier;
import org.scribe.oauth.OAuthService;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.dao.MySQL;
import com.viralogy.rewardme.jaxb.TwitterType;
import com.viralogy.rewardme.manager.PreferencesManager;
import com.viralogy.rewardme.manager.UserManager;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.CustomerPreference;
import com.viralogy.rewardme.model.UserPreference;
import com.viralogy.rewardme.model.UserSocialCheckin;
import com.viralogy.rewardme.servlet.GatewayServlet;
import com.viralogy.rewardme.util.Cache;
import com.viralogy.rewardme.util.ListUtil;
import com.viralogy.rewardme.util.SecurityUtil;
import com.viralogy.rewardme.util.StringUtil;

public class Twitter extends SocialSite implements Serializable{

	private static final long serialVersionUID = 5881140527443084587L;

	private static Logger logger = Logger.getLogger(Twitter.class);

    private static final String ID = "heSfvFwwXwgPdvLqsnUZGQ";
    private static final String SECRET = "39nvwqwyRLGrTlqyeikjRVeNYCgha0O8thgDsynVgO4";
	
	private static final String API_BETA_REDIRECT_URI = "https://api-beta.rewardme.com/rewardme/twitter";
	private static final String API_SANDBOX_REDIRECT_URI = "https://api-sandbox.rewardme.com/rewardme/twitter";
    private static final String PRODUCTION_REDIRECT_URI = "https://api.rewardme.com/rewardme/twitter";
	
    private static final String TWEET_URL = "http://api.twitter.com/1/statuses/update.json";
    
    
    private String accessTokenSecret;
	
    
    public Twitter() {
    	setType( Social.Type.TWITTER);
    }
    
	@Override
	public void onConnect() {
		//TODO: fetch and store preferences (name, birthday, etc.)
	}    
    
    private static String getRedirectURI () {
    	if (GatewayServlet.isBeta())
    		return API_BETA_REDIRECT_URI;
    	else if (GatewayServlet.isSandbox())
    		return API_SANDBOX_REDIRECT_URI;
    	else
    		return PRODUCTION_REDIRECT_URI;
    }
    
	public void checkin(Address address) throws FatalException, InvalidParameterException {
		
		if( !isEnabled()) {
    		throw new InvalidParameterException( Constants.Error.SOCIAL.NOT_ENABLED, ListUtil.from( getType().toString()));
		}
		
		Customer customer = address.getCustomer();
		String message;
		
		CustomerPreference customerPreference = customer.getCustomerPreference(Constants.CustomerPreference.Keys.TWITTER_CHECKIN_MESSAGE, address);
		if( customerPreference != null ) {
			message = customerPreference.getValue();
		} else {
			customerPreference = customer.getCustomerPreference(Constants.CustomerPreference.Keys.TWITTER_CHECKIN_MESSAGE, null);
			
			if( customerPreference != null ) { 
				message = customerPreference.getValue(); 
			} else {
				String twitterId = getTwitterId(customer);
				
				if(StringUtil.isNullOrEmpty(twitterId)) {
					twitterId = customer.getName();
				}
				
				message = Constants.SocialSite.DEFAULT_CHECKIN_MESSAGE.replace("%s", twitterId);
			}
		}	
		// if successful checkin
		if(tweet(message)) {
			UserSocialCheckin userSocialCheckin = new UserSocialCheckin(this.getSocial().getUser(), customer, address, this.getType());
			UserManager.save(userSocialCheckin);
		}
	}
	
	private String getTwitterId( Customer customer ) throws FatalException, InvalidParameterException {
		CustomerPreference customerPreference = customer.getCustomerPreference(Constants.CustomerPreference.Keys.TWITTER_ID, null);
		return customerPreference != null ? customerPreference.getValue() : null;
	}
	
	@Override
	public void post() {
		//TODO: SOCIAL: implement post() for Social
	}
	
	@Override
    public void like(String id) throws InvalidParameterException, FatalException{
		throw new InvalidParameterException(Constants.Error.SOCIAL.FACEBOOK_ONLY);
	}
	
	// return value is whether it was successful or not
	private boolean tweet( String message ) throws FatalException, InvalidParameterException {
		OAuthRequest request = new OAuthRequest(Verb.POST, TWEET_URL);
		request.addQuerystringParameter(Constants.Twitter.STATUS, message);

		Token accessToken = new Token(getAccessToken(), getAccessTokenSecret());
		
		OAuthService oauthService = getOAuthService(null);
		
		oauthService.signRequest(accessToken, request); // the access token from step 4
		Response response = request.send();
		
		String responseString = response.getBody();
		try {
			JSONObject jsonObject = new JSONObject(responseString);
			if( jsonObject.has(Constants.Twitter.ERROR) && jsonObject.getString(Constants.Twitter.ERROR).equals("Could not authenticate with OAuth.")) {
	    		UserPreference userPreference = getSocial().getUser().getUserPreference(Constants.UserPreference.TWITTER_ACCESS_TOKEN, null);
	    		PreferencesManager.remove(userPreference);
            	logger.debug("Response: " + responseString);
				throw new InvalidParameterException( Constants.Error.SOCIAL.INVALID_ACCESS_TOKEN, ListUtil.from(Social.Type.TWITTER.toString(), Social.Type.TWITTER.toString()));
			
			}else {
				// successful checkin
				return true;
			}
		} catch( JSONException e) {
			throw new FatalException(e);
		}
	}

	public TwitterType toTwitterType() {
		TwitterType twitterType = new TwitterType();
		twitterType.setEnabled(isEnabled());
		return twitterType;
	}

	@Override
	public String getOauthURI(String phoneNumber) throws FatalException {
    	String md5PhoneNumber = SecurityUtil.md5(phoneNumber);
    	Cache.put(phoneNumber, md5PhoneNumber, Cache.namespace.MD5_PHONE_NUMBER_TO_PHONE_NUMBER);

    	OAuthService oauthService = getOAuthService(md5PhoneNumber);
    	
		Token requestToken = oauthService.getRequestToken();
    	Cache.put(MySQL.serialize(requestToken ), md5PhoneNumber, Cache.namespace.MD5_PHONE_NUMBER_TO_TWITTER_REQUEST_TOKEN);
		
		return oauthService.getAuthorizationUrl(requestToken);
	}
	
	public void setAccessTokenSecret( String accessTokenSecret ) {
		this.accessTokenSecret = accessTokenSecret;
	}
	
	public String getAccessTokenSecret() {
		return accessTokenSecret;
	}
	
	public static OAuthService getOAuthService(String md5PhoneNumber) {
		ServiceBuilder serviceBuilder = new ServiceBuilder()
											.provider(TwitterApi.class)
											.apiKey(ID)
											.apiSecret(SECRET);
		if( md5PhoneNumber != null ) 
			serviceBuilder.callback( getRedirectURI() + "/" + md5PhoneNumber);
		else 
			serviceBuilder.callback( getRedirectURI() );
		
		return serviceBuilder.build();
	}
	
	public static Map<String, String> getTokenInformation(String oauthVerifier, String md5PhoneNumber) throws FatalException {

		
		Map<String, String> tokenInformation = new HashMap<String, String>();
		
		Verifier verifier = new Verifier(oauthVerifier);
		OAuthService service = getOAuthService(md5PhoneNumber);
		
		Token requestToken = MySQL.deserialize((byte[]) Cache.get(md5PhoneNumber, Cache.namespace.MD5_PHONE_NUMBER_TO_TWITTER_REQUEST_TOKEN));
		Token accessToken = service.getAccessToken(requestToken, verifier);
		
		tokenInformation.put(Constants.UserPreference.TWITTER_ACCESS_TOKEN, accessToken.getToken() );
		tokenInformation.put(Constants.UserPreference.TWITTER_ACCESS_TOKEN_SECRET, accessToken.getSecret());
		
		return tokenInformation;
		
	}
}
