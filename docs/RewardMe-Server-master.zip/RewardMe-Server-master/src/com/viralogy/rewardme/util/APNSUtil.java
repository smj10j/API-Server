package com.viralogy.rewardme.util;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.notnoop.apns.APNS;
import com.notnoop.apns.ApnsService;
import com.notnoop.apns.PayloadBuilder;
import com.notnoop.exceptions.ApnsException;
import com.notnoop.exceptions.NetworkIOException;
import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Device;
import com.viralogy.rewardme.model.User;
import com.viralogy.rewardme.servlet.GatewayServlet;

public abstract class APNSUtil {

	private static Logger logger = Logger.getLogger(APNSUtil.class);

	private static ApnsService getApnsService() throws FatalException {
		if(GatewayServlet.isProduction()) {
			return getProductionApnsService();
		}else {
			return getSandboxApnsService();
		}
	}
	
	private static ApnsService getSandboxApnsService() throws FatalException {	
		try {
			String prefix = Constants.SERVLET_CONTEXT_PATH;
			String file = "WEB-INF/apns/"+"apns_development.p12";
			logger.info("Loading sandbox APNS cert from " + prefix+file);		
			return APNS.newService()
			.withCert(prefix+file, "roger56andbeth23")
			.withSandboxDestination()
			.build();
		}catch(Exception e) {
			throw new FatalException(e);
		}
	}

	private static ApnsService getProductionApnsService() throws FatalException {
		try {
			String prefix = Constants.SERVLET_CONTEXT_PATH;
			String file = "WEB-INF/apns/"+"apns_production.p12";
			logger.info("Loading production APNS cert from " + prefix+file);		
			return APNS.newService()
			.withCert(prefix+file, "A(sd;lki2346h;bobyeah")
			.withProductionDestination()
			.build();
		}catch(Exception e) {
			throw new FatalException(e);
		}
	}	
	
	public static void send(User user, String payload) throws InvalidParameterException, FatalException {

		//validate the payload
		if(StringUtil.isNullOrEmpty(payload) || payload.length() > 255) {
			throw new InvalidParameterException(Constants.Error.GENERAL.INVALID_APNS_PAYLOAD, ListUtil.from(payload != null ? payload.length()+"" : "0",payload));			
		}

		//get the service
		ApnsService service = getApnsService();
		
		//send to each device
		boolean validRemoteDeviceUUID = false;
		for(Device device : user.getDevices()) {
			
			if(!StringUtil.isNullOrEmpty(device.getRemoteDeviceUUID())) {
				validRemoteDeviceUUID = true;
		
				//push the notification
				try {
					logger.debug("Going to send notification: " + payload + " to userId=" + user.getUserId() +", deviceId="+device.getDeviceId());			
					service.push(device.getRemoteDeviceUUID(), payload);
				}catch(NetworkIOException e) {
					logger.error(e);
					throw new FatalException(e);
				}catch(ApnsException e) {
					logger.error(e);
					throw new FatalException(e);			
				}
				
			}
		}
		
		if(!validRemoteDeviceUUID) {
			throw new InvalidParameterException(Constants.Error.INVALID_ID.DEVICE_REMOTE_UUID, ListUtil.from(user.getUserId()+"",""));
		}
	}
	
	public static String createPayload(String body, List<String> args, JSONObject customData, Integer badges, String sound, String actionText) {
		
		PayloadBuilder builder = APNS.newPayload();
	    if(actionText != null) builder = builder.actionKey(actionText);						//Changes the Open App Button
	    if(body != null) {
		    if(args != null) {
		    	builder = builder.localizedKey(body);								//The message - %@ will be replaced by the arguments in order
		    	builder = builder.localizedArguments(args.toArray(new String[0]));	//args
		    }else {
		    	builder = builder.alertBody(body);
		    }
	    }
	    if(badges != null) builder = builder.badge(badges);									//amount of notifications to flag on the badge
	    if(sound != null) builder = builder.sound(sound);									//sound to play ("default")
	    
	    String payload = builder.build();
	    
		if(customData != null) {
			//add custom data
			payload = payload.replace("aps\":{","aps\":{\"custom\":"+customData.toString());
		}
		
		return payload;
	}

	public static Map<String, Date> getInactiveUserIds() throws FatalException {

		//use this to remove inactive apps and stop sending out pushes to them
		
		//get the service
		ApnsService service = getApnsService();

		try {
			return service.getInactiveDevices();
		}catch(NetworkIOException e) {
			throw new FatalException(e);
		}catch(ApnsException e) {
			throw new FatalException(e);			
		}
		/*
		for (String deviceToken : inactiveDevices.keySet()) {
			Date inactiveAsOf = inactiveDevices.get(deviceToken);
			...
		}
		*/
	}
}
