package com.viralogy.rewardme.util;

import java.io.IOException;
import java.nio.BufferUnderflowException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import net.spy.memcached.AddrUtil;
import net.spy.memcached.BinaryConnectionFactory;
import net.spy.memcached.MemcachedClient;
import net.spy.memcached.OperationTimeoutException;
import net.spy.memcached.transcoders.SerializingTranscoder;

import org.apache.log4j.Logger;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.servlet.GatewayServlet;

public abstract class Cache {

	public static final String NULL = "null";
	private static MemcachedClient memcached = null;	
	private static long lastConnectAttempt = 0l;
	private static SerializingTranscoder serializingTranscoder = new SerializingTranscoder();
	
	private static Logger logger = Logger.getLogger(Cache.class);
	
	private static Map<Long, Boolean> threadToUseCache = new ConcurrentHashMap<Long, Boolean>();
	
	public static class lifetime {
		public static final int HALF_MINUTE = 30;
		public static final int MINUTE = 60;
		public static final int FIVE_MINUTE = MINUTE*5;
		public static final int HALF_HOUR = MINUTE*30;
		public static final int HOUR = MINUTE*60;
		public static final int TWO_HOUR = HOUR*2;
		public static final int DAY = HOUR*24;
		public static final int DEFAULT = FIVE_MINUTE;
	}
	
	public static class namespace {
		public static final String CUSTOMER_API_KEY_TO_CUSTOMER_ID = "CUSTOMER_API_KEY_TO_CUSTOMER_ID";
		public static final String CUSTOMER_BY_ID = "CUSTOMER_BY_ID";
		public static final String CUSTOMER_BY_API_KEY = "CUSTOMER_BY_API_KEY";
		public static final String CUSTOMER_CONTACT = "CUSTOMER_CONTACT";
		public static final String QUERY_ADDRESSES = "QUERY_ADDRESSES";
		public static final String NEARBY_ADDRESSES = "NEARBY_ADDRESSES";
		public static final String ADDRESS_ID_TO_CUSTOMER_ID = "ADDRESS_ID_TO_CUSTOMER";
		public static final String ADDRESS = "ADDRESS";
		public static final String ADDRESS_STRING_TO_ADDRESS_ID = "ADDRESS_STRING_TO_ADDRESS_ID";
		public static final String ADDRESS_META_DATA = "ADDRESS_META_DATA";
		public static final String REVERSE_GEOCODE = "REVERSE_GEOCODE";
		public static final String GEOCODE_FORMATTED_ADDRESS = "GEOCODE_FORMATTED_ADDRESS";
		public static final String GEOCODE_GEOCOORD = "GEOCODE_GEOCOORD";
		public static final String YELP_DATA = "YELP_DATA";
		public static final String USER_BY_ID = "USER";
		public static final String USER_BY_DEVICE = "USER_BY_DEVICE";
		public static final String USER_BY_PHONE_NUMBER = "USER_BY_PHONE_NUMBER";
		public static final String USER_CHECKIN = "USER_CHECKIN";
		public static final String COUNT_USER_CHECKINS = "COUNT_USER_CHECKINS";
		public static final String USER_REDEEM = "USER_REDEEM";
		public static final String USER_CHECKIN_ADDRESS_BARCODE = "USER_CHECKIN_ADDRESS_BARCODE";
		public static final String USER_ADDRESSES = "USER_ADDRESSES";
		public static final String USER_REWARDS = "USER_REWARDS";
		public static final String DEVICE_BY_ID = "DEVICE_BY_ID";
		public static final String DEVICE_BY_PHONE_NUMBER = "DEVICE_BY_PHONE_NUMBER";
		public static final String DEVICE_APPLICATION_BY_DEVICE_ID = "DEVICE_APPLICATION_BY_DEVICE_ID";
		public static final String DEVICE_LINK_BY_ID = "DEVICE_LINK_BY_ID";
		public static final String DEVICE_LINK_BY_DEVICE_IDS = "DEVICE_LINK_BY_DEVICE_IDS";
		public static final String DEVICE_LINKS_BY_DEVICE_ID = "DEVICE_LINKS_BY_DEVICE_ID";
		public static final String CUSTOMER_CHECKIN_OPTIONS = "CUSTOMER_CHECKIN_OPTIONS";
		public static final String CUSTOMER_ADDRESSES = "CUSTOMER_ADDRESS";
		public static final String CUSTOMER_REWARDS = "CUSTOMER_REWARDS";
		public static final String CUSTOMER_LOTTERIES = "CUSTOMER_LOTTERIES";
		public static final String CHECKIN_OPTION = "CHECKIN_OPTION";
		public static final String REWARD = "REWARD";
		public static final String REWARD_ID_TO_CUSTOMER_ID = "REWARD_ID_TO_CUSTOMER_ID";
		public static final String DEVICE_LINK_EVENT = "DEVICE_LINK_EVENT";
		public static final String SCHEDULE = "SCHEDULE";
		public static final String REWARD_REDEMPTION_LIMIT_HIT = "REWARD_REDEMPTION_LIMIT_HIT";
		public static final String USER_REFERRAL_BY_PHONE_NUMBER_CUSTOMER = "USER_REFERRAL_BY_PHONE_NUMBER_CUSTOMER";
		public static final String USER_REFERRAL_BY_USER_CUSTOMER = "USER_REFERRAL_BY_USER_CUSTOMER";
		public static final String USER_REFERRAL_REQUEST_BY_ID = "USER_REFERRAL_REQUEST_BY_ID";
		public static final String USER_REFERRAL_REQUEST_BY_USER = "USER_REFERRAL_REQUEST_BY_USER";
		public static final String USER_REFERRAL_REQUEST_BY_PHONE_NUMBER = "USER_REFERRAL_REQUEST_BY_PHONE_NUMBER";
		public static final String USER_REFERRAL_REQUESTS_BY_USER = "USER_REFERRAL_REQUESTS_BY_USER";
		public static final String USER_POINTS = "USER_POINTS";
		public static final String CHECKIN_TOKEN = "CHECKIN_TOKEN";
		public static final String USER_PREFERENCES = "USER_PREFERENCES";
		public static final String USER_DEVICES = "USER_DEVICES";
		public static final String MD5_PHONE_NUMBER_TO_PHONE_NUMBER = "MD5_PHONE_NUMBER_TO_PHONE_NUMBER";
		public static final String USERS_WITH_CHECKIN_AT_CUSTOMER_ADDRESS = "USERS_WITH_CHECKIN_AT_CUSTOMER_ADDRESS";
		public static final String MD5_PHONE_NUMBER_TO_TWITTER_REQUEST_TOKEN = "MD5_PHONE_NUMBER_TO_TWITTER_REQUEST_TOKEN";
		public static final String CUSTOMER_PREFERENCES = "CUSTOMER_PREFERENCES";
		public static final String SESSION_BY_USER_ID_AND_CUSTOMER_AND_ID_ADDRESS_ID = "SESSION_BY_USER_ID_CUSTOMER_ID_ADDRESS_ID";
		public static final String WAREHOUSE_SESSION_BY_SESSION_ID = "WAREHOUSE_SESSION_BY_SESSION_ID";
		public static final String SESSION_BY_ID = "SESSION_BY_ID";
		public static final String SEGMENT = "SEGMENT";
		public static final String SEGMENT_ARCHIVED = "SEGMENT_ARCHIVED";
		public static final String CUSTOMER_SEGMENTS = "CUSTOMER_SEGMENTS";
		public static final String GLOBAL_USER_SEGMENTS = "GLOBAL_USER_SEGMENTS";
		public static final String ADDRESS_USER_SEGMENTS = "ADDRESS_USER_SEGMENTS";
		public static final String USER_SEGMENT = "USER_SEGMENT";
		
		public static final String WAREHOUSE_EVENT_DESCRIPTOR = "WAREHOUSE_EVENT_DESCRIPTOR";
		public static final String CLAZZ_TO_WAREHOUSE_EVENT_DESCRIPTORS = "CLAZZ_TO_WAREHOUSE_EVENT_DESCRIPTORS";
		public static final String DELAYED_WAREHOUSE_EVENT_DESCRIPTORS = "DELAYED_WAREHOUSE_EVENT_DESCRIPTORS";
		public static final String ALL_WAREHOUSE_EVENT_DESCRIPTORS = "ALL_WAREHOUSE_EVENT_DESCRIPTORS";
	

		public static final String PERIPHERAL_BY_ID = "PERIPHERAL_BY_ID";
		public static final String PERIPHERAL_BY_EXTERNAL_ID = "PERIPHERAL_BY_EXTERNAL_ID";

		public static final String SMS_VALIDATION_STATUS_BY_SID = "SMS_VALIDATION_STATUS_BY_SID";

		public static final String EMPLOYEE_BY_ID = "EMPLOYEE_BY_ID";
		public static final String EMPLOYEE_BY_EXTERNAL_ID = "EMPLOYEE_BY_EXTERNAL_ID";
		
		public static final String RATE_LIMIT_CUSTOMER_USER_METHOD = "RATE_LIMIT_CUSTOMER_USER_METHOD";
		public static final String RATE_LIMIT_HIT_FOR_CUSTOMER_USER_METHOD = "RATE_LIMIT_HIT_FOR_CUSTOMER_USER_METHOD";

		public static final String SECRET_KEY_BY_ID = "SECRET_KEY_BY_ID";
		public static final String SECRET_KEYS_BY_TYPE = "SECRET_KEYS_BY_TYPE";
		public static final String SECRET_KEY_BY_TYPE_AND_KEY = "SECRET_KEY_BY_TYPE_AND_KEY";

		public static final String DEVICE_APPLICATION_BY_DEVICE_APPLICATION_ID = "DA_BY_DA_ID";
		public static final String APPLICATION_BY_APPLICATION_ID = "APPLICATION_BY_APPLICATION_ID";
		public static final String UNLINKED_DEVICE_APPLICATION_BY_UNLINKED_DEVICE_APPLICATION_ID = "UDA_BY_UDA_ID";
		
		public static final String PHONE_NUMBER_LOOKUP_REQUEST = "PHONE_NUMBER_LOOKUP_REQUEST";
		
		public static final String COMPLETED_REPORT = "COMPLETED_REPORT";
		public static final String SERVLET_AUTHENTICATION_TO_CUSTOMER_CONTACT = "SERVLET_AUTHENTICATION_TO_CUSTOMER_CONTACT";
		public static final String AB_TESTS = "AB_TESTS";
		public static final String AB_COHORTS = "AB_COHORTS";
		public static final String DEVICE_TEST_PAIRS = "DEVICE_TEST_PAIRS";

		public static final class POS {
			public static final String TX_BY_ID = "TX_BY_ID";
			public static final String TX_BY_EXTERNAL_TX_ID = "TX_BY_EXTERNAL_TX_ID";
			public static final String INVENTORY_ITEM_BY_ID = "INVENTORY_ITEM_BY_ID";
			public static final String INVENTORY_ITEM_MOD_BY_ID = "INVENTORY_ITEM_MOD_BY_ID";
			public static final String INVENTORY_CATEGORY_BY_ID = "INVENTORY_CATEGORY_BY_ID";
			public static final String INVENTORY_CATEGORIES_BY_INVENTORY_ITEM_ID = "INVENTORY_CATEGORIES_BY_INVENTORY_ITEM_ID";
			public static final String INVENTORY_ITEMS_BY_TX_ID = "INVENTORY_ITEMS_BY_TX_ID";
			public static final String INVENTORY_ITEMS_MODS_BY_ITEM_ID_AND_TX_ID = "INVENTORY_ITEMS_MODS_BY_ITEM_ID_AND_TX_ID";
			public static final String DISCOUNT_BY_ID = "DISCOUNT_BY_ID";
			public static final String DISCOUNTS_BY_TX_ID = "DISCOUNTS_BY_TX_ID";
			public static final String INVENTORY_ITEMS_DISCOUNTS_BY_ITEM_ID_AND_TX_ID = "INVENTORY_ITEMS_DISCOUNTS_BY_ITEM_ID_AND_TX_ID";
			public static final String INVENTORY_ITEM_MOD_BY_EXTERNAL_ID = "INVENTORY_ITEM_MOD_BY_EXTERNAL_ID";
			public static final String INVENTORY_ITEM_BY_EXTERNAL_ID = "INVENTORY_ITEM_BY_EXTERNAL_ID";
			public static final String INVENTORY_ITEM_BY_KITCHEN_ITEM_NAME = "INVENTORY_ITEM_BY_KITCHEN_ITEM_NAME";
			public static final String INVENTORY_ITEM_MOD_BY_KITCHEN_ITEM_NAME = "INVENTORY_ITEM_MOD_BY_KITCHEN_ITEM_NAME";
			public static final String SEGMENT_SUM_AMOUNT_LESS_TAX_AND_DISCOUNT = "SEGMENT_SUM_AMOUNT_LESS_TAX_AND_DISCOUNT";
			public static final String SEGMENT_SUM_AMOUNT_LESS_DISCOUNT = "SEGMENT_SUM_AMOUNT_LESS_DISCOUNT";
			public static final String SEGMENT_SUM_AMOUNT_LESS_TAX = "SEGMENT_SUM_AMOUNT_LESS_TAX";
			public static final String SEGMENT_SUM_AMOUNT = "SEGMENT_SUM_AMOUNT";
			
		}
	}
	
	private static String getNamespaceKey(String...namespaces) {
		String server = GatewayServlet.getHostname();
		String key = server + "|" + Constants.API_VERSION + "|";
		for(String ns : namespaces) {
			key+= ns + "|";
		}
		//logger.debug("CacheKey: " + key);

		return key.toUpperCase();
	}
	
	private static String getSafeKey(String key) throws FatalException {
		String encodedKey = StringUtil.utf8Encode(key);
		//logger.debug("Encoded key="+key+ " to "+encodedKey);
		String safeKey = encodedKey;
		if(safeKey.length() > 250) {
			//make it a 64 byte key
			//logger.debug("Shortening key of length " + safeKey.length() + "...");
			safeKey = SecurityUtil.md5(safeKey.substring(0,249)) + SecurityUtil.md5(safeKey.substring(249));
		}
		return safeKey.toUpperCase();
	}
	
	public static void init() throws FatalException {
		//only allow attempts to reinitialize the connection every 30 seconds
		if(System.currentTimeMillis() - lastConnectAttempt < (1000 * 30))
			return;
		lastConnectAttempt = System.currentTimeMillis();
		shutdown();
		
		//start-up memcached server if not already up
		//String prefix = Constants.SERVLET_CONTEXT_PATH;
		//String file = "WEB-INF/scripts/memcached-start.sh";
		
		String memcachedServers = ArrayUtil.implode(Constants.memcacheServers," ");
		logger.info("Memcached: using the remote, shared cache nodes at : " + memcachedServers);
		
		try {
			memcached = new MemcachedClient(new BinaryConnectionFactory(), AddrUtil.getAddresses(memcachedServers));
			
			//compress anything over 10 kb
			serializingTranscoder.setCompressionThreshold(1024*10);
			
		} catch (IOException e) {
			throw new FatalException(e);
		}
	}
	
	private static void shutdown() {
		if(memcached != null)
			memcached.shutdown();
		memcached = null;
	}
	
	private static void handleFailure(boolean restartCache, String message) throws FatalException {
		if(restartCache) {
			init();
		}
		if(message != null) {
			logger.warn(message);
		}
	}

	private static void put(Object value, int lifetime, String key) throws FatalException {
		if(memcached == null) return;		
		if(value == null)
			return;
		
		Boolean useCache = threadToUseCache.get(Thread.currentThread().getId());
		if(useCache == null) {
			threadToUseCache.put(Thread.currentThread().getId(), true);
		}else if(useCache == false) {
			threadToUseCache.put(Thread.currentThread().getId(), true);
			return;
		}		
		
		String safeKey = getSafeKey(key);
		memcached.set(safeKey, lifetime, value, serializingTranscoder);
	}
	
	public static void put(Object value, String key, String...namespaces) throws FatalException {
		if(memcached == null) return;
		String namespaceKey = getNamespaceKey(namespaces);
		//logger.debug("Just put value: " + value + " into namespace: " + namespaceKey);
		put(value, lifetime.DEFAULT, namespaceKey + key);
	}	
	
	public static void put(Object value, int lifetime, String key, String...namespaces) throws FatalException {
		if(memcached == null) return;
		String namespaceKey = getNamespaceKey(namespaces);
		//logger.debug("Just put value: " + value + " into namespace: " + namespaceKey);
		put(value, lifetime, namespaceKey + key);
	}
	
	public static void ignoreCacheOnNext() {
		threadToUseCache.put(Thread.currentThread().getId(), false);
	}
	
	private static Object get(String key) throws FatalException {
		if(memcached == null) return null;
		Boolean useCache = threadToUseCache.get(Thread.currentThread().getId());
		if(useCache == null) {
			threadToUseCache.put(Thread.currentThread().getId(), true);
		}else if(useCache == false) {
			threadToUseCache.put(Thread.currentThread().getId(), true);
			return null;
		}

		String safeKey = getSafeKey(key);
		try {
			return memcached.get(safeKey, serializingTranscoder);
		}catch (BufferUnderflowException e) {
			handleFailure(true, "Memcached: connection error on get(\""+safeKey+"\")");	//safeKey may have been the problem
			return null;
		}catch (OperationTimeoutException e) {
			handleFailure(true, "Memcached: timeout on get(\""+key+"\")");
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static <T> T get(String key,String...namespaces) throws FatalException {
		if(memcached == null) return null;
		String namespaceKey = getNamespaceKey(namespaces);
		return (T) get(namespaceKey + key);
	}	
	
	private static void remove(String key) throws FatalException {
		if(memcached == null) return;
		String safeKey = getSafeKey(key);
		memcached.delete(safeKey);
	}
	
	public static void remove(String key,String...namespaces) throws FatalException {
		if(memcached == null) return;
		String namespaceKey = getNamespaceKey(namespaces);
		//logger.debug("Removed with namespace: " + namespaceKey);
		remove(namespaceKey + key);
	}		
	
	public static void clear() throws FatalException {
		if(memcached == null) return;
		memcached.flush();
		logger.info("Memcached: clearing cache");
	}
}
