package com.viralogy.rewardme.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.httpclient.NameValuePair;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.manager.CustomerInvoiceManager;
import com.viralogy.rewardme.model.CustomerBilling;
import com.viralogy.rewardme.model.CustomerInvoice;
import com.viralogy.rewardme.model.CustomerInvoiceItem;
import com.viralogy.rewardme.model.CustomerInvoicePayment;
import com.viralogy.rewardme.model.FreshbooksResponse;

public class FreshbooksUtil
{
    private static Logger logger = Logger.getLogger(FreshbooksUtil.class);

	private static final String FRESHBOOKS_SYSTEM_GERALD = "https://geraldwebsite.freshbooks.com";
	private static final String FRESHBOOKS_SYSTEM_PRODUCTION = "https://viralogy.freshbooks.com";
	
	private static final String AUTH_TOKEN_GERALD = "bf3b22e406ef55d4064c81b5a203e74b";
    private static final String AUTH_TOKEN_PRODUCTION = "25f5c9e8789280350601b31b63f52d28";
    
    private static final String API_ENDPOINT_GERALD = "https://geraldwebsite.freshbooks.com/api/2.1/xml-in";
    private static final String API_ENDPOINT_PRODUCTION = "https://viralogy.freshbooks.com/api/2.1/xml-in";
    
    private static String getApiEndpoint(boolean production) {
    	if(production) {
    		return API_ENDPOINT_PRODUCTION;
    	}
    	return API_ENDPOINT_GERALD;
    }
    
    private static String getAuthToken(boolean production) {
    	if(production) {
    		return AUTH_TOKEN_PRODUCTION;
    	}
    	return AUTH_TOKEN_GERALD;
    }
    
    public static String getSystemUrl(boolean production) {
    	if(production) {
    		return FRESHBOOKS_SYSTEM_PRODUCTION;
    	}
    	return FRESHBOOKS_SYSTEM_GERALD;
    }
    
    public static long createClient( String contactName, String customerName, String email, String password, boolean production) throws FatalException {
        
        //logger.debug( "About to execute create client with parameters: "+contactName+" "+customerName+" "+email+" "+password );
        String firstName;
        String lastName;
        if( contactName.indexOf(' ') != -1 )
        {
            firstName = contactName.substring( 0, contactName.indexOf( ' ' ) );
            lastName = contactName.substring( contactName.indexOf(' ') + 1 );
        }
        else {
            firstName = contactName;
            lastName = "";
        }
        
        NameValuePair[] pairs = {
            new NameValuePair(Constants.Freshbooks.FIRST_NAME, firstName ),
            new NameValuePair(Constants.Freshbooks.LAST_NAME, lastName),
            new NameValuePair(Constants.Freshbooks.ORGANIZATION, customerName),
            new NameValuePair(Constants.Freshbooks.EMAIL, email),
            new NameValuePair(Constants.Freshbooks.PASSWORD, password)
        };
        
        String requestXml = createRequestXml(Constants.Freshbooks.CREATE_CLIENT, pairs, null);
        
        logger.debug("CreateClient XML: " + requestXml);
        
        // The password is arbitrary since Freshbooks uses only the authentication token
        String responseXml = RemoteRequestUtil.post( getApiEndpoint(production), requestXml, getAuthToken(production), "X", null, null );
        
        
        logger.debug("Length of response: " + responseXml.length());
        logger.debug("Response: " + responseXml);
        FreshbooksResponse freshbooksResponse = processResponseXml( responseXml, Constants.Freshbooks.CREATE_CLIENT );
        
        return freshbooksResponse.getFreshbooksId();
    }
    
    public static void updateClient( long freshbooksClientId, String contactName, String email, String password, boolean production) throws FatalException {
        logger.debug( "About to execute updateClient with parameters: "+freshbooksClientId+" "+contactName+" "+email+" "+password );

        String firstName = contactName.substring( 0, contactName.indexOf( ' ' ) );
        String lastName = contactName.substring( contactName.indexOf(' ') + 1 );
        
        NameValuePair[] pairs = {
            new NameValuePair(Constants.Freshbooks.CLIENT_ID, freshbooksClientId+""),
            new NameValuePair(Constants.Freshbooks.FIRST_NAME, firstName ),
            new NameValuePair(Constants.Freshbooks.LAST_NAME, lastName),
            new NameValuePair(Constants.Freshbooks.EMAIL, email),
            new NameValuePair(Constants.Freshbooks.PASSWORD, password)
        };
        
        // used to get a sample recurring, for testing
        /*
        NameValuePair[] pairs = {
            new NameValuePair(Constants.Freshbooks.RECURRING_ID, 4+""),
        };
        String xmlRequest = XmlUtil.createFreshbooksRequest(Constants.Freshbooks.GET_RECURRING, pairs, null);*/
        
        // used to get the list of invoices, testing only!
        //String xmlRequest = XmlUtil.createFreshbooksRequest(Constants.Freshbooks.LIST_INVOICE, null, null);
        
        String xmlRequest = createRequestXml(Constants.Freshbooks.UPDATE_CLIENT, pairs, null);
        
        
        logger.debug("CreateClient XML:\n" + xmlRequest);
        
        String responseXml = RemoteRequestUtil.post( getApiEndpoint(production), xmlRequest, getAuthToken(production), "X", null, null );

        logger.debug("Length of response: " + responseXml.length());
        logger.debug("Response:\n" + responseXml);

        // checks if it was successful
        processResponseXml(responseXml, Constants.Freshbooks.UPDATE_CLIENT);
         
    }

    public static long createRecurring( long freshbooksClientId, List<CustomerInvoiceItem> customerInvoiceItems, boolean production ) throws FatalException {
        logger.debug("Just entered FreshbooksUtil.createRecurring");
        
        logger.debug("Constants.Freshbooks.Monthly value is: " + Constants.Freshbooks.MONTHLY);
        NameValuePair[] pairs = {
            new NameValuePair(Constants.Freshbooks.CLIENT_ID, freshbooksClientId+""),
            new NameValuePair(Constants.Freshbooks.FREQUENCY, Constants.Freshbooks.MONTHLY)
        };
        
        String xmlRequest = createRequestXml(Constants.Freshbooks.CREATE_RECURRING, pairs, customerInvoiceItems);
        logger.debug("CreateRecurring XML:\n" + xmlRequest);
        
        String responseXml = RemoteRequestUtil.post( getApiEndpoint(production), xmlRequest, getAuthToken(production), "X", null, null );
        
        logger.debug("Length of response: " + responseXml.length());
        logger.debug("Response: " + responseXml);
        
        FreshbooksResponse freshbooksResponse = processResponseXml( responseXml, Constants.Freshbooks.CREATE_RECURRING );
        
        return freshbooksResponse.getFreshbooksId();
        
    }

    public static FreshbooksResponse getCustomerInvoice( long freshbooksInvoiceId, boolean production ) throws FatalException {
        logger.debug("Entered getCustomerInvoice with freshbooksinvoiceId: " + freshbooksInvoiceId);
        
        
        NameValuePair[] pairs = {
            new NameValuePair(Constants.Freshbooks.INVOICE_ID, freshbooksInvoiceId+""),
        };
        String xmlRequest = createRequestXml(Constants.Freshbooks.GET_INVOICE, pairs, null);
        
        logger.debug("getCustomerInvoice XML:\n" + xmlRequest);
        
        String responseXml = RemoteRequestUtil.post( getApiEndpoint(production), xmlRequest, getAuthToken(production), "X", null, null );

        logger.debug("Length of response: " + responseXml.length());
        logger.debug("Response:\n" + responseXml);
        
        return processResponseXml( responseXml, Constants.Freshbooks.GET_INVOICE);
    }
    
    public static FreshbooksResponse getPayment( long freshbooksPaymentId, boolean production) throws FatalException {
        logger.debug("In getPayment method with freshbooksPaymentId: " + freshbooksPaymentId);
        
        NameValuePair[] pairs = {
            new NameValuePair(Constants.Freshbooks.PAYMENT_ID, freshbooksPaymentId+"")
        };
        String xmlRequest = createRequestXml(Constants.Freshbooks.GET_PAYMENT, pairs, null );
        
        logger.debug("getPayment XML:\n" + xmlRequest);
        
        String responseXml = RemoteRequestUtil.post( getApiEndpoint(production), xmlRequest, getAuthToken(production), "X", null, null );

        logger.debug("Length of response: " + responseXml.length());
        logger.debug("Response:\n" + responseXml);
        
        return processResponseXml( responseXml, Constants.Freshbooks.GET_PAYMENT);
    }
    
    private static String createRequestXml(String methodName, NameValuePair[] pairs, List<CustomerInvoiceItem> customerInvoiceItems ) throws FatalException{
        try {
            logger.debug("Just entered XmlUtil.createFreshbooksRequest");
            DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = dbfac.newDocumentBuilder();
            Document doc = docBuilder.newDocument();
            
            Element root = doc.createElement( Constants.Freshbooks.REQUEST );
            doc.appendChild(root);
            root.setAttribute( Constants.Freshbooks.METHOD, methodName );
            
            // if the request is a creation or update
            if( Constants.Freshbooks.CREATE_CLIENT.equals( methodName ) ||
                Constants.Freshbooks.UPDATE_CLIENT.equals( methodName ) ||
                Constants.Freshbooks.CREATE_RECURRING.equals( methodName ) ) 
            {
                Element type = doc.createElement(Constants.Freshbooks.methodToRequestType.get( methodName ));
                root.appendChild( type );
                
                Element child = null;
                Text value = null;
                for (NameValuePair pair : pairs ) {
                    child = doc.createElement(pair.getName());
                    type.appendChild( child );
                    
                    value = doc.createTextNode( pair.getValue() );
                    child.appendChild( value );
                }
                
                // if there are items to be placed into the request lines
                if( customerInvoiceItems != null ) {
                    Element lines = doc.createElement( Constants.Freshbooks.LINES );
                    type.appendChild( lines );
                    
                    for (CustomerInvoiceItem customerInvoiceItem : customerInvoiceItems) {
                        Element line = doc.createElement( Constants.Freshbooks.LINE);
                        lines.appendChild( line );
                        logger.debug("Creating one item line");
                        for (NameValuePair pair : customerInvoiceItem.getNameValuePairs() ) {
                            child = doc.createElement(pair.getName());
                            line.appendChild( child );
                            
                            value = doc.createTextNode( pair.getValue() );
                            child.appendChild( value );
                        }
                    }
                }
            }
            // else if the request is a get method or delete
            else if ( Constants.Freshbooks.GET_RECURRING.equals( methodName ) ||
                      Constants.Freshbooks.GET_INVOICE.equals(methodName) || 
                      Constants.Freshbooks.GET_PAYMENT.equals(methodName) ||
                      Constants.Freshbooks.DELETE_CLIENT.equals(methodName) )
            {
                Element type = doc.createElement(Constants.Freshbooks.methodToRequestType.get(methodName));
                root.appendChild(type);
                String id = pairs[0].getValue();
                
                Text value = doc.createTextNode( id );
                type.appendChild( value );
                
            }
            else if(Constants.Freshbooks.LIST_INVOICE.equals(methodName))
            {
                // do nothing since requires no child nodes
            }
            
            TransformerFactory transfac = TransformerFactory.newInstance();
            Transformer trans = transfac.newTransformer();
            trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
            trans.setOutputProperty(OutputKeys.INDENT, "yes");
            
            StringWriter sw = new StringWriter();
            StreamResult result = new StreamResult(sw);
            DOMSource source = new DOMSource(doc);
            trans.transform(source, result);
            String xmlString = sw.toString();
            
        
            return xmlString;
            
        } catch (ParserConfigurationException e ) {
            throw new FatalException(e);
        } catch (TransformerConfigurationException e) {
            throw new FatalException(e);
        } catch (TransformerException e ) {
            throw new FatalException(e);
        }
    }
    
    private static FreshbooksResponse processResponseXml( String responseXml, String methodName) throws FatalException {
        FreshbooksResponse freshbooksResponse = new FreshbooksResponse();
        
        //get the factory
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        try {

            //Using factory get an instance of document builder
            DocumentBuilder db = dbf.newDocumentBuilder();

            InputStream inputStream = new ByteArrayInputStream(responseXml.getBytes("UTF-8"));

            //parse using builder to get DOM representation of the XML file
            Document doc = db.parse(inputStream);
            Element ele = doc.getDocumentElement();
            
            String status = ele.getAttribute( Constants.Freshbooks.STATUS );
            if( !Constants.Freshbooks.METHOD_SUCCESSFUL.equals( status )) {
                throw new FatalException("Freshbooks method "+methodName+" failed.");
            }
            
            String responseType = Constants.Freshbooks.methodToResponseType.get(methodName);
            
            if( Constants.Freshbooks.CLIENT_ID.equals( responseType) ||
                Constants.Freshbooks.RECURRING_ID.equals(responseType) ) {
                Long freshbooksId = XmlUtil.getLongValue(ele, responseType);
                freshbooksResponse.setFreshbooksId(  freshbooksId );
            } else if( Constants.Freshbooks.INVOICE.equals( responseType ) ) {
                logger.debug( "Extracting customer invoice from respnose" );
                
                Long freshbooksInvoiceId = XmlUtil.getLongValue( ele, Constants.Freshbooks.INVOICE_ID );
                Long freshbooksClientId = XmlUtil.getLongValue(ele, Constants.Freshbooks.CLIENT_ID);
                Date date = XmlUtil.getDateValue( ele, Constants.Freshbooks.DATE);
                Date dueDate = DateUtil.addToDate( date, Calendar.DATE, Constants.Freshbooks.DAYS_TILL_REMINDER );
                logger.debug("Date: " + date.toString() );
                logger.debug("Due date: " + dueDate.toString() );
                boolean paid = Constants.Freshbooks.PAID.equals( XmlUtil.getTextValue( ele, Constants.Freshbooks.STATUS ) );
                Date paidDate = paid ?  date : null;
                
                CustomerBilling customerBilling = CustomerInvoiceManager.getBilling( freshbooksClientId );
                
                CustomerInvoice customerInvoice = new CustomerInvoice( customerBilling, freshbooksInvoiceId, dueDate, paidDate );
                List<CustomerInvoiceItem> customerInvoiceItems = getResponseItems( ele );
                
                freshbooksResponse.setCustomerInvoice( customerInvoice );
                freshbooksResponse.setCustomerInvoiceItems(customerInvoiceItems);
                logger.debug("Extracted info: " + freshbooksInvoiceId + " " + freshbooksClientId + " " + paidDate + " " + dueDate);
            
            } else if( Constants.Freshbooks.PAYMENT.equals( responseType ) ) {
                logger.debug("Extracting payment from response" );
                
                // we do not track freshbooksPaymentId, so this is for debug only
                Long freshbooksPaymentId = XmlUtil.getLongValue( ele, Constants.Freshbooks.PAYMENT_ID);
                Long freshbooksClientId = XmlUtil.getLongValue(  ele, Constants.Freshbooks.CLIENT_ID );
                Long freshbooksInvoiceId = XmlUtil.getLongValue( ele, Constants.Freshbooks.INVOICE_ID);
                Date datePaid = XmlUtil.getDateValue( ele, Constants.Freshbooks.DATE);
                Double amount = XmlUtil.getDoubleValue( ele, Constants.Freshbooks.AMOUNT);

                CustomerInvoicePayment customerInvoicePayment = new CustomerInvoicePayment( freshbooksClientId, freshbooksInvoiceId, datePaid, amount);

                freshbooksResponse.setCustomerInvoicePayment( customerInvoicePayment);
                
                logger.debug("FreshbooksPaymentId: " + freshbooksPaymentId);
            }
            
            return freshbooksResponse;
            
        } catch(ParserConfigurationException e) {
            throw new FatalException(e);
        } catch(SAXException e) {
            throw new FatalException(e);
        } catch(IOException e) {
            throw new FatalException(e);
        } catch ( ParseException e ){
            throw new FatalException(e);
        } catch( InvalidParameterException e ) {
            throw new FatalException (e);
        }
    }
    
    private static List<CustomerInvoiceItem> getResponseItems( Element ele ) {
        
        NodeList customerInvoiceItemNodes = ele.getElementsByTagName(Constants.Freshbooks.LINE);
        ArrayList<CustomerInvoiceItem> customerInvoiceItems = new ArrayList<CustomerInvoiceItem>();
        if( customerInvoiceItemNodes != null && customerInvoiceItemNodes.getLength() > 0 ) {
           for( int i = 0; i < customerInvoiceItemNodes.getLength(); i++ ) {
                Element customerInvoiceEle = (Element)customerInvoiceItemNodes.item( i );
                
                customerInvoiceItems.add( getCustomerInvoiceItem(customerInvoiceEle) );
            }
        }
        return customerInvoiceItems;
    }
    
    private static CustomerInvoiceItem getCustomerInvoiceItem( Element ele ) {
        String name = XmlUtil.getTextValue( ele, Constants.Freshbooks.NAME );
        String description = XmlUtil.getTextValue( ele, Constants.Freshbooks.DESCRIPTION );
        Float unitCost = XmlUtil.getFloatValue(ele, Constants.Freshbooks.UNIT_COST);
        Long quantity = XmlUtil.getLongValue(ele, Constants.Freshbooks.QUANTITY);
            
        logger.debug("Created new item with values " + name + " " + description + " " + unitCost + " " + quantity);
        return new CustomerInvoiceItem( name, description, unitCost, quantity );
    }
}
