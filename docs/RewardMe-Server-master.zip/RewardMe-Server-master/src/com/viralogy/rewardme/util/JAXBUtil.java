package com.viralogy.rewardme.util;

import java.io.StringReader;
import java.io.Writer;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.jaxb.RewardMeType;
import com.viralogy.rewardme.model.RewardMeRequest;

public abstract class JAXBUtil {

	public static <T> void marshal(RewardMeRequest request, JAXBElement<T> responseRoot, Writer writer) throws FatalException {
		try {
			//setup
			JAXBContext jaxbContext = JAXBContext.newInstance(Constants.Path.JaxbPackage);
			Marshaller marshaller = jaxbContext.createMarshaller();
			
			//options
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

			//do the marshalling
			//marshaller.marshal(response.get(), writer);

			//marshalls with RewardMe as the root element
			marshaller.marshal( responseRoot, writer);

			
		} catch (JAXBException e) {
			throw new FatalException(e);
		}
	}
	
	public static RewardMeType unmarshal(String xmlRewardMeResponse) throws FatalException {
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(Constants.Path.JaxbPackage);
				
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

			JAXBElement<RewardMeType> rewardMeResponse = unmarshaller.unmarshal(
					new StreamSource( 
							new StringReader(
									xmlRewardMeResponse
							)
					),
					RewardMeType.class
			);
			return rewardMeResponse.getValue();
						
		} catch (JAXBException e) {
			throw new FatalException(e);
		}

	}
}
