package com.viralogy.rewardme.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.viralogy.rewardme.conf.FatalException;

public class SlicehostUtil {

	private static final String API_KEY = "8bea69b719cdb1c13d3c0c650eedc631d06d36dc222f19f7b7b9c6de186598db";
	private static final String API_URL = "https://api.slicehost.com/";
	private static final String REWARDME_COM_ZONE_ID = "172830";
	private static final String SUFFIX = ".xml";
	
	private static final String PARAM_ZONE_ID = "zone_id";
	private static final String PARAM_NAME = "name";
	private static final String PARAM_DATA = "data";
	private static final String REQ_ZONES = "zones";
	private static final String REQ_RECORDS = "records";
	
	private static Logger logger = Logger.getLogger(SlicehostUtil.class);

	public static boolean recordNameExists(String name) throws FatalException {
		String url = API_URL + REQ_RECORDS + SUFFIX;
		String params = PARAM_ZONE_ID + "=" + REWARDME_COM_ZONE_ID + "&" +  
						PARAM_NAME + "=" + name;
		
		String response = RemoteRequestUtil.get(url, params, API_KEY, null, false);
		if(response.contains("<"+PARAM_NAME+">"+name+"</"+PARAM_NAME+">")) {
			//exists
			return true;
		}
		return false;
	}
	
	public static boolean recordIPExists(String ip) throws FatalException {
		String url = API_URL + REQ_RECORDS + SUFFIX;
		String params = PARAM_ZONE_ID + "=" + REWARDME_COM_ZONE_ID + "&" +  
						PARAM_DATA + "=" + ip;
		
		String response = RemoteRequestUtil.get(url, params, API_KEY, null, false);
		if(response.contains("<"+PARAM_DATA+">"+ip+"</"+PARAM_DATA+">")) {
			//exists
			return true;
		}
		return false;
	}

	public static Map<String, String> getFallbackTrustedIPs() {
		Map<String, String> trustedServers = new HashMap<String, String>();
		
		//add loopback
		trustedServers.put("127.0.0.1", "localhost");
		
		//add mail server
		trustedServers.put("204.232.201.119", "www");
		
		return trustedServers;
	}
	
	public static Map<String, String> getAllTrustedIPs() throws FatalException {
		Map<String, String> trustedServers = new HashMap<String, String>();
		
		//add loopback
		trustedServers.put("127.0.0.1", "localhost");
		
		String url = API_URL + REQ_RECORDS + SUFFIX;
		String params = PARAM_ZONE_ID + "=" + REWARDME_COM_ZONE_ID;
		
		
		String response = null;
		try {
			response = RemoteRequestUtil.get(url, params, API_KEY, null, false);
		}catch(FatalException e) {
			//try once more
			response = RemoteRequestUtil.get(url, params, API_KEY, null, false);
		}
		
    	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    	try {
    		DocumentBuilder db = dbf.newDocumentBuilder();
    		Document dom = db.parse(new ByteArrayInputStream(response.getBytes("UTF-8")));
    		Element documentElement = dom.getDocumentElement();
    		
    		NodeList recordNodeList = documentElement.getElementsByTagName("record");
    		
			if( recordNodeList != null && recordNodeList.getLength() > 0) {
				for(int i = 0; i < recordNodeList.getLength(); i++) {
					Element recordNode = (Element)recordNodeList.item(i);
					
					Element recordTypeNode = (Element)(recordNode.getElementsByTagName("record-type").item(0));
					String recordType = recordTypeNode.getTextContent();
					
					if(recordType.equals("A")) {
						Element nameNode = (Element)(recordNode.getElementsByTagName("name").item(0));
						String name = nameNode.getTextContent();
						
						Element dataNode = (Element)(recordNode.getElementsByTagName("data").item(0));
						String ip = dataNode.getTextContent();					
						
						trustedServers.put(ip, name);
					}
				}
			}

    	} catch(ParserConfigurationException e) {
			logger.error("Parser Config Problem reading Slicehost API xml", e);
		} catch (SAXException e) {
			logger.error("SaxException reading Slicehost API xml", e);
		} catch (IOException e) {
			logger.error("IOException reading Slicehost API xml", e);
		} 		

		return trustedServers;
	}
	
	
	/*
	
	//TODO: Slicehost: API doesn't support this yet
	public static boolean createRecord(String name) throws FatalException {
		
	}
	
	public static boolean removeRecord(String name) throws FatalException {
		
	}*/
}