package com.viralogy.rewardme.util;

import org.apache.commons.httpclient.NameValuePair;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.servlet.GatewayServlet;

public abstract class TwilioUtil {

	private static Logger logger = Logger.getLogger(TwilioUtil.class);


	private static final String ACCOUNT_SID = "ACe068b69835109a6d4b427611f7c4959b";
	private static final String ACCOUNT_AUTH_TOKEN = "f6212cea2f707e21afc00af9fb9066b2";
	private static final String PRODUCTION_ACCOUNT_SMS_NUMBER = "+14157023379";
	private static final String SANDBOX_ACCOUNT_SMS_NUMBER = "+16502620885";

	private static final String API_ENDPOINT = "https://api.twilio.com/2010-04-01/";
	private static final String API_METHOD_GET_SMS_LIST = "Accounts/{AccountSid}/SMS/Messages.json";
	private static final String API_METHOD_SEND_SMS = "Accounts/{AccountSid}/SMS/Messages.json";

	public static final String TWILIO_FROM = "From";
	public static final String TWILIO_TO = "To";
	public static final String TWILIO_BODY = "Body";

	public static final String TWILIO_STATUS_CALLBACK = "StatusCallback";	
	public static final String TWILIO_SMS_STATUS = "SmsStatus";
	public static final String TWILIO_SMS_SID = "SmsSid";	
	
	private static String getUrl(String method) {
		return (API_ENDPOINT + method).replaceAll("\\{AccountSid\\}", ACCOUNT_SID);
	}
	
	public static void getSMSList() throws FatalException, InvalidParameterException {
		
		String response = RemoteRequestUtil.get(getUrl(API_METHOD_GET_SMS_LIST), null, ACCOUNT_SID, ACCOUNT_AUTH_TOKEN, false);
		
		//parse the JSON
		try {
			JSONObject jsonData = new JSONObject(response);
			JSONArray messages = jsonData.getJSONArray("sms_messages");
			for(int i = 0; i < messages.length(); i++) {
				JSONObject message = messages.getJSONObject(i);
				logger.debug("Text message from " + message.getString("from") + ": " + message.getString("body"));
			}
			
		}catch(JSONException e) {
			logger.error("ERROR from Twilio: " + response);
			throw new InvalidParameterException(Constants.Error.GENERAL.TWILIO_API_ERROR,ListUtil.from(e.getMessage()));
		}		
		
	}
		
	public static String sendSMS(String toPhoneNumber, String body) throws FatalException, InvalidParameterException {
		
		String fromPhoneNumber = GatewayServlet.getExternalServerBaseUrl().contains("sandbox") ? SANDBOX_ACCOUNT_SMS_NUMBER : PRODUCTION_ACCOUNT_SMS_NUMBER;
		body = cleanBody(body);
		
		NameValuePair[] parameters = {
			new NameValuePair(TWILIO_FROM, fromPhoneNumber),
			new NameValuePair(TWILIO_TO, toPhoneNumber),
			new NameValuePair(TWILIO_BODY, body),
			new NameValuePair(TWILIO_STATUS_CALLBACK, GatewayServlet.getExternalServerBaseUrl() + "api?method=phone.sendSMSCallback")
		};

		String response = RemoteRequestUtil.post(getUrl(API_METHOD_SEND_SMS), parameters, ACCOUNT_SID, ACCOUNT_AUTH_TOKEN, false);
		
		//parse the JSON
		try {
			JSONObject message = new JSONObject(response);
			
			if(message.getString("status").equals("400")) {
				logger.error("ERROR from Twilio: " + response);
				throw new InvalidParameterException(Constants.Error.GENERAL.TWILIO_API_ERROR,ListUtil.from(message.getString("message")));
			}else {
				logger.debug("Text message sent to " + message.getString("to") + ": " + message.getString("body") + ". Status: " + message.getString("status"));
				return message.getString("sid");				
			}

		}catch(JSONException e) {
			logger.error("ERROR parsing Twilio response: " + response);
			throw new InvalidParameterException(Constants.Error.GENERAL.TWILIO_API_ERROR,ListUtil.from(e.getMessage()));
		}		

	}
	
	private static String cleanBody(String body) {
		return body.replaceAll("\\\\n", "\n");
	}
	
	public static String cleanNumber(String phoneNumber) throws InvalidParameterException {
		if(StringUtil.isNullOrEmpty(phoneNumber)) {
			throw new InvalidParameterException(Constants.Error.PHONE.INVALID_PHONE_NUMBER, ListUtil.from(phoneNumber+""));			
		}
		phoneNumber = phoneNumber.trim().replace("[\\(\\)\\-]", "");
		phoneNumber = (phoneNumber.length()==10 ? "+1" : (phoneNumber.length()==11 ? "+" : "")) + phoneNumber;

		if(phoneNumber.length() != 12) {	//US numbers only
			throw new InvalidParameterException(Constants.Error.PHONE.INVALID_PHONE_NUMBER, ListUtil.from(phoneNumber+""));
		}
		
		return phoneNumber;
	}
	
}
