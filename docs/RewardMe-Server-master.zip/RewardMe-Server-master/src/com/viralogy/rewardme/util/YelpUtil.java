package com.viralogy.rewardme.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.viralogy.rewardme.conf.Constants;
import com.viralogy.rewardme.conf.FatalException;
import com.viralogy.rewardme.conf.InvalidParameterException;
import com.viralogy.rewardme.model.Address;
import com.viralogy.rewardme.model.AddressMetaData;
import com.viralogy.rewardme.model.Customer;
import com.viralogy.rewardme.model.GeoCoord;
import com.viralogy.rewardme.model.AddressMetaData.Provider;

public class YelpUtil {

	private static final String YELP_API_KEY = "G9CI3Tv61HYzjqxKAzaSew";

	private static Logger logger = Logger.getLogger(YelpUtil.class);

	public static AddressMetaData getBusinessInformation(Customer customer, Address address) throws FatalException, InvalidParameterException {
		
		AddressMetaData addressMetaData = null;//Cache.get(address.getAddress(), Cache.namespace.ADDRESS_META_DATA);
		if(addressMetaData == null) {
			addressMetaData = new AddressMetaData(Provider.YELP);
			addressMetaData.setAddressId(address.getAddressId());
			try {
				String requestParams = "term="+URLEncoder.encode(customer.getName(),"UTF-8")+"&radius=1&lat="+address.getGeoCoord().getLatitude()+"&long="+address.getGeoCoord().getLongitude()+"&limit=25&ywsid="+YELP_API_KEY;
				logger.debug("Yelp Request: " + requestParams);
				String response = RemoteRequestUtil.get(
						"http://api.yelp.com/business_review_search", 
						requestParams, false
				);
				logger.debug("Yelp Response length: " + response.length());
	
				JSONObject responseObject = new JSONObject(response);
				int code = responseObject.getJSONObject("message").getInt("code");
				if(code != 0) {
					throw new FatalException("Yelp API Error: " + responseObject.getJSONObject("message") + " | " + response);
				}
				//logger.debug("Yelp Response: " + responseObject);
				
				
				if(responseObject.getJSONArray("businesses") == null || responseObject.getJSONArray("businesses").length() == 0) {
					throw new InvalidParameterException(Constants.Error.GENERAL.YELP_NO_BUSINESS_FOUND_FOR_ADDRESS_AND_NAME, ListUtil.from(customer.getName(), address.getAddress()));
				}

				JSONArray businesses = responseObject.getJSONArray("businesses");
				logger.debug("Found " + businesses.length() + " matches on Yelp");
				for(int i = 0; i < businesses.length(); i++) {

					JSONObject business = responseObject.getJSONArray("businesses").getJSONObject(i);
					
					double latitude = business.getDouble("latitude");
					double longitude = business.getDouble("longitude");
					GeoCoord yelpGeoCoord = new GeoCoord(longitude, latitude);
					double distance = address.getGeoCoord().distanceTo(yelpGeoCoord);
					if(distance > Constants.Distance.METERS_PER_MILE) {
						//more than 1 mile from our target
						logger.debug("Found yelp address but it was " + distance + " meters from the address we passed in");
						continue;
					}
					String[] targetAddressTokens = address.getAddress().toLowerCase().split("[ ,#]");
					String[] yelpAddressTokens = (business.getString("address1").toLowerCase() + " " + business.getString("address2").toLowerCase()).split("[ ,#]");
					boolean match = false;
					for(String token : yelpAddressTokens) {
						if(targetAddressTokens[0].equals(token)) {
							//address numbers match
							
							//confirm any suite numbers match
							String[] yelpAddress2Tokens = (business.getString("address2").toLowerCase() + " " + business.getString("address3").toLowerCase()).split("[ ,#]");
							if(yelpAddress2Tokens.length > 0) {
								for(String targetAddressToken : targetAddressTokens) {
									if(targetAddressToken.equals(yelpAddress2Tokens[yelpAddress2Tokens.length-1])) {
										match = true;
										break;
									}
								}
							}else {
								match = true;
								break;								
							}
						}
					}
					if(!match) {
						logger.debug("Found yelp address but it was at " + business.getString("address1") + " " + business.getString("address2") + " " + business.getString("address3") + " and we wanted something more like " + address.getAddress());
						continue;
					}
					address.setGeoCoord(yelpGeoCoord);
					
					//update the address with even better data (not self-reported like the result from geocode)
					//this will be the addressed stored in the database
					address.setAddress((business.getString("address1") + " " + business.getString("address2") + " " + business.getString("address3")).replace("  ", " ") + " " + 
							business.getString("city") + ", " + business.getString("state") + ", " + business.getString("zip"));
					
					String category = business.getJSONArray("categories").getJSONObject(0).getString("name");
					addressMetaData.setAddressId(address.getAddressId());
					addressMetaData.setProviderId(business.getString("id"));
					addressMetaData.setProviderLink(business.getString("mobile_url"));
					addressMetaData.setName(business.getString("name"));
					addressMetaData.setCategory(category);
					addressMetaData.setRatingUrl(business.getString("rating_img_url_small"));
					addressMetaData.setImageUrl(business.getString("photo_url"));
					addressMetaData.setImageUrlSmall(business.getString("photo_url_small"));
					addressMetaData.setPhoneNumber(business.getString("phone"));
					addressMetaData.setTotalReviews(business.getInt("review_count"));
										
					//Cache.put(addressMetaData, address.getAddress(), Cache.namespace.ADDRESS_META_DATA);
					
					logger.debug("Found match and returning Yelp data with location name: " + addressMetaData.getName());
					return addressMetaData;
				}
				
				logger.debug("No Yelp business info found for address " + address.getAddress());
				throw new InvalidParameterException(Constants.Error.GENERAL.YELP_NO_BUSINESS_FOUND_FOR_ADDRESS_AND_NAME, ListUtil.from(customer.getName(), address.getAddress()));
				
			} catch (JSONException e) {
				throw new FatalException(e);
			} catch (UnsupportedEncodingException e) {
				throw new FatalException(e);
			}
		}else {
			return addressMetaData;
		}
	}
}