export ANT_HOME=/usr/ant
export MAVEN_HOME=/usr/maven
export XDOCLET_HOME=/usr/xdoclet
export JAVA_HOME=/usr/java/jdk1.6.0_18/
export JBOSS_HOME=/usr/jboss
export HADOOP_HOME=/usr/lib/hadoop
export HBASE_HOME=/usr/hbase

export PATH=$PATH:$ANT_HOME/bin:$MAVEN_HOME/bin:$JAVA_HOME/bin:$JBOSS_HOME/bin:$HBASE_HOME/bin

