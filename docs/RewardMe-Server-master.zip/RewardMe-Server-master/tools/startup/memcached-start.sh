memcached -u root -d -m 48
echo "Memcache daemon started"
