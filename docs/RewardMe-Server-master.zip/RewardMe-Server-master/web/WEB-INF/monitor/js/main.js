var HOME="/WEB-INF/monitor/";
var IMAGE_MAP = {
  "Fraiche":"pin_fraiche",
  "MOOYAH":"pin_mooyah",
  "Le Boulanger":"pin_lebou",
  "Quickly":"pin_quickly",
  "Cohiba":"pin_cohiba",
}
var BAY_AREA= new google.maps.LatLng(37.467774,-122.045746);
var TEXAS = new google.maps.LatLng(32.813824,-96.959839);
var DEFAULT_ZOOM = 9;
//From old servlet
var deviceActionsEnabled = true;
var deviceUpdate = function(deviceId, argument) {if(!deviceActionsEnabled || !confirm('Please confirm that you would like to UPDATE this device.')) return; document.getElementById('subscribeServerActionsIFrame').src= '/rewardme/monitor?section=subscribe&subscribeServerAction=deviceUpdate&subscribeServerArgument='+argument+'&deviceId='+deviceId;} 
var deviceDebug = function(deviceId, argument) {if(!deviceActionsEnabled || !confirm('Please confirm that you would like to DEBUG this device.')) return; document.getElementById('subscribeServerActionsIFrame').src= '/rewardme/monitor?section=subscribe&subscribeServerAction=deviceDebug&subscribeServerArgument='+argument+'&deviceId='+deviceId;} 
var deviceShowInitialSetupOptions = function(deviceId, argument) {if(!deviceActionsEnabled || !confirm('Please confirm that you would like to SHOW PRINTER OPTIONS on this device.')) return; document.getElementById('subscribeServerActionsIFrame').src= '/rewardme/monitor?section=subscribe&subscribeServerAction=deviceShowInitialSetupOptions&subscribeServerArgument='+argument+'&deviceId='+deviceId;} 
var deviceReload = function(deviceId, argument) {if(!deviceActionsEnabled || !confirm('Please confirm that you would like to RELOAD this device.')) return; document.getElementById('subscribeServerActionsIFrame').src= '/rewardme/monitor?section=subscribe&subscribeServerAction=deviceReload&subscribeServerArgument='+argument+'&deviceId='+deviceId;}; 
var deviceLink = function(deviceId, argument) {if(!deviceActionsEnabled || !confirm('Please confirm that you would like to SHOW LINK OPTIONS on this device.')) return; document.getElementById('subscribeServerActionsIFrame').src= '/rewardme/monitor?section=subscribe&subscribeServerAction=deviceLink&subscribeServerArgument='+argument+'&deviceId='+deviceId;}; 
var deviceTestRedeem = function(deviceId, argument) {if(!deviceActionsEnabled || !confirm('Please confirm that you would like to TEST A REDEEM on this device.')) return; document.getElementById('subscribeServerActionsIFrame').src= '/rewardme/monitor?section=subscribe&subscribeServerAction=deviceTestRedeem&subscribeServerArgument='+argument+'&deviceId='+deviceId;}; 
var deviceAlert = function(deviceId, argument) {if(!deviceActionsEnabled || !(argument=prompt('What message would you like to display?'))) return; document.getElementById('subscribeServerActionsIFrame').src= '/rewardme/monitor?section=subscribe&subscribeServerAction=deviceAlert&subscribeServerArgument='+escape(argument)+'&deviceId='+deviceId;}; 

var addresses = {};
var devices = {};
var markers = {};
var infoWindows = {};
var initialized = false;
var curDevice = "";

var loadDevice = function(device){
  curDevice = device;
  var d = devices[device];
  var infoPanel = $("#infoPanel");
  infoPanel.html("");
  var info = $("<div id='infoBox'></div>");
  info.append($("<div></div>").html("<strong>Device:</strong> "+d.customer.name+" - "+d.customer.city));
  info.append($("<div></div>").html("<strong>ID:</strong> "+d.customer.application+"("+d.device.deviceId+")"));
  info.append($("<div></div>").html("<strong>Status:</strong> <span class='"+d.status+"'>"+d.status+"</span>"));
  info.append($("<div></div>").html("<strong>Last Checkin:</strong> "+(d.lastCheckin == undefined ? "Never":d.lastCheckin)));
  info.append($("<div></div>").html("<strong>Last Transaction:</strong> "+(d.lastTransaction ==  undefined ? "Never":d.lastTransaction)));
  infoPanel.append(info);
  if (d.status == "online"){
    var actions = $("<div id='actionBox'></div>");
    var buttons = $("<div id='buttonBox'></div>");
    actions.append($("<div></div>").html("Actions"));
    buttons.append("<button class='btn mapButton' onclick='deviceAlert(\""+device+"\")'>Alert</button>");
    buttons.append("<button class='btn mapButton' onclick='deviceDebug(\""+device+"\")'>Debug</button>");
    buttons.append("<button class='btn mapButton' onclick='deviceUpdate(\""+device+"\")'>On-Restart Update</button>");
    buttons.append("<button class='btn mapButton' onclick='deviceUpdate(\""+device+"\", true)'>Immediate Update</button>");
    buttons.append("<button class='btn mapButton' onclick='deviceReload(\""+device+"\")'>Soft Reload</button>");
    buttons.append("<button class='btn mapButton' onclick='deviceReload(\""+device+"\", true)'>Hard Reload</button>");
    buttons.append("<button class='btn mapButton' onclick='deviceLink(\""+device+"\")'>Link</button>");
    buttons.append("<button class='btn mapButton' onclick='deviceTestRedeem(\""+device+"\")'>Test Redeem</button>");
    buttons.append("<button class='btn mapButton' onclick='deviceShowInitialSetupOptions(\""+device+"\")'>Show Setup</button>");
    actions.append(buttons);
    actions.append($("<div class='clearBoth'></div>"));
    infoPanel.append(actions);
  }
}

var initialize = function() {
  var curWindow = null;
  var myOptions = {
    zoom: DEFAULT_ZOOM,
    center:BAY_AREA,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  }
  var map = new google.maps.Map(document.getElementById('mapCanvas'),
      myOptions);

  $("#bayArea").click(function(){
    map.panTo(BAY_AREA);
    map.setZoom(DEFAULT_ZOOM);
  });
  $("#texas").click(function(){
    map.panTo(TEXAS);
    map.setZoom(DEFAULT_ZOOM);
  });

  var setUpMap = function(plac, p){
    icon = new google.maps.MarkerImage(HOME+"img/home.png");
    offset = new google.maps.Point(20,85);
    stats = "";
    for (var i in p){
      if ((stats == "" || stats == "red") && p[i].status=="offline"){
        stats = "red";
      } else if (stats == "red"){
        stats = "yellow";
        break;
      } else if (p[i].status == "online"){
        stats = "green";
      }
    }
    var shape = new google.maps.Marker().getShape();
    if (IMAGE_MAP[plac.customer.name]) {
      icon = new google.maps.MarkerImage(HOME+"img/"+IMAGE_MAP[plac.customer.name]+"-"+stats+".png", null, null,offset );
      shape = {
        coord:[0,35,40,85],
        type:"rect"
      }
    }
    if (!initialized){
      var pos = new google.maps.LatLng(plac.latitude, plac.longitude);
      var marker = new google.maps.Marker({title:plac.address,map:map,position:pos});
      marker.setClickable(true);
      markers[plac.address]=marker;
      var infoOptions = {
        boxStyle:{
                   "padding":"2px",
                   "background-color": "#292b2d",
                   "opacity": 0.9,
                   "border-style": "solid 1px",
                   "border-color": "#fbfbfb",
                   "color": "#ffffff",
                 }
      }
      var infoWindow = new InfoBox(infoOptions);
      google.maps.event.addListener(marker,'click',function() {
        infoWindow.open(map,marker);
        if (curWindow != null){
          if (curWindow != infoWindow) {
            curWindow.close();
            curWindow = infoWindow;
          }
        } else {
          curWindow = infoWindow;
        }
      });
      infoWindows[plac.address] = infoWindow;
    } else {
      var pos = new google.maps.LatLng(plac.latitude, plac.longitude);
      var marker = markers[plac.address];
      var infoWindow = infoWindows[plac.address];
    }
    var div = $("<div></div>");
    div.html("");
    div.append($("<div class='address'></div>").html(plac.address));
    console.log(p);
    for (var i in p){
      var pi = p[i];
      var temp = $("<div id='"+pi.device.deviceId+"' class='device "+pi.status+"' onclick='loadDevice(\""+pi.device.deviceId+"\")'></div>");
      div.append(temp.html(pi.device.deviceId));
    }
    infoWindow.setContent(div.html());
    marker.setIcon(icon);
    marker.setShape(shape);
  }
  var processResponse = function(obj){
    //repopulates addresses and devices
    addresses = {};
    devices = {};

    for (var i in obj){
      devices[obj[i].device.deviceId] = obj[i];
      var address = obj[i].addressId;
      if (addresses[address] === undefined) {
        addresses[address] = []; 
      }
      addresses[address].push(obj[i]); 
    }
    for (var p in addresses) {
      (function(address){
        var place = address[0];
        if (place.latitude && place.longitude) {
          setUpMap(place,address);
        } else {
          var geocoder = new google.maps.Geocoder();
          geocoder.geocode({address:plac.address},function(result){
            result = result[0];
            place.latitude = result.geometry.location["$a"];
            place.longitude = result.geometry.location["ab"];
            setUpMap(place,address);
          });
        }
      })(addresses[p]);
    }
    initialized = true;
    if (curDevice != ""){
      loadDevice(curDevice);
    }
  };
  var poll = function(){
    $.ajax({url:"/rewardme/devices",success:function(obj){
      processResponse(obj);
      setTimeout(poll,parseInt($("#refresh").val()));

    },dataType:"jsonp",timeout:30000});
  }
  poll();
}
google.maps.event.addDomListener(window, 'load', initialize);
